from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


# ============================================================
# STATE
# ============================================================

class ContractDraftState(BaseModel):
    # --- Contract Type (toggle — one true at a time) ---
    contract_type: Dict[str, bool] = Field(default_factory=dict)

    # --- Document Upload (required — scope of work / proposal) ---
    document_upload: Dict[str, Any] = Field(default_factory=dict)

    # --- Supporting Document (optional) ---
    supporting_document: Dict[str, Any] = Field(default_factory=dict)

    # --- Identifiers ---
    prid: str = ""
    flex_id: str = ""

    # --- Template (optional) ---
    template: Dict[str, Any] = Field(default_factory=dict)

    # --- Icertis Lookup ---
    lookup_in_icertis: bool = False

    # --- Document Extraction & Validation ---
    document_text: str = ""
    extracted_fields: Dict[str, Any] = Field(default_factory=dict)
    missing_fields: List[Dict[str, Any]] = Field(default_factory=list)
    validation_passed: bool = False

    # --- Draft Output ---
    draft_content: str = ""

    # --- Final Response ---
    final_response: Optional[Dict[str, Any]] = None

    class Config:
        extra = "forbid"
