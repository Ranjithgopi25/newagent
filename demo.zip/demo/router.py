import json
import os
import logging
from typing import Dict, Any, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .graph import run_contract_draft_graph, resume_contract_draft_graph

logger = logging.getLogger(__name__)

router = APIRouter()

FIELD_MAPPING_PATH = os.path.join(os.path.dirname(__file__), "field_mapping.json")


def _load_field_mapping() -> dict:
    with open(FIELD_MAPPING_PATH, "r") as f:
        return json.load(f)


# ============================================================
# GET /field-mapping/{contract_type}
# ============================================================

@router.get("/field-mapping/{contract_type}")
async def get_field_mapping(contract_type: str):
    """Return field definitions for a given contract type."""
    data = _load_field_mapping()

    mapping_contract_type = data.get("contract_type", "")
    if mapping_contract_type.upper() != contract_type.upper():
        raise HTTPException(
            status_code=404,
            detail=f"No field mapping found for contract type: {contract_type}",
        )

    field_definitions = data.get("field_definitions", [])

    required_fields = [f for f in field_definitions if f.get("required")]
    optional_fields = [f for f in field_definitions if not f.get("required")]

    return {
        "contract_type": contract_type.upper(),
        "total_fields": len(field_definitions),
        "required_count": len(required_fields),
        "optional_count": len(optional_fields),
        "field_definitions": field_definitions,
    }


# ============================================================
# POST /draft — Step 1: Extract, validate, generate (if valid)
# ============================================================

class DraftContractRequest(BaseModel):
    contract_type: Dict[str, bool]
    document_upload: Dict[str, Any]
    supporting_document: Optional[Dict[str, Any]] = Field(default_factory=dict)
    prid: str
    flex_id: str
    template: Optional[Dict[str, Any]] = Field(default_factory=dict)
    lookup_in_icertis: bool = False


@router.post("/draft")
async def draft_contract(request: DraftContractRequest):
    """Step 1: Upload document → extract fields → validate → generate draft (or return missing fields)."""
    result = await run_contract_draft_graph(request.model_dump())
    return result


# ============================================================
# POST /draft/resume — Step 2: User fills missing fields, resume draft generation
# ============================================================

class ResumeDraftRequest(BaseModel):
    contract_type: Dict[str, bool]
    prid: str
    flex_id: str
    extracted_fields: Dict[str, Any]
    user_filled_fields: Dict[str, Any]


@router.post("/draft/resume")
async def resume_draft_contract(request: ResumeDraftRequest):
    """Step 2: User provides missing field values → re-validate → generate draft."""
    result = await resume_contract_draft_graph(request.model_dump())
    return result
