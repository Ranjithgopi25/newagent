"""
Semantic Retriever for Perplexity-style citation system
Uses vector embeddings + BM25 hybrid search for relevant source retrieval
"""

import logging
from typing import List, Dict, Optional, Tuple
import re
from collections import defaultdict

logger = logging.getLogger(__name__)

# Optional semantic search dependencies
DEPENDENCIES_AVAILABLE = False
np = None

try:
    import numpy as np  # type: ignore
    from sentence_transformers import SentenceTransformer
    from rank_bm25 import BM25Okapi
    import chromadb
    from chromadb.config import Settings

    DEPENDENCIES_AVAILABLE = True
except ImportError as e:
    logger.warning(
        "Semantic search dependencies not available. "
        "Install optional ML packages to enable semantic features. "
        f"Details: {e}"
    )
    DEPENDENCIES_AVAILABLE = False
    np = None


class SemanticRetriever:
    """
    Hybrid semantic + keyword search retriever for research sources.
    Combines vector embeddings (semantic) with BM25 (keyword) for best results.
    """

    def __init__(self, embedding_model: str = "all-MiniLM-L6-v2"):
        """
        Initialize the semantic retriever.

        Args:
            embedding_model: Sentence transformer model name (default: lightweight all-MiniLM-L6-v2)
        """
        if not DEPENDENCIES_AVAILABLE:
            raise ImportError(
                "Semantic search dependencies not installed. "
                "Install with: pip install sentence-transformers chromadb rank-bm25 numpy"
            )

        self.embedding_model_name = embedding_model
        self.embedder = None
        self.chroma_client = None
        self.collection = None
        self.bm25_index = None
        self.documents = []
        self.tokenized_docs = []
        self.source_metadata = {}

        # Initialize embedding model (lazy loading)
        self._initialize_embedder()

        # Initialize ChromaDB (in-memory for now, can be persisted)
        self._initialize_vector_db()

    def _initialize_embedder(self):
        """Initialize the sentence transformer model"""
        try:
            logger.info(f"Loading embedding model: {self.embedding_model_name}")
            self.embedder = SentenceTransformer(self.embedding_model_name)
            logger.info("Embedding model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            raise

    def _initialize_vector_db(self):
        """Initialize ChromaDB vector database"""
        try:
            # Use in-memory database (can be changed to persistent)
            self.chroma_client = chromadb.Client(
                Settings(anonymized_telemetry=False, allow_reset=True)
            )
            logger.info("ChromaDB initialized")
        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB: {e}")
            raise

    def _chunk_text(
        self, text: str, chunk_size: int = 800, overlap: int = 100
    ) -> List[str]:
        """
        Split text into overlapping chunks for better retrieval.

        Args:
            text: Text to chunk
            chunk_size: Target size of each chunk (characters)
            overlap: Number of characters to overlap between chunks

        Returns:
            List of text chunks
        """
        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0

        while start < len(text):
            end = start + chunk_size

            # Try to break at sentence boundary
            if end < len(text):
                # Look for sentence endings
                sentence_endings = [". ", ".\n", "! ", "?\n", "?\n"]
                for ending in sentence_endings:
                    last_ending = text.rfind(ending, start, end)
                    if last_ending != -1:
                        end = last_ending + len(ending)
                        break

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)

            # Move start with overlap
            start = end - overlap
            if start >= len(text):
                break

        return chunks

    def _tokenize(self, text: str) -> List[str]:
        """Simple tokenization for BM25"""
        # Convert to lowercase and split on whitespace/punctuation
        text = text.lower()
        # Remove special characters but keep alphanumeric
        tokens = re.findall(r"\b\w+\b", text)
        return tokens

    async def index_sources(self, sources: List[Dict]) -> None:
        """
        Index sources with both vector embeddings and BM25.

        Args:
            sources: List of source dictionaries with keys:
                - citation_number: int
                - name: str
                - url: str
                - title: str
                - content: str
        """
        if not sources:
            logger.warning("No sources provided for indexing")
            return

        logger.info(f"Indexing {len(sources)} sources...")

        # Reset collections
        try:
            self.chroma_client.delete_collection("research_sources")
        except:
            pass

        self.collection = self.chroma_client.create_collection(
            name="research_sources",
            metadata={"description": "Research source embeddings"},
        )

        # Prepare data structures
        all_chunks = []
        all_metadatas = []
        all_ids = []
        self.documents = []
        self.tokenized_docs = []
        self.source_metadata = {}

        # Process each source
        for source in sources:
            citation_num = source.get("citation_number")
            content = source.get("content", "")

            if not content:
                continue

            # Store source metadata
            self.source_metadata[citation_num] = {
                "name": source.get("name", ""),
                "url": source.get("url", ""),
                "title": source.get("title", ""),
                "citation_number": citation_num,
            }

            # Chunk the content
            chunks = self._chunk_text(content, chunk_size=800, overlap=100)

            # Add chunks to vector DB
            for i, chunk in enumerate(chunks):
                chunk_id = f"source_{citation_num}_chunk_{i}"
                all_chunks.append(chunk)
                all_metadatas.append(
                    {
                        "citation_number": citation_num,
                        "url": source.get("url", ""),
                        "title": source.get("title", ""),
                        "source_name": source.get("name", ""),
                        "chunk_index": i,
                    }
                )
                all_ids.append(chunk_id)

            # For BM25, use full document
            self.documents.append(content)
            self.tokenized_docs.append(self._tokenize(content))

        # Generate embeddings
        logger.info(f"Generating embeddings for {len(all_chunks)} chunks...")
        try:
            embeddings = self.embedder.encode(
                all_chunks, show_progress_bar=False
            ).tolist()
        except Exception as e:
            logger.error(f"Failed to generate embeddings: {e}")
            raise

        # Store in ChromaDB
        try:
            self.collection.add(
                embeddings=embeddings,
                documents=all_chunks,
                metadatas=all_metadatas,
                ids=all_ids,
            )
            logger.info(f"Indexed {len(all_chunks)} chunks in vector database")
        except Exception as e:
            logger.error(f"Failed to add to ChromaDB: {e}")
            raise

        # Build BM25 index
        if self.tokenized_docs:
            self.bm25_index = BM25Okapi(self.tokenized_docs)
            logger.info("BM25 index built successfully")

    async def retrieve(
        self,
        query: str,
        top_k: int = 5,
        semantic_weight: float = 0.7,
        bm25_weight: float = 0.3,
    ) -> List[Dict]:
        """
        Retrieve relevant chunks using hybrid semantic + BM25 search.

        Args:
            query: Search query
            top_k: Number of results to return
            semantic_weight: Weight for semantic search (0-1)
            bm25_weight: Weight for BM25 search (0-1)

        Returns:
            List of relevant chunks with metadata and scores
        """
        if not self.collection or not self.bm25_index:
            logger.warning("Sources not indexed yet. Returning empty results.")
            return []

        results = []

        # Semantic search
        try:
            query_embedding = self.embedder.encode(
                [query], show_progress_bar=False
            ).tolist()[0]

            semantic_results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=min(top_k * 3, 20),  # Get more candidates for reranking
            )

            # Extract semantic results
            semantic_scores = {}
            if semantic_results["ids"] and len(semantic_results["ids"][0]) > 0:
                for i, doc_id in enumerate(semantic_results["ids"][0]):
                    # ChromaDB returns distances (lower is better), convert to scores
                    distance = (
                        semantic_results["distances"][0][i]
                        if semantic_results["distances"]
                        else 1.0
                    )
                    score = 1.0 / (
                        1.0 + distance
                    )  # Convert distance to similarity score
                    semantic_scores[doc_id] = score
        except Exception as e:
            logger.error(f"Semantic search failed: {e}")
            semantic_scores = {}

        # BM25 search - score each chunk based on its parent document
        try:
            tokenized_query = self._tokenize(query)
            bm25_scores_list = self.bm25_index.get_scores(tokenized_query)

            # Map document scores to chunks
            bm25_scores = {}
            doc_idx = 0

            # Get all chunk IDs from semantic results or collection
            all_chunk_ids = set()
            if semantic_scores:
                all_chunk_ids = set(semantic_scores.keys())
            else:
                # If no semantic results, get all chunks from collection
                try:
                    all_data = self.collection.get()
                    all_chunk_ids = (
                        set(all_data["ids"]) if all_data.get("ids") else set()
                    )
                except:
                    pass

            # Map each chunk to its source document
            chunk_to_doc_idx = {}
            for chunk_id in all_chunk_ids:
                match = re.match(r"source_(\d+)_chunk_(\d+)", chunk_id)
                if match:
                    source_num = int(match.group(1))
                    # Find which document index this source corresponds to
                    source_list = list(self.source_metadata.keys())
                    if source_num in source_list:
                        doc_idx_for_source = source_list.index(source_num)
                        chunk_to_doc_idx[chunk_id] = doc_idx_for_source

            # Assign BM25 scores to chunks
            for chunk_id, doc_idx_for_chunk in chunk_to_doc_idx.items():
                if doc_idx_for_chunk < len(bm25_scores_list):
                    score = bm25_scores_list[doc_idx_for_chunk]
                    # Normalize BM25 score (typically 0-10 range, sometimes higher)
                    normalized_score = min(score / 10.0, 1.0)
                    bm25_scores[chunk_id] = normalized_score
        except Exception as e:
            logger.error(f"BM25 search failed: {e}")
            bm25_scores = {}

        # Combine scores
        combined_scores = defaultdict(float)
        all_chunk_ids = set(semantic_scores.keys()) | set(bm25_scores.keys())

        for chunk_id in all_chunk_ids:
            semantic_score = semantic_scores.get(chunk_id, 0.0)
            bm25_score = bm25_scores.get(chunk_id, 0.0)

            # Weighted combination
            combined_score = (semantic_weight * semantic_score) + (
                bm25_weight * bm25_score
            )
            combined_scores[chunk_id] = combined_score

        # Get top-k chunks
        sorted_chunks = sorted(
            combined_scores.items(), key=lambda x: x[1], reverse=True
        )[:top_k]

        # Build result list
        for chunk_id, score in sorted_chunks:
            # Extract source number from chunk_id
            match = re.match(r"source_(\d+)_chunk_(\d+)", chunk_id)
            if not match:
                continue

            source_num = int(match.group(1))
            chunk_idx = int(match.group(2))

            # Get chunk content and metadata from ChromaDB
            try:
                chunk_data = self.collection.get(ids=[chunk_id])
                if chunk_data["documents"]:
                    results.append(
                        {
                            "document": chunk_data["documents"][0],
                            "metadata": chunk_data["metadatas"][0],
                            "score": score,
                            "citation_number": source_num,
                        }
                    )
            except Exception as e:
                logger.warning(f"Failed to retrieve chunk {chunk_id}: {e}")
                continue

        logger.info(
            f"Retrieved {len(results)} relevant chunks for query: {query[:50]}..."
        )
        return results

    def get_source_metadata(self, citation_number: int) -> Optional[Dict]:
        """Get metadata for a specific source by citation number"""
        return self.source_metadata.get(citation_number)

    def reset(self):
        """Reset the retriever (clear all indexes)"""
        try:
            if self.chroma_client:
                self.chroma_client.delete_collection("research_sources")
            self.collection = None
            self.bm25_index = None
            self.documents = []
            self.tokenized_docs = []
            self.source_metadata = {}
            logger.info("Retriever reset successfully")
        except Exception as e:
            logger.warning(f"Error resetting retriever: {e}")
