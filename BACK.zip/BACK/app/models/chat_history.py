"""
SQLAlchemy models for chat history and user management.
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, DateTime, ForeignKey, Text, CheckConstraint
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

Base = declarative_base()


class User(Base):
    """
    User model representing application users.
    Maps to public.users table (PostgreSQL format in schema, but using SQL Server).
    """
    __tablename__ = "Users"
    __table_args__ = {'schema': 'dbo'}
    
    id = Column(UNIQUEIDENTIFIER, primary_key=True, server_default=func.newid())
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(150), unique=True, nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=func.sysdatetimeoffset())
    updated_at = Column(DateTime(timezone=True), nullable=False, server_default=func.sysdatetimeoffset(), onupdate=func.sysdatetimeoffset())
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationship to chat history
    chat_histories = relationship("ChatHistory", back_populates="user", foreign_keys="ChatHistory.user_id")
    
    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, email={self.email})>"


class ChatHistory(Base):
    """
    Chat history model for storing conversation sessions.
    One record = one complete conversation session.
    Maps to dbo.chat_history table.
    """
    __tablename__ = "chat_history"
    __table_args__ = (
        CheckConstraint(
            "source IN ('DDDC', 'Market_Intelligence', 'Thought_Leadership', 'Export', 'Chat')",
            name="CHK_chat_history_source"
        ),
        {'schema': 'dbo'}
    )
    
    session_id = Column(String(50), primary_key=True)  # Unique session identifier
    user_id = Column(UNIQUEIDENTIFIER, ForeignKey('dbo.Users.id'), nullable=False, index=True)
    source = Column(String(50), nullable=False, default='Chat')
    title = Column(String(255), nullable=True)  # Session title (e.g., first user message)
    conversation = Column(Text, nullable=False)  # Stores JSON array of all messages
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=func.sysdatetimeoffset())
    updated_at = Column(DateTime(timezone=True), nullable=False, server_default=func.sysdatetimeoffset(), onupdate=func.sysdatetimeoffset())
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationship to user
    user = relationship("User", back_populates="chat_histories", foreign_keys=[user_id])
    
    def __repr__(self):
        return f"<ChatHistory(session_id={self.session_id}, user={self.user_id}, source={self.source})>"
