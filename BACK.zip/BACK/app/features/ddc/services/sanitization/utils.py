from app.infrastructure.llm.base_services import BasePPTWorkflowService
from app.features.ddc.services.sanitization.graph import TEXT_LLM, VISION_LLM, ppt_graph
from tempfile import NamedTemporaryFile
from typing import List, Dict, Any, Optional
from datetime import datetime
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


def map_services_to_options(selected_services: List[str]) -> Dict[str, Any]:
    """Map frontend service IDs to LangGraph sanitizer options."""

    options = {
        "numeric_data": False,
        "personal_info": False,
        "financial_data": False,
        "locations": False,
        "identifiers": False,
        "names": False,
        "logos": False,
        "metadata": False,
        "hyperlinks": False,
        "business_units": False,
        # "embedded_objects": False,
        "competitor": False,
        # "convert_charts_to_images": False,
    }

    service_mapping = {
        "replace_client": ["names", "logos"],
        "delete_notes": ["metadata"],
        "cut_hyperlinks": ["hyperlinks"],
        "mask_leadership": ["names", "personal_info"],
        "change_competitors": ["competitor", "logos"],
        "remove_data": ["numeric_data", "financial_data", "identifiers"],
        "conceal_regions": ["locations"],
        "disguise_bus": ["business_units"],
    }

    for service_id in selected_services:
        for option in service_mapping.get(service_id, []):
            options[option] = True

    logger.info(f"[ServiceMapper] Options resolved: {options}")
    return options


class SanitizationService(BasePPTWorkflowService):
    """Service for Presentation Sanitization workflow (LangGraph-native)."""
    async def sanitize_presentation(
        self,
        ppt_bytes: bytes,
        filename: str,
        selected_services: List[str],
        client_identifiers: str,
        template: str = "core",
        template_bytes: Optional[bytes] = None,
        llm_service=None,
        additional_guidelines: Optional[str] = None,
    ) -> tuple[bytes, dict]:

        logger.info(
            f"[Sanitization] Processing {filename} with {len(selected_services)} services"
        )

        options = map_services_to_options(selected_services)

        # Write input PPT
        with NamedTemporaryFile(delete=False, suffix=".pptx") as tmp_input:
            tmp_input.write(ppt_bytes)
            input_path = tmp_input.name

        # Output PPT path
        with NamedTemporaryFile(delete=False, suffix=".pptx") as tmp_output:
            output_path = tmp_output.name

        # LangGraph state 
        initial_state: Dict[str, Any] = {
            "input_path": input_path,
            "output_path": output_path,
            "options": options,
            "stats": defaultdict(int),
            
            # NEW: optional hints
            "client_identifiers": client_identifiers,
            "additional_guidelines": additional_guidelines,
        }

        # Execute LangGraph
        for event in ppt_graph.stream(initial_state):
            node_name, state = next(iter(event.items()))

            if state.get("progress_current") is not None:
                logger.info(
                    f"[SanitizationProgress] "
                    f"{state['progress_current']}/{state.get('progress_total', '?')} "
                    f"({node_name})"
                )

        # Read sanitized PPT
        with open(output_path, "rb") as f:
            sanitized_bytes = f.read()

        stats = dict(initial_state["stats"])

        # Log node durations (if populated by nodes)
        for k, v in stats.items():
            if k.endswith("_duration_sec"):
                logger.info(f"[NodeTiming] {k.replace('_duration_sec','')}: {v}s")

        plan = self._build_sanitization_plan(selected_services, stats, template)

        logger.info(
            f"[Sanitization] Complete. "
            f"Processed {stats.get('slides_processed', 0)} slides"
        )

        return sanitized_bytes, plan
    

    def _build_sanitization_plan(self, selected_services: List[str], stats: dict, template: str = "core") -> dict:
        """Build a clean line-by-line sanitization plan."""
        
        service_labels = {
            # "convert_template": "Convert to PwC Standard Template",
            "replace_client": "Replace Client Names and Logos",
            "delete_notes": "Delete Notes/Comments",
            "cut_hyperlinks": "Cut Hyperlinks",
            "mask_leadership": "Mask Leadership/Employee Names",
            "change_competitors": "Change Competitor Names/Logos",
            "remove_data": "Remove Client-specific Data",
            "conceal_regions": "Conceal Client-identifying Regions",
            "disguise_bus": "Disguise Business Units"
        }
        
        # Services not yet implemented - exclude from plan
        placeholder_services = {"convert_template", "crop_thumbnails", "paste_as_pictures"}
        
        plan_items = []
        
        for service_id in selected_services:
            # Skip placeholder services from the plan display
            if service_id in placeholder_services:
                logger.info(f"[SanitizationPlan] Skipping placeholder service: {service_id}")
                continue
                
            label = service_labels.get(service_id, service_id)
            details = self._get_service_details(service_id, stats, template)
            
            plan_items.append({
                "service_id": service_id,
                "label": label,
                "status": "completed",
                "details": details
            })
        
        return {
            "items": plan_items,
            "summary": {
                "slides_processed": stats.get("slides_processed", 0),
                "total_changes": (
                    stats.get("client_name_replacements", 0) +
                    stats.get("logos_removed", 0)+
                    stats.get("notes_removed", 0) +
                    stats.get("comments_removed", 0) +
                    stats.get("hyperlinks_removed", 0) +
                    stats.get("person_names_removed", 0) +
                    stats.get("competitor_sanitized", 0) +
                    stats.get("numeric_data_redacted", 0) +
                    stats.get("locations_redacted", 0) +
                    stats.get("business_units", 0) 
                    
                )
            }
        }
    
    def _get_service_details(self, service_id: str, stats: dict, template: str = "core") -> str:
        """Get details for a specific service based on stats."""
        
        details_map = {
            "replace_client": f"{stats.get('client_name_replacements', 0)} references replaced, {stats.get('logos_removed', 0)} logos removed",
            "delete_notes": f"{stats.get('notes_removed', 0)} slide notes removed, {stats.get('comments_removed', 0)} comments removed",
            "cut_hyperlinks": f"{stats.get('hyperlinks_removed', 0)} hyperlinks removed",
            "mask_leadership": f"{stats.get('person_names_removed', 0)} person names masked",
            "change_competitors": f"{stats.get('competitor_sanitized', 0)} competitor references changed",
            "remove_data": f"{stats.get('numeric_data_redacted', 0)} numeric values sanitized",
            "conceal_regions": f"{stats.get('locations_redacted', 0)} locations redacted",
            "disguise_bus": f"{stats.get('business_units', 0)} business units disguised",
            # "convert_template": f"Converted to {template.capitalize()} template"
        }
        
        return details_map.get(service_id, "Applied successfully")
    
    def execute(self, *args, **kwargs):
        """Execute sanitization"""
        return self.sanitize_presentation(*args, **kwargs)

