prompt = """You are an information extraction assistant.
TASK:
From the provided PowerPoint content, extract:
1) The PwC client organization name(s)
2) Competitor organization name(s)

DEFINITIONS:
- "Client" refers ONLY to the organization for whom the deck is prepared and marked as confidential
  (e.g., “Confidential Information for the sole benefit and use of PwC’s Client”, internal financials,
  internal interviews, references to the client’s offices or employees).
- "Competitors" are other companies explicitly mentioned in the PPT that operate in the same industry
  and business model as the client.

CLIENT IDENTIFICATION RULES (STRICT):
- Identify a company as a client ONLY if it is explicitly indicated as PwC’s client or the owner of
  internal data (e.g., “client offices”, “client financials”, “internal client interviews”).
- Do NOT classify companies as clients based on:
  - Case studies
  - Benchmarks
  - Market analysis
  - Revenue or market-share analysis
  - Peer comparisons
- Companies appearing in sections titled or framed as “Case Study”, “Market participant”,
  “Benchmark”, or similar are NOT clients unless explicitly stated otherwise.
COMPETITOR IDENTIFICATION RULES (STRICT):
- Extract ONLY companies that are explicitly described in the PPT as
  directly competing with the identified client.
- A company qualifies as a competitor ONLY if the PPT explicitly indicates
  competition with the client through one or more of the following:
  - Stated market share comparisons involving the client
  - Statements that the company won or lost work relative to the client
  - Statements that the company dominates, competes in, or takes share
    from the same client-specific market or subsegment
- Do NOT treat a company as a competitor solely because it:
  - Operates in the same industry
  - Appears in market composition charts without client comparison
  - Is a general market participant or peer
  - Is a construction-only firm unless explicitly stated as competing
    with the client
- Do NOT infer competitive relationships.
- Extract competitors ONLY when competition with the client is explicitly stated.

GLOBAL RULES:
- Do NOT hallucinate relationships or roles.
- Deduplicate all names.
- EXPLICIT EXCLUSIONS:
  - Do NOT extract “PwC”, “PricewaterhouseCoopers”, “Strategy&”, or any PwC brand variants.
  - Treat PwC as internal, never as a client or competitor.

OUTPUT FORMAT (JSON ONLY):
{
  "client_names": ["Client A"],
  "competitor_names": ["Competitor X", "Competitor Y"]
}
"""


# prompt= """COMPETITOR IDENTIFICATION RULES:
# - Extract ONLY competitors that are explicitly mentioned in the PPT.
# - Competitors must directly compete with the client in the same industry and business model.
# - Do NOT infer competitors or add companies not present in the PPT.
# - Do NOT include the client itself as a competitor.

# You are an information extraction assistant.
#                 TASK:
#                 From the PowerPoint content, extract:
#                 - Client organization names
#                 - Competitor organization names
#                 CLIENT IDENTIFICATION RULE:
#                     - Treat as a client ONLY the organization that is explicitly referenced as:
#                         • “PwC’s Client”
#                         • The owner of internal financials, interviews, or offices referenced as “our” or “client’s”
#                     - Companies described under “Case Study”, “Benchmark”, “Market participant”, or “Competitor” headings are NOT clients.


#                 List only unique competitor companies that 
#                     (1) directly compete with the listed clients,
#                     (2) operate in the same industry and business model, and 
#                     (3) are explicitly mentioned in the provided PPT context. Do not include clients, inferred competitors, or companies not present in the PPT.

#                 RULES:
#                 - Detect client names by **understanding the context in the PowerPoint content**.
#                 - Detect competitor names by **understanding the context in the PowerPoint content**.
#                 - Do NOT hallucinate or assume relationships that are not stated in the content.
#                 - Deduplicate values.
#                 - EXPLICIT EXCLUSIONS:
#                 - Do NOT extract "PwC", "PricewaterhouseCoopers", or any PwC brand variants.
#                 - Treat PwC as an internal/allowed name, not a competitor or client.

#                 OUTPUT FORMAT:
#                 {
#                 "client_names": ["Client A", "Client B"],
#                 "competitor_names": ["Competitor X", "Competitor Y"],
#                 }
#                  """


# MASK_CLIENT_PROMPT = """
# You are a data sanitization expert.

# CONTEXT:
# - PwC is performing the sanitization.
# - PwC is NOT a client and must NEVER be masked.

# Input:
# A JSON array of text blocks from a PowerPoint presentation.

# TASK:
# Detect and mask the PRIMARY CLIENT ORGANIZATION NAME only.
# Replace the detected client organization name with "[CLIENT]".

# MASKING RULES (ABSOLUTE):
# - Mask ONLY actual client/company names (e.g Spire, S&B)
# - Mask ONLY when the name clearly refers to a client organization
# - Replace exact organization names (case-insensitive, full match)
# - If uncertain, make NO changes

# DO NOT MASK:
# - PwC
# - Deloitte, EY, KPMG, BCG, McKinsey or similar firms
# - Software or platform names (Windows, SAP, Oracle, etc.)
# - Consumer or packaged goods brands unless explicitly stated as a client
# - Product names, tools, or technologies
# - Person names
# - Locations
# - Emails, phone numbers, URLs
# - Dates, IDs, percentages
# - Generic terms (IT, HR, Finance)
# - Already masked placeholders ([Client], [Product], [BU], etc.)

# PROGRAM / PROJECT RULE:
# - Mask client names in proper nouns such as:
#   "ABC Transformation Program" → "[Client] Transformation Program"
# - Do NOT mask generic uses of "program" or "project"

# DISAMBIGUATION RULE:
# - If a name could be a product, brand, or technology, do NOT mask it
#   unless the text explicitly states it is a client
#   (e.g., "our client ABC").

# TECHNICAL RULES (ABSOLUTE):
# - ONLY modify the "text" field
# - Do NOT add, remove, or reorder array items
# - Do NOT rephrase sentences
# - Preserve formatting, spacing, and punctuation
# - Return VALID JSON ONLY
# """


MASK_PERSON_PROMPT ="""
TASK: Mask client-related and personal information.

ABSOLUTE RULES:
- Replace ONLY the sensitive values, NOT labels, headings, or descriptors
- Preserve formatting, spacing, punctuation, casing, and line breaks exactly
- Do NOT invent or infer missing information
- Do NOT modify PwC, dates, percentages, industry terms, or generic words
- Do NOT modify already-sanitized placeholders
- Return ONLY the sanitized text, no explanations or comments

STRICT REMOVALS:
- Remove all occurrences of 'Booz & Company' completely (no placeholder)

PLACEHOLDER MAPPINGS (AUTHORITATIVE):

COMPANY & CLIENT STRUCTURE:
- Client IDs (e.g., MS-REF-####) → [CLIENT ID] (do NOT replace descriptor words like 'client reference')
- Multiple client companies → [CLIENT LIST]
- Client parent companies → [CLIENT PARENT]
- Client affiliates or subsidiaries → [CLIENT SUBSIDIARY]

CLIENT INTERNAL STRUCTURE:
- Client departments → [CLIENT DEPARTMENT]
- Client descriptions or classifications (project/program labels) → [CLIENT DESCRIPTION]
- Client programs → [CLIENT PROGRAM]
- Client projects → [CLIENT PROJECT]
- Client systems, tools, portals, or networks → [CLIENT SYSTEM]
- Client trust names → [CLIENT TRUST]
- Client fund names → [CLIENT FUND]

PEOPLE & ROLES:
- Client employee names → [CLIENT EMPLOYEE]
- Names in organizational structures, reporting lines, or leadership roles → [CLIENT EMPLOYEE]
- Client reference contacts → [CONTACT]
- Titles/designations appearing immediately before or after client employee names → [TITLE]
- Client Employee or Client Reference Title/Designation in conjunction with Client Employee Name → [TITLE]
- Individual names not tied to the client → [NAME]

CONTACT DETAILS:
- Client or client-reference email addresses → [EMAIL]
- Client or client-reference phone numbers → [PHONE]

DIGITAL PRESENCE:
- Client websites or portals → [CLIENT WEBSITE]

OTHER:
- Client slogans or marketing taglines → [CLIENT SLOGAN]
- Client suppliers, vendors, or third-party service providers → [VENDOR]

IMPORTANT DISAMBIGUATION:
- Use context, labels, and sentence meaning to choose the correct placeholder
- Do NOT replace generic descriptors like 'project','client department', 'project name'
- Preserve formatting, spacing, and punctuation
- Return only JSON array of sanitized blocks
- Only modify the "text" field
"""

MASK_COMPETITOR_PROMPT ="""TASK:Mask competitor-related entities in the content, including their short forms or abbreviations.

WHAT TO MASK:
- Client competitor company names (full name or short form) → [COMPETITOR]
- Products or services of competitors (e.g., Lays, Pepsi, Doritos, Windows) → [PRODUCT]
- Auditor / consulting firm names that are competitors of PwC (full name or abbreviation)
  e.g., Deloitte, Deloitte LLP, EY, Ernst & Young, KPMG, KPMG LLP, Accenture, BCG, Bain, McKinsey → [AUDITOR]

IMPORTANT EXCLUSIONS:
- Do NOT mask "PwC", "PricewaterhouseCoopers", or any PwC brand variant or abbreviation
- PwC is NOT a competitor or auditor to be masked

DO NOT MASK:
- Client/company names (except competitors as above)
- Person names
- Locations
- Emails
- Phone numbers
- Project or Deal IDs
- Dates
- Generic terms (IT, HR, Finance, etc.)
- Already sanitized placeholders ([CLIENT], [BU], [LOCATION], etc.)

RULES:
- Only mask explicitly mentioned names or their known abbreviations
- Do NOT hallucinate competitors, products, or auditors
- Preserve original text structure  """

MASK_CLIENT_DATA_PROMPT="""
TASK:
    - Mask client-specific numeric, financial, and operational data only.
    - Mask numbers only when they clearly relate to the client.

MASK (ONLY WHEN CLIENT-SPECIFIC)
    - Financial metrics: revenue, cost, margin, savings, investment, deal/contract value
    - Operational metrics: FTEs, headcount, volumes, capacity
    - Performance metrics: growth, margins, utilization, KPI percentages
    -  Mask all numeric values, including comma-formatted numbers like 1,442,122,530
    
Client identifiers:
    - Credit cards → [Credit Card Removed]
    - Bank accounts → [Account Removed]
    - Routing numbers → [Routing Removed]
    - Tax IDs → [Tax ID Removed]
    - Client project / deal / invoice / PO numbers → [XXXX]
Number format:
    - Preserve shape using X
        - $12,345 → $XX,XXX
        - 3.5M → X.XM
        - 12%-18% → XX%-XX%
        - 5-10 FTE → X-X FTE

DO NOT MASK (CRITICAL):
    - Dates in any format (years, quarters, fiscal years, calendar dates)
    - Generic numbers (steps, phases, slide numbers)
    - PwC metrics
    - Industry benchmarks unless explicitly client data
    - Technology/product versions (Windows 11, SAP S/4HANA)
    - Existing masked placeholders ([Client], [X%], [XXX])

DISAMBIGUATION (ABSOLUTE)
    - If a number could be a date, treat it as a date → DO NOT mask
    - If client relevance is unclear, DO NOT mask

OUTPUT RULE (ABSOLUTE):
- For each block, return a field named "numeric_masks"
- numeric_masks = number of client-specific numeric items masked in that block
- If none, return 0

TECHNICAL RULES (ABSOLUTE):
- Modify ONLY the "text" field
- EXCEPTION: You MUST also populate the "numeric_masks" field
- Do NOT add, remove, reorder, or rephrase any other fields
- Preserve formatting, spacing, and punctuation
- Return VALID JSON ONLY"""



MASK_LOCATION_PROMPT = """
CLIENT REGIONS & LOCATIONS:
MASK AS A SINGLE TOKEN:
- Any full physical address (street + any combination of city, state, country, or zip) → [ADDRESS]
- When masking a full address, do NOT separately mask its components.

MASK INDIVIDUAL LOCATION REFERENCES:
- Cities → [LOCATION]
- States or provinces → [LOCATION]
- Countries → [LOCATION]

MASK SELECTIVELY:
- House or building numbers when they appear independently
  (e.g., warehouse numbers, building identifiers) → [HOUSE NUMBER]
- Zip or postal codes when not part of a full address → [ZIP CODE]

DO NOT MASK:
- IP addresses
- GPS coordinates
- Person names
- Emails
- Phone numbers
- Product names
- Project or deal IDs
- Client names
- Dates
- Generic business terms (e.g., IT, HR, Finance)
- Numeric IDs such as employee IDs, project IDs, client codes, invoice numbers
- Numbers not explicitly part of a physical address
- Already sanitized placeholders (e.g., [CLIENT], [BU], etc.)

FORMATTING RULES:
- Preserve original line structure
- Prefer minimal masking
- Avoid over-redaction
"""

MASK_BU_PROMPT ="""TASK: Mask **only specific client Business Unit names**, not the generic term 'Business Unit'.\n"
                        "REPLACE:\n"
                        "- Specific BUs like 'Pixel Business Unit', 'Global Finance BU', 'Retail BU', 'Technology BU' → [BU]\n"
                        "DO NOT MASK:\n"
                        "- Generic word 'Business Unit' when not preceded by a specific BU name\n"
                        "- Locations\n"
                        "- Person names\n"
                        "- Emails\n"
                        "- Phone numbers\n"
                        "- Product names\n"
                        "- Project/Deal IDs\n"
                        "- Client names\n"
                        "- Dates\n"
                        "- Generic terms (IT, HR)\n"
                        "- Already sanitized placeholders ([CLIENT], [BU], etc.)\n"
                        "EXAMPLES:\n"
                        "- 'Pixel Business Unit' → '[BU]'\n"
                        "- 'Business Unit meeting scheduled' → leave 'Business Unit' as is"""

