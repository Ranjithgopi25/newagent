from typing import TypedDict, Annotated, Sequence, Optional, Dict, Any, Literal, List
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langchain_openai import AzureChatOpenAI
from app.features.ddc.agents.tools import get_all_tools
import operator
import json
import logging
from app.features.ddc.agents.prompts import get_system_prompt
from app.core.config import config 

logger = logging.getLogger(__name__)

class AgentState(TypedDict):
    """State for the sanitization agent"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    conversation_id: Optional[str]
    collected_data: Dict[str, Any]
    file_data: Optional[bytes]
    file_name: Optional[str]
    custom_template_data: Optional[bytes]
    custom_template_name: Optional[str]
    conversation_history: List[Dict[str, str]]

class SanitizationAgent:
    """LangGraph agent for handling sanitization workflow conversationally with tool calling"""
    
    def __init__(self, llm_service, sanitization_service,ppt_service):
        self.llm_service = llm_service
        self.sanitization_service = sanitization_service
        self.ppt_service = ppt_service
        # Store tools - use original tools for binding to LLM
        self.tools = get_all_tools()
        
        # Use Azure OpenAI with config 
        self.llm = AzureChatOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT,
            temperature=0
        ).bind_tools(self.tools)
        
        # Build graph
        self.graph = self._build_graph()
    
    def _call_model(self, state: AgentState) -> AgentState:
        file_provided = state.get('file_data') is not None
        file_name = state.get('file_name', 'No file')
        conversation_history = state.get('conversation_history', [])
        system_prompt = get_system_prompt(file_provided, file_name, conversation_history)
        # system_prompt = get_system_prompt(file_provided, file_name)  # ✅ Use external prompt
        
        messages = [HumanMessage(content=system_prompt)] + state["messages"]
        response = self.llm.invoke(messages)
        return {"messages": [response]}
        
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow with tool calling"""
        workflow = StateGraph(AgentState)
        
        # Create tool node - we'll handle tool execution in a custom way
        workflow.add_node("agent", self._call_model)
        workflow.add_node("tools", self._execute_tools)
        
        # Define edges
        workflow.set_entry_point("agent")
        
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "tools",
                "end": END
            }
        )
        
        # workflow.add_edge("tools", "agent")
        workflow.add_edge("tools", END)
        
        return workflow.compile()
    
    async def _execute_tools(self, state: AgentState) -> AgentState:
        """Execute tool calls with access to services"""
        last_message = state["messages"][-1]

        logger.info(f'came inside _execute_tools')
        
        tool_messages = []
        
        for tool_call in last_message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"].copy()
            
            logger.info(f"[Agent] Executing tool: {tool_name}")
            
            try:
                # ✅ Dynamic injection based on tool
                if tool_name == "sanitize_presentation":
                    tool_args["file_data"] = state.get("file_data")
                    tool_args["file_name"] = state.get("file_name")
                    tool_args["sanitization_service"] = self.sanitization_service
                    tool_args["llm_service"] = self.llm_service
                elif tool_name == "generate_powerpoint_presentation":
                    tool_args["ppt_service"] = self.ppt_service
                
                # ✅ Find and invoke tool dynamically
                tool_func = next((t for t in self.tools if t.name == tool_name), None)
                if tool_func:
                    # Both tools are async now
                    result = await tool_func.ainvoke(tool_args)
                else:
                    result = {"error": f"Unknown tool: {tool_name}"}
                
                # Create tool message
                tool_message = ToolMessage(
                    content=json.dumps(result),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
                
            except Exception as e:
                logger.error(f"[Agent] Tool execution error: {e}", exc_info=True)
                tool_message = ToolMessage(
                    content=json.dumps({"error": str(e)}),
                    tool_call_id=tool_call["id"]
                )
                tool_messages.append(tool_message)
        
        return {"messages": tool_messages}

    def _should_continue(self, state: AgentState) -> Literal["continue", "end"]:
        if state.get("_terminal"):
            return "end"

        last_message = state["messages"][-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "continue"

        return "end"

    async def process_message_sync(
        self, 
        message: str, 
        conversation_id: Optional[str] = None,
        file_data: Optional[bytes] = None,
        file_name: Optional[str] = None,
        custom_template_data: Optional[bytes] = None,
        custom_template_name: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Process user message through the graph (non-streaming version)
        Returns dict with message, and optionally file_bytes + metadata
        """
        
        initial_state = {
            "messages": [HumanMessage(content=message)],
            "conversation_id": conversation_id,
            "collected_data": {},
            "file_data": file_data,
            "file_name": file_name,
            "custom_template_data": custom_template_data,
            "custom_template_name": custom_template_name,
            "conversation_history": conversation_history or []
        }
        
        try:
            # final_state = self.graph.invoke(initial_state)
            final_state = await self.graph.ainvoke(initial_state)
            
            # Extract AI response
            ai_messages = [msg for msg in final_state["messages"] if isinstance(msg, AIMessage)]
            response_message = ai_messages[-1].content if ai_messages else "Processing..."
            
            # Check if sanitization was performed
            tool_messages = [msg for msg in final_state["messages"] if isinstance(msg, ToolMessage)]
            sanitization_result = None
            
            for tool_msg in tool_messages:
                try:
                    result_data = json.loads(tool_msg.content)
                    if result_data.get("status") == "success":
                        sanitization_result = result_data
                        break
                except:
                    pass
            
            # ✅ Build result
            result = {
                "message": response_message,
                "conversation_id": conversation_id
            }
            
            # ✅ If sanitization completed, include file data
            if sanitization_result:
                file_bytes = bytes.fromhex(sanitization_result["file_data_base64"])
                
                result.update({
                    "file_bytes": file_bytes,
                    "file_name": sanitization_result["file_name"],
                    "file_size": sanitization_result["file_size"],
                    "summary": sanitization_result["summary"],
                    "plan": sanitization_result["plan"]
                })
            
            return result
                
        except Exception as e:
            logger.error(f"[Agent] Error: {e}", exc_info=True)
            return {
                "message": f"Error: {str(e)}",
                "conversation_id": conversation_id
            }