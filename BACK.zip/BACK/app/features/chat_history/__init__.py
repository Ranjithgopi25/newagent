"""
Chat History Feature Module.
Handles all chat session management, retrieval, and conversation history.
"""

from .router import router


def get_router():
    """
    Get the router for this feature.
    Used by main.py to register this feature's endpoints.
    
    Returns:
        FastAPI APIRouter for chat history endpoints
    """
    return router


__all__ = ['get_router', 'router']
