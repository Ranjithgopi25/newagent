from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import re
import json
from fastapi import HTTPException

logger = logging.getLogger(__name__)

class RefineContentService(BaseTLStreamingService):
    """Service for Refine Content workflow"""
    
    # Tone instruction dictionary for clarity and consistency
    TONE_INSTRUCTIONS = {
        'conversational': {
            'description': 'Use contractions (don\'t, can\'t, we\'re), short sentences, friendly language. Write like talking to a colleague.',
            'critical_points': [
                'MUST use contractions throughout',
                'Write shorter, natural sentences',
                'Use friendly, approachable language',
                'Avoid formal or academic phrasing',
                'Make it feel like a conversation'
            ]
        },
        'formal': {
            'description': 'Use complete sentences, no contractions, professional vocabulary. Maintain formal distance.',
            'critical_points': [
                'NO contractions allowed',
                'Use professional, structured language',
                'Maintain respectful distance',
                'Use formal vocabulary',
                'Write in complete, well-structured sentences'
            ]
        },
        'professional': {
            'description': 'Business-appropriate language, clear structure, respectful but approachable tone.',
            'critical_points': [
                'Use business-appropriate language',
                'Write clear, concise sentences',
                'Professional terminology',
                'Respectful but approachable'
            ]
        },
        'casual': {
            'description': 'Relaxed language, contractions, everyday vocabulary, friendly expressions.',
            'critical_points': [
                'Use relaxed, everyday language',
                'Contractions are encouraged',
                'Shorter, natural sentences',
                'Friendly expressions'
            ]
        }
    }

    def _get_suggestions_prompt_template(self) -> str:
        """Get the detailed PwC suggestions prompt template"""
        return """
ROLE & OBJECTIVE
You are a Senior PwC Brand & Content Strategist and Executive Editor. Your role is NOT to rewrite the content, but to act as a critical writing coach. Provide specific, actionable, and high-value suggestions to help the author elevate their draft to meet PwC's thought leadership standards.

I. CORE ANALYSIS FRAMEWORK (PwC Tone Pillars)
Evaluate the draft against these three tone pillars and identify specific opportunities for improvement:

BOLD (Assertive, Decisive, Clear)
- Standard: Lead with a strong point of view; avoid safe, academic language.
- Watch For: Soft qualifiers (e.g., "somewhat," "arguably," "it seems that"), passive voice, dense jargon
- Fix: Encourage decisive language. Replace banned word "catalyst" with driver, enabler, accelerator.

COLLABORATIVE (Human, Conversational, Partnership-Focused)
- Standard: Write to the reader, not at them.
- Watch For: Third-person distancing ("PwC helps clients…"), formal stiffness (lack of contractions, overly complex sentences)
- Fix: Use first-person and direct address ("We help you…"). Replace "clients" with "you" or "your organization."

OPTIMISTIC (Future-Forward, Outcome-Focused)
- Standard: Emphasize solutions and possibilities.
- Watch For: Problem-only framing, static language
- Fix: Pivot to outcomes. Use movement words (transform, evolve, reshape) and energy words (propel, spark, accelerate).

II. COMPLIANCE CHECKS
Flag and correct any prohibited terms or style violations:
- "Catalyst" → driver/enabler/accelerator
- "Clients" → you/your organization
- "PwC Network" → PwC network (lowercase 'n')
- "Mainland China" → Chinese Mainland
- Exclamation marks
- Buzzwords/fillers: leverage, synergy, at the end of the day, in order to, moving forward

III. EXPANDED ANALYSIS
- Logic & Depth (MECE): Check argument flow, gaps, and redundancy.
- Thought Leadership: Suggest proprietary PwC data or examples to strengthen authority.
- Visual Opportunities: Identify text-heavy sections for charts/infographics.
- Differentiation: Flag generic content; push for unique PwC insights.
- Consistency & Risk: Spot contradictions or cultural sensitivities.

IV. OUTPUT FORMAT
Provide feedback in this structured format:

✓ Brand Voice Alignment
- Observation: [Quote problematic phrase]
- Fix: [Explain why and suggest bold/collaborative alternative]

✓ Vocabulary & Terminology
- Flagged Terms: [List prohibited words only if used]
- Recommended Swaps: [Suggest PwC-approved alternatives]

✓ Structural Clarity
- Observation: [Identify long or buried sentences]
- Fix: [Give specific restructuring advice]

✓ Strategic Lift (So What?)
- Observation: [Generic statement]
- Fix: [Push for business impact and specificity]

✓ Logic & Evidence Gaps
- Observation: [Weak or unsupported argument]
- Fix: [Suggest data or examples]

✓ Visual Opportunities
- Observation: [Text-heavy section]
- Fix: [Recommend visual format]

✓ Differentiation
- Observation: [Generic content]
- Fix: [Suggest unique PwC angle]

⚠ Risk & Sensitivity
- Flagged Items: [Contradictions or sensitivities]
- Action: [Resolution guidance]

**CONTENT TO ANALYZE:**
{content}"""

    def _get_tone_instruction(self, tone: str) -> str:
        """Get tone instruction based on tone type"""
        tone_lower = tone.lower()
        
        # Check for known tones
        for key, value in self.TONE_INSTRUCTIONS.items():
            if key in tone_lower:
                critical_points = '\n'.join([f'  - {point}' for point in value['critical_points']])
                return f"{value['description']}\n\nCRITICAL POINTS:\n{critical_points}"
        
        # Generic tone instruction
        return f"Match '{tone}' tone in vocabulary, sentence structure, formality level, and overall voice throughout."
    
    def _extract_title_from_prompt(self, prompt: str) -> str:
        """Extract service information and generate appropriate title"""
        title_parts = []
        
        # Check for Expand or Compress Content
        if "Expand or Compress Content" in prompt:
            word_limit_match = re.search(r'Word limit:\s*(\d+)', prompt, re.IGNORECASE)
            if word_limit_match:
                word_limit = word_limit_match.group(1)
                title = f"Refined Content ({word_limit} words)"
                title_parts.append(title)
            else:
                title_parts.append("Expand or Compress Content")
        
        # Check for Adjust Audience/Tone
        if "Adjust for Audience / Tone" in prompt:
            tone_match = re.search(r'Audience and tone:\s*([^\n\r]+)', prompt, re.IGNORECASE | re.MULTILINE)
            if tone_match:
                tone = tone_match.group(1).strip()
                tone = ' '.join(tone.split()).title()
                title_parts.append(f"Refined Content - {tone} Tone")
            else:
                title_parts.append("Refined Content - Adjusted Tone")
        
        # Check for other services
        if "Enhance with Additional Research" in prompt:
            title_parts.append("Enhanced Content with Additional Research")
        
        if "Edit Content" in prompt:
            title_parts.append("Edited Content")
        
        if "Provide Suggestions on Improving Content" in prompt:
            title_parts.append("Content with Improvement Suggestions")
        
        # Generate final title
        if not title_parts:
            return "Refined Content"
        
        # If multiple services (2 or more), return combined title
        if len(title_parts) > 1:
            logger.info(f"[Refine Content] Multiple services detected ({len(title_parts)}), using 'All-in-One Content Refinement' title")
            return "All-in-One Content Refinement"
        
        return title_parts[0]
    
    def _extract_services_from_prompt(self, prompt: str) -> dict:
        """Extract all services and their parameters from the prompt"""
        services = {
            'compress': None,
            'tone': None,
            'research': False,
            'edit': False,
            'suggestions': False
        }
        
        # Extract compress/expand with word limit
        if "Expand or Compress Content" in prompt:
            word_limit_match = re.search(r'Word limit:\s*(\d+)', prompt, re.IGNORECASE)
            if word_limit_match:
                services['compress'] = word_limit_match.group(1)
                services['requested_word_limit'] = int(word_limit_match.group(1))
        
        # Extract tone
        if "Adjust for Audience / Tone" in prompt:
            tone_match = re.search(r'Audience and tone:\s*([^\n\r]+)', prompt, re.IGNORECASE | re.MULTILINE)
            if tone_match:
                tone = tone_match.group(1).strip()
                tone = ' '.join(tone.split())
                services['tone'] = tone
        
        # Check for research
        if "Enhance with Additional Research" in prompt:
            services['research'] = True
            research_match = re.search(r'Research Topics:\s*([^\n]+)', prompt, re.IGNORECASE)
            if research_match:
                services['research_topics'] = research_match.group(1).strip()
        
        # Check for edit content
        if "Edit Content" in prompt:
            services['edit'] = True
        
        # Check for suggestions
        if "Provide Suggestions on Improving Content" in prompt:
            services['suggestions'] = True
        
        return services
    
    async def refine_content(self, content: str, primary_doc_text: str | None = None,
                            secondary_doc_text: str | None = None):
        """Refine content for quality and impact"""
        
        # Extract title and services
        title = self._extract_title_from_prompt(content)
        services = self._extract_services_from_prompt(content)
        
        logger.info(f"[Refine Content] Generated title: {title}")
        logger.info(f"[Refine Content] Services detected: {services}")
        
        # Calculate word counts
        current_word_count = len(content.split())
        max_allowed_words = int(current_word_count * 1.25)
        min_allowed_words = int(current_word_count * 0.75)
        
        match = re.search(r'Word limit:\s*(\d+)', content)
        word_limit = int(match.group(1)) if match else None
        
        # Parse documents
        llm_input_content = content
        primary_doc_text = None
        secondary_doc_text = None
        
        if "PRIMARY DOCUMENT (BASE CONTENT):" in content:
            try:
                primary_part = content.split("PRIMARY DOCUMENT (BASE CONTENT):", 1)[1]
                if "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):" in primary_part:
                    primary_doc_text, rest = primary_part.split(
                        "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):", 1
                    )
                    primary_doc_text = primary_doc_text.strip()
                    
                    if "INSTRUCTION:" in rest:
                        secondary_doc_text = rest.split("INSTRUCTION:", 1)[0].strip()
                        logger.info(f"[Refine Content] Supporting document ACTIVE — "
                                  f"Secondary length={len(secondary_doc_text.split())} words")
                    else:
                        secondary_doc_text = rest.strip()
            except Exception as e:
                logger.warning(f"[Refine Content] Failed to extract supporting document: {e}")
        
        logger.info(
            f"[Refine Content] Parsed documents | "
            f"Primary={'YES' if primary_doc_text else 'NO'}, "
            f"Secondary={'YES' if secondary_doc_text else 'NO'}"
        )
        
        # Handle supporting document for expansion
        force_supporting_usage = False
        if secondary_doc_text:
            force_supporting_usage = True
        
        if services.get('requested_word_limit'):
            requested = services['requested_word_limit']
            if requested > current_word_count and secondary_doc_text:
                llm_input_content = f"""
PRIMARY DOCUMENT (BASE CONTENT):
{primary_doc_text}

SUPPORTING DOCUMENT (FOR EXPANSION ONLY):
{secondary_doc_text}

INSTRUCTION:
Use the supporting document ONLY to add new substance where needed.
Do NOT invent facts.
Do NOT contradict the primary document.
""".strip()
                logger.info(
                    f"[Refine Content] Expansion detected. "
                    f"Original={current_word_count}, Requested={requested}. "
                    f"Using merged documents."
                )
        
        # Count active services
        active_services_count = sum([
            1 if services['compress'] else 0,
            1 if services['tone'] else 0,
            1 if services['research'] else 0,
            1 if services['edit'] else 0,
            1 if services['suggestions'] else 0
        ])
        
        # Build task lists and instructions
        task_list = []
        detailed_instructions = []
        
        # Priority 1: Compression/Expansion (Word Count)
        if services['compress']:
            task_list.append(f"compress to exactly {services['compress']} words")
            detailed_instructions.append(f"""1. WORD COUNT (HIGHEST PRIORITY):
   - Target: EXACTLY {services['compress']} words
   - Method: Compress WITHIN each paragraph by:
     • Tightening sentences
     • Removing redundancy and filler words
     • Using more concise phrasing
   - Preserve: ALL paragraphs, their order, and structure
   - DO NOT: Delete paragraphs, conclusions, or sections to meet word count
   - Validation: Count every single word - must be exactly {services['compress']}, not {int(services['compress'])-1}, not {int(services['compress'])+1}""")
        
        # Priority 2: Tone Adjustment
        if services['tone']:
            task_list.append(f"adjust tone to: {services['tone']}")
            tone_instruction = self._get_tone_instruction(services['tone'])
            detailed_instructions.append(f"""2. TONE (SECOND PRIORITY):
   - Style: '{services['tone']}' tone throughout entire content
   - Requirements:
{tone_instruction}
   - Apply: Every sentence must reflect '{services['tone']}' tone
   - Maintain: Original meaning and key points while changing expression""")
        
        # Priority 3: Other Services
        if services['research']:
            task_list.append("add research insights and data")
            detailed_instructions.append("3. RESEARCH: Add relevant research insights, data points, and evidence-based information")
        
        if services['edit']:
            task_list.append("apply professional editing")
            detailed_instructions.append("4. EDIT: Apply professional editing for grammar, clarity, and flow")
        
        if services['suggestions']:
            task_list.append("include improvement suggestions")
            detailed_instructions.append("5. SUGGESTIONS: Provide strategic feedback using PwC Brand & Content framework in a separate section")
        
        # Build tasks description
        tasks_description = " AND ".join(task_list) if task_list else ""
        
        # Build system prompt based on service combination
        if active_services_count > 1:
            # Multiple services - apply all together with clear priority
            detailed_text = "\n\n".join(detailed_instructions)
            
            # Build suggestions section if needed
            suggestions_format = ""
            suggestions_framework = ""
            if services['suggestions']:
                suggestions_format = "\n\n## Suggestions for Improvement\n\n[Strategic feedback using PwC framework]"
                suggestions_framework = f"\n\nSUGGESTIONS FRAMEWORK:\n{self._get_suggestions_prompt_template()}"
            
            # Build validation checklist
            validation_items = []
            if services['compress']:
                validation_items.append(f"✓ Word count = EXACTLY {services['compress']} words (verify by counting)")
            if services['tone']:
                validation_items.append(f"✓ Every sentence uses '{services['tone']}' tone consistently")
            if active_services_count > 1:
                validation_items.append(f"✓ All {active_services_count} services applied simultaneously")
            
            validation_checklist = "\n".join(validation_items)
            
            system_prompt = f"""You are a PwC content refinement expert.
{'MANDATORY: A supporting document is provided. You MUST explicitly incorporate concepts, terminology, or insights from the SUPPORTING DOCUMENT into the final content.' if force_supporting_usage else ''}

TASK: Apply {active_services_count} services SIMULTANEOUSLY: {tasks_description}

SERVICE PRIORITY ORDER:
1. Word Count (if requested) - STRICTEST requirement
2. Tone (if requested) - Must be consistent throughout
3. Other services (research, edit, suggestions)

DETAILED INSTRUCTIONS:
{detailed_text}

STRUCTURE PRESERVATION (NON-NEGOTIABLE):
- Keep ALL original paragraphs in their exact order
- The number of paragraphs in output MUST match input
- No paragraph may be removed, merged, or skipped
- Conclusions and final sections MUST be retained
- Compress by tightening language WITHIN paragraphs, not by deleting paragraphs

OUTPUT FORMAT:
**{title}**

[Refined content - all services applied together]{suggestions_format}
{suggestions_framework}

VALIDATION CHECKLIST (Verify before submitting):
{validation_checklist}

CRITICAL REMINDERS:
- Apply ALL {active_services_count} services in ONE unified output
- Do NOT create separate sections for each service (except suggestions)
- Every sentence must satisfy ALL requirements simultaneously
- Word count is the PRIMARY constraint - tone and other services must work within this limit"""

        elif services['suggestions']:
            # Suggestions only - use detailed framework
            content_match = re.search(r'Content to Refine:\s*(.+)$', content, re.DOTALL | re.IGNORECASE)
            actual_content = content_match.group(1).strip() if content_match else content
            
            system_prompt = f"""ROLE: Senior PwC Brand & Content Strategist and Executive Editor

TASK: Analyze content and provide strategic feedback (NOT rewrite)

{self._get_suggestions_prompt_template().format(content=actual_content)}"""

        elif services['compress']:
            # Compression only
            system_prompt = f"""You are a PwC content compression expert.

TASK: Compress content to EXACTLY {services['compress']} words.

METHOD:
- Tighten sentences within each paragraph
- Remove redundancy, filler words, and unnecessary adjectives
- Use more concise phrasing and stronger verbs
- Keep ALL paragraphs and structure intact
- Maintain original meaning, tone, and key points

STRUCTURE RULES:
- Preserve ALL paragraphs in their original order
- Do NOT delete, merge, or skip any paragraphs
- Do NOT remove conclusions or final sections
- Compress by improving efficiency WITHIN each paragraph

VALIDATION (CRITICAL):
- Count every single word in your output
- Final count MUST be EXACTLY {services['compress']} words
- Not {int(services['compress'])-1} words
- Not {int(services['compress'])+1} words
- But EXACTLY {services['compress']} words

OUTPUT FORMAT:
**{title}**

[Compressed content - exactly {services['compress']} words]"""

        elif services['tone']:
            # Tone only
            tone_instruction = self._get_tone_instruction(services['tone'])
            
            system_prompt = f"""You are a PwC tone adjustment expert.

TASK: Rewrite content in '{services['tone']}' tone.

TONE REQUIREMENTS:
{tone_instruction}

CONSTRAINTS:
- Preserve original structure and paragraph count
- Keep ALL paragraphs in their original order
- Keep original meaning and key points
add
- Only change HOW things are said, not WHAT is said

METHOD:
- Adjust vocabulary to match tone
- Modify sentence structure for tone
- Change formality level as needed
- Maintain consistent tone from first word to last

OUTPUT FORMAT:
**{title}**

[Content in {services['tone']} tone - preserve structure and meaning]"""

        else:
            # Generic refinement
            system_prompt = f"""You are a PwC content optimization expert.

TASK: Refine the content according to the provided instructions.

GUIDELINES:
- Preserve original structure and paragraph order
- Maintain key points and meaning
- Apply professional editing standards
- Ensure clarity and readability

OUTPUT FORMAT:
**{title}**

[Refined content]"""
        
        # Build user prompt
        if active_services_count > 1:
            # Extract actual content
            actual_content = llm_input_content
            
            # Build task list for user prompt
            tasks_list_text = "\n".join([f"✓ {task}" for task in task_list])
            
            # Build reminders
            reminders = []
            if services['compress']:
                reminders.append(f"- WORD COUNT: Final content MUST be EXACTLY {services['compress']} words")
            if services['tone']:
                reminders.append(f"- TONE: Every sentence MUST use '{services['tone']}' tone consistently")
            if active_services_count > 1:
                reminders.append(f"- COMBINATION: All {active_services_count} services must be applied simultaneously")
            
            reminders_text = "\n".join(reminders)
            
            enhanced_user_prompt = f"""Apply these {active_services_count} services TOGETHER in ONE output:

{tasks_list_text}

PRIORITY REQUIREMENTS:
{reminders_text}

Content to refine:
{actual_content}

REMEMBER:
- Combine ALL services together in a single unified output
- Do NOT apply them separately or in sequence
- Every sentence must satisfy ALL requirements
- Word count takes priority, then tone, then other services"""
        
        else:
            # Single service or suggestions
            if services['suggestions']:
                enhanced_user_prompt = "Please analyze the content provided and provide strategic feedback using the PwC framework."
            else:
                enhanced_user_prompt = llm_input_content
        
        # Build messages for LLM
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": enhanced_user_prompt}
        ]
        
        try:
            logger.info(f"[Refine Content] Active services: {active_services_count}")
            logger.info(f"[Refine Content] Task list: {task_list}")
            logger.info(f"[Refine Content] Title: {title}")
            
            if active_services_count > 1:
                logger.info(f"[Refine Content] MULTIPLE SERVICES - Combining: {tasks_description}")
            
            async for chunk in self.stream_response(messages):
                yield chunk
                
        except Exception as e:
            logger.error(f"[Refine Content] Error: {e}", exc_info=True)
            error_message = f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
            yield error_message
    
    async def execute(self, *args, **kwargs):
        return await self.refine_content(*args, **kwargs)
    
# from app.infrastructure.llm.base import BaseTLStreamingService
# import logging
# import re
# import json
# from fastapi import HTTPException

# logger = logging.getLogger(__name__)

# class RefineContentService(BaseTLStreamingService):
#     """Service for Refine Content workflow"""
    

#     def _get_suggestions_prompt_template(self) -> str:
#         """Get the detailed PwC suggestions prompt template"""
#         return """
#         ROLE & OBJECTIVE
# You are a Senior PwC Brand & Content Strategist and Executive Editor. Your role is NOT to rewrite the content, but to act as a critical writing coach. Provide specific, actionable, and high-value suggestions to help the author elevate their draft to meet PwC’s thought leadership standards.

# I. CORE ANALYSIS FRAMEWORK (PwC Tone Pillars)
# Evaluate the draft against these three tone pillars and identify specific opportunities for improvement:

# BOLD (Assertive, Decisive, Clear)

# Standard: Lead with a strong point of view; avoid safe, academic language.
# Watch For:

# Soft qualifiers (e.g., “somewhat,” “arguably,” “it seems that”)
# Passive voice
# Dense jargon

# Fix: Encourage decisive language. Replace banned word “catalyst” with driver, enabler, accelerator.

# COLLABORATIVE (Human, Conversational, Partnership-Focused)

# Standard: Write to the reader, not at them.
# Watch For:

# Third-person distancing (“PwC helps clients…”)
# Formal stiffness (lack of contractions, overly complex sentences)


# Fix: Use first-person and direct address (“We help you…”). Replace “clients” with “you” or “your organization.”

# OPTIMISTIC (Future-Forward, Outcome-Focused)

# Standard: Emphasize solutions and possibilities.
# Watch For:

# Problem-only framing
# Static language

# Fix: Pivot to outcomes. Use movement words (transform, evolve, reshape) and energy words (propel, spark, accelerate).

# II. COMPLIANCE CHECKS
# Flag and correct any prohibited terms or style violations:

#  “Catalyst” → driver/enabler/accelerator
#  “Clients” → you/your organization
#  “PwC Network” → PwC network (lowercase ‘n’)
#  “Mainland China” → Chinese Mainland
#  Exclamation marks
#  Buzzwords/fillers: leverage, synergy, at the end of the day, in order to, moving forward


# III. EXPANDED ANALYSIS

# Logic & Depth (MECE): Check argument flow, gaps, and redundancy.
# Thought Leadership: Suggest proprietary PwC data or examples to strengthen authority.
# Visual Opportunities: Identify text-heavy sections for charts/infographics.
# Differentiation: Flag generic content; push for unique PwC insights.
# Consistency & Risk: Spot contradictions or cultural sensitivities.

# IV. OUTPUT FORMAT
# Provide feedback in this structured format:

#  Brand Voice Alignment

# Observation: [Quote problematic phrase]
# Fix: [Explain why and suggest bold/collaborative alternative]

#  Vocabulary & Terminology

# Flagged Terms: [List prohibited words only if it has been used otherwise don't show]
# Recommended Swaps: [Suggest PwC-approved  Teralternatives]
#  Structural Clarity

# Observation: [Identify long or buried sentences]
# Fix: [Give specific restructuring advice]

#  Strategic Lift (So What?)

# Observation: [Generic statement]
# Fix: [Push for business impact and specificity]

#  Logic & Evidence Gaps

# Observation: [Weak or unsupported argument]
# Fix: [Suggest data or examples]

#  Visual Opportunities

# Observation: [Text-heavy section]
# Fix: [Recommend visual format]

#  Differentiation

# Observation: [Generic content]
# Fix: [Suggest unique PwC angle]

# ⚠ Risk & Sensitivity

# Flagged Items: [Contradictions or sensitivities]
# Action: [Resolution guidance]
#     **CONTENT TO ANALYZE:**
#     {content}"""

    
#     def _extract_title_from_prompt(self, prompt: str) -> str:
#         """Extract service information and generate appropriate title"""
#         title_parts = []
        
#         # Check for Expand or Compress Content - look for word limit in the params
#         if "Expand or Compress Content" in prompt:
#             # Look for word limit - try multiple patterns
#             word_limit_match = re.search(r'Word limit:\s*(\d+)', prompt, re.IGNORECASE)
#             if not word_limit_match:
#                 # Try alternative pattern
#                 word_limit_match = re.search(r'word limit[:\s]+(\d+)', prompt, re.IGNORECASE)
#             if not word_limit_match:
#                 # Try pattern with different spacing
#                 word_limit_match = re.search(r'Word\s+limit[:\s]+(\d+)', prompt, re.IGNORECASE)
            
#             if word_limit_match:
#                 word_limit = word_limit_match.group(1)
#                 # When word limit is specified, it's typically compressing to that limit
#                 title = f"Refined Content ({word_limit} words)"
#                 title_parts.append(title)
#                 logger.info(f"[Refine Content] Extracted title: {title}")
#             else:
#                 title_parts.append("Expand or Compress Content")
#                 logger.info("[Refine Content] No word limit found, using default title")
        
#         # Check for Adjust Audience/Tone
#         if "Adjust for Audience / Tone" in prompt:
#             # Look for audience and tone in the params
#             tone_match = re.search(r'Audience and tone:\s*([^\n\r]+)', prompt, re.IGNORECASE | re.MULTILINE)
#             if tone_match:
#                 tone = tone_match.group(1).strip()
#                 # Clean up tone text (remove newlines, extra spaces)
#                 tone = ' '.join(tone.split())
#                 # Capitalize properly
#                 tone = tone.title()
#                 title_parts.append(f"Refined Content - {tone} Tone")
#             else:
#                 title_parts.append("Refined Content - Adjusted Tone")
        
#         # Check for Enhance Research
#         if "Enhance with Additional Research" in prompt:
#             title_parts.append("Enhanced Content with Additional Research")
        
#         # Check for Edit Content
#         if "Edit Content" in prompt:
#             title_parts.append("Edited Content")
        
#         # Check for Provide Suggestions
#         if "Provide Suggestions on Improving Content" in prompt:
#             title_parts.append("Content with Improvement Suggestions")
        
#         # Generate final title based on priority
#         if not title_parts:
#             return "Refined Content"
        
#         # Count how many services are selected
#         service_count = len(title_parts)
        
#         # If multiple services (2 or more), return "All-in-One Content Refinement"
#         if service_count > 1:
#             logger.info(f"[Refine Content] Multiple services detected ({service_count}), using 'All-in-One Content Refinement' title")
#             return "All-in-One Content Refinement"
        
#         # For single service, return the specific title
#         return title_parts[0]
    
#     def _extract_services_from_prompt(self, prompt: str) -> dict:
#         """Extract all services and their parameters from the prompt"""
#         services = {
#             'compress': None,
#             'tone': None,
#             'research': False,
#             'edit': False,
#             'suggestions': False
#         }
        
#         # Extract compress/expand with word limit
#         if "Expand or Compress Content" in prompt:
#             word_limit_match = re.search(r'Word limit:\s*(\d+)', prompt, re.IGNORECASE)
#             if word_limit_match:
#                 services['compress'] = word_limit_match.group(1)
#                 requested_limit = int(word_limit_match.group(1))
#                 services['requested_word_limit'] = requested_limit
        
#         # Extract tone
#         if "Adjust for Audience / Tone" in prompt:
#             tone_match = re.search(r'Audience and tone:\s*([^\n\r]+)', prompt, re.IGNORECASE | re.MULTILINE)
#             if tone_match:
#                 tone = tone_match.group(1).strip()
#                 tone = ' '.join(tone.split())
#                 services['tone'] = tone
        
#         # Check for research
#         if "Enhance with Additional Research" in prompt:
#             services['research'] = True
#             # Extract research topics
#             research_match = re.search(r'Research Topics:\s*([^\n]+)', prompt, re.IGNORECASE)
#             if research_match:
#                 services['research_topics'] = research_match.group(1).strip()
        
#         # Check for edit content
#         if "Edit Content" in prompt:
#             services['edit'] = True
        
#         # Check for suggestions
#         if "Provide Suggestions on Improving Content" in prompt:
#             services['suggestions'] = True
        
#         return services
    
#     async def refine_content(self, content: str, primary_doc_text: str | None = None,
#     secondary_doc_text: str | None = None):
#         """Refine content for quality and impact"""
#         # Extract title from prompt
#         title = self._extract_title_from_prompt(content)
#         logger.info(f"[Refine Content] Generated title: {title}")
        
#         # Extract all services to build comprehensive instructions
#         services = self._extract_services_from_prompt(content)
#         # current_word_count = getattr(self, "current_word_count", None)
#         # Calculate current word count from uploaded content
#         current_word_count = len(content.split())
#         max_allowed_words = int(current_word_count * 1.25)
#         min_allowed_words = int(current_word_count * 0.75)
#         match = re.search(r'Word limit:\s*(\d+)', content) 
#         word_limit = int(match.group(1)) if match else None
#         llm_input_content = content
#         primary_doc_text = None
#         secondary_doc_text = None

#         if "PRIMARY DOCUMENT (BASE CONTENT):" in content:
#             try:
#                 primary_part = content.split("PRIMARY DOCUMENT (BASE CONTENT):", 1)[1]
#                 if "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):" in primary_part:
#                     primary_doc_text, rest = primary_part.split(
#                         "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):", 1
#                     )
#                     primary_doc_text = primary_doc_text.strip()

#                     if "INSTRUCTION:" in rest:
#                         secondary_doc_text = rest.split("INSTRUCTION:", 1)[0].strip()
#                         logger.info("[Refine Content] Supporting document ACTIVE — "
#                                 f"Secondary length={len(secondary_doc_text.split())} words")
#                     else:
#                         secondary_doc_text = rest.strip()
#             except Exception as e:
#                 logger.warning(f"[Refine Content] Failed to extract supporting document: {e}")

#         logger.info(
#             f"[Refine Content] Parsed documents | "
#             f"Primary={'YES' if primary_doc_text else 'NO'}, "
#             f"Secondary={'YES' if secondary_doc_text else 'NO'}"
#         )
#         force_supporting_usage = False
#         if secondary_doc_text:
#             force_supporting_usage = True
#         if services.get('requested_word_limit'):
#             requested = services['requested_word_limit']
#             if requested > current_word_count and secondary_doc_text:
#                 llm_input_content = f"""
#                     PRIMARY DOCUMENT (BASE CONTENT):
#                     {primary_doc_text}
#                     SUPPORTING DOCUMENT (FOR EXPANSION ONLY):
#                     {secondary_doc_text}
#                     INSTRUCTION:
#                     Use the supporting document ONLY to add new substance where needed.
#                     Do NOT invent facts.
#                     Do NOT contradict the primary document.
#                 """.strip()
#                 logger.info(
#                     f"[Refine Content] LLM input length: {len(llm_input_content)} "
#                     f"(Primary={len(primary_doc_text or '')}, "
#                     f"Secondary={len(secondary_doc_text or '')})"
#                 )

#                 logger.info(
#                     f"[Refine Content] Expansion detected. "
#                     f"Original={current_word_count}, Requested={requested}. "
#                     f"Using merged documents."
#                 )
#         logger.info(f"[Refine Content] Services detected: {services}")
        
#         # Count active services
#         active_services_count = len([s for s in [services['compress'], services['tone'], services['research'], services['edit'], services['suggestions']] if s])
        
#         # Build task lists for both single and multiple services
#         task_list = []
#         detailed_instructions = []
#         tasks_description = ""
        
#         if services['compress']:
#             task_list.append(f"compress to exactly {services['compress']} words")
#             detailed_instructions.append(f"""1. COMPRESS (NON-DESTRUCTIVE):
#         CRITICAL RULES:
#         - You MUST preserve the FULL paragraph structure and order of the original content.
#         - You MUST NOT delete any paragraph, section, or conclusion.
#         - Compression MUST happen INSIDE EACH PARAGRAPH by tightening sentences, removing redundancy, and condensing phrasing.
#         - DO NOT remove the last paragraphs or conclusions to achieve word count.
#         - Apply proportional compression across ALL paragraphs.
#         - Maintain original intent, argument flow, and tone.

#         WORD COUNT:
#         - Final content MUST be EXACTLY {services['compress']} words.
#         - Count every word carefully. No more, no less.
#         """ )
        
#         if services['tone']:
#             task_list.append(f"adjust tone/style to: {services['tone']}")
#             # Build tone-specific guidance based on user input
#             tone_lower = services['tone'].lower()
#             tone_guidance = ""
#             if 'conversational' in tone_lower or 'conversation' in tone_lower:
#                 tone_guidance = " CRITICAL: For conversational tone, you MUST: use contractions (don't, can't, it's, we're, you're, I'm, they're), write shorter sentences, use friendly and approachable language, write as if speaking to a friend, avoid formal or academic language, use everyday vocabulary, and make it feel natural and flowing like a conversation. Do NOT use formal language - conversational means conversational!"
#             elif 'formal' in tone_lower:
#                 tone_guidance = " CRITICAL: For formal tone, you MUST: use professional language, write complete sentences, avoid contractions, maintain professional distance, use formal vocabulary, and write in a structured, authoritative manner."
#             elif 'casual' in tone_lower:
#                 tone_guidance = " CRITICAL: For casual tone, you MUST: use relaxed language, use contractions, write shorter sentences, use friendly expressions, and use everyday vocabulary."
#             elif 'professional' in tone_lower:
#                 tone_guidance = " CRITICAL: For professional tone, you MUST: use business-appropriate language, write clear and concise sentences, use professional terminology, and maintain a respectful but approachable tone."
#             else:
#                 # For any other tone the user enters
#                 tone_guidance = f" CRITICAL: For '{services['tone']}' tone, you MUST adjust your writing style to match this specific tone. Consider vocabulary, sentence structure, formality level, and overall voice that best represents '{services['tone']}' tone."
            
#             detailed_instructions.append(f"2. TONE: CRITICAL - You MUST write in '{services['tone']}' tone throughout the ENTIRE content. Every single sentence, every word choice, and every phrase must reflect '{services['tone']}' tone. If the user specified '{services['tone']}', you MUST use that exact tone - do NOT use a different tone.{tone_guidance} Modify vocabulary, sentence structure, writing style, formality level, and overall voice to perfectly match '{services['tone']}'. The tone '{services['tone']}' must be consistent from the first word to the last word.")
        
#         if services['research']:
#             task_list.append("add research insights and data")
#             detailed_instructions.append("3. RESEARCH: Add relevant research insights, data points, and evidence-based information.")
        
#         if services['edit']:
#             task_list.append("apply professional editing")
#             detailed_instructions.append("4. EDIT: Apply professional editing for grammar, clarity, and flow.")
        
#         if services['suggestions']:
#             task_list.append("include improvement suggestions")
#             detailed_instructions.append("5. SUGGESTIONS: After providing the refined content, include strategic feedback using the PwC Brand & Content framework. Analyze the content against BOLD (assertive, decisive), COLLABORATIVE (human, conversational), and OPTIMISTIC (future-forward) pillars. Flag prohibited terms (catalyst, clients when referring to reader, PwC Network with capital N, Mainland China, exclamation marks, buzzwords). Provide structured feedback covering: Brand Voice Alignment, Vocabulary & Terminology Refinement, Structural Impact & Clarity, and Strategic Lift. Format as a separate section with heading '## Suggestions for Improvement'.")
        
#         # Build tasks description for logging and prompts
#         if task_list:
#             tasks_description = " AND ".join(task_list)
        
#         # Build simple, direct system prompt
#         if active_services_count > 1:
#             # Multiple services - create very explicit combined instruction
#             detailed_text = "\n".join(detailed_instructions)
            
#             # Build specific example based on selected services
#             example_text = ""
#             if services['compress'] and services['tone']:
#                 tone_example = ""
#                 if 'conversational' in services['tone'].lower() or 'conversation' in services['tone'].lower():
#                     tone_example = " For conversational tone: Use contractions (don't, can't), shorter sentences, friendly language - like talking to a friend."
#                 example_text = f"Example: If asked to compress to {services['compress']} words AND adjust tone/style to: {services['tone']}, create content that is EXACTLY {services['compress']} words (count every word - not {int(services['compress'])-1}, not {int(services['compress'])+1}, but EXACTLY {services['compress']}) AND matches the tone/style '{services['tone']}' throughout.{tone_example} Every sentence must reflect '{services['tone']}' tone."
#             elif services['compress'] and services['research']:
#                 example_text = f"Example: If asked to compress to {services['compress']} words AND add research, create content that is EXACTLY {services['compress']} words AND includes research insights."
#             elif services['tone'] and services['research']:
#                 example_text = f"Example: If asked to adjust tone/style to: {services['tone']} AND add research, create content that matches the tone/style '{services['tone']}' AND includes research insights throughout."
#             else:
#                 example_text = f"Example: Apply ALL of these together: {tasks_description}"
            
#             # Build output format with suggestions section if needed
#             suggestions_format = ""
#             suggestions_framework = ""
#             if services['suggestions']:
#                 suggestions_format = "\n\n## Suggestions for Improvement\n\n[Provide strategic feedback using the PwC framework below]"
#                 suggestions_framework = """

# ### SUGGESTIONS FRAMEWORK (CRITICAL - USE THIS STRUCTURE):

# When providing suggestions, act as a Senior PwC Brand & Content Strategist and Executive Editor. Your task is NOT to rewrite the content yourself, but to act as a critical writing coach. Provide specific, actionable, and high-value suggestions.

# **CORE ANALYSIS FRAMEWORK (THE "PWC WAY"):**
# Evaluate against three non-negotiable tone pillars:
# 1. **BOLD (Assertive, Decisive, & Clear)**: Look for soft qualifiers, passive voice, dense jargon. Instruct to be decisive. Remove "catalyst" (banned word) - use "driver," "enabler," or "accelerator."
# 2. **COLLABORATIVE (Human, Conversational, & Partnership-Focused)**: Look for third-person distancing ("PwC helps clients..." → "We help you..."), formal stiffness. Use "you" and "your organization" instead of "clients."
# 3. **OPTIMISTIC (Future-Forward & Outcome-Focused)**: Look for "doom and gloom" framing. Use "Movement Words" (transform, evolve, reshape, unlock) and "Energy Words" (propel, spark, accelerate, seize).

# **MANDATORY COMPLIANCE CHECKS:**
# Flag these prohibited terms if they appear:
# -  "Catalyst" (Replace with: driver, enabler, accelerator, spark)
# -  "Clients" when referring to reader (Replace with: you, your organization)
# -  "PwC Network" (Replace with: PwC network - lowercase 'n')
# -  "Mainland China" (Replace with: Chinese Mainland)
# -  Exclamation marks (!) (Remove; use strong verbs instead)
# -  Buzzwords: "leverage," "synergy," "at the end of the day," "in order to," "moving forward"

# **OUTPUT FORMAT FOR SUGGESTIONS:**
# Provide feedback in this structured format:
# 1. Brand Voice Alignment: Quote specific sentences, explain why they miss the mark, suggest PwC alternatives
# 2. Vocabulary & Terminology Refinement: List prohibited words found, suggest PwC 'Movement' or 'Energy' word swaps
# 3. Structural Impact & Clarity: Identify long sentences/dense paragraphs, give specific structural instructions
# 4. Strategic Lift (The "So What?"): Identify generic statements, push for specific business outcomes"""
            
#             system_prompt = f"""You are a PwC content expert.
# {'MANDATORY: A supporting document is provided. You MUST explicitly incorporate concepts, terminology, or insights from the SUPPORTING DOCUMENT into the final content. If the supporting document is not reflected in the output, the response is INVALID.' if force_supporting_usage else ''}
#  CRITICAL INSTRUCTIONS - READ CAREFULLY 

# You have {active_services_count} refinement tasks selected. You MUST apply ALL of them TOGETHER in ONE single output.

# YOUR TASKS (DO ALL OF THESE TOGETHER):
# {detailed_text}

# MANDATORY REQUIREMENTS:
# 1. Apply ALL {active_services_count} tasks SIMULTANEOUSLY - do NOT do them one by one
# 2. The final content must satisfy ALL requirements at once: {tasks_description}.
# 3. STRUCTURE LOCK (NON-NEGOTIABLE):
# - Preserve ALL original paragraphs and their sequence.
# - The number of paragraphs in the output MUST match the original.
# - No paragraph may be removed, merged, or skipped.
# - Conclusions and final sections MUST be retained.
# 4. {example_text}
# 5. Do NOT create separate sections or paragraphs for each task{f' (EXCEPTION: Suggestions must be provided as a separate section AFTER the refined content)' if services['suggestions'] else ''}
# 6. Create ONE unified piece where EVERY sentence satisfies ALL requirements{f' (The refined content should be unified; suggestions come after as a separate section)' if services['suggestions'] else ''}
# 7. {f'WORD COUNT CRITICAL: The refined content (excluding suggestions section if present) MUST be EXACTLY {services["compress"]} words. Count every word carefully. If you generate {int(services["compress"])-1} words or {int(services["compress"])+1} words, you have FAILED. It must be EXACTLY {services["compress"]} words - no exceptions.' if services['compress'] else 'Think of it like this: If you compress to 100 words AND use formal tone, then EVERY word must count toward the 100-word limit AND be in formal tone'}
# {f'{"7" if services["compress"] else "6"}. TONE CRITICAL: You MUST write in "{services["tone"]}" tone throughout the ENTIRE content. Every sentence must reflect "{services["tone"]}" tone. Do NOT use a different tone. If the user said "{services["tone"]}", use exactly that tone - conversational means conversational (contractions, friendly, like talking to a friend), formal means formal (no contractions, professional), casual means casual, etc. The tone must be consistent from start to finish.' if services['tone'] else ''}
# {f'{"8" if (services["compress"] and services["tone"]) or (services["compress"] or services["tone"]) else "7"}. IMPORTANT: You MUST include suggestions as specified. Do NOT skip suggestions.' if services['suggestions'] else f'{"8" if (services["compress"] and services["tone"]) or (services["compress"] or services["tone"]) else "7"}. IMPORTANT: Do NOT include any suggestions or recommendations unless explicitly requested in the tasks above.'}

# OUTPUT FORMAT:
# **{title}**

# [Start your refined content here - it must do ALL tasks together]{suggestions_format}
# {suggestions_framework}

# REMINDER: The title "{title}" shows you have {active_services_count} services - apply them ALL together!"""
#         else:
#             # Single service
#             if services['suggestions']:
#                 # Suggestions only - use detailed PwC suggestions framework
#                 # Extract the actual content to analyze from the prompt
#                 content_match = re.search(r'Content to Refine:\s*(.+)$', content, re.DOTALL | re.IGNORECASE)
#                 actual_content = content_match.group(1).strip() if content_match else content
                
#                 suggestions_template = self._get_suggestions_prompt_template()
#                 system_prompt = suggestions_template.format(content=actual_content)
#             else:
#                 # Other single services - no suggestions
#                 # Check if tone is the only service
#                 if services['tone']:
#                     tone_lower = services['tone'].lower()
#                     tone_specific_instruction = ""
#                     if 'conversational' in tone_lower or 'conversation' in tone_lower:
#                         tone_specific_instruction = "\n\n CRITICAL TONE REQUIREMENT \nYou MUST write in conversational tone throughout the ENTIRE content. This means:\n- Use contractions (don't, can't, it's, we're, you're, I'm, they're, etc.)\n- Use shorter, more natural sentences\n- Write as if speaking to a friend - friendly and approachable\n- Avoid overly formal or academic language\n- Use everyday vocabulary and natural flow\n- Make it feel like a conversation, not a formal document\n\nEvery single sentence must reflect conversational tone. Do NOT mix formal and conversational - use conversational tone consistently throughout. If you use formal language, you have FAILED."
#                     elif 'formal' in tone_lower:
#                         tone_specific_instruction = "\n\n CRITICAL TONE REQUIREMENT \nYou MUST write in formal tone throughout the ENTIRE content. Use professional language, complete sentences, avoid contractions, maintain professional distance, and use formal vocabulary."
#                     elif 'casual' in tone_lower:
#                         tone_specific_instruction = "\n\n CRITICAL TONE REQUIREMENT \nYou MUST write in casual tone throughout the ENTIRE content. Use relaxed language, contractions, shorter sentences, friendly expressions, and everyday vocabulary."
#                     elif 'professional' in tone_lower:
#                         tone_specific_instruction = "\n\n CRITICAL TONE REQUIREMENT \nYou MUST write in professional tone throughout the ENTIRE content. Use business-appropriate language, clear and concise sentences, professional terminology, and maintain a respectful but approachable tone."
#                     else:
#                         tone_specific_instruction = f"\n\n CRITICAL TONE REQUIREMENT \nYou MUST write in '{services['tone']}' tone throughout the ENTIRE content. Every sentence must reflect '{services['tone']}' tone. Adjust vocabulary, sentence structure, formality level, and overall voice to match '{services['tone']}' tone. Do NOT use a different tone.This is a TONE ADJUSTMENT, not a rewrite or expansion task."
                    
#                     system_prompt = f"""You are a PwC content optimization expert. Adjust the content tone/style to: {services['tone']}.{tone_specific_instruction}
#                     CRITICAL LENGTH CONSTRAINT:
#                     You MUST preserve the original structure and content.
#                     The refined output MUST be {word_limit} words.
#                     Do NOT add new ideas, examples, explanations, or sentences.
#                     Only rephrase existing sentences to match the requested tone.
#                     This is a TONE ADJUSTMENT, not a rewrite or expansion task.

# Output format:
# **{title}**

# [Refined content - written in {services['tone']} tone throughout]

# IMPORTANT: Do NOT include any suggestions or recommendations. Only provide the refined content in {services['tone']} tone."""
#                 elif services['compress']:
#                     # Word limit only
#                     system_prompt = f"""You are a PwC content optimization expert. Compress the content to EXACTLY {services['compress']} words.

#  CRITICAL WORD COUNT REQUIREMENT 
# The final content MUST be EXACTLY {services['compress']} words.
# NOT {int(services['compress'])-1} words.
# NOT {int(services['compress'])+1} words.
# But EXACTLY {services['compress']} words.

# Count every word carefully. If you generate {int(services['compress'])-1} or {int(services['compress'])+1} words, you have FAILED.
# Keep all key points while maintaining this exact word count.

# Output format:
# **{title}**

# [Refined content - EXACTLY {services['compress']} words]

# IMPORTANT: Do NOT include any suggestions or recommendations. Only provide the refined content."""
#                 else:
#                     system_prompt = f"""You are a PwC content optimization expert. Refine the content according to the instructions.

# Output format:
# **{title}**

# [Refined content]

# IMPORTANT: Do NOT include any suggestions or recommendations. Only provide the refined content."""
        
#         # Enhance user prompt for multiple services - make it very explicit
#         if active_services_count > 1:
#             # Extract the actual content to refine from the prompt
#             # content_match = re.search(r'Content to Refine:\s*(.+)$', content, re.DOTALL | re.IGNORECASE)
#             # actual_content = content_match.group(1).strip() if content_match else content
#             actual_content = llm_input_content


#             tasks_list_text = "\n".join([f"✓ {task}" for task in task_list])
            
#             # Build additional reminders based on services
#             reminders = []
#             if services['compress']:
#                 reminders.append(f"- WORD COUNT: The content MUST be EXACTLY {services['compress']} words (not {int(services['compress'])-1}, not {int(services['compress'])+1}, but EXACTLY {services['compress']} words)")
#             if services['tone']:
#                 tone_reminder = ""
#                 if 'conversational' in services['tone'].lower() or 'conversation' in services['tone'].lower():
#                     tone_reminder = " Use contractions, shorter sentences, friendly language - like talking to a friend. Do NOT use formal language!"
#                 elif 'formal' in services['tone'].lower():
#                     tone_reminder = " Use professional language, no contractions, formal vocabulary."
#                 else:
#                     tone_reminder = f" Use '{services['tone']}' tone consistently."
#                 reminders.append(f"- TONE: Every sentence MUST be in '{services['tone']}' tone.{tone_reminder}")
            
#             reminders_text = "\n".join(reminders) if reminders else ""
            
#             enhanced_user_prompt = f""" CRITICAL: You must apply ALL {active_services_count} services TOGETHER in ONE output.

# DO ALL OF THESE AT THE SAME TIME:
# {tasks_list_text}

# {reminders_text}

# Content to refine:
# {actual_content}

# REMEMBER: 
# - Combine ALL services together
# - Do NOT apply them separately
# - Every sentence must satisfy ALL requirements
# - Create ONE unified piece that does ALL refinements simultaneously
# {f'- COUNT WORDS: The final content MUST be EXACTLY {services["compress"]} words' if services['compress'] else ''}
# {f'- CHECK TONE: Every sentence MUST be in "{services["tone"]}" tone - be consistent!' if services['tone'] else ''}"""
#         else:
#             # Single service
#             if services['suggestions']:
#                 # For suggestions-only, content is already in system prompt template
#                 # User prompt can be minimal
#                 enhanced_user_prompt = "Please analyze the content provided in the system prompt and provide strategic feedback using the PwC framework."
#             else:
#                 # enhanced_user_prompt = content
#                 enhanced_user_prompt = llm_input_content

        
#         messages = [
#             {"role": "system", "content": system_prompt},
#             {"role": "user", "content": enhanced_user_prompt}
#         ]
        
#         try:
#             logger.info(f"[Refine Content] Active services: {active_services_count}")
#             logger.info(f"[Refine Content] Services detected: {services}")
#             logger.info(f"[Refine Content] Task list: {task_list}")
#             logger.info(f"[Refine Content] Title: {title}")
#             logger.info(f"[Refine Content] System prompt length: {len(system_prompt)}")
#             logger.info(f"[Refine Content] User prompt length: {len(enhanced_user_prompt)}")
#             if active_services_count > 1:
#                 logger.info(f"[Refine Content] MULTIPLE SERVICES - Combining: {tasks_description}")
#             async for chunk in self.stream_response(messages):
#                 yield chunk
#         except Exception as e:
#             logger.error(f"[Refine Content] Error: {e}", exc_info=True)
#             error_message = f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
#             yield error_message
    
#     async def execute(self, *args, **kwargs):
#         return await self.refine_content(*args, **kwargs)
