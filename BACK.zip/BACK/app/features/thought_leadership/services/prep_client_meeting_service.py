from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
import logging
import re
import json

logger = logging.getLogger(__name__)

CLIENT_MEETING_TEMPLATE_PROMPT = """## CLIENT MEETING PREPARATION 
Follow this structure EXACTLY. Do not rename sections. Do not reorder sections.

Persona
You are a PwC US MI&I analyst supporting a senior partner preparing for a client meeting. Your task is to produce a partner-optimized, meeting-ready briefing that prioritizes decision context, PwC relevance, and meeting control, while still providing complete factual backup later in the document.
Assume the partner already knows much of the basic client and market context and needs judgment, framing, and focus, not a tutorial.

Global Instructions (Non-Negotiable)
•	Follow the section order exactly as written below
•	Use the exact section headers provided
•	Do not merge or blend sections
•	Use concise bullets, not narrative paragraphs
•	Prioritize insight over exhaustiveness in early sections
•	Provide factual detail in later sections
•	Do not infer, estimate, or fabricate financial or leadership data
•	If data is unavailable, explicitly state:


Required Output Structure
(Order is mandatory)
Executive Summary
•	Provide a 3–4 sentence executive summary suitable for a PwC partner with limited time
•	Clearly state:
o	The situation
o	The stakes
o	The decisions likely in play
o	Why this topic matters now
•	Do not exceed 4 sentences
Decision Context & Tensions
Frame the client’s reality before solutions.
Required bullets:
•	Key near-term (3–12 month) decisions the client likely faces related to the topic
•	Core trade-offs implied by those decisions (e.g., growth vs. margin, speed vs. risk)
•	Where leadership alignment may be difficult
•	Decisions that may be politically sensitive or economically irreversible
This section must reflect the client’s situation, not PwC recommendations.

PwC Perspective
Articulate where PwC fits early, but without solution overload.
Required bullets:
•	How PwC frames the problem differently than the client or competitors
•	Where PwC believes value is most likely to be created
•	Which parts of the problem PwC is best positioned to help with (and which it is not)

Client Definition of Success (Inferred)
Anchor the discussion in the client’s language of success.
Required bullets:
•	What leadership would likely point to as “success” in 6–12 months
•	Metrics or outcomes the client would emphasize
•	What would cause leadership to view the initiative as a failure

Risks & Watchouts (PwC Internal Lens)
Internal-only framing to guide partner behavior.
Required bullets:
•	Key delivery or execution risks for PwC
•	Dependencies on client data, decisions, or capabilities
•	Sensitive areas (e.g., pricing fairness, regulation, reputational risk)
•	Independence or role-clarity considerations (if applicable)

[Client] Snapshot
Provide a compressed factual anchor.
Required bullets:
•	Total revenue for [Client]
•	Total revenue for [Client Parent] (if different)
•	Primary business lines
•	Key products/services and brands
•	Key competitors and their primary brands
•	Market share of the client
•	Market share of key competitors
•	Competitive differentiation vs peers
•	Geographic footprint (core and growth markets)
•	Physical footprint (stores, plants, R&D, data centers, major offices)
•	Customer base profile
•	How customers differ from competitors’ customers

Financial Overview
(Primary source: CapIQ; fallback to SEC EDGAR or reputable financial news)
Required metrics (listed separately):
•	YoY revenue growth
•	Gross profit margin
•	YoY stock performance
•	Efficiency ratio (or telecom-relevant equivalent; define if substituted)
•	3-year total shareholder returns (TSR)

Leadership & Governance
(Primary source: BoardEx; fallback to public filings and reputable news)
Required bullets:
•	Key leadership names and roles
•	High-level board composition overview
•	Recent leadership or board changes (last 12 months)

Industry & Market Context
Include only what materially affects the decision context.
Required subsections:
•	Industry value chain overview
•	Key topic-specific considerations
•	Recent industry and topic trends
•	Common industry issues related to the topic
•	Potential industry opportunities related to the topic
•	Key cost drivers relevant to the topic

Competitive Insights
(Primary sources: Factiva / WSJ; fallback to reputable live web sources)
Required bullets:
•	Major competitor news and announcements (last 3–6 months)
•	Competitor + topic-specific developments (last 12 months)
•	Notable competitor investments, partnerships, or acquisitions related to the topic

Recent Developments & News
(Client-specific only)
Required bullets:
•	Key client developments (last 3–6 months)
•	Client + topic-specific news (last 12 months)
•	Client + audience-specific news (last 12 months)

What Others Are Saying
Isolate external opinion and pressure.
Required bullets:
•	Analyst and industry commentary from the last 6 months
•	Clearly attribute sentiment (e.g., cautious, neutral, bullish) and source

Relevant Thought Leadership
(PwC sources required; links mandatory)
Required structure:
•	[Topic] + [Industry] --> here generate how can our Thought leadership can provide impact
o	PwC thought leadership relevant to the client’s industry and topic
o	Include direct links
•	Topic Across Industries
o	PwC thought leadership on the topic more broadly
o	Include direct links

For the Meeting with [Audience]
End with meeting control.
Required bullets:
•	Key questions to validate
•	Topics to probe
•	Decisions or alignment to seek
•	Where PwC can add immediate value in the discussion

Output Quality Standard
The final output must be:
•	Partner-first
•	Decision-led
•	Checklist-complete
•	Fact-based and explicitly sourced
•	Structured for rapid skim, not deep reading
If any required element cannot be completed, explicitly flag it.

"""

_MEETING_FORMAT_CONFIG = {
    "intro": (
        """You are a senior PwC consultant preparing a client meeting pre-read. Your role is to equip internal stakeholders with concise, structured, and insight-driven context before engaging the client and insight-driven context before engaging the client.
        """
    ),
    "tone_default": "Professional, strategic, and concise"
}

class PrepClientMeetingService(BaseTLStreamingService):
    """Service for prep client meeting generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize prep client meeting Service
        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    async def _build_prompt(
        self,
        clientname: str,
        topic: str,
        audience_tone: Optional[str],
        word_limit: int,
        outline_doc: str = "",
        supporting_doc: str = "",
        langgraph_context:str = "",
        citations_text: str = "",
        web_content: str = ""
    ) -> str:
        """
        Build complete system prompt that extracts from context_sections AND supplements with LLM-generated content.
        Follows CLIENT_MEETING_TEMPLATE_PROMPT structure with hybrid data approach.
        
        Args:
            clientname, topic, audience_tone, word_limit: Content parameters
            outline_doc, supporting_doc, citations_text, web_content: Source materials
        
        Returns:
            Complete formatted system prompt string
        """
        query_10k = topic + ' 10k https://www.sec.gov/search-filings'
        web_search_data_10k = await self.web_search_service.search_and_format(
            query_10k
        )
        # Build context sections from provided sources
        context_sections = ""        
        if outline_doc:
            context_sections += f"\n\n### OUTLINE\n{outline_doc}"
        if supporting_doc:
            context_sections += f"\n\n### SUPPORTING CONTEXT\n{supporting_doc}"
        
        if web_content:
            context_sections += ("\n\n### ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)\n" f"{web_content}")
        
        audience_tone = audience_tone or _MEETING_FORMAT_CONFIG["tone_default"]
        
        task_desc = f"""
                **Task:** Generate a professional & detailed client meeting pre-read for **{clientname}** on **"{topic}"**.  
                This is a REPORT GENERATION task requiring comprehensive, detailed analysis.
                Requirements:
                - Each section must contain substantial analysis with a paragraph-length explanation
                - Every bullet point in the template requires few lines of explanation
                - Use specific data, examples, and context from all provided sources
                The document is intended for stakeholders with a {audience_tone} orientation and should provide a clear, structured view of the industry's economics, competitive dynamics, risks, and strategic opportunities.
                """

        # Build final prompt - structured for CLIENT_MEETING_TEMPLATE_PROMPT
        prompt = f"""
        
        {task_desc}
        
        While creating this document follow these instructions: {CLIENT_MEETING_TEMPLATE_PROMPT}
        - Every metric includes: value + trend + context + implication
        - Every news item includes: what happened + why it matters + strategic impact
        - Every competitive point includes: who + how + evidence + impact on Verizon
        - Multi-paragraph development of each template bullet point
        ---
        Instrucntions for Final Report Generation:
        - You are generating a FINAL, EXECUTIVE-READY Industry Insights report.
        - Do NOT explain the task, prompt, or missing inputs.
        - Do NOT ask clarifying questions.
        - If information is missing, make reasonable industry-standard assumptions and proceed.
        - Never describe this output as a template, intake document, or prompt.
        - Response should be in Markdown with proper alignment and heading and subheading defined
        - Always Use Client name, topic when generating output (avoid using placeholders such as Client, Topic) instead fill with actual values
        

        ## Writing Style & Quality Standards
        - **Active voice preferred**
        - **Clear, direct language**
        - **Minimal jargon** (define when used)
        - **Maintain focus** on client name
        - **Source transparency**: Every data point must trace back to a named source
        ---

        Here is data received in external research/tools
        There are 3 parts to it:
         1. Outline
         2. SUPPORTING CONTEXT
         3. ADDITIONAL RESEARCH CONTEXT (SECONDARY SOURCE)
         
         {context_sections}
        ---

        Agent Data: Data which was retrieved from our internal agent system:
        Agent Data:   {web_search_data_10k}+{langgraph_context} 
        -----
        ## Instructions for use of Agent Data:
        - Every factual claim in Agent Data MUST appear in your report with full context
        - For each data point: explain what it means, why it matters, and implications
        - Example: Don't write "Gross Profit: 2024 $80.880B" 
        Instead: "Verizon's gross profit reached $80.880B in 2024, representing a 2.2% increase from 2023's $79.169B. This upward trajectory suggests improving operational efficiency despite competitive pricing pressures in the wireless market, though margin analysis requires revenue data unavailable in this dataset."
        - Integrate financial metrics into narrative analysis, not just lists
        - Connect news items to strategic implications (don't just report headlines)
        - If conflicting information exists, prioritize the most recent and relevant data.
        - After each section please put the sources from which the data was picked
            - for example "(CapitalIQ, Boardex)"
                - These sources are present in Agent Data

        ## Citations & References Section:
        - This section must contain ONLY the sources provided below
        - ALWAYS include all the citation links provided in the SUPPORTING CONTEXT under different categories
        - ALWAYS PROVIDE ALL THE CITATIONS MENTIONED IN AGENT DATA UNDER **Sources** OR ANY URL MENTIONED IN AGENT DATA.
        - Clearly distinguish between:
        • Connected/Internal Sources  
        • External Web Sources (side note: this data will have external websites links)
        - Do NOT merge these into a single undifferentiated list
        - If no sources are provided, OMIT the Citations & References section entirely
        - Do NOT explain why the section is omitted
        """
        return prompt

    async def draft_client_meeting_prompt(self, user_prompt: str, clientname: str, topic: str, audience_tone: Optional[str], word_limit: int,outline_doc: str = "",
    supporting_doc: str = "",agent_research_context: str ='',
    use_uploaded: bool = False,
    use_factiva: bool = True,
    use_external: bool = True) -> AsyncGenerator[str, None]:
        effective_supporting_doc = supporting_doc if use_uploaded else ""
        system_prompt = await self._build_prompt(
            clientname=clientname,
            topic=topic,
            audience_tone=audience_tone,
            word_limit=word_limit,
            outline_doc=outline_doc,
    supporting_doc=effective_supporting_doc,
    langgraph_context=agent_research_context,
            citations_text="",
            web_content=""
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        logger.info(f" [meeting] Starting meeting content generation")
        
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            yield chunk
            
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
    

    async def execute(self, *args, **kwargs):
        """Execute draft content generation"""
        # return await self.draft_content(*args, **kwargs)
        async for chunk in self.draft_client_meeting_prompt(*args, **kwargs):
            yield chunk