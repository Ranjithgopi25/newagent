"""
Utility functions for managing default audience and tone values.
Provides default audience/tone combinations based on content type.
"""

import logging

logger = logging.getLogger(__name__)


def get_default_audience_tone(content_type: str) -> dict:
    """
    Get default audience and tone values based on content type.
    
    Args:
        content_type: Type of content (Article, Blog, Executive Brief, White Paper)
    
    Returns:
        dict: Contains 'audience_tone', 'audience', and 'tone' keys with appropriate defaults
    """
    
    defaults = {
        'Article': {
            'audience_tone': 'General or niche, Informative/analytical',
            'audience': 'General or niche',
            'tone': 'Informative/analytical'
        },
        'Blog': {
            'audience_tone': 'Broad online audience, Conversational',
            'audience': 'Broad online audience',
            'tone': 'Conversational'
        },
        'Executive Brief': {
            'audience_tone': 'Executives, Decision-makers, experts, Formal & concise',
            'audience': 'Executives, Decision-makers, experts',
            'tone': 'Formal & concise'
        },
        'White Paper': {
            'audience_tone': 'Decision-makers, experts, Formal & authoritative',
            'audience': 'Decision-makers, experts',
            'tone': 'Formal & authoritative'
        }
    }
    
    # Get default for content type, with fallback to Article if type not recognized
    default = defaults.get(content_type, defaults['Article'])
    
    logger.info(
        f"[Audience/Tone Defaults] Applied default for content_type='{content_type}': "
        f"audience_tone='{default['audience_tone']}'"
    )
    
    return default


def apply_audience_tone_defaults(
    content_type: str, 
    user_provided_audience_tone: str = None
) -> str:
    """
    Apply default audience/tone if user didn't provide one.
    Logs whether user-provided or default value is being used.
    
    Args:
        content_type: Type of content
        user_provided_audience_tone: User-provided audience/tone value (can be None or empty string)
    
    Returns:
        str: The audience/tone value to use (user-provided or default)
    """
    
    if user_provided_audience_tone and user_provided_audience_tone.strip():
        # User provided a value - use it
        logger.info(
            f"[Audience/Tone] Using user-provided value: '{user_provided_audience_tone.strip()}'"
        )
        return user_provided_audience_tone.strip()
    
    # User didn't provide - apply default
    default = get_default_audience_tone(content_type)
    audience_tone = default['audience_tone']
    
    logger.info(
        f"[Audience/Tone] User did not provide audience/tone. "
        f"Applied default for content_type='{content_type}': '{audience_tone}'"
    )
    
    return audience_tone
