from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from app.features.thought_leadership.schemas.extended import UpdateSectionRequest
from app.features.thought_leadership.services.update_section_service import UpdateSectionService
from app.core.deps import get_tl_service
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def update_section_workflow(
    request: UpdateSectionRequest,
    service: UpdateSectionService = Depends(get_tl_service(UpdateSectionService))
):
    """Canvas Update Section: Update a specific section based on user instructions"""
    try:
        logger.info(f"[Update Section] Content Type: {request.contentType}")
        logger.info(f"[Update Section] Section Index: {request.sectionIndex}")
        logger.info(f"[Update Section] User Prompt: {request.userPrompt[:100]}...")
        
        return StreamingResponse(
            service.update_section(
                request.fullArticle,
                request.sectionContent,
                request.userPrompt,
                request.contentType
            ),
            media_type="text/event-stream"
        )
    except Exception as e:
        logger.error(f"[Update Section] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
