from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
from app.features.thought_leadership.services.edit_content.graph import build_sequential_graph
from app.features.thought_leadership.services.edit_content.utils import segment_document_with_llm
from app.features.thought_leadership.services.edit_content_service import EditContentService
from app.core.deps import get_tl_service
import logging
import json

router = APIRouter()
logger = logging.getLogger(__name__)

class EditContentRequest(BaseModel):
    messages: List[dict]
    editor_types: List[str] = []
    temperature: Optional[float] = None
    max_tokens: Optional[int] = 32000
    

class FinalArticleRequest(BaseModel):
    original_content: str
    paragraph_edits: List[dict]
    decisions: List[dict]  # List of {index: int, approved: bool}

class CombineSelectedServicesRequest(BaseModel):
    original_content: str
    paragraph_edits: List[dict]
    selected_services: List[str]  # e.g., ['development', 'content']
    temperature: Optional[float] = 0.0
    max_tokens: Optional[int] = 32000

class AgentEditRequest(BaseModel):
    content: str
    editor_types: List[str] = []  # e.g., ['development', 'content', 'line', 'copy', 'brand']
    temperature: Optional[float] = 0.0
    max_tokens: Optional[int] = 32000

# @router.post("")
# async def edit_content_workflow(
#     request: EditContentRequest,
#     service: EditContentService = Depends(get_tl_service(EditContentService))
# ):
#     """Edit Content workflow: Brand alignment, copy editing, line editing, content editing"""
#     try:
#         if not request.messages:
#             raise HTTPException(status_code=400, detail="Messages cannot be empty")
        
#         content = request.messages[-1].get('content', '')
#         if not content or not content.strip():
#             raise HTTPException(status_code=400, detail="Content cannot be empty")

#         editor_types = request.editor_types or []
#         temperature = request.temperature if request.temperature is not None else 0.0
#         top_p = 1.0
#         frequency_penalty = 0.0
#         presence_penalty = 0.0
#         max_tokens = request.max_tokens if request.max_tokens is not None else 32000

#         # Calculate word and token count
#         word_count = len(content.split())
#         # Simple token estimate: 1 token ≈ 0.75 words (OpenAI guideline)
#         token_estimate = int(word_count / 0.75)
#         logger.info(f"[Edit Content] Uploaded document: {word_count} words, ~{token_estimate} tokens.")

#         logger.info(f"[Edit Content] Editor Types: {editor_types if editor_types else 'all editors (default)'}, "
#                    f"Temperature: {temperature}, f'max_tokens: {max_tokens}")

#         return StreamingResponse(
#             service.edit_content(content, editor_types, temperature, top_p, frequency_penalty, presence_penalty, max_tokens=max_tokens),
#             media_type="text/event-stream"
#         )
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"[Edit Content] Error: {e}", exc_info=True)
#         raise HTTPException(status_code=500, detail="An error occurred while editing content")

@router.post("/final")
async def generate_final_article(
    request: FinalArticleRequest,
    service: EditContentService = Depends(get_tl_service(EditContentService))
):
    """Generate final article using approved edits and original text for declined paragraphs"""
    try:
        if not request.original_content:
            raise HTTPException(status_code=400, detail="Original content cannot be empty")
        
        if not request.paragraph_edits:
            raise HTTPException(status_code=400, detail="Paragraph edits cannot be empty")
        
        if not request.decisions:
            raise HTTPException(status_code=400, detail="Decisions cannot be empty")
        
        logger.info(f"[Final Article] Generating final article with {len(request.paragraph_edits)} paragraphs, {len(request.decisions)} decisions")
        
        final_article = await service.generate_final_article(
            request.original_content,
            request.paragraph_edits,
            request.decisions
        )
        
        return JSONResponse(content={
            "final_article": final_article
        })
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Final Article] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred while generating final article")



# @router.post("/agent-edit")
# async def edit_content_workflow(
#     request: AgentEditRequest,
#     # service: EditContentService = Depends(get_tl_service(EditContentService))
# ):
#     """
#     Edit Content workflow using supervisor agent architecture.
#     Coordinates multiple specialized sub-agents (development, content, line, copy, brand editors).
    
#     Request body:
#     {
#         "content": "Document content to edit...",
#         "editor_types": ["development", "content"],  // Optional, defaults to all editors
#         "temperature": 0.0,
#         "max_tokens": 32000
#     }
#     """
#     try:
#         if not request.content or not request.content.strip():
#             raise HTTPException(status_code=400, detail="Content cannot be empty")
        
#         editor_types = request.editor_types or []
#         temperature = request.temperature if request.temperature is not None else 0.0
#         max_tokens = request.max_tokens if request.max_tokens is not None else 32000
#         logger.info(f"[Agent Edit] Editor Types: {editor_types if editor_types else 'all editors (default)'}, "
#                    f"Temperature: {temperature}, Max Tokens: {max_tokens}")
        
      
        
#         # Segment the document
#         logger.info("[Agent Edit] Segmenting document...")
#         doc_struct = segment_document_with_llm(request.content)
        
#         # Prepare messages for the supervisor agent
#         user_message = doc_struct.model_dump_json()
#         if editor_types:
#             # Add editor types to the message
#             user_message = json.dumps({
#                 "document": doc_struct.model_dump(),
#                 "requested_editors": editor_types
#             })
        
#         logger.info("[Agent Edit] Invoking supervisor agent...")
        
#         # Stream the agent's response
#         async def stream_agent_response():
#             try:
#                 for step in supervisor_agent.stream(
#                     {"messages": [{"role": "user", "content": user_message}]}
#                 ):
#                     for update in step.values():
#                         if isinstance(update, dict):
#                             messages = update.get("messages", [])
#                             for message in messages:
#                                 # Stream the message content
#                                 if hasattr(message, 'content'):
#                                     content = message.content
#                                     # If content is structured, serialize it
#                                     if isinstance(content, dict):
#                                         yield f"data: {json.dumps(content)}\n\n"
#                                     else:
#                                         yield f"data: {json.dumps({'content': str(content)})}\n\n"
#                         else:
#                             # Handle interrupts or other updates
#                             yield f"data: {json.dumps({'update': str(update)})}\n\n"
                
#                 yield "data: [DONE]\n\n"
#             except Exception as e:
#                 logger.error(f"[Agent Edit] Streaming error: {e}", exc_info=True)
#                 yield f"data: {json.dumps({'error': str(e)})}\n\n"
        
#         return StreamingResponse(
#             stream_agent_response(),
#             media_type="text/event-stream"
#         )
        
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"[Agent Edit] Error: {e}", exc_info=True)
#         raise HTTPException(status_code=500, detail=f"An error occurred while processing with agent: {str(e)}")
