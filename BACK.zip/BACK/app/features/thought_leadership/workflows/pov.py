from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.pov_service import POVService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.deps import get_tl_service, get_factiva_client, get_settings, get_llm_service
from app.common.factiva_client import FactivaClient
from app.core.config import Settings, config
from app.infrastructure.llm.llm_service import LLMService
from app.utils.market_intelligence_agent.graph import get_market_insights
import logging
import re
import json

router = APIRouter()
logger = logging.getLogger(__name__)

class POVRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    improvement_prompt: Optional[str] = None  
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[str] = None
    audience_tone: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_factiva_research: Optional[bool] = None
    services: Optional[Dict[str, Any]] = None  # Add support for structured services payload
    #additional_guidelines: Optional[str] = None
    use_research: Optional[bool] = False


class SatisfactionAnalysisRequest(BaseModel):
    """Request to analyze user satisfaction with generated content"""
    user_input: str
    generated_content: str
    content_type: str
    topic: str


class SatisfactionAnalysisResponse(BaseModel):
    """Response from satisfaction analysis"""
    is_satisfied: bool
    confidence: float  # 0.0 to 1.0
    reasoning: str
    improvement_suggestions: Optional[str] = None


def extract_research_info(content: str) -> dict:
    """Extract research-related information from content."""
    research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)
    research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
    research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
    additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
    
    return {
        'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,
        'topics': research_topics.group(1).strip() if research_topics else None,
        'sources': research_sources.group(1).strip() if research_sources else None,
        'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
    }

def should_use_langgraph_agent(sources: str) -> bool:
    """Check if LangGraph agent should be called"""
    if not sources:
        return False
    
    # Triggers for LangGraph agent with multi-source integration
    triggers = [
        'PwC Content or Link', 
        'PwC Proprietary Research', 
        'PwC Licensed Third Party Tools', 
        'External Research',
        'CapIQ',
        'BoardEx',
        'Financial Data',
        'Corporate Data',
        'Director Data',
        'Advisor Data',
        'Factiva',
        'News',
        'Market Data'
    ]
    
    return any(trigger.lower() in sources.lower() for trigger in triggers)

def should_use_sql_agent(sources: str) -> bool:
    """Check if SQL agent should be called"""
    return sources and 'PwC Licensed Third Party Tools' in sources

def is_improvement_request(improvement_prompt: Optional[str]) -> bool:
    """Check if this is an improvement request"""
    return improvement_prompt is not None and improvement_prompt.strip()

def build_improvement_prompt(original_prompt: str, improvement_feedback: str, original_content: str) -> str:
    """Build enhanced prompt with improvement feedback"""
    improvement_message = f"""This is an improvement iteration. The user has provided specific improvement instructions along with previously generated content. Please apply ONLY the requested improvements while regenerating the entire content.

User Improvement Request:
{improvement_feedback}

Original Generated Content:
{original_content}

Please regenerate the content with the following approach:
1. Read the user's improvement request carefully
2. Preserve the overall structure and length expectations
3. Apply the requested improvements throughout
4. Maintain consistency with the original topic and audience
5. Ensure the improved content flows naturally

{original_prompt}"""
    return improvement_message

@router.post("")
async def pov_workflow(
    request: POVRequest,
    service: POVService = Depends(get_tl_service(POVService)),
    factiva_client: Optional[FactivaClient] = Depends(get_factiva_client),
    settings: Settings = Depends(get_settings)
):
    """POV workflow:"""
    try:
        user_prompt = ""
        if request.messages:
            user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[POV] User prompt length: {len(user_prompt)}")
        logger.debug(f"[POV] Full user prompt:\n{user_prompt}")

        # Check if this is an improvement request
        is_improvement = is_improvement_request(request.improvement_prompt)
        if is_improvement:
            logger.info(f"[POV] Improvement request detected")
            logger.info(f"[POV] Improvement feedback: {request.improvement_prompt}")
        
        # Initialize variables
        content_type = ''
        topic = ''
        word_limit = ''
        audience_tone = ''
        supporting_doc = ''
        outline_doc = ''
        #use_factiva_research = False
        #additional_guidelines = ''
        original_generated_content = ""
        
        # Check if this is an improvement request
        is_improvement = is_improvement_request(request.improvement_prompt)
        if is_improvement:
            logger.info(f"[POV] Improvement request detected")
            logger.info(f"[POV] Improvement feedback: {request.improvement_prompt}")
        
        # For improvement iterations, use provided parameters; otherwise parse from prompt
        if is_improvement and request.content_type:
            logger.info(f"[POV] Using preserved parameters for improvement iteration")
            content_type = request.content_type
            topic = request.topic or ''
            word_limit = request.word_limit or ''
            audience_tone = apply_audience_tone_defaults(content_type, request.audience_tone)
            outline_doc = request.outline_doc or ''
            supporting_doc = request.supporting_doc or ''
            #additional_guidelines = request.additional_guidelines or ''
            #use_factiva_research = request.use_factiva_research or False
            
            logger.info(f"[POV] Improvement iteration params - content_type='{content_type}', topic='{topic}', word_limit='{word_limit}', audience='{audience_tone}'")
        else:
            # First, try to extract from structured services.draft object (NEW UI format)
            if request.services and request.services.get('draft'):
                draft_data = request.services.get('draft', {})
                logger.info(f"[POV] Found structured services.draft object - extracting data")
                
                # Extract content type mapping
                content_type_key = draft_data.get('content_type', '')
                if content_type_key == 'article':
                    content_type = 'Article'
                elif content_type_key == 'blog':
                    content_type = 'Blog'
                elif content_type_key == 'executive_brief':
                    content_type = 'Executive Brief'
                elif content_type_key == 'white_paper':
                    content_type = 'White Paper'
                
                topic = draft_data.get('topic', '')
                word_limit = draft_data.get('word_limit', '')
                audience_tone = draft_data.get('audience_tone', '')
                
                # Extract outline data
                outline_info = draft_data.get('outline', {})
                if outline_info:
                    outline_doc = outline_info.get('content', '')
                
                # Extract supporting documents
                supporting_docs_info = draft_data.get('supporting_documents', {})
                if supporting_docs_info:
                    supporting_doc = supporting_docs_info.get('content', '')
                
                logger.info(f"[POV] Extracted from services.draft - content_type='{content_type}', topic='{topic}', word_limit='{word_limit}', audience_tone='{audience_tone}'")
            else:
                # Fall back to parsing from user_prompt (OLD UI format)
                logger.info(f"[POV] No services.draft found, parsing from user_prompt")
            
            # Parse user prompt for initial draft - support multi-line values
            lines = user_prompt.splitlines()
            i = 0
            while i < len(lines):
                line = lines[i]
                logger.debug(f"[PARSE] Processing line {i}: {repr(line[:80])}")
                
                if line.startswith("Content Type:"):
                    content_type = line.split(":", 1)[1].strip()
                elif line.startswith("Topic:"):
                    topic = line.split(":", 1)[1].strip()
                elif line.startswith("Word Limit:"):
                    word_limit = line.split(":",1)[1].strip()
                elif line.startswith("Audience/Tone:"):
                    audience_tone = line.split(":",1)[1].strip()
                elif line.startswith("Initial Outline/Concept:"):
                    # Capture the rest of the line
                    outline_doc = line.split(":", 1)[1].strip()
                    # If the line is empty after the colon, capture subsequent lines until next field marker
                    if not outline_doc:
                        i += 1
                        outline_lines = []
                        while i < len(lines):
                            next_line = lines[i]
                            # Stop if we hit another field marker
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Supporting Documents:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            # Only add non-empty lines or lines that are part of the outline (indented or start with numbers)
                            if next_line.strip():
                                outline_lines.append(next_line)
                            i += 1
                        outline_doc = "\n".join(outline_lines)
                        i -= 1  # Adjust because the main loop will increment
                    else:
                        # If there's content on the same line, also capture following lines
                        outline_lines = [outline_doc]
                        i += 1
                        while i < len(lines):
                            next_line = lines[i]
                            # Stop if we hit another field marker
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Supporting Documents:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            # Only add non-empty lines or lines that are part of the outline
                            if next_line.strip():
                                outline_lines.append(next_line)
                            i += 1
                        outline_doc = "\n".join(outline_lines)
                        i -= 1  # Adjust because the main loop will increment
                        
                elif line.startswith("Supporting Documents:"):
                    # Capture the rest of the line
                    supporting_doc = line.split(":", 1)[1].strip()
                    # If the line is empty after the colon, capture subsequent lines until next field marker
                    if not supporting_doc:
                        i += 1
                        supporting_lines = []
                        while i < len(lines):
                            next_line = lines[i]
                            # Stop if we hit another field marker
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Initial Outline/Concept:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            # Only add non-empty lines or lines that are part of the documents
                            if next_line.strip():
                                supporting_lines.append(next_line)
                            i += 1
                        supporting_doc = "\n".join(supporting_lines)
                        i -= 1  # Adjust because the main loop will increment
                    else:
                        # If there's content on the same line, also capture following lines
                        supporting_lines = [supporting_doc]
                        i += 1
                        while i < len(lines):
                            next_line = lines[i]
                            # Stop if we hit another field marker
                            if any(next_line.startswith(marker) for marker in 
                                   ["Content Type:", "Topic:", "Word Limit:", "Audience/Tone:", 
                                    "Initial Outline/Concept:", "Additional Guidelines:", "Research Requested:"]):
                                break
                            # Only add non-empty lines or lines that are part of the documents
                            if next_line.strip():
                                supporting_lines.append(next_line)
                            i += 1
                        supporting_doc = "\n".join(supporting_lines)
                        i -= 1  # Adjust because the main loop will increment
                elif line.startswith("Additional Guidelines:"):
                    additional_guidelines = line.split(":",1)[1].strip()
                    
                i += 1

            logger.info(f"[PARSE] Parsed values - Content Type: '{content_type}', Topic: '{topic}', Word Limit: '{word_limit}', Audience: '{audience_tone}', Outline Doc : '{outline_doc}', Supporting Doc: '{supporting_doc[:500]}' ")

        # Extract research information
        research_info = extract_research_info(user_prompt)
        enhanced_user_prompt = user_prompt
        langgraph_context = ""
        research_context = ""
        
        # Check if using graph.py for market intelligence research
        use_graph_py = False
        if request.services and request.services.get('research', {}).get('isSelected'):
            use_graph_py = True
            logger.info(f"[POV] Research service is selected - using graph.py for market intelligence")
        
        # Handle Multi-Source Research Integration
        if use_graph_py:
            # Use graph.py approach for market intelligence
            try:
                logger.info(f"[POV] Initializing graph.py for market intelligence research")
                
                # Build input data for graph.py
                input_data = {
                    "research_topics": research_info['topics'] or topic or "Market trends and insights",
                    "research_guidelines": research_info['additional_guidelines'] or "",
                    "pwc_content": {},
                    "proprietary": {},
                    "thirdParty": {},
                    "externalResearch": {}
                }
                
                # Add pwc_content if selected
                pwc_content = request.services.get('research', {}).get('pwc_content', {})
                if pwc_content.get('isSelected'):
                    input_data["pwc_content"] = {
                        "isSelected": True,
                        "supportingDoc": pwc_content.get('supportingDoc', ''),
                        "supportingDoc_instructions": pwc_content.get('supportingDoc_instructions', ''),
                        "research_links": pwc_content.get('research_links', '')
                    }
                
                # Add proprietary if selected
                proprietary = request.services.get('research', {}).get('proprietary', {})
                if proprietary.get('isSelected'):
                    input_data["proprietary"] = {
                        "isSelected": True,
                        "sources": proprietary.get('sources', [])
                    }

                # Add third party if selected
                thirdparty = request.services.get('research', {}).get('thirdParty', {})
                if thirdparty.get('isSelected'):
                    input_data["thirdParty"] = {
                        "isSelected": True,
                        "sources": thirdparty.get('sources', [])
                    }
                
                # Add externalResearch if selected
                external_research = request.services.get('research', {}).get('externalResearch', {})
                if external_research.get('isSelected'):
                    input_data["externalResearch"] = {
                        "isSelected": True
                    }
                
                logger.info(f"[POV] Calling graph.py with input: {json.dumps(input_data, default=str)}")
                
                # Get market insights from graph.py
                market_insights = get_market_insights(input_data)
                
                if market_insights:
                    logger.info(f"[POV] Graph.py returned market insights {market_insights[:100]}")
                    
                    # Format the market insights into langgraph_context
                    insights_text = json.dumps(market_insights, indent=2, default=str)
                    research_context = f"""

--- Market Intelligence from Multi-Source Research ---
Research Sources:
- PwC Content & Documents
- PwC Proprietary Research Tools
- Licensed Third-Party Data Sources
- External Market Research

{insights_text}

--- End of Market Intelligence ---
"""
                    logger.info("[POV] Market intelligence context added to research")
                else:
                    logger.warning("[POV] Graph.py returned empty insights")
                    
            except Exception as e:
                logger.error(f"[POV] Graph.py error: {e}", exc_info=True)
                logger.warning("[POV] Falling back to default LangGraph Agent approach")
                # Fall back to default agent if graph.py fails
                use_graph_py = False
        
        # Fall back to default LangGraph Agent if not using graph.py
        if True: # not use_graph_py:
            try:
                logger.info(f"[POV] Initializing LangGraph Agent for multi-source query")
                
                # Create LangGraph agent instance
                langgraph_agent = create_data_source_agent(
                    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                    api_key=config.AZURE_OPENAI_API_KEY,
                    api_version=config.AZURE_OPENAI_API_VERSION,
                    deployment_name=config.AZURE_OPENAI_DEPLOYMENT
                )
                
                # Build the query message for the agent
                search_query = research_info['topics'] or topic
                if not search_query:
                    logger.warning("[Meeting] LangGraph search_query is empty — provide 'topic' in the request or include 'Topic:' lines in the prompt")
                additional_guidelines = research_info.get('additional_guidelines') or ''
                logger.info(f"[Meeting][LangGraph] Query: {search_query}")
                agent_messages = [
                    {
                        "role": "user",
                        "content": (
                            f"Research query: {search_query}\n\n"
                            "Please search relevant data sources and provide comprehensive information. "
                            "If a company name is present, include a Financial Overview retrieved from CapitalIQ: "
                            "YoY revenue, gross profit margin, recent stock performance, and a 3-year total shareholder return. "
                            "When returning the research, explicitly call the CapitalIQ tools (query_capitaliq_financials and query_capitaliq_balance_sheet) "
                            "for financial data, and include BoardEx for leadership info and Factiva for recent news. "
                            f"Refer {additional_guidelines}"
                        )
                    }
                ]
                
                logger.info(f"[POV] Calling LangGraph Agent with query: {search_query}")
                
                # Get response from LangGraph agent
                agent_response = await langgraph_agent.process_query(agent_messages)
                
                if agent_response:
                    logger.info(f"[POV] LangGraph Agent returned {len(agent_response)} characters")
                    langgraph_context = f"""

--- Research Results from Multi-Source Data Integration ---
Sources automatically queried by AI Agent:
- Factiva News (external news and media coverage)
- Internal Knowledge Base (company documents and reports)
- CapitalIQ Financials (income statements and balance sheets)
- BoardEx Intelligence (advisors and executive achievements)
- Connected Sources
- Internet
{agent_response}

--- End of Research Results ---
"""
                    logger.info("[POV] LangGraph Agent context added to research")
                else:
                    logger.warning("[POV] LangGraph Agent returned empty response")
                
                # Close agent connections
                langgraph_agent.close()
                
            except Exception as e:
                logger.error(f"[POV] LangGraph Agent error: {e}", exc_info=True)
                # Continue without agent context - don't break the workflow
                logger.warning("[POV] Continuing POV without LangGraph Agent data")

        # Apply default word limits if not provided by user
        word_limit_source = 'user'
        if not word_limit or not word_limit.strip():
            word_limit_source = 'default'
            # Set defaults based on content type (1000 words per page)
            if content_type == 'Perspective':
                word_limit = '2000'
            elif content_type == 'Blog':
                word_limit = '1500'
            elif content_type == 'Executive Brief':
                word_limit = '500'
            elif content_type == 'White Paper':
                word_limit = '5000'
            else:
                word_limit = '2000'

        # Apply default audience/tone if not provided by user
        audience_tone = apply_audience_tone_defaults(content_type, audience_tone)

        # Convert word_limit to int and decrease by 30%
        try:
            word_limit_num = int(word_limit)
            word_limit_int = int(word_limit_num - (word_limit_num * 0.3))
        except (ValueError, TypeError):
            word_limit_int = 2000
            word_limit_source = 'default-conversion-failed'
            logger.warning(f"[POV] Failed to convert word_limit '{word_limit}' to int, using default 2000")

        logger.info(f"[POV] Analytics - content_type={content_type}, word_limit_source={word_limit_source}, word_limit_value={word_limit_int}")

        # if content_type == 'White Paper':
        #     # Use improvement prompt if this is an improvement iteration
        #     final_prompt = enhanced_user_prompt
        #     if is_improvement and original_generated_content:
        #         final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
        #         logger.info(f"[CONTENT GENERATION] Using improvement prompt for White Paper (original content: {len(original_generated_content)} chars)")
        #     
        #     # Add research context if available (now passed as separate parameter)
        #     # research_context will be passed to service method
        #     
        #     # Add LangGraph context if available
        #     if langgraph_context:
        #         supporting_doc += langgraph_context
        #     
        #     return StreamingResponse(
        #         service.pov_whitepaper_system_prompt(
        #             final_prompt, topic, word_limit_int, audience_tone, outline_doc, supporting_doc, research_context
        #         ),
        #         media_type="text/event-stream",
        #         headers={"X-Content-Type": content_type}
        #     )
        
        
        if content_type == 'Article':            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Perspective (original content: {len(original_generated_content)} chars)")
            
            # Add research context if available (now passed as separate parameter)
            # research_context will be passed to service method
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.pov_article_system_prompt(
                    final_prompt, topic, word_limit_int, audience_tone, 
                    outline_doc, supporting_doc, research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        if content_type == 'Blog':
           
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Blog (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            return StreamingResponse(
                service.pov_blog_system_prompt(
                    final_prompt, topic, word_limit_int, audience_tone, outline_doc, supporting_doc, research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        if content_type == 'Executive Brief':

            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Executive Brief (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
                
            return StreamingResponse(
                service.pov_executivebrief_system_prompt(
                    final_prompt, topic, word_limit_int, audience_tone, outline_doc, supporting_doc, research_context
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        else:            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for default content type (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.pov_content_from_prompt(final_prompt, research_context),
                media_type="text/event-stream"
            )
    except Exception as e:
        logger.error(f"[POV] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/analyze-satisfaction", response_model=SatisfactionAnalysisResponse)
async def analyze_satisfaction(
    request: SatisfactionAnalysisRequest,
    llm_service: LLMService = Depends(get_llm_service)
) -> SatisfactionAnalysisResponse:
    """
    Use LLM to analyze whether user is satisfied with generated content.
    
    This is more robust than keyword matching because the LLM can understand:
    - Nuanced responses like "not bad", "could be better", "okay I guess"
    - Context and sentiment
    - Implicit improvement suggestions
    """
    
    logger.info(f"[Satisfaction Analysis] --- ENDPOINT CALLED ---")
    
    prompt = f"""You are analyzing whether a user is satisfied with AI-generated content.

CONTEXT:
- Content Type: {request.content_type}
- Topic: {request.topic}
- Generated Content Preview: {request.generated_content[:500]}...

USER'S RESPONSE: "{request.user_input}"

TASK: Determine if the user is satisfied with the content or if they want improvements.

DECISION RULES (apply in order):

1. EXPLICIT SATISFACTION PHRASES (is_satisfied=true, confidence=0.95):
   - "yes", "yeah", "yep", "looks good", "perfect", "great", "that works", "that's perfect", "love it", "excellent", "exactly what I needed", "approved", "accepted", "ok", "okay", "good job"

2. EXPLICIT IMPROVEMENT/CHANGE REQUESTS (is_satisfied=false, confidence=0.95):
   - Starts with "can you": e.g., "can you make it shorter", "can you concise that article"
   - Contains action verbs: "make it", "make it [adjective]", "add", "remove", "change", "rewrite", "improve", "fix", "shorten", "expand", "simplify"
   - Improvement keywords: "concise", "shorter", "longer", "better", "simpler", "clearer", "more", "less"
   - Explicit negatives: "no", "nope", "don't like", "not happy", "not satisfied"
   - Regeneration requests: "regenerate", "redo", "try again", "different"

3. AMBIGUOUS RESPONSES (analyze context):
   - "okay", "it's fine", "not bad", "could be better", "alright"
   - If contains improvement keywords or action verbs → is_satisfied=false, confidence=0.7
   - If pure acceptance with no action verbs → is_satisfied=true, confidence=0.6

OUTPUT FORMAT (respond ONLY with this JSON, no markdown, no extra text):
{{
    "is_satisfied": true or false,
    "confidence": 0.0-1.0 (float),
    "reasoning": "Brief one-sentence explanation",
    "improvement_suggestions": null or "extracted improvement request"
}}

EXAMPLES:
- Input: "can you concise that article for me" → is_satisfied=false, confidence=0.95, improvement="make it more concise"
- Input: "yes, looks good" → is_satisfied=true, confidence=0.95, improvement=null
- Input: "not bad" → is_satisfied=true, confidence=0.6, improvement=null
- Input: "make it shorter and clearer" → is_satisfied=false, confidence=0.95, improvement="make it shorter and clearer"

Respond ONLY with valid JSON."""

    try:
        response_text = await llm_service.chat_completion(
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert at analyzing user satisfaction with generated content. Respond ONLY with valid JSON, no markdown, no extra text."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3,  # Lower temperature for consistent analysis
            max_tokens=200
        )
        
        logger.info(f"[Satisfaction Analysis] Raw LLM response: {response_text}")
        
        # Parse JSON response
        analysis = json.loads(response_text.strip())
        
        logger.info(f"[Satisfaction Analysis] Parsed JSON: {analysis}")
        logger.info(f"[Satisfaction Analysis] User input: '{request.user_input}'")
        
        return SatisfactionAnalysisResponse(
            is_satisfied=analysis.get("is_satisfied", False),
            confidence=float(analysis.get("confidence", 0.5)),
            reasoning=analysis.get("reasoning", ""),
            improvement_suggestions=analysis.get("improvement_suggestions")
        )
        
    except json.JSONDecodeError as e:
        logger.error(f"[Satisfaction Analysis] JSON Parse Error: {e}")
        logger.error(f"[Satisfaction Analysis] Raw response was: {response_text}")
        # Fallback: treat as not satisfied if we can't parse
        return SatisfactionAnalysisResponse(
            is_satisfied=False,
            confidence=0.3,
            reasoning="Unable to parse analysis, treating as improvement request",
            improvement_suggestions=request.user_input
        )
    except Exception as e:
        logger.error(f"[Satisfaction Analysis] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Satisfaction analysis failed: {str(e)}")