from fastapi import APIRouter, File, UploadFile, Form, HTTPException, Depends
from fastapi.responses import StreamingResponse, JSONResponse
from app.features.thought_leadership.services.format_translator_service import FormatTranslatorService
from app.core.deps import get_tl_service
from app.features.thought_leadership.services.format_translator_service import PlusDocsClient
from app.features.ddc.utils.text_refiner import (
    extract_text_from_any,
    refine_text_for_placemat,
    extract_page_count
)
import logging
from typing import Optional
from app.core.config import get_settings

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def format_translator_workflow(
    uploadedFile: Optional[UploadFile] = File(None),
    content: str = Form(...),
    source_format: str = Form(...),
    target_format: str = Form(...),
    customization: str = Form(None),
    podcast_style: str = Form(None),
    speaker1_name: str = Form(None),
    speaker1_voice: str = Form(None),
    speaker1_accent: str = Form(None),
    speaker2_name: str = Form(None),
    speaker2_voice: str = Form(None),
    speaker2_accent: str = Form(None),
    word_limit: str = Form(None),
    service: FormatTranslatorService = Depends(get_tl_service(FormatTranslatorService))
):
    """Format Translator workflow: Convert content between formats"""    
    try:
        logger.info(f"[Format Translator] {source_format} -> {target_format}, word_limit={word_limit}")        
        file_bytes = await uploadedFile.read()
        raw_text = extract_text_from_any(uploadedFile.filename, file_bytes)
        
        # Only extract page count for Placemat format to avoid NoneType errors for other formats
        placematNumPages = 1  # Default value
        if target_format == "Placemat" and customization and customization.strip():
            placematNumPages = extract_page_count(customization)
        
        if target_format == "Placemat":        
           
           try:
                raw_text_placemat = extract_text_from_any(uploadedFile.filename, file_bytes)
                logger.error(f"[Placemat] raw_text: {raw_text}")
                refined_text = refine_text_for_placemat(raw_text,placematNumPages)
                logger.error(f"[Placemat] refined_text: {refined_text}")
                logger.info("[Placemat] Document text extracted and refined.")
           
           except Exception as e:
                logger.error(f"[Placemat] Extraction/Refinement failed: {e}")
                raise HTTPException(status_code=400, detail="Failed to process uploaded file.")
           
           prompt_parts = []

           prompt_parts.append("User wants to create a placemat. [IMPORTANT] Create the placemat such that it has data and an image on either left or right side of the slide(s).")
           prompt_parts.append("Make sure to use this content "+ refined_text +" for preparing the placemat slide(s)")
           prompt_parts.append(f"""Follow these guidelines while creating the placemat:
                               Distills the content’s key arguments, insights, and takeaways. 
                               Organizes content into a visually appealing layout that prioritizes charts, diagrams, and images. 
                               Refines language to be concise, ensuring quick and effective communication of main ideas. 
                               """)

           prompt = "\n\n".join(prompt_parts).strip()
           settings = get_settings()

           template_id = settings.PLUSDOCS_TEMPLATE_ID
           API_TOKEN = settings.PLUSDOCS_API_TOKEN

           client = PlusDocsClient(API_TOKEN)
           download_url = client.create_and_wait(
            prompt=prompt,
            numberOfSlides= placematNumPages,
            template_id=template_id,
            poll_interval=5,
            max_attempts=60
        )

           if not download_url:
                raise HTTPException(status_code=500, detail="Slide generation failed")
          
           return JSONResponse({
           "target_format":"placemat",
            "status": "success",
            "download_url": download_url
            }) 
            
        
        else:
            return StreamingResponse(
                service.translate_format(
                    content=raw_text,
                    source_format=source_format,
                    target_format=target_format,
                    customization=customization,
                    podcast_style=podcast_style,
                    speaker1_name=speaker1_name,
                    speaker1_voice=speaker1_voice,
                    speaker1_accent=speaker1_accent,
                    speaker2_name=speaker2_name,
                    speaker2_voice=speaker2_voice,
                    speaker2_accent=speaker2_accent,
                    word_limit=word_limit
                ),
                media_type="text/event-stream"
            )
    except Exception as e:
        logger.error(f"[Format Translator] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    