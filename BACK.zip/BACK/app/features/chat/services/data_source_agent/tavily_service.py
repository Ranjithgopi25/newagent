"""
Tavily Web Extraction Service.
Extracts text content from URLs using Tavily API.
"""

import logging
import ssl
import os
from typing import List, Dict, Any

# Disable SSL warnings and verification BEFORE any imports
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Set environment variables to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

from tavily import TavilyClient

logger = logging.getLogger(__name__)


class TavilyService:
    """Service for extracting web content via Tavily API."""
    
    def __init__(self, api_key: str):
        """
        Initialize Tavily service.
        
        Args:
            api_key: Tavily API key
        """
        # Patch SSL context globally
        self._patch_ssl_verification()
        
        # Initialize client
        self.client = TavilyClient(api_key)
        self.last_search_urls = []
        logger.info("[TavilyService] Initialized with SSL verification disabled")
    
    
    def _patch_ssl_verification(self):
        """Globally disable SSL verification for Tavily API calls."""
        try:
            # Patch requests library to not verify SSL
            import requests
            from requests.adapters import HTTPAdapter
            from urllib3.poolmanager import PoolManager
            
            class NoSSLVerifyAdapter(HTTPAdapter):
                def init_poolmanager(self, *args, **kwargs):
                    kwargs['ssl_version'] = ssl.PROTOCOL_TLS
                    kwargs['cert_reqs'] = ssl.CERT_NONE
                    kwargs['assert_hostname'] = False
                    return super().init_poolmanager(*args, **kwargs)
            
            # Monkey patch requests Session
            original_session_init = requests.Session.__init__
            
            def patched_session_init(self, *args, **kwargs):
                original_session_init(self, *args, **kwargs)
                self.verify = False
                self.mount('https://', NoSSLVerifyAdapter())
                self.mount('http://', NoSSLVerifyAdapter())
            
            requests.Session.__init__ = patched_session_init
            
            # Also patch the default SSL context
            ssl._create_default_https_context = ssl._create_unverified_context
            
            logger.info("[TavilyService] SSL verification globally disabled")
            
        except Exception as e:
            logger.warning(f"[TavilyService] Could not fully disable SSL verification: {e}")
    
    async def search(self, query: str, search_depth: str = "advanced") -> Dict[str, Any]:
        """
        Search the web using Tavily API.
        
        Args:
            query: Search query
            search_depth: "basic" or "advanced"
        
        Returns:
            Search results from Tavily
        """
        try:
            logger.info(f"[TavilyService] Search query: {query}")
            
            import asyncio
            loop = asyncio.get_event_loop()
            
            response = await loop.run_in_executor(
                None, 
                lambda: self.client.search(query=query, search_depth=search_depth)
            )
            self.last_search_urls = [
                result.get('url') for result in response.get('results', [])
                if result.get('url')
            ]
            # logger.info(f"[TavilyService] Found {len(response.get('results', []))} results")
            return response
            
        except Exception as e:
            logger.error(f"[TavilyService] Search error: {e}", exc_info=True)
            raise

    def format_search_response(self, response: Dict[str, Any]) -> str:
        """
        Format Tavily search results.
        
        Args:
            response: Tavily API search response
        
        Returns:
            Formatted text with results
        """
        results = response.get("results", [])
        
        if not results:
            return "No results found."
        
        formatted = []
        formatted.append(f"**Found {len(results)} results:**\n")
        
        for i, result in enumerate(results, 1):
            title = result.get("title", "Untitled")
            url = result.get("url", "")
            content = result.get("content", "No content available")
            score = result.get("score", 0)
            
            formatted.append(f"**{i}. {title}** (Relevance: {score:.2f})")
            formatted.append(f"**URL:** {url}")
            formatted.append(f"{content}\n")
            formatted.append("-" * 80)
        
        return "\n".join(formatted)
    
    async def extract_from_urls(self, urls: List[str]) -> Dict[str, Any]:
        """
        Extract content from multiple URLs.
        
        Args:
            urls: List of URLs to extract from
        
        Returns:
            Dictionary with results and failed_results
        """
        try:
            logger.info(f"[TavilyService] ===== EXTRACTION STARTED =====")
            logger.info(f"[TavilyService] URLs to extract: {urls}")
            logger.info(f"[TavilyService] Number of URLs: {len(urls)}")
            
            # Tavily's extract is synchronous, run in executor for async context
            import asyncio
            loop = asyncio.get_event_loop()
            
            logger.info(f"[TavilyService] Calling Tavily client.extract()...")
            response = await loop.run_in_executor(None, self.client.extract, urls)
            logger.info(f"[TavilyService] Tavily API call completed")
            
            results_count = len(response.get('results', []))
            failed_count = len(response.get('failed_results', []))
            
            logger.info(f"[TavilyService] Successfully extracted {results_count} pages")
            logger.info(f"[TavilyService] Failed extractions: {failed_count}")
            
            # Log each result
            for i, result in enumerate(response.get('results', []), 1):
                url = result.get('url', 'unknown')
                title = result.get('title', 'untitled')
                content_length = len(result.get('raw_content', ''))
                logger.info(f"[TavilyService] Result {i}: {title} ({url}) - {content_length} chars")
            
            # Log failed results
            for failed_url in response.get('failed_results', []):
                logger.warning(f"[TavilyService] Failed to extract: {failed_url}")
            
            return response
            
        except Exception as e:
            logger.error(f"[TavilyService] Error: {e}", exc_info=True)
            raise
    
    def format_response(self, response: Dict[str, Any]) -> str:
        """
        Format extraction results with citations.
        
        Args:
            response: Tavily API response
        
        Returns:
            Formatted text with content and citations
        """
        results = response.get("results", [])
        failed = response.get("failed_results", [])
        
        if not results and not failed:
            return "No content could be extracted from the provided URLs."
        
        formatted = []
        
        # Format successful extractions
        for result in results:
            url = result.get("url", "Unknown URL")
            title = result.get("title", "Untitled")
            content = result.get("raw_content", "No content available")
            
            formatted.append(f"**Source:** {title}")
            formatted.append(f"**URL:** {url}")
            formatted.append(f"\n{content}\n")
            formatted.append("-" * 80)
        
        # Report failed URLs
        if failed:
            formatted.append("\n**Failed to extract:**")
            for fail in failed:
                formatted.append(f"- {fail}")
        
        return "\n".join(formatted)