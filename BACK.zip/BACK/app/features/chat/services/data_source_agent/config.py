"""
Configuration for data source connections.
"""

import os
import pyodbc

SCHEMA_REGISTRY = {
    "capitaliq": {
        "vw_CompanyIncomeStatementFinancials": {
            "description": "Company financial statements including income statement metrics",
            "columns": {
                "companyName": "Name of the company",
                "CapIQ_Id": "Capital IQ identifier",
                "periodEndDate": "End date of the financial period",
                "calendarYear": "Calendar year",
                "periodTypeName": "Type of period (Annual, Quarterly)",
                "dataItemName": "Name of the financial metric",
                "dataItemValue": "Value of the financial metric"
            },
            "data_items": [
                "Net Income - (IS)",
                "Total Revenues", 
                "Gross Profit",
                "Cost Of Revenues",
                "Depreciation & Amortization, Total - (IS)"
            ]
        },
        "vw_CompanyBalanceSheetFinancials": {
            "description": "Company balance sheet data including assets, liabilities, and equity",
            "columns": {
                "companyName": "Name of the company",
                "CapIQ_Id": "Capital IQ identifier",
                "SEC_CIK": "SEC CIK number",
                "DUNS": "DUNS number",
                "periodEndDate": "End date of the financial period",
                "filingDate": "Date of filing",
                "periodTypeName": "Type of period (Annual)",
                "calendarYear": "Calendar year",
                "dataItemId": "ID of the financial data item",
                "dataItemName": "Name of the balance sheet metric",
                "dataItemValue": "Value of the balance sheet metric"
            },
            "data_items": [
                "Total Assets",
                "Total Current Assets",
                "Total Cash And Short Term Investments",
                "Total Receivables",
                "Net Property Plant And Equipment",
                "Total Liabilities And Equity",
                "Total Equity",
                "Total Common Equity",
                "Total Current Liabilities",
                "Total Liabilities - (Standard / Utility Template)",
                "Gain (Loss) on Sale of Investment, Total (Rev)"
            ]
        }
    },
    "boardex": {
        "company_profile_advisors": {
            "description": "Company advisor relationships including auditors",
            "columns": {
                "BoardName": "Name of the company",
                "AdvisorName": "Name of the advisory firm",
                "AdvTypeDesc": "Type of advisor (Auditors, Corporate Advisors)"
            },
            "advisor_types": ["Auditors", "Corporate Advisors", "Investor Relations Advisors"]
        },
        "director_profile_achievements": {
            "description": "Director achievements and awards",
            "columns": {
                "DirectorName": "Name of the director",
                "CompanyName": "Name of the company",
                "Achievement": "Description of the achievement",
                "AchievementDate": "Date of achievement"
            }
        }
    }
}