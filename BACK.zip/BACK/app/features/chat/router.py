"""
Chat Router.
Handles chat endpoints with LangGraph agent and tool calling.
"""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from app.features.chat.schemas import ChatRequest, ChatResponse, IntentDetectionRequest, IntentDetectionResponse, DraftIntentDetectionRequest, DraftIntentDetectionResponse
from app.features.chat.services.chat_service import ChatService
from app.features.chat.services.intent_detection_service import IntentDetectionService
from app.infrastructure.llm.llm_service import get_llm_service, LLMService
from app.common.chat_history_helper import ChatHistoryHelper
from typing import Optional
import logging
import json
import os
from app.core.config import config
from app.features.chat.services.data_source_agent import (
    DataSourceLangGraphAgent, 
    create_data_source_agent
)
from app.services.auth_service import validate_jwt_token

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat", tags=["Chat"], dependencies=[Depends(validate_jwt_token)])

# Singleton instances
_langgraph_agent: Optional[DataSourceLangGraphAgent] = None


# In router.py, update get_langgraph_agent():

def get_langgraph_agent() -> DataSourceLangGraphAgent:
    """Get or create LangGraph agent singleton."""
    global _langgraph_agent
    
    if _langgraph_agent is None:
        try:
            _langgraph_agent = create_data_source_agent(
                azure_endpoint= config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT
            )
            logger.info("[Router] LangGraph DataSourceAgent initialized")
        except Exception as e:
            logger.error(f"[Router] Failed to initialize LangGraph agent: {e}")
            return None
    
    return _langgraph_agent


def get_chat_service(
    llm_service: LLMService = Depends(get_llm_service),
    langgraph_agent: Optional[DataSourceLangGraphAgent] = Depends(get_langgraph_agent)
) -> ChatService:
    """Dependency for chat service."""
    return ChatService(llm_service, langgraph_agent=langgraph_agent)


def get_intent_detection_service(
    llm_service: LLMService = Depends(get_llm_service)
) -> IntentDetectionService:
    """Dependency for intent detection service."""
    return IntentDetectionService(llm_service)


@router.post("", response_model=ChatResponse)
@router.post("/", response_model=ChatResponse, include_in_schema=False)
async def chat(
    request: ChatRequest,
    chat_service: ChatService = Depends(get_chat_service)
):
    """
    Handle chat requests with optional streaming support and chat history tracking.
    
    - **messages**: List of conversation messages
    - **stream**: Whether to stream the response (SSE) or return complete response
    - **user_id**: Optional user email/ID for chat history (e.g., user@example.com)
    - **session_id**: Optional session ID for grouping conversations
    - **thread_id**: Optional thread ID to continue existing conversation
    - **source**: Source of conversation (DDDC, Market_Intelligence, Thought_Leadership, Export, Chat)
    
    Note: If the user message contains keywords like 'wall street journal', 'WSJ', or 'street journal',
    the service will automatically fetch relevant content from Factiva/Dow Jones API and include it as context.
    Handle chat requests with LangGraph agent and tool calling.
    
    The agent automatically uses tools to fetch data from:
    - **Factiva**: News articles, WSJ, press releases
    - **CapitalIQ**: Company financials, revenue, income
    - **BoardEx**: Auditors, advisors, executive achievements
    
    - **messages**: List of conversation messages
    - **stream**: Whether to stream the response (SSE) or return complete response
    """
    try:
        # Debug logging with detailed session_id tracking
        logger.info(f"Chat request received - user_id: {request.user_id}")
        logger.info(f"Frontend session_id: '{request.session_id}' (type: {type(request.session_id).__name__}, length: {len(request.session_id) if request.session_id else 0})")
        
        # Validate session_id from frontend
        if not request.session_id:
            logger.warning("WARNING: session_id is None/empty from frontend! Chat history will not persist.")
        else:
            logger.info(f"Using frontend session_id: {request.session_id}")
        
        # Initialize chat history helper with FRONTEND session_id and source
        history_helper = ChatHistoryHelper(
            user_id=request.user_id,
            session_id=request.session_id,
            source=request.source or "Chat"
        )
        
        # logger.info(f"ChatHistoryHelper initialized - enabled: {history_helper._enabled}")
        if history_helper._enabled:
            logger.info(f"Chat history ENABLED for session: {history_helper.session_id}")
        
        # Save user message if chat history is enabled
        if request.messages:
            last_user_msg = next((msg for msg in reversed(request.messages) if msg.role == "user"), None)
            if last_user_msg:
                logger.info(f"Attempting to save user message: {last_user_msg.content[:50]}...")
                thread_id = await history_helper.save_user_message(last_user_msg.content)
                logger.info(f"User message saved - thread_id: {thread_id}")
        
        if request.stream:
            async def stream_with_error_handling():
                full_response = ""
                try:
                    async for chunk in chat_service.stream_response(request.messages):
                        # Extract content from SSE data format
                        if chunk.startswith("data: "):
                            try:
                                data = json.loads(chunk[6:])
                                if 'content' in data:
                                    full_response += data['content']
                            except:
                                pass
                        yield chunk
                    
                    # Save complete assistant response to chat history
                    if full_response:
                        logger.info(f"Attempting to save assistant message - length: {len(full_response)}")
                        saved = await history_helper.save_assistant_message(full_response)
                        logger.info(f"Assistant message saved: {saved}")
                        
                except Exception as e:
                    logger.error(f"[Chat] Streaming error: {e}", exc_info=True)
                    yield f"data: {json.dumps({'error': 'Failed to generate response. Please try again.'})}\n\n"
            
            return StreamingResponse(
                stream_with_error_handling(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no"
                }
            )
        else:
            content = await chat_service.generate_response(request.messages)
            
            # Save assistant response to chat history
            logger.info(f"Attempting to save non-streaming assistant message - length: {len(content)}")
            saved = await history_helper.save_assistant_message(content)
            logger.info(f"Non-streaming assistant message saved: {saved}")
            
            return ChatResponse(content=content, role="assistant")
            
    except Exception as e:
        logger.error(f"[Chat] Endpoint error: {e}", exc_info=True)
        
        if "No LLM providers available" in str(e) or "API key" in str(e):
            raise HTTPException(
                status_code=502,
                detail="AI service is currently unavailable. Please check your API configuration."
            )
        elif "validation" in str(e).lower():
            raise HTTPException(
                status_code=400,
                detail=f"Invalid request: {str(e)}"
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=f"An error occurred while processing your request: {str(e)}"
            )



@router.post("/detect-draft-intent", response_model=DraftIntentDetectionResponse)
async def detect_draft_intent(
    request: DraftIntentDetectionRequest,
    intent_service: IntentDetectionService = Depends(get_intent_detection_service)
):
   """
   Detect if user input indicates draft/write/create intent using LLM.
   Also extracts topic, content type, word limit, and audience/tone if mentioned.
   - **input**: User input text to analyze
   - Returns: is_draft_intent (bool), confidence (float), detected_topic (str|None), detected_content_type (list[str]), word_limit (str|None), audience_tone (str|None)
   """
   try:
       logger.info(f"router called...............................")
       if not request.input or not request.input.strip():
           raise HTTPException(status_code=400, detail="Input cannot be empty")
       
       result = await intent_service.detect_draft_intent(request.input.strip())

       return DraftIntentDetectionResponse(
           is_draft_intent=result.get("is_draft_intent", False),
           confidence=result.get("confidence", 0.0),
           detected_topic=result.get("detected_topic"),
           detected_content_type=result.get("detected_content_type", []),
           word_limit=result.get("word_limit"),
           audience_tone=result.get("audience_tone")
       )
   except HTTPException:
       raise
   except Exception as e:
       logger.error(f"Draft intent detection endpoint error: {str(e)}", exc_info=True)

       # Return safe default on error
       return DraftIntentDetectionResponse(
           is_draft_intent=False,
           confidence=0.0,
           detected_topic=None,
           detected_content_type=[],
           word_limit=None,
           audience_tone=None
       )
        


@router.post("/detect-edit-intent", response_model=IntentDetectionResponse)
async def detect_edit_intent(
    request: IntentDetectionRequest,
    intent_service: IntentDetectionService = Depends(get_intent_detection_service)
):
    """
    Detect if user input indicates edit/improve/review intent using LLM.
    Also extracts editor names if mentioned by user.
    """
    try:
        if not request.input or not request.input.strip():
            raise HTTPException(status_code=400, detail="Input cannot be empty")
        
        result = await intent_service.detect_edit_intent(request.input.strip())
        
        return IntentDetectionResponse(
            is_edit_intent=result.get("is_edit_intent", False),
            confidence=result.get("confidence", 0.0),
            detected_editors=result.get("detected_editors", [])
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[DetectEditIntent] Error: {e}", exc_info=True)
        return IntentDetectionResponse(
            is_edit_intent=False,
            confidence=0.0,
            detected_editors=[]
        )


def get_router() -> APIRouter:
    """Return the chat router."""
    return router
