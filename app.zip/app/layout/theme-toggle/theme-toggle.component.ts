import { Component, OnInit } from '@angular/core';

import { ThemeService, ThemeMode } from '../../core/services';

@Component({
  selector: 'app-theme-toggle',
  standalone: true,
  imports: [],
  templateUrl: './theme-toggle.component.html',
  styleUrls: ['./theme-toggle.component.scss']
})
export class ThemeToggleComponent implements OnInit {
  showThemeDropdown: boolean = false;
  currentTheme: ThemeMode = 'light';

  constructor(private themeService: ThemeService) {}

  ngOnInit(): void {
    this.currentTheme = this.themeService.getCurrentTheme();
  }

  toggleDropdown(): void {
    this.showThemeDropdown = !this.showThemeDropdown;
  }

  setTheme(theme: ThemeMode): void {
    this.themeService.setTheme(theme);
    this.currentTheme = theme;
    this.showThemeDropdown = false;
  }

  getThemeIcon(): string {
    switch (this.currentTheme) {
      case 'light': return 'sun';
      case 'dark': return 'moon';
      case 'auto': return 'auto';
      default: return 'sun';
    }
  }

  getThemeLabel(): string {
    switch (this.currentTheme) {
      case 'light': return 'Light';
      case 'dark': return 'Dark';
      case 'auto': return 'Auto';
      default: return 'Light';
    }
  }
}
