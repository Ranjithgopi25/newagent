import { Injectable } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../auth/auth.service';

/**
 * Centralized helper for authenticated fetch() calls.
 * - Use authenticatedFetch for JSON requests
 * - Use authenticatedFetchFormData for FormData uploads
 */
@Injectable({
  providedIn: 'root'
})
export class AuthFetchService {
  constructor(private msalService: MsalService, private authService: AuthService) {}

  private async acquireAccessToken(): Promise<string | null> {
    if (!environment.useAuth) return null;

    try {
      const account = this.msalService.instance.getActiveAccount();
      if (!account) return null;

      const result = await this.msalService.instance.acquireTokenSilent({
        scopes: ['User.Read'],
        account
      });

      return result?.idToken ?? null;
    } catch (e) {
      console.error('[AuthFetchService] acquireAccessToken failed', e);
      return null;
    }
  }

  /** JSON requests - sets Content-Type and Authorization (if available) */
  async authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    const token = await this.acquireAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    console.log('[AuthFetchService] authenticatedFetch - URL:', url, 'Has Authorization:', !!headers['Authorization']);

    const response = await fetch(url, {
      ...options,
      headers
    });

    // If backend rejects authorization for fetch-based requests, trigger logout
    if (response && (response.status === 401 || response.status === 403)) {
      console.error('[AuthFetchService] Fetch returned auth error:', response.status, 'for', url);
      try {
        this.authService.logout();
      } catch (e) {
        console.error('[AuthFetchService] Failed to invoke logout on auth error', e);
      }
    }

    return response;
  }

  /** FormData requests - do not set Content-Type (browser will set boundary) */
  async authenticatedFetchFormData(url: string, options: RequestInit = {}): Promise<Response> {
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string> || {})
    };

    const token = await this.acquireAccessToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    console.log('[AuthFetchService] authenticatedFetchFormData - URL:', url, 'Has Authorization:', !!headers['Authorization']);

    const response = await fetch(url, {
      ...options,
      headers
    });

    if (response && (response.status === 401 || response.status === 403)) {
      console.error('[AuthFetchService] Fetch FormData returned auth error:', response.status, 'for', url);
      try {
        this.authService.logout();
      } catch (e) {
        console.error('[AuthFetchService] Failed to invoke logout on auth error', e);
      }
    }

    return response;
  }
}
