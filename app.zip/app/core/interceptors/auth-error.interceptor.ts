import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../../auth/auth.service';

/**
 * HTTP Interceptor that catches authentication errors (401/403) from the backend
 * and automatically logs out the user when the backend rejects the token
 */
export const authErrorInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);

  return next(req).pipe(
    catchError(error => {
      // Check if the error is due to invalid/expired token rejected by backend
      if (error.status === 401 || error.status === 403) {
        console.error('[AuthErrorInterceptor] Backend rejected token:', error.status);
        console.log('[AuthErrorInterceptor] Logging out user due to invalid token from backend');
        authService.logout();
      }
      return throwError(() => error);
    })
  );
};
