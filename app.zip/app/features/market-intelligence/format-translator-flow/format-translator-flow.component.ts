import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';

@Component({
    selector: 'app-mi-format-translator-flow',
    imports: [FormsModule],
    templateUrl: './format-translator-flow.component.html',
    styleUrls: ['./format-translator-flow.component.scss']
})
export class MiFormatTranslatorFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(private miFlowService: MiFlowService) {}

  ngOnInit(): void {
    this.miFlowService.formatTranslatorFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => this.isOpen = isOpen);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onClose(): void {
    this.miFlowService.closeFormatTranslatorFlow();
  }
}
