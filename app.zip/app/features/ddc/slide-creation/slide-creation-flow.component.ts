import { Component, Input, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { firstValueFrom, Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';

@Component({
    selector: 'app-slide-creation-flow',
    imports: [FormsModule, FileUploadComponent, DDCRequestFormComponent],
    templateUrl: './slide-creation-flow.component.html',
    styleUrls: ['./slide-creation-flow.component.scss']
})
export class SlideCreationFlowComponent implements OnInit, OnDestroy {
  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;
  
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  showDownloadButton = true;
  showDownloadButton1 = false;
  downloadUrl : string | undefined;
  showCreateRequestButton = false;
  showRequestForm = false;
  
  // File uploads
  uploadedFile: File | null = null;
  selectedTemplate = '';
  customTemplateFile: File | null = null;
  chartDataFile: File | null = null;
  
  // Additional fields
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'slide-creation';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SlideCreationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = '';
    this.customTemplateFile = null;
    this.chartDataFile = null;
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  onChartDataSelected(file: File): void {
    this.chartDataFile = file;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  onTemplateChange(): void {
    if (!this.needsCustomTemplate) {
      this.customTemplateFile = null;
    }
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    //if (!this.selectedTemplate.trim()) return false;
    //if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
    //return this.additionalGuidelines.trim().length > 0;;
    /*
    return (
    (this.additionalGuidelines?.trim().length > 0) ||
    (this.uploadedFile !== null)
  );
  */
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    // if (!this.additionalGuidelines || this.additionalGuidelines.trim().length === 0) {
    // console.error('[SlideCreationFlow] additionalGuidelines is required');
    // return;
  //}
    this.cancelStream(); // ensure no active stream
    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      if (this.uploadedFile) {
      formData.append('file', this.uploadedFile);
    }

    if (this.selectedTemplate && this.selectedTemplate.trim().length > 0) {
      formData.append('template', this.selectedTemplate);
    }
      //formData.append('file', this.uploadedFile);
      //formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('custom_template_file', this.customTemplateFile);
      }
      
      if (this.chartDataFile) {
        formData.append('chart_data_file', this.chartDataFile);
      }

      if (this.additionalGuidelines=="") {
        formData.append('additional_guidelines','Follow the guidelines while creating the presentation');
      }
      else{
        formData.append('additional_guidelines',this.additionalGuidelines);
      }
      //formData.append('additional_guidelines', this.additionalGuidelines);

      console.log('[SlideCreationFlow] Sending request:', {
        //fileName: this.uploadedFile.name,
        fileName: this.uploadedFile?.name ?? null,
        //template: this.selectedTemplate,
        template: this.selectedTemplate || null,
        hasCustomTemplate: !!this.customTemplateFile,
        hasChartData: !!this.chartDataFile,
        hasGuidelines: !!this.additionalGuidelines
      });
      /*
      this.streamSubscription = this.chatService.streamDdcSlideCreation(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[SlideCreationFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error creating the slides. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[SlideCreationFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
      */
      //const response: any = await this.chatService.createDdcSlide(formData).toPromise();
        const response: any = await firstValueFrom(this.chatService.createDdcSlide(formData));
      if (response?.status === 'success' && response?.download_url) {
        this.generatedContent = `🎉 Slide(s) generated successfully!`;
        this.showDownloadButton = true;
        //\nDownload URL: ${response.download_url}
        this.downloadUrl = response.download_url;
        console.log('[SlideCreationFlow] Download URL:', response.download_url);
      } else {
        this.generatedContent = '✗ Slide generation failed. Please try again.';
        this.downloadUrl = undefined;
        this.showDownloadButton = false;
        console.error('[SlideCreationFlow] Unexpected response:', response);
      }

    } catch (error) {
      console.error('[SlideCreationFlow] Exception:', error);
      this.generatedContent =
      '✗ An error occurred while generating the slides. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
    }finally {
    this.isGenerating = false; // ensure spinner stops
  }
  }

  downloadProcessedFile(): void {
    if (!this.downloadUrl) {
      console.warn('[SlideCreationFlow] No download URL available');
      this.generatedContent =
      '✗ An error occurred while generating the slides. Please try again.';
      this.isGenerating = false;
      this.showDownloadButton = false;
      this.downloadUrl = undefined;
      return;
    }

    fetch(this.downloadUrl)
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');

      link.href = url;
      link.download = 'Generated_Presentation.pptx';
      link.click();

      window.URL.revokeObjectURL(url);
    })
    .finally(() => {
      this.showDownloadButton = false;
      this.generatedContent = "You may raise an issue by clicking on the button below."
      this.showCreateRequestButton = true;

    })
    .catch(err => console.error('Download error:', err));
    /*
    const link = document.createElement('a');
    link.href = this.downloadUrl;
    link.target = '_blank';
    link.download = 'Slide.pptx'; // default filename
    link.click();
    */
  }

  openRequestForm() {
  this.showRequestForm = true;
}

phoenixRdpLink = '';

onTicketCreated(event: {
  requestNumber: string;
  phoenixRdpLink: string;
}): void {
  this.phoenixRdpLink = event.phoenixRdpLink;
  console.log('Ticket created:', event.requestNumber);
  this.generatedContent =`✅ Request created successfully! Your request number is: <a href="${event.phoenixRdpLink}" target="_blank" rel="noopener noreferrer">${event.requestNumber}</a>`;
  this.showRequestForm = false;
  this.showCreateRequestButton = false;
}
}
