import { Component, Input, Output, EventEmitter } from '@angular/core';


export interface QuickAction {
  title: string;
  description: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-welcome-screen',
  standalone: true,
  imports: [],
  templateUrl: './welcome-screen.component.html',
  styleUrls: ['./welcome-screen.component.scss']
})
export class WelcomeScreenComponent {
  @Input() featureName: string = 'Doc Studio';
  @Input() quickActions: QuickAction[] = [];
  @Output() quickActionClick = new EventEmitter<string>();
  @Output() quickStartClick = new EventEmitter<void>();
  @Output() guidedJourneyClick = new EventEmitter<void>();
  @Output() ddcGuidedJourneyClick = new EventEmitter<void>();

  onQuickActionClick(action: string): void {
    this.quickActionClick.emit(action);
  }

  onQuickStart(): void {
    this.quickStartClick.emit();
  }

  onGuidedJourney(): void {
    this.guidedJourneyClick.emit();
  }

  onDdcGuidedJourney(): void {
    this.ddcGuidedJourneyClick.emit();
  }
}
