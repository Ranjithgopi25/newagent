import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../../../shared/components/file-upload/file-upload.component';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { ThoughtLeadershipMetadata } from '../../../core/models/message.model';

@Component({
    selector: 'app-conduct-research-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './conduct-research-flow.component.html',
    styleUrls: ['./conduct-research-flow.component.scss']
})
export class ConductResearchFlowComponent {
  researchTopic = '';
  
  uploadedContentLink = false;
  pwcProprietaryResearch = true;
  pwcLicensedThirdParty = true;
  externalResearch = true;
  multiple = true;

  // supportingDocFile: File | null = null;
  MAX_SUPPORTING_DOCS = 5;
  supportingDocFiles: File[] = [];
  supportingDocInstructions = '';
  supportingDocsError = '';

  researchLinks = '';

  selectSpecificPwcSources = false;

  allPwcProprietarySources = true;
  pwcProprietarySources = [
    { name: 'PwC Industry Edge', selected: true },
    { name: 'PwC Insights', selected: true },
    { name: 's+b Journal', selected: true },
    { name: 'Executive Leadership Hub', selected: true },
    { name: 'The Exchange', selected: true },
    { name: 'PwC Connected Source', selected: true },
    { name: 'PwC Benchmarking', selected: true },
    //{ name: 'Insights Factory', selected: true },
    //{ name: 'PwC Intelligence', selected: true },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    //{ name: 'Client Success Stories', selected: true },
    //{ name: 'Inside Industries', selected: true },
    //{ name: 'Value Store', selected: true }
  ];
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;

pwcThirdPartySources = [
  { name: 'Factiva', selected: true },
    { name: 'S&P Global- Capital IQ Xpressfeed', selected: true },
    { name: 'IBIS World', selected: true },
    { name: 'BoardEx', selected: true },
    // { name: 'S&P Global- Connect', selected: true },
    // { name: 'Audit Analytics', selected: true },
    // { name: 'S&P Global- SNL Insurance', selected: true },
    // { name: 'Claritas', selected: true },
    // { name: 'Equifax', selected: true },
    // { name: 'Equifax IXI', selected: true },
    // { name: 'Definitive Healthcare Provider Database', selected: true },
    // { name: 'Sg2 Health Care Intelligence', selected: true },
    // //{ name: 'Strata Market Insights', selected: true },
    // //{ name: 'CompanyIQ', selected: true },
    // { name: 'Global Data(Retail)', selected: true },
    // { name: 'Technology Business Review', selected: true },
    
    // //{ name: 'IDC', selected: true },
    // { name: 'CFRA Industry Surveys', selected: true }
];

  allPwcThirdPartySources = true;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;

  additionalGuidelines = '';

  researchContent = '';
  isGenerating = false;

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private tlChatBridge: TlChatBridgeService
  ) {}

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'conduct-research';
  }
  removeSupportingDoc(index: number): void {
  this.supportingDocFiles.splice(index, 1);
  this.supportingDocsError = '';
}

  onClose(): void {
    // Reset all toggle states
  this.researchTopic = '';
  this.uploadedContentLink = false;
  this.pwcProprietaryResearch = true;
  this.pwcLicensedThirdParty = true;
  this.externalResearch = true;
  this.selectSpecificPwcSources = false;
  
  // Reset all proprietary sources
  this.allPwcProprietarySources = true;
  this.pwcProprietarySources.forEach(source => source.selected = true);
  
  // Reset all third party sources
  this.allPwcThirdPartySources = true;
  this.pwcThirdPartySources.forEach(source => source.selected = true);
  
  // Reset other fields
  this.supportingDocFiles;
  this.supportingDocsError = '';
  this.researchLinks = '';
  this.additionalGuidelines = '';
  this.researchContent = '';
  this.isGenerating = false;
    this.tlFlowService.closeFlow();
  }

  back(): void{
    this.onClose();
    //this.tlFlowService.closeFlow();
    this.tlFlowService.openGuidedDialog();
  }

 
onSupportingDocsSelected(files: File | File[]): void {
  const incomingFiles = Array.isArray(files) ? files : [files];

  incomingFiles.forEach(file => {
    const alreadyAdded = this.supportingDocFiles.some(
      existing =>
        existing.name === file.name &&
        existing.size === file.size
    );

    if (!alreadyAdded) {
      this.supportingDocFiles.push(file);
    }
  });
}

// Handle multiple supporting documents upload
onSupportingDocsFilesChange(event: Event): void {
  const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const filesArray = Array.from(input.files);
      
      // Check if adding these files would exceed max
      const totalFiles = this.supportingDocFiles.length + filesArray.length;
      if (totalFiles > this.MAX_SUPPORTING_DOCS) {
        const availableSlots = this.MAX_SUPPORTING_DOCS - this.supportingDocFiles.length;
        if (availableSlots > 0) {
          this.supportingDocFiles.push(...filesArray.slice(0, availableSlots));
          this.supportingDocsError = `Only ${availableSlots} file(s) were added. Maximum of ${this.MAX_SUPPORTING_DOCS} files allowed.`;
        } else {
          this.supportingDocsError = `Maximum of ${this.MAX_SUPPORTING_DOCS} supporting documents already reached.`;
        }
      } else {
        this.supportingDocFiles.push(...filesArray);
        this.supportingDocsError = '';
      }
      
      // Reset the input so the same file can be selected again
      input.value = '';
      
    }
  }



onSupportingDocSelected(files: File[]): void {
  this.onSupportingDocsSelected(files);
}

  onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  // onAllPwcThirdPartyToggle(value: boolean): void {
  //   this.allPwcThirdPartySources = value;
  //   this.pwcThirdPartySource1 = value;
  //   this.pwcThirdPartySource2 = value;
  //   this.pwcThirdPartySource3 = value;
  //   this.pwcThirdPartySource4 = value;
  // }

  onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}


onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}
  // onPwcThirdPartySourceChange(): void {
  //   setTimeout(() => {
  //     this.allPwcThirdPartySources = this.pwcThirdPartySource1 && this.pwcThirdPartySource2 && this.pwcThirdPartySource3 && this.pwcThirdPartySource4;
  //   });
  // }

  get showPwcSourceSelection(): boolean {
    return this.selectSpecificPwcSources && 
           (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }


get showPwcProprietarySources(): boolean {
  return this.selectSpecificPwcSources && this.pwcProprietaryResearch;
}
get invalidLinks(): boolean {
  if (!this.researchLinks) return false;

  return this.researchLinks
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean)
    .some(link => !/^https?:\/\/.+/.test(link));
}

get showPwcThirdPartySources(): boolean {
  return this.selectSpecificPwcSources && this.pwcLicensedThirdParty;
}

  // get canGenerateResearch(): boolean {
  //   if (!this.researchTopic.trim()) return false;

  //   if (!this.uploadedContentLink && !this.pwcProprietaryResearch && 
  //       !this.pwcLicensedThirdParty && !this.externalResearch) {
  //     return false;
  //   }
  //   const hasDoc = !!this.supportingDocFile;
  //   const hasUrl = !!this.researchLinks?.trim();
  //   if (!hasDoc && !hasUrl) return false;


  //   return true;
  // }
  get canGenerateResearch(): boolean {
    if (!this.researchTopic.trim()) return false;

    // const hasSourceSelected = this.uploadedContentLink || this.pwcProprietaryResearch || 
    //                           this.pwcLicensedThirdParty || this.externalResearch;
    
    // if (!hasSourceSelected) return false;

    // Only require doc/link if "Uploaded Content or Link" is selected
    if (this.uploadedContentLink) {
      const hasDoc = !!this.supportingDocFiles;
      //const hasUrl = !!this.researchLinks?.trim();
      const hasUrl = !!this.invalidLinks
      // if (!hasDoc && !hasUrl) return false;
      if (hasUrl) return false;
    }

    return true;
  }
  
  generateResearch(): void {
    if (!this.canGenerateResearch) {
      console.error('Form validation failed');
      return;
    }

    this.isGenerating = true;
    this.researchContent = '';

    // Build comprehensive prompt with all metadata
    let prompt = `Conduct comprehensive research on the following topic:\n\n`;
    prompt += `Research Topic: ${this.researchTopic}\n`;

    // Add selected research sources
    const selectedSources: string[] = [];
    if (this.uploadedContentLink) selectedSources.push('Uploaded Content or Link');
    if (this.pwcProprietaryResearch) selectedSources.push('PwC Proprietary Research');
    if (this.pwcLicensedThirdParty) selectedSources.push('PwC Licensed Third Party Tools');
    if (this.externalResearch) selectedSources.push('External Research');
    
    if (selectedSources.length > 0) {
      prompt += `Research Sources: ${selectedSources.join(', ')}\n`;
    }

    // Add supporting document if provided
    if (this.supportingDocFiles.length > 0) {
      const fileNames = this.supportingDocFiles.map(f => f.name).join(', ');
      prompt += `Supporting Documents: ${fileNames}\n`;
    }


    // Add research links if provided
    if (this.researchLinks.trim()) {
      prompt += `Research Links: ${this.researchLinks}\n`;
    }

    // Add specific PwC sources if selected
    if (this.selectSpecificPwcSources) {
      if (this.pwcProprietaryResearch) {
        const pwcSources: string[] = [];
        if (this.pwcSource1) pwcSources.push('Source 1');
        if (this.pwcSource2) pwcSources.push('Source 2');
        if (this.pwcSource3) pwcSources.push('Source 3');
        if (this.pwcSource4) pwcSources.push('Source 4');
        if (pwcSources.length > 0) {
          prompt += `PwC Proprietary Research Sources: ${pwcSources.join(', ')}\n`;
        }
      }
      
      if (this.pwcLicensedThirdParty) {
        const thirdPartySources: string[] = [];
        if (this.pwcThirdPartySource1) thirdPartySources.push('Source 1');
        if (this.pwcThirdPartySource2) thirdPartySources.push('Source 2');
        if (this.pwcThirdPartySource3) thirdPartySources.push('Source 3');
        if (this.pwcThirdPartySource4) thirdPartySources.push('Source 4');
        if (thirdPartySources.length > 0) {
          prompt += `PwC Third Party Tool Sources: ${thirdPartySources.join(', ')}\n`;
        }
      }
    }

    // Add additional guidelines if provided
    if (this.additionalGuidelines.trim()) {
      prompt += `\nAdditional Guidelines: ${this.additionalGuidelines}\n`;
    }

    const messages = [{
      role: 'user' as const,
      content: prompt
    }];

    // Build source groups for ChatService
    const sourceGroups: string[] = [];
    if (this.uploadedContentLink) sourceGroups.push('Uploaded Content/Link');
    if (this.pwcProprietaryResearch) sourceGroups.push('PwC Proprietary');
    if (this.pwcLicensedThirdParty) sourceGroups.push('PwC Licensed');
    if (this.externalResearch) sourceGroups.push('External Research');

    console.log('[ConductResearchFlow] Sending request:', {
      topic: this.researchTopic,
      sources: selectedSources
    });
      const formData = new FormData();
      formData.append("messages", JSON.stringify(messages));
      formData.append("source_groups", JSON.stringify(sourceGroups));
      formData.append("stream", "true");
      formData.append('additional_guidelines', this.additionalGuidelines || '');

      if (this.supportingDocFiles) {
        this.supportingDocFiles.forEach(file => {
        formData.append('files', file);
      });
;
      }

    // this.chatService.streamConductResearch(messages, sourceGroups.length > 0 ? sourceGroups : undefined).subscribe({
    this.chatService.streamConductResearch(formData).subscribe({ 
    next: (data: any) => {
        // Accumulate content for sending to chat
        if (typeof data === 'string') {
          this.researchContent += data;
        } else if (data.type === 'content' && data.content) {
          this.researchContent += data.content;
        }
      },
      error: (error: any) => {
        console.error('Error conducting research:', error);
        const errorMessage = 'Sorry, there was an error conducting your research. Please try again.';
        
        // Send error message to chat
        const metadata: ThoughtLeadershipMetadata = {
          contentType: 'article',
          topic: this.researchTopic,
          fullContent: errorMessage,
          showActions: true
        };
        this.tlChatBridge.sendToChat(errorMessage, metadata);
        
        this.isGenerating = false;
        this.onClose();
      },
      complete: () => {
        console.log('[ConductResearchFlow] Research generation complete');
        this.isGenerating = false;
        
        // Send research content to main chat window with TL metadata
        if (this.researchContent && this.researchContent.trim()) {
          const metadata: ThoughtLeadershipMetadata = {
            contentType: 'article',
            topic: this.researchTopic,
            fullContent: this.researchContent,
            showActions: true
          };
          
          console.log('[ConductResearchFlow] Sending to chat with metadata:', metadata);
          this.tlChatBridge.sendToChat(this.researchContent, metadata);
          
          // Close the modal after sending to chat
          this.onClose();
        }
      }
    });
  }
}
