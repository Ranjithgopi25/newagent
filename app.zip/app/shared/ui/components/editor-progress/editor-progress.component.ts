import { Component, Input, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';


export interface EditorProgressItem {
  editorId: string;
  editorName: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  current?: number;
  total?: number;
}

@Component({
    selector: 'app-editor-progress',
    imports: [],
    templateUrl: './editor-progress.component.html',
    styleUrls: ['./editor-progress.component.scss']
})
export class EditorProgressComponent implements OnChanges {
  @Input() editors: EditorProgressItem[] = [];
  @Input() currentEditor?: string;
  @Input() currentIndex?: number;
  @Input() totalEditors?: number;

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['editors'] || changes['currentEditor'] || changes['currentIndex']) {
      this.cdr.detectChanges();
    }

  }

  isCompleted(): boolean {
    // Check if all editors are completed or if currentEditor is 'completed'
    if (this.currentEditor === 'completed') {
      return true;
    }
    if (this.currentIndex && this.totalEditors && this.currentIndex >= this.totalEditors) {
      return true;
    }
    if (this.editors && this.editors.length > 0) {
      return this.editors.every(e => e.status === 'completed' || e.status === 'error');
    }
    return false;
  }

  getCurrentEditorName(): string {
    // If completed, show the last editor name
    if (this.isCompleted() && this.editors && this.editors.length > 0) {
      const lastEditor = this.editors[this.editors.length - 1];
      return lastEditor.editorName;
    }
    
    if (!this.currentEditor || !this.editors || this.editors.length === 0) {
      return this.currentEditor || 'Editor';
    }
    
    // Find editor by ID
    const editor = this.editors.find(e => e.editorId === this.currentEditor);
    if (editor) {
      return editor.editorName;
    }
    
    // Fallback: try to get from currentEditor directly
    return this.currentEditor;
  }
}

