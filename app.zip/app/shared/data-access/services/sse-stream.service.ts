import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';

export interface SSEMessage {
  type: 'chunk' | 'error' | 'done';
  content: string;
}

@Injectable({
  providedIn: 'root'
})
export class SSEStreamService {
  constructor(private authFetch: AuthFetchService) {}

  streamResponse(url: string, options: { body?: any; headers?: Record<string, string> } = {}): Observable<SSEMessage> {
    const subject = new Subject<SSEMessage>();

    const eventSource = new EventSource(url);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.done) {
          subject.next({ type: 'done', content: '' });
          subject.complete();
          eventSource.close();
        } else if (data.content) {
          subject.next({ type: 'chunk', content: data.content });
        }
      } catch (error) {
        subject.next({ type: 'error', content: 'Failed to parse response' });
      }
    };

    eventSource.onerror = (error) => {
      subject.next({ type: 'error', content: 'Stream connection error' });
      subject.error(error);
      eventSource.close();
    };

    return subject.asObservable();
  }

  streamWithFetch(url: string, options: { method?: string; body?: any; headers?: Record<string, string> } = {}): Observable<SSEMessage> {
    const subject = new Subject<SSEMessage>();

    const isFormData = options.body instanceof FormData;
    const isBlob = options.body instanceof Blob;
    
    const headers: Record<string, string> = {};
    
    if (!isFormData && !isBlob && options.body) {
      headers['Content-Type'] = 'application/json';
    }
    
    if (options.headers) {
      Object.assign(headers, options.headers);
    }

    let body: any;
    if (options.body) {
      if (isFormData || isBlob) {
        body = options.body;
      } else {
        body = JSON.stringify(options.body);
      }
    }

    const responsePromise: Promise<Response> = (isFormData || isBlob)
      ? this.authFetch.authenticatedFetchFormData(url, { method: options.method || 'POST', body })
      : this.authFetch.authenticatedFetch(url, { method: options.method || 'POST', body });

    responsePromise
      .then(async response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (!reader) {
          throw new Error('No response body');
        }

        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          
          if (done) {
            subject.next({ type: 'done', content: '' });
            subject.complete();
            break;
          }

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.trim() === '') continue;
            
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              
              if (data === '[DONE]') {
                subject.next({ type: 'done', content: '' });
                subject.complete();
                return;
              }

              try {
                const parsed = JSON.parse(data);
                subject.next({ type: 'chunk', content: parsed.content || parsed.delta || data });
              } catch {
                subject.next({ type: 'chunk', content: data });
              }
            }
          }
        }
      })
      .catch(error => {
        subject.next({ type: 'error', content: error.message });
        subject.error(error);
      });

    return subject.asObservable();
  }
}
