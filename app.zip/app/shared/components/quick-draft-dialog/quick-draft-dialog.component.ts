import { Component, Input, Output, EventEmitter } from '@angular/core';

import { FormsModule } from '@angular/forms';

export interface QuickDraftInputs {
  wordLimit: string;
  audienceTone: string;
}

@Component({
    selector: 'app-quick-draft-dialog',
    imports: [FormsModule],
    templateUrl: './quick-draft-dialog.component.html',
    styleUrls: ['./quick-draft-dialog.component.scss']
})
export class QuickDraftDialogComponent {
  @Input() isOpen: boolean = false;
  @Input() topic: string = '';
  @Input() contentType: string = '';
  @Output() close = new EventEmitter<void>();
  @Output() submit = new EventEmitter<QuickDraftInputs>();

  wordLimit: string = '';
  audienceTone: string = '';

  onClose(): void {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }

  onSubmit(): void {
    const inputs: QuickDraftInputs = {
      wordLimit: this.wordLimit.trim(),
      audienceTone: this.audienceTone.trim()
    };
    this.submit.emit(inputs);
  }
}

