import { Component, Input, Output, EventEmitter } from '@angular/core';

import { WorkflowCard } from '../../../core/models/guided-journey.models';

@Component({
    selector: 'app-guided-dialog',
    imports: [],
    templateUrl: './guided-dialog.component.html',
    styleUrls: ['./guided-dialog.component.scss']
})
export class GuidedDialogComponent {
  @Input() isOpen: boolean = false;
  @Input() title: string = 'Guided Journey';
  @Input() introText: string = '';
  @Input() subIntroText: string = '';
  @Input() workflows: WorkflowCard[] = [];
  @Input() showCloseButton: boolean = true;
  @Output() close = new EventEmitter<void>();
  @Output() workflowSelected = new EventEmitter<string>();

  onClose(): void {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }

  onWorkflowClick(workflow: WorkflowCard): void {
    // Prevent click if workflow is disabled
    if (workflow.disabled) {
      return;
    }
    console.log('[GuidedDialog] Workflow clicked:', workflow.id);
    this.workflowSelected.emit(workflow.id);
    console.log('[GuidedDialog] Event emitted, closing dialog');
    this.onClose();
  }
}
