export interface ContentSection {
  id: string;
  type: 'heading' | 'paragraph' | 'list' | 'quote' | 'code';
  content: string;
  level?: number;
  originalContent: string;
  isEdited: boolean;
  editHistory: SectionEdit[];
}

export interface SectionEdit {
  timestamp: Date;
  prompt: string;
  previousContent: string;
  newContent: string;
}

export interface CanvasDocument {
  id: string;
  title: string;
  contentType: 'article' | 'blog' | 'white_paper' | 'executive_brief';
  sections: ContentSection[];
  fullText: string;
  createdAt: Date;
  updatedAt: Date;
  messageId?: string;
}

export interface UpdateSectionRequest {
  fullArticle: string;
  sectionIndex: number;
  sectionContent: string;
  userPrompt: string;
  contentType: string;
}

export interface CanvasState {
  document: CanvasDocument | null;
  selectedSectionId: string | null;
  isEditing: boolean;
  canUndo: boolean;
  canRedo: boolean;
  isOpen: boolean;
}
