export function toSnakeCase(value: string): string {
  if (!value) return '';

  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}
