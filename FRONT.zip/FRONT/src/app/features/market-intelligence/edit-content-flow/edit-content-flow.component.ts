import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';

@Component({
    selector: 'app-mi-edit-content-flow',
    imports: [FormsModule],
    templateUrl: './edit-content-flow.component.html',
    styleUrls: ['./edit-content-flow.component.scss']
})
export class MiEditContentFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(private miFlowService: MiFlowService) {}

  ngOnInit(): void {
    this.miFlowService.editContentFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => this.isOpen = isOpen);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onClose(): void {
    this.miFlowService.closeEditContentFlow();
  }
}
