import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';
import { MiChatBridgeService, MarketIntelligenceMetadata } from '../mi-chat-bridge.service';
//import { FileUploadComponent } from '../../../shared/components/file-upload/file-upload.component';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { ThoughtLeadershipMetadata, Message } from '../../../core/models';
import { environment } from '../../../../environments/environment';

interface EditForm {
  outlineFile: File | null;
  supportingDocsFile: File | null;
  supportingDocsFiles: File[]; // Array for multiple supporting documents
}

@Component({
    selector: 'app-mi-create-pov-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './create-pov-flow.component.html',
    styleUrls: ['./create-pov-flow.component.scss']
})
export class MiCreatePOVFlowComponent implements OnInit, OnDestroy {
  maxWordLimit = 10000;
  wordLimitError = '';
  isGenerating = false;
  createPOV = '';
  
  // Satisfaction feedback properties
  showSatisfactionPrompt = false;
  showImprovementInput = false;
  improvementRequestText = '';
  iterationCount = 0;
  
  // Store original draft parameters for improvement iterations
  originalContentType = '';
  originalWordLimit = '';
  originalAudienceTone = '';
  originalOutlineDoc = '';
  originalSupportingDoc = '';
  originalUseFactivaResearch = false;

  // Topic input
  topicInput = '';
  clientName = '';

    // Outline text input validation
  outlineTextInputError = '';
  private readonly MIN_OUTLINE_WORDS = 50;

  // Content type selection - exclusive toggles (only ONE can be ON)
  contentTypeArticle = false;
  contentTypeBlog = false;
  contentTypeExecutiveBrief = false;
  contentTypeWhitePaper = false;
  contentTypePov = false;

  // Basic fields
  wordLimit = '';
    onWordLimitChange(value: any): void {
      if (value && Number(value) > this.maxWordLimit) {
        this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.*`;
        //alert(this.wordLimitError);
        // Optionally, reset the value
        this.wordLimit = this.maxWordLimit.toString();
      } else {
        this.wordLimitError = '';
      }
    }
    
  audienceTone = '';
  outlineTextInput = '';

  // File uploads
    formData: EditForm = {
    outlineFile: null,
    supportingDocsFile: null,
    supportingDocsFiles: []
  };
  originalContent: string = '';
  originalcontentoutlineText: string = '';

  // Research toggle (Yes/No)
  conductResearch = false;

  // Research conditional fields
  researchTopics = '';

  // Research sources (4 toggles)
  pwcContentLink = false;
  pwcProprietaryResearch = false;
  pwcLicensedThirdParty = false;
  externalResearch = false;

  // Research document and links
  researchDocumentFile: File | null = null;
  researchDocInstructions = '';
  researchLinks = '';
  
    // Supporting documents multi-upload properties
  MAX_SUPPORTING_DOCS = 5;
  MAX_TOKEN_LIMIT = 20000;
  supportingDocsTokenCount = 0;
  supportingDocsError = '';
  
  // Supporting documents for research (when "Uploaded Content or Link" is ON)
  extractedDocumentsMap = new Map<string, string>(); // fileName -> extractedText
  isExtractingText = false;
  extractionError = '';
  //outlineTextInput = '';

  // Select specific PwC sources (appears if PwC sources selected)
  selectSpecificPwcSources = false;

  // PwC Proprietary Research Sources
  allPwcProprietarySources = true;
  pwcSource1 = false;
  pwcSource2 = false;
  pwcSource3 = false;
  pwcSource4 = false;

pwcProprietarySources = [
    { name: 'PwC Industry Edge', selected: true },
    { name: 'PwC.com', selected: true },
    { name: 'PwC Insights', selected: true },
    { name: 's+b Journal', selected: true },
    { name: 'Executive Leadership Hub', selected: true },
    { name: 'The Exchange', selected: true },
    { name: 'PwC Connected Source', selected: true },
    { name: 'PwC Benchmarking', selected: true },
    //{ name: 'Insights Factory', selected: true },
    //{ name: 'PwC Intelligence', selected: true },
    //{ name: 'C-Suite Connection Program', selected: true },
    //{ name: 'Viewpoint', selected: true },
    //{ name: 'Analyst and Advisor Relations', selected: true },
    //{ name: 'Assurance Benchmarking Tools', selected: true },
    //{ name: 'Policy on Demand', selected: true },
    //{ name: 'Tax Source', selected: true },
    //{ name: 'FFG Benchmarking', selected: true },
    //{ name: 'Client Success Stories', selected: true },
    //{ name: 'Inside Industries', selected: true },
    //{ name: 'Value Store', selected: true }
  ];

  // PwC Third Party Tools
  allPwcThirdPartySources = true;
  pwcThirdPartySource1 = false;
  pwcThirdPartySource2 = false;
  pwcThirdPartySource3 = false;
  pwcThirdPartySource4 = false;

pwcThirdPartySources = [
  { name: 'Factiva, WSJ, Dow Jones', selected: true },
    { name: 'S&P Global- Capital IQ Xpressfeed', selected: true },
    { name: 'IBIS World', selected: true },
    { name: 'BoardEx', selected: true },
    // { name: 'S&P Global- Connect', selected: true },
    // { name: 'Audit Analytics', selected: true },
    // { name: 'S&P Global- SNL Insurance', selected: true },
    // { name: 'Claritas', selected: true },
    // { name: 'Equifax', selected: true },
    // { name: 'Equifax IXI', selected: true },
    // { name: 'Definitive Healthcare Provider Database', selected: true },
    // { name: 'Sg2 Health Care Intelligence', selected: true },
    // //{ name: 'Strata Market Insights', selected: true },
    // //{ name: 'CompanyIQ', selected: true },
    // { name: 'Global Data(Retail)', selected: true },
    // { name: 'Technology Business Review', selected: true },
    
    // //{ name: 'IDC', selected: true },
    // { name: 'CFRA Industry Surveys', selected: true }
];


  // Additional guidelines
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    public miFlowService: MiFlowService,
    private chatService: ChatService,
    private miChatBridge: MiChatBridgeService,
    private cdr: ChangeDetectorRef,
    private authFetchService: AuthFetchService
  ) { }

  ngOnInit(): void {
    // Subscribe to preselected content type
    this.miFlowService.preselectedContentType$
      .pipe(takeUntil(this.destroy$))
      .subscribe((contentType: string | null) => {
        if (contentType) {
          this.preselectContentType(contentType);
        }
      });

    // Subscribe to preselected topic
    this.miFlowService.preselectedTopic$
      .pipe(takeUntil(this.destroy$))
      .subscribe((topic: string | null) => {
        if (topic !== null) {
          this.topicInput = topic;
        }
      });

    this.miFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe((flow: any) => {
        if (flow === 'create-pov') {
          // Get preselected values before reset
          // Get preselected values from the current flow event
          const preselectedType = flow?.preselectedContentType ?? null;
          const preselectedTopic = flow?.preselectedTopic ?? null;

          console.log('[CreatePOVFlow] Flow activated, preselected values:', { preselectedType, preselectedTopic });

          // Always reset the form
          this.resetForm();

          // Then reapply the preselected content type if it exists
          if (preselectedType) {
            this.preselectContentType(preselectedType);
          }
          // Set topic after reset and content type
          if (preselectedTopic) {
            console.log('[CreatePOVFlow] Setting topicInput to:', preselectedTopic);
            this.topicInput = preselectedTopic;
            this.cdr.detectChanges();
          }
        }
      });
  }

  private preselectContentType(contentType: string): void {
    // Reset all content types first
    this.contentTypeArticle = false;
    this.contentTypeBlog = false;
    this.contentTypeExecutiveBrief = false;
    this.contentTypeWhitePaper = false;
    this.contentTypePov = false;
    // Set the selected content type
    switch (contentType) {
      case 'Article':
        this.contentTypeArticle = true;
        break;
      case 'Blog':
        this.contentTypeBlog = true;
        break;
      case 'Executive Brief':
        this.contentTypeExecutiveBrief = true;
        break;
      case 'White Paper':
        this.contentTypeWhitePaper = true;
        break;
    }
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  // Copy to Clipboard functionality removed

  private getContentTypeLabel(contentType: string): string {
    const labels: { [key: string]: string } = {
      'article': 'Article',
      'blog': 'Blog Post',
      'white_paper': 'White Paper',
      'executive_brief': 'Executive Brief',
      'podcast': 'Podcast'
    };
    return labels[contentType] || contentType;
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[CreatePOVFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  private formatContentWithSpacing(content: string): string {
  // Ultra-compact formatting - minimal line breaks
  let formatted = content
    // Replace multiple newlines with single newline
    .replace(/\n{2,}/g, '\n')
    // Remove line breaks within paragraphs (join lines)
    .replace(/([^\n-*#\d])\n([^\n-*#\d])/g, '$1 $2')
    // Add single spacing before headers
    .replace(/([^\n])\n(#{1,6}\s)/g, '$1\n$2')
    // Add single spacing before lists
    .replace(/([^\n-*\d])\n([-*]\s)/g, '$1\n$2')
    .replace(/([^\n\d])\n(\d+\.\s)/g, '$1\n$2')
    .trim();

  return formatted;
}

  get isOpen(): boolean {
    return this.miFlowService.currentFlow === 'create-pov';
  }

  onClose(): void {
    this.cancelStream();
    this.miFlowService.closeAllFlows();
  }

  back(): void{
    this.cancelStream();
    this.miFlowService.closeFlow();
    this.miFlowService.openGuidedDialog();
  }

  resetForm(): void {
    this.topicInput = '';
    this.clientName = '';
    this.outlineTextInputError = '';
    this.contentTypeArticle = false;
    this.contentTypeBlog = false;
    this.contentTypeExecutiveBrief = false;
    this.contentTypeWhitePaper = false;
    this.contentTypePov = false;
    this.wordLimit = '';
    this.audienceTone = '';
      this.formData = {
      outlineFile: null,
      supportingDocsFile: null,
      supportingDocsFiles: []
    };
    this.conductResearch = false;
    this.clearResearchFields();
    this.additionalGuidelines = '';
    this.createPOV = '';
    this.outlineTextInput = '';
    this.allPwcProprietarySources = true;
    this.allPwcThirdPartySources = true;
    this.showSatisfactionPrompt = false;
    this.showImprovementInput = false;
    this.improvementRequestText = '';
    this.iterationCount = 0;
    // Reset all proprietary sources array to selected (ON by default)
  this.pwcProprietarySources.forEach(source => source.selected = true);

  // Reset all third party sources array to selected (ON by default)
  this.pwcThirdPartySources.forEach(source => source.selected = true);
  }

  private clearResearchFields(): void {
    this.researchTopics = '';
    this.pwcContentLink = false;
    this.pwcProprietaryResearch = true;
    this.pwcLicensedThirdParty = true;
    this.externalResearch = true;
    this.researchDocumentFile = null;
    this.researchLinks = '';
    this.formData.supportingDocsFiles = [];
    this.extractedDocumentsMap.clear();
    this.isExtractingText = false;
    this.extractionError = '';
    this.selectSpecificPwcSources = false;
    this.clearPwcSources();
  }

  private clearPwcSources(): void {
    this.allPwcProprietarySources = true;
    this.pwcSource1 = false;
    this.pwcSource2 = false;
    this.pwcSource3 = false;
    this.pwcSource4 = false;
    this.allPwcThirdPartySources = true;
    this.pwcThirdPartySource1 = false;
    this.pwcThirdPartySource2 = false;
    this.pwcThirdPartySource3 = false;
    this.pwcThirdPartySource4 = false;
  }

  onContentTypeToggle(type: string, newValue: boolean): void {
    // Ensure only ONE content type is ON at a time (exclusive selection)
    if (newValue) {
      switch (type) {
        case 'article':
          this.contentTypeBlog = false;
          this.contentTypeExecutiveBrief = false;
          this.contentTypeWhitePaper = false;
          break;
        case 'blog':
          this.contentTypeArticle = false;
          this.contentTypeExecutiveBrief = false;
          this.contentTypeWhitePaper = false;
          break;
        case 'executive-brief':
          this.contentTypeArticle = false;
          this.contentTypeBlog = false;
          this.contentTypeWhitePaper = false;
          break;
        case 'white-paper':
          this.contentTypeArticle = false;
          this.contentTypeBlog = false;
          this.contentTypeExecutiveBrief = false;
          break;
      }
    }
  }

  onResearchToggle(value: boolean): void {
    this.conductResearch = value;
    if (!value) {
      this.clearResearchFields();
    }
  }

  onOutlineFileSelected(file: File): void {
    this.formData.outlineFile = file;
  }

  onSupportingDocsFileSelected(file: File): void {
    this.formData.supportingDocsFile = file;

  //   if (file.length > 3) {
  //   this.formData.supportingDocsFile = file.slice(0, 3);
  //   alert("You can upload a maximum of 3 supporting documents. Only the first 3 were accepted.");
  // } else {
  //   this.formData.supportingDocsFile = file;
  // }

  }
  onOutlineTextInputChange(value: string): void {
    if (value && value.trim()) {
      const wordCount = value.trim().split(/\s+/).length;
      if (wordCount < this.MIN_OUTLINE_WORDS) {
        this.outlineTextInputError = `Outline must contain at least ${this.MIN_OUTLINE_WORDS} words. Current: ${wordCount} words.`;
      } else {
        this.outlineTextInputError = '';
      }
    } else {
      this.outlineTextInputError = '';
    }
  }

  
  // Handle multiple supporting documents upload
  onSupportingDocsFilesChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const filesArray = Array.from(input.files);
      
      // Check if adding these files would exceed max
      const totalFiles = this.formData.supportingDocsFiles.length + filesArray.length;
      if (totalFiles > this.MAX_SUPPORTING_DOCS) {
        const availableSlots = this.MAX_SUPPORTING_DOCS - this.formData.supportingDocsFiles.length;
        if (availableSlots > 0) {
          this.formData.supportingDocsFiles.push(...filesArray.slice(0, availableSlots));
          this.supportingDocsError = `Only ${availableSlots} file(s) were added. Maximum of ${this.MAX_SUPPORTING_DOCS} files allowed.`;
        } else {
          this.supportingDocsError = `Maximum of ${this.MAX_SUPPORTING_DOCS} supporting documents already reached.`;
        }
      } else {
        this.formData.supportingDocsFiles.push(...filesArray);
        this.supportingDocsError = '';
      }
      
      // Reset the input so the same file can be selected again
      input.value = '';
      
      // Validate token count
     // this.validateSupportingDocsTokenCount();
    }
  }


  onResearchDocumentSelected(file: File): void {
    this.researchDocumentFile = file;
  }

    onAllPwcProprietaryToggle(value: boolean): void {
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  onAllPwcThirdPartySourcesChange(): void {
    const value = this.allPwcThirdPartySources;
    this.pwcThirdPartySource1 = value;
    this.pwcThirdPartySource2 = value;
    this.pwcThirdPartySource3 = value;
    this.pwcThirdPartySource4 = value;
  }

  // onPwcProprietarySourceChange(): void {
  //   // Sync "All" checkbox with individual sources
  //   // Use setTimeout to ensure Angular has updated the bound values first
  //   setTimeout(() => {
  //     this.allPwcProprietarySources = this.pwcSource1 && this.pwcSource2 && this.pwcSource3 && this.pwcSource4;
  //   });
  // }

  // onPwcThirdPartySourceChange(): void {
  //   // Sync "All" checkbox with individual sources
  //   // Use setTimeout to ensure Angular has updated the bound values first
  //   setTimeout(() => {
  //     this.allPwcThirdPartySources = this.pwcThirdPartySource1 && this.pwcThirdPartySource2 && this.pwcThirdPartySource3 && this.pwcThirdPartySource4;
  //   });
  // }

  onAllPwcThirdPartyToggle(value: boolean): void {
  this.allPwcThirdPartySources = value;
  this.pwcThirdPartySources.forEach(source => source.selected = value);
}


onPwcThirdPartySourceChange(): void {
  this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
}

  removeSupportingDoc(index: number): void {
    const file = this.formData.supportingDocsFiles[index];
    if (file) {
      // Remove the extracted text from the map
      this.extractedDocumentsMap.delete(file.name);
    }
    this.formData.supportingDocsFiles.splice(index, 1);
  }

  onSupportingDocsSelected(files: File | File[]): void {
    const incomingFiles = Array.isArray(files) ? files : [files];

    // Prevent adding more than 5 files
    if (this.formData.supportingDocsFiles.length >= 5) {
      return;
    }

    for (const file of incomingFiles) {
      if (this.formData.supportingDocsFiles.length >= 5) {
        break;
      }
      const alreadyAdded = this.formData.supportingDocsFiles.some(
        existing =>
          existing.name === file.name &&
          existing.size === file.size
      );

      if (!alreadyAdded) {
        this.formData.supportingDocsFiles.push(file);
        // Extract text for the new file
        this.extractTextFromFile(file);
      }
    }
  }

  /**
   * Extract text from uploaded document using the extract-text API
   */
  private async extractTextFromFile(file: File): Promise<void> {
    console.log('[CreatePOVFlow] Extracting text from:', file.name);
    
    this.isExtractingText = true;
    this.extractionError = '';
    this.cdr.detectChanges();

    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const endpoint = `${apiUrl}/api/v1/export/extract-text`;

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await this.authFetchService.authenticatedFetchFormData(endpoint, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[CreatePOVFlow] Extract-text failed for ${file.name}:`, response.status, errorText);
        this.extractionError = `Failed to extract text from "${file.name}".`;
        this.isExtractingText = false;
        this.cdr.detectChanges();
        return;
      }

      const data = await response.json();
      const extractedText = data?.text || '';

      if (!extractedText) {
        console.warn(`[CreatePOVFlow] Extract-text returned empty text for ${file.name}`);
        this.extractionError = `No text could be extracted from "${file.name}".`;
        this.isExtractingText = false;
        this.cdr.detectChanges();
        return;
      }

      console.log(`[CreatePOVFlow] Text extracted from ${file.name}, length:`, extractedText.length, 'chars');
      
      // Store extracted text mapped by filename
      this.extractedDocumentsMap.set(file.name, extractedText);
      
      this.isExtractingText = false;
      this.cdr.detectChanges();

    } catch (error) {
      console.error('[CreatePOVFlow] Error extracting text:', error);
      this.extractionError = `An error occurred while extracting text from "${file.name}".`;
      this.isExtractingText = false;
      this.cdr.detectChanges();
    }
  }

  get invalidLinks(): boolean {
    if (!this.researchLinks) return false;

    return this.researchLinks
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .some(link => !/^https?:\/\/.+/.test(link));
  }

  get showPwcSourceSelection(): boolean {
    // return this.conductResearch &&
    return this.selectSpecificPwcSources &&
      (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }

  get showPwcProprietarySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcProprietaryResearch;
  }

  get showPwcThirdPartySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcLicensedThirdParty;
  }

  get canGeneratePOV(): boolean {
    // Must have topic
    if (!this.topicInput.trim()) return false;

    // Must have selected a content type (one of the exclusive toggles)
    if (!this.contentTypeArticle && !this.contentTypeBlog &&
        !this.contentTypeExecutiveBrief && !this.contentTypeWhitePaper) {
      return false;
    }
   // Must have outline file
    if (!this.formData.outlineFile && !this.outlineTextInput.trim()) {
        return false;
    }
    if (this.outlineTextInputError) return false;
    return true;
    }

  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);

    // Get API URL from environment (supports runtime config via window._env)
    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/export/extract-text`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }

    const data = await response.json();
    return data.text || '';
  }

  async generatePOVContent(): Promise<void> {
    if (!this.canGeneratePOV) {
      console.error('Form validation failed');
      return;
    }
    // Validate word limit before generating
    if (this.wordLimit && Number(this.wordLimit) > this.maxWordLimit) {
      this.wordLimitError = `Word limit cannot exceed ${this.maxWordLimit}.`;
      return;
    }

    this.isGenerating = true;
    this.createPOV = '';

    try {
      // Determine selected content type
      let contentType = '';
      let contentTypeKey = '';
      if (this.contentTypeArticle) {
        contentType = 'Article';
        contentTypeKey = 'article';
      } else if (this.contentTypeBlog) {
        contentType = 'Blog';
        contentTypeKey = 'blog';
      } else if (this.contentTypeExecutiveBrief) {
        contentType = 'Executive Brief';
        contentTypeKey = 'executive_brief';
      } else if (this.contentTypeWhitePaper) {
        contentType = 'White Paper';
        contentTypeKey = 'white_paper';
      }

      // Build the original prompt text for messages field
      let prompt = `Please draft the following type of content:\n\n`;
      prompt += `Content Type: ${contentType}\n`;
      prompt += `Topic: ${this.topicInput}\n`;
      prompt += `Client name: ${this.clientName}\n`;
      if (String(this.wordLimit).trim()) {
        prompt += `Word Limit: ${this.wordLimit}\n`;
      }
      prompt += `Audience/Tone: ${this.audienceTone}\n`;

      // Extract outline text
      let contentoutlineText = '';
      let outlineType: 'text' | 'file' = 'text';
      
      if (this.formData.outlineFile) {
        console.log('Extracting outline file text');
        const outlineText = await this.extractFileText(this.formData.outlineFile);
        contentoutlineText = outlineText;
        this.originalcontentoutlineText = contentoutlineText;
        outlineType = 'file';
        prompt += `\nInitial Outline/Concept:\n${this.originalcontentoutlineText}\n`;
      } else if (this.outlineTextInput.trim()) {
        contentoutlineText = this.outlineTextInput.trim();
        this.originalcontentoutlineText = contentoutlineText;
        outlineType = 'text';
        prompt += `\nInitial Outline/Concept:\n${this.originalcontentoutlineText}\n`;
      }

      // Extract supporting document text
      let contentText = '';
      if (this.formData.supportingDocsFile) {
        const extractedText = await this.extractFileText(this.formData.supportingDocsFile);
        contentText = extractedText;
        this.originalContent = contentText;
        prompt += `\nSupporting Documents:\n${this.originalContent}\n`;
      }

      // Check if Factiva is selected
      const isFactivaSelected = this.pwcThirdPartySources.some(source => source.name === 'Factiva, WSJ, Dow Jones' && source.selected);
      if (isFactivaSelected) {
        prompt += `\nUse Factiva, WSJ, Dow Jones Research: true\n`;
      }

      // Add research to prompt
      if (this.conductResearch) {
        prompt += `\nResearch Requested: Yes\n`;
        prompt += `Research Topics: ${this.researchTopics}\n`;

        const sources = [];
        if (this.pwcContentLink) sources.push('PwC Content or Link');
        if (this.pwcProprietaryResearch) sources.push('PwC Proprietary Research');
        if (this.pwcLicensedThirdParty) sources.push('PwC Licensed Third Party Tools');
        if (this.externalResearch) sources.push('External Research');

        if (sources.length > 0) {
          prompt += `Research Sources: ${sources.join(', ')}\n`;
        }

        if (this.researchLinks) {
          prompt += `Research Links: ${this.researchLinks}\n`;
        }

        if (this.researchDocumentFile) {
          prompt += `Research Document: ${this.researchDocumentFile.name}\n`;
        }
      }

      if (this.additionalGuidelines.trim()) {
        prompt += `\nAdditional Guidelines: ${this.additionalGuidelines}\n`;
      }

      // Build structured research object
      const researchData: any = {
        isSelected: this.conductResearch
      };

      if (this.conductResearch) {
        // Add research topics if provided
        if (this.researchTopics.trim()) {
          researchData.research_topics = this.researchTopics;
        }

        // Add additional guidelines if provided
        if (this.additionalGuidelines.trim()) {
          researchData.additional_guidelines = this.additionalGuidelines;
        }

        // PwC Content - only include if toggle is ON
        if (this.pwcContentLink) {
          researchData.pwc_content = {
            isSelected: true
          };

          // Add research document text if file was uploaded
          if (this.researchDocumentFile) {
            try {
              const researchDocText = await this.extractFileText(this.researchDocumentFile);
              researchData.pwc_content.supportingDoc = researchDocText;
            } catch (error) {
              console.error('[CreatePOVFlow] Error extracting research document:', error);
            }
          }

          // Add instructions if provided
          if (this.researchDocInstructions) {
            researchData.pwc_content.supportingDoc_instructions = this.researchDocInstructions;
          }

          // Add research links if provided
          if (this.researchLinks) {
            researchData.pwc_content.research_links = this.researchLinks;
          }
        }

        // Proprietary Sources - only include if toggle is ON
        if (this.pwcProprietaryResearch) {
          const selectedProprietarySources = this.pwcProprietarySources
            .filter(s => s.selected)
            .map(s => s.name);

          researchData.proprietary = {
            isSelected: true,
            sources: selectedProprietarySources
          };
        }

        // Third Party Sources - only include if toggle is ON
        if (this.pwcLicensedThirdParty) {
          const selectedThirdPartySources = this.pwcThirdPartySources
            .filter(s => s.selected)
            .map(s => s.name);

          researchData.thirdParty = {
            isSelected: true,
            sources: selectedThirdPartySources
          };
        }

        // External Research - only include if toggle is ON
        if (this.externalResearch) {
          researchData.externalResearch = {
            isSelected: true
          };

          // Add research links if provided
          if (this.researchLinks) {
            researchData.externalResearch.research_links = this.researchLinks;
          }
        }
      }

      // Build the complete payload with all user selections nested under `services`
      const services: any = {};

      // Draft/service-specific parameters
      services.draft = {
        content_type: contentTypeKey,
        topic: this.topicInput,
        client: this.clientName,
        audience_tone: this.audienceTone,
        outline: {
          type: outlineType,
          content: contentoutlineText
        }
      };

      // Add optional draft-level fields
      if (this.wordLimit && String(this.wordLimit).trim()) {
        services.draft.word_limit = this.wordLimit;
      }

      if (contentText) {
        services.draft.supporting_documents = {
          content: contentText
        };
      }

      // Attach research configuration under services
      services.research = researchData;

      const payload: any = {
        messages: [{ role: 'user' as const, content: prompt }],
        services,
        stream: true
      };

      console.log('[CreatePOVFlow] Sending structured request (messages + services):', {
        contentType: contentTypeKey,
        client: this.clientName,
        topic: this.topicInput,
        hasResearch: this.conductResearch
      });

      // Store original parameters for improvement iterations
      this.originalContentType = contentType;
      this.originalWordLimit = this.wordLimit;
      this.originalAudienceTone = this.audienceTone;
      this.originalOutlineDoc = contentoutlineText;
      this.originalSupportingDoc = contentText;
      this.originalUseFactivaResearch = isFactivaSelected;

      this.streamSubscription = this.chatService.streamPOVContent(payload as any).subscribe({
        next: (data: any) => {
          if (typeof data === 'string') {
            this.createPOV += data;
          } else if (data.type === 'content' && data.content) {
            this.createPOV += data.content;
          }
        },
        error: (error: any) => {
          console.error('[CreatePOVFlow] Error:', error);
          this.createPOV = 'Sorry, there was an error generating your POV content. Please try again.';
          this.isGenerating = false;
        },
        complete: () => {
          console.log('[CreatePOVFlow] POV generation complete');
          this.isGenerating = false;

          // Send content to chat immediately with satisfaction question
          if (this.createPOV && this.createPOV.trim()) {
            this.iterationCount = 1;
            this.sendDraftToChatWithSatisfactionQuestion();
          }
        }
      });
    } catch (error) {
      console.error('[CreatePOVFlow] Error:', error);
      this.isGenerating = false;
    }
  }

  /** Get satisfaction prompt text */
  getSatisfactionPromptText(): string {
    if (this.iterationCount === 0) {
      return 'Are you satisfied with the generated content, or do you need additional improvements?';
    }
    return `Are you satisfied with this revision (Iteration ${this.iterationCount}), or do you need additional improvements?`;
  }

  /** Send draft content to chat with satisfaction question */
  private sendDraftToChatWithSatisfactionQuestion(): void {
    if (this.createPOV && this.createPOV.trim()) {
      let plainText = this.createPOV;
      if (this.createPOV.includes('<')) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = this.createPOV;
        plainText = tempDiv.textContent || tempDiv.innerText || '';
      }

      // Map content type to metadata format
      let metadataContentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' |'pov'| 'podcast' = 'pov';
      if (this.contentTypeBlog) metadataContentType = 'blog';
      else if (this.contentTypeWhitePaper) metadataContentType = 'white_paper';
      else if (this.contentTypeExecutiveBrief) metadataContentType = 'executive_brief';
      else if (this.contentTypePov) metadataContentType =  'pov';
 

      // Prepend a header with content type for better identification
      //const contentWithHeader = `**Generated Content** - ${this.getContentTypeLabel(metadataContentType)}\n\n${this.createPOV}`;
      const contentWithHeader = `${this.createPOV}`;
      const metadata: MarketIntelligenceMetadata = {
        contentType: metadataContentType,
        topic: this.topicInput,
        fullContent: plainText,
        showActions: true
      };

      // Send the draft content to chat
      console.log('[CreatePovFlow] Sending create pov to chat:', metadata);
      this.miChatBridge.sendToChat(contentWithHeader, metadata);

      // Store draft context for handling improvement requests
      // this.miChatBridge.setDraftContext({
      //   contentType: this.originalContentType,
      //   topic: this.topicInput,
      //   wordLimit: this.originalWordLimit,
      //   audienceTone: this.originalAudienceTone,
      //   outlineDoc: this.originalOutlineDoc,
      //   supportingDoc: this.originalSupportingDoc,
      //   useFactivaResearch: this.originalUseFactivaResearch,
      //   generatedContent: plainText
      // });
      console.log('[CreatePOVFlow] ✓ POV context stored successfully');

      // Add satisfaction question as a system message in the chat
      const satisfactionMessage = 'Are you satisfied with this content? If not, let me know what improvements you\'d like and I\'ll regenerate it for you.';
      console.log('[CreatePOVFlow] Sending satisfaction question to chat');
      
      // Send as a system message using sendMessage method
      const systemMessage: Message = {
        role: 'system',
        content: satisfactionMessage,
        timestamp: new Date()
      };
      //this.miChatBridge.sendMessage(systemMessage);
      console.log('[CreatePOVFlow] ✓ Satisfaction question sent');

      // Close the modal after sending to chat
      console.log('[CreatePOVFlow] About to close modal');
      this.onClose();
      console.log('[CreatePOVFlow] Modal closed');
    }
  }

  /** Get validation for improvement request */
  get isImprovementRequestValid(): boolean {
    return !!this.improvementRequestText && this.improvementRequestText.trim().length > 0;
  }

  /** Trigger change detection when improvement text changes */
  onImprovementTextChange(): void {
    this.cdr.markForCheck();
  }

  /** Handle satisfaction response - send to chat or show improvement input */
  onSatisfactionResponse(isSatisfied: boolean): void {
    if (isSatisfied) {
      if (this.createPOV && this.createPOV.trim()) {
        let plainText = this.createPOV;
        if (this.createPOV.includes('<')) {
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = this.createPOV;
          plainText = tempDiv.textContent || tempDiv.innerText || '';
        }

        // Map content type to metadata format
        let metadataContentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast' = 'article';
        if (this.contentTypeBlog) metadataContentType = 'blog';
        else if (this.contentTypeWhitePaper) metadataContentType = 'white_paper';
        else if (this.contentTypeExecutiveBrief) metadataContentType = 'executive_brief';

        // Prepend a header with content type for better identification
        const contentWithHeader = `**Generated Content** - ${this.getContentTypeLabel(metadataContentType)}\n\n${this.createPOV}`;

        const metadata: MarketIntelligenceMetadata = {
          contentType: metadataContentType,
          topic: this.topicInput,
          fullContent: plainText,
          showActions: true
        };

        console.log('[CreatePOVFlow] Sending satisfied content to chat:', metadata);
        this.miChatBridge.sendToChat(contentWithHeader, metadata);

        // Close the modal after sending to chat
        this.onClose();
      }
    } else {
      // Show improvement input
      this.showImprovementInput = true;
      this.showSatisfactionPrompt = false;
    }
  }

  /** Submit improvement request */
  submitImprovementRequest(): void {
    if (!this.improvementRequestText?.trim()) {
      return;
    }

    const nextIteration = this.iterationCount + 1;
    if (nextIteration > 5) {
      alert('You have reached the maximum number of iterations (5). Please start a new draft if you need further changes.');
      this.cancelImprovementRequest();
      return;
    }

    const revisedPlainText = this.createPOV.replace(/<br>/g, '\n');
    const improvementMessage = `Topic: ${this.topicInput}\n\nPlease review the following generated content and apply these improvements:\n\n${this.improvementRequestText.trim()}\n\nGenerated Content:\n${revisedPlainText}`;

    const messages = [{
      role: 'user' as const,
      content: improvementMessage
    }];

    this.isGenerating = true;
    this.showImprovementInput = false;
    
    // Store the improvement text before clearing it
    const improvementText = this.improvementRequestText;
    this.improvementRequestText = '';
    this.createPOV = '';

    // Prepare draft parameters to send to backend
    const draftParams = {
      contentType: this.originalContentType,
      wordLimit: this.originalWordLimit,
      audienceTone: this.originalAudienceTone,
      outlineDoc: this.originalOutlineDoc,
      supportingDoc: this.originalSupportingDoc,
      useFactivaResearch: this.originalUseFactivaResearch
    };

    this.streamSubscription = this.chatService.streamDraftContent(messages, improvementText, draftParams).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.createPOV += data;
        } else if (data.type === 'content' && data.content) {
          this.createPOV += data.content;
        }
      },
      error: (error: any) => {
        console.error('[CreatePOVFlow] Error improving content:', error);
        this.createPOV = 'Sorry, there was an error processing your improvement request. Please try again.';
        this.isGenerating = false;
        this.createPOV = revisedPlainText.replace(/\n/g, '<br>');
        this.showSatisfactionPrompt = true;
      },
      complete: () => {
        this.isGenerating = false;
        this.iterationCount = nextIteration;
        this.showSatisfactionPrompt = true;
      }
    });
  }

  /** Cancel improvement request and return to satisfaction prompt */
  cancelImprovementRequest(): void {
    this.showImprovementInput = false;
    this.improvementRequestText = '';
    this.showSatisfactionPrompt = true;
  }
}


