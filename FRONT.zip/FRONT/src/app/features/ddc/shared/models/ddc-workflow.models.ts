/**
 * Shared TypeScript interfaces for DDC workflows
 * Enables type safety and consistent contracts across all workflows
 */

export interface DdcWorkflowConfig {
  id: string;
  title: string;
  steps: DdcStepConfig[];
  requiresSecondaryUpload?: boolean;
}

export interface DdcStepConfig {
  id: number;
  title: string;
  subtitle?: string;
  validationFn?: () => boolean;
}

export interface DdcFormValues {
  file: File | null;
  secondaryFile?: File | null;
  selectedOptions: string[];
  customInputs: Record<string, any>;
}

export interface DdcSseEvent {
  content: string;
  done?: boolean;
  error?: string;
}

export interface DdcRequestPayload {
  workflowType: string;
  file: File;
  options: Record<string, any>;
}
