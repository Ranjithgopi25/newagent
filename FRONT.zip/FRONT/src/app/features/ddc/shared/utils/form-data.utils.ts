/**
 * Shared utilities for FormData assembly across DDC workflows
 * Centralizes payload construction to minimize duplication
 */

export class DdcFormDataBuilder {
  private formData: FormData;

  constructor() {
    this.formData = new FormData();
  }

  addFile(key: string, file: File | null): this {
    if (file) {
      this.formData.append(key, file);
    }
    return this;
  }

  addField(key: string, value: string | number | boolean): this {
    this.formData.append(key, String(value));
    return this;
  }

  addJsonField(key: string, value: any): this {
    this.formData.append(key, JSON.stringify(value));
    return this;
  }

  addOptions(options: string[]): this {
    this.formData.append('options', JSON.stringify(options));
    return this;
  }

  build(): FormData {
    return this.formData;
  }
}

export function buildDdcFormData(
  file: File,
  options: Record<string, any>
): FormData {
  const builder = new DdcFormDataBuilder();
  builder.addFile('file', file);
  
  Object.entries(options).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      builder.addJsonField(key, value);
    } else if (value instanceof File) {
      builder.addFile(key, value);
    } else {
      builder.addField(key, value);
    }
  });
  
  return builder.build();
}
