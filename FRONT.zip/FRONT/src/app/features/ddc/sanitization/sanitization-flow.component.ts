import { Component, Input, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { AuthFetchService } from '../../../core/services/auth-fetch.service';
import { environment } from '../../../../environments/environment';
import { DDCRequestFormComponent } from '../../phoenix/ddc/request-form-ddc';

interface SanitizationService {
  id: string;
  label: string;
  selected: boolean;
}

@Component({
    selector: 'app-sanitization-flow',
    imports: [FormsModule, DDCRequestFormComponent],
    templateUrl: './sanitization-flow.component.html',
    styleUrls: ['./sanitization-flow.component.scss']
})
export class SanitizationFlowComponent implements OnInit, OnDestroy {
  // Input properties from parent component
  @Input() hideBackButton: boolean = false;
  @Input() openedFrom: 'quick-action' | 'guided-dialog' | null = null;

  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  showCreateRequestButton = false;
  showRequestForm = false;
  phoenixRdpLink = '';

  // Form fields
  uploadedFile: File | null = null;
  selectedTemplate: string = 'existing';
  customTemplateFile: File | null = null;
  clientIdentifiers: string = '';
  additionalGuidelines: string = '';

  // Sanitization services (4 default-checked)
  sanitizationServices: SanitizationService[] = [
    { id: 'replace_client', label: 'Replace Client Name and Logos', selected: true },
    { id: 'delete_notes', label: 'Delete Notes/Comments', selected: true },
    { id: 'cut_hyperlinks', label: 'Cut Hyperlinks', selected: true },
    { id: 'mask_leadership', label: 'Mask Leadership/Employee Names or Client-Identifying Titles', selected: true },
    { id: 'change_competitors', label: 'Change Competitor Names, Logos, and Product Names', selected: false },
    { id: 'remove_data', label: 'Remove Client-specific Data (e.g., Financials, FTEs, Ops. Metrics)', selected: false },
    { id: 'conceal_regions', label: 'Conceal Regions and Locations', selected: false },
    { id: 'disguise_bus', label: 'Disguise Client-identifying BUs', selected: false }
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService,
    private authFetchService: AuthFetchService
  ) {}


  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'sanitization';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SanitizationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = 'core';
    this.customTemplateFile = null;
    this.clientIdentifiers = '';
    this.additionalGuidelines = '';
    // this.sanitizationServices.forEach((service, index) => {
    //   // First 4 services default to checked
    //   service.selected = index < 8;
    // });
    this.sanitizationServices = [
    { id: 'replace_client', label: 'Replace Client Name, Logos and Product Names', selected: true },
    { id: 'delete_notes', label: 'Delete Notes/Comments', selected: true },
    { id: 'cut_hyperlinks', label: 'Cut Hyperlinks', selected: true },
    { id: 'mask_leadership', label: 'Mask Leadership/Employee Names or Client-Identifying Titles', selected: true },
    { id: 'change_competitors', label: 'Change Competitor Names, Logos, and Product Names', selected: false },
    { id: 'remove_data', label: 'Remove Financials', selected: false },
    { id: 'conceal_regions', label: 'Conceal Regions and Locations', selected: false },
    { id: 'disguise_bus', label: 'Disguise Client-identifying BUs', selected: false }
  ];
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onTemplateFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.customTemplateFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.selectedTemplate === 'other' && !this.customTemplateFile) return false;
    return this.sanitizationServices.some(s => s.selected);
  }

  get selectedServices(): SanitizationService[] {
    return this.sanitizationServices.filter(s => s.selected);
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.canGenerate) return;

    try {
      this.isGenerating = true;
      this.generatedContent = 'Sanitizing your presentation... This may take a moment.';
      console.log('[SanitizationFlow] Additional Guidelines:', this.additionalGuidelines);

      console.log('[SanitizationFlow] Additional Guidelines:', this.additionalGuidelines);

      const formData = new FormData();
      formData.append('file', this.uploadedFile!);
      formData.append('template', this.selectedTemplate);
      if (this.customTemplateFile) {
        formData.append('custom_template', this.customTemplateFile);
      }
      formData.append('client_identifiers', this.clientIdentifiers);
      formData.append('services', JSON.stringify(this.selectedServices.map(s => s.id)));
      formData.append('additional_guidelines', this.additionalGuidelines);

      console.log('[SanitizationFlow] Additional Guidelines:', this.additionalGuidelines);

      console.log('[SanitizationFlow] Sending request with', this.selectedServices.length, 'services');

      // Call the backend to sanitize and download the file
      const apiUrl = environment.apiUrl || '';
      const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/ddc/sanitization`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        let errorMessage = `Sanitization failed: ${response.statusText}`;
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            errorMessage = errorData.detail;
          }
        } catch (e) {
          // If response is not JSON, use status text
        }
        throw new Error(errorMessage);
      }

      // Parse sanitization plan from response headers
      const planHeader = response.headers.get('X-Sanitization-Plan');
      const summaryHeader = response.headers.get('X-Sanitization-Summary');

      let planItems: any[] = [];
      let summary: any = null;

      try {
        if (planHeader) {
          planItems = JSON.parse(planHeader);
        }
        if (summaryHeader) {
          summary = JSON.parse(summaryHeader);
        }
      } catch (e) {
        console.warn('[SanitizationFlow] Could not parse sanitization plan from headers', e);
      }

      // Get the sanitized file
      const blob = await response.blob();
      const filename = this.uploadedFile!.name.replace('.pptx', '_sanitized.pptx');

      // Download the file
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      // Build clean line-by-line sanitization plan
      let planDisplay = '';
      if (planItems.length > 0) {
        planDisplay = '\n\nSanitization Plan:\n' + planItems.map((item: any) =>
          `✓ ${item.label}\n   ${item.details}`
        ).join('\n');
      }

      // Show success message with clean plan
      //this.generatedContent = `✅ Sanitization Complete!\n\nYour sanitized presentation "${filename}" has been downloaded.${planDisplay}`;
      this.generatedContent = `🎉 Sanitization completed successfully!`;
      if (summary) {
        this.generatedContent += `\n\nSummary: ${summary.slides_processed} slides processed, ${summary.total_changes} changes made.`;
      }

      this.isGenerating = false;
      this.showCreateRequestButton = true;

      console.log('[SanitizationFlow] Sanitization and download complete');
    } catch (error) {
      console.error('[SanitizationFlow] Exception:', error);
      this.generatedContent = '❌ I apologize, but I encountered an error during sanitization. Please try again.';
      this.isGenerating = false;
    }
  }

  openRequestForm(): void {
    this.showRequestForm = true;
  }

  onTicketCreated(event: {requestNumber: string, phoenixRdpLink: string}): void {
    this.phoenixRdpLink = event.phoenixRdpLink;
    this.generatedContent = `✅ Request created successfully! Your request number is: <a href="${event.phoenixRdpLink}" target="_blank">${event.requestNumber}</a>`;
    this.showRequestForm = false;
    this.showCreateRequestButton = false;
  }
}
