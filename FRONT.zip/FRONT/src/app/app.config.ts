import { ApplicationConfig, importProvidersFrom, ErrorHandler } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi, withInterceptors, HTTP_INTERCEPTORS, HttpInterceptorFn } from '@angular/common/http';
import { routes } from './app.routes';
import { provideAnimations } from '@angular/platform-browser/animations';
// MSAL Imports
import { BrowserCacheLocation, InteractionType, PublicClientApplication, LogLevel } from '@azure/msal-browser';
import { MsalGuard, MsalInterceptor, MsalModule, MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { GlobalErrorHandler } from './app.global-error-handler';
import { environment } from '../environments/environment';
import { authErrorInterceptor } from './core/interceptors/auth-error.interceptor';
import { inject } from '@angular/core';
import { from, switchMap } from 'rxjs';
import { AuthService } from './auth/auth.service';
 
const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
 
 
const ENABLE_AUTH = environment.useAuth;

//console.log('[MSAL Config] ENABLE_AUTH:', ENABLE_AUTH);
//console.log('[MSAL Config] clientId:', environment.clientId);
//console.log('[MSAL Config] issuer:', environment.issuer);
 
// MSAL Configuration
export const msalConfig = {
  auth: {
    //clientId: '6e658362-b527-4141-8fa1-17c4ac17ce3d', // Replace with your Azure AD Client ID
    clientId: environment.clientId,
    //authority: 'https://login.microsoftonline.com/d4093791-9818-48dc-8880-35d134b8c79d', // Replace with your Tenant ID
    authority: environment.issuer, // Replace with your Tenant ID
    redirectUri: window.location.origin,
    postLogoutRedirectUri: window.location.origin,
    navigateToLoginRequestUrl: false,
  },
  cache: {
    cacheLocation: BrowserCacheLocation.SessionStorage,
    storeAuthStateInCookie: isIE,
  },
  system: {
    loggerOptions: {
      // Print MSAL logs to console (non-PII only) so we can debug token acquisition
      loggerCallback: (level: any, message: string, containsPii: boolean) => {
        if (containsPii) {
          return;
        }
        // level: 0 = Error, 1 = Info, 2 = Verbose, 3 = Warning in some msal builds - print generically
        try {
          const levelName = typeof level === 'string' ? level : ['ERROR','INFO','VERBOSE','WARNING'][level] ?? level;
          // Use debug for verbose detail
          if (levelName === 'VERBOSE') {
            //console.debug(`[MSAL ${levelName}] ${message}`);
          } else if (levelName === 'ERROR') {
            //console.error(`[MSAL ${levelName}] ${message}`);
          } else {
            //console.log(`[MSAL ${levelName}] ${message}`);
          }
        } catch (e) {
          //console.log('[MSAL] ', message);
        }
      },
      // Enable verbose logging from the library (some versions read this property)
      logLevel: LogLevel.Verbose
    }
  }
};
 
export const loginRequest = {
  scopes: ['User.Read']
};

/**
 * ID Token interceptor - attaches ID token to backend API requests
 * Defined here inline to avoid separate file
 */
const authIdTokenInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);

  // Only attach for requests to the configured API URL
  if (!environment.apiUrl || !req.url.startsWith(environment.apiUrl)) {
    return next(req);
  }

  // getAccessToken returns a Promise<string|null> (it actually returns idToken)
  return from(authService.getAccessToken()).pipe(
    switchMap(token => {
      if (token) {
        const modified = req.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`
          }
        });
        return next(modified);
      }
      return next(req);
    })
  );
};
 
export const appConfig: ApplicationConfig = {
  providers: [
    { provide: ErrorHandler, useClass: GlobalErrorHandler },    
    provideHttpClient(
      withInterceptorsFromDi(), 
      withInterceptors([authErrorInterceptor, authIdTokenInterceptor])
    ),
    provideAnimations(),
    ...(ENABLE_AUTH ? [
      // MSAL Module
      importProvidersFrom(
        MsalModule.forRoot(
          new PublicClientApplication(msalConfig),
          {
            interactionType: InteractionType.Redirect,
            authRequest: loginRequest
          },
          {
            interactionType: InteractionType.Redirect,
            // Only protect Microsoft Graph here. We handle attaching the ID token
            // for our backend API via a custom interceptor (authIdTokenInterceptor).
            protectedResourceMap: new Map([
              ['https://graph.microsoft.com/v1.0/me', ['User.Read']],
            ])
          }
        )
      ),
     
      // MSAL Services
      MsalService,
      MsalGuard,
      MsalBroadcastService,
     
      // MSAL Interceptor as HTTP_INTERCEPTORS
      {
        provide: HTTP_INTERCEPTORS,
        useClass: MsalInterceptor,
        multi: true
      }
    ] : []),
    provideRouter(routes)
  ]
};