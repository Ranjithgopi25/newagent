(function(window) {
  window._env = window._env || {};
  window._env.apiUrl = '${API_URL}';
}(this));

