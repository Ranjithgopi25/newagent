import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface MarketIntelligenceMetadata {
  contentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast'| 'conduct-research';
  topic: string;
  fullContent: string;
  showActions: boolean;
}

/**
 * Market Intelligence Chat Bridge Service
 * Routes responses from backend to Market Intelligence components
 * Completely isolated from Thought Leadership chat bridge
 */
@Injectable({
  providedIn: 'root'
})
export class MiChatBridgeService {
  private messageToChat = new BehaviorSubject<{
    content: string;
    metadata: MarketIntelligenceMetadata;
  } | null>(null);

  messageToChat$ = this.messageToChat.asObservable();

  constructor() {
    console.log('[MiChatBridge] Initialized - Market Intelligence chat bridge started');
  }

  sendToChat(content: string, metadata: MarketIntelligenceMetadata): void {
    console.log('[MiChatBridge] Sending to chat:', { content, metadata });
    this.messageToChat.next({
      content,
      metadata
    });
  }

  handleResponse(response: any, message: any): void {
    console.log('[MiChatBridge] Processing response:', response);
    // Handle post-processing of responses specific to MI
    if (response.metadata) {
      console.log('[MiChatBridge] Response has metadata:', response.metadata);
    }
  }

  clearMessage(): void {
    this.messageToChat.next(null);
  }
}
