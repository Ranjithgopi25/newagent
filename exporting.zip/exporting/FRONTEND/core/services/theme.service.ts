import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type ThemeMode = 'light' | 'dark' | 'auto';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private currentTheme = new BehaviorSubject<ThemeMode>('light');
  public theme$ = this.currentTheme.asObservable();

  constructor() {
    // Always set theme to light
    this.applyTheme('light');
    this.currentTheme.next('light');
  }

  setTheme(theme: ThemeMode): void {
    // Ignore theme changes, always stay light
    this.currentTheme.next('light');
    this.applyTheme('light');
  }

  private applyTheme(theme: ThemeMode): void {
    const root = document.documentElement;
    // Always apply light theme
    root.setAttribute('data-theme', 'light');
  }

  getCurrentTheme(): ThemeMode {
    return this.currentTheme.value;
  }
}
