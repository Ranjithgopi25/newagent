import { Injectable } from '@angular/core';
import { ContentSection } from '../models/canvas.model';

@Injectable({
  providedIn: 'root'
})
export class SectionParserService {

  private generateId(): string {
    return `section_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  parseArticle(content: string): ContentSection[] {
    const sections: ContentSection[] = [];
    const lines = content.split('\n');
    let currentParagraph: string[] = [];
    let inList = false;
    let listItems: string[] = [];
    let inCodeBlock = false;
    let codeLines: string[] = [];

    const flushParagraph = () => {
      if (currentParagraph.length > 0) {
        const text = currentParagraph.join('\n').trim();
        if (text) {
          sections.push({
            id: this.generateId(),
            type: 'paragraph',
            content: text,
            originalContent: text,
            isEdited: false,
            editHistory: []
          });
        }
        currentParagraph = [];
      }
    };

    const flushList = () => {
      if (listItems.length > 0) {
        sections.push({
          id: this.generateId(),
          type: 'list',
          content: listItems.join('\n'),
          originalContent: listItems.join('\n'),
          isEdited: false,
          editHistory: []
        });
        listItems = [];
        inList = false;
      }
    };

    const flushCodeBlock = () => {
      if (codeLines.length > 0) {
        sections.push({
          id: this.generateId(),
          type: 'code',
          content: codeLines.join('\n'),
          originalContent: codeLines.join('\n'),
          isEdited: false,
          editHistory: []
        });
        codeLines = [];
        inCodeBlock = false;
      }
    };

    lines.forEach(line => {
      const trimmed = line.trim();

      // Code block detection (triple backticks)
      if (trimmed.startsWith('```')) {
        if (inCodeBlock) {
          // End of code block
          flushCodeBlock();
        } else {
          // Start of code block
          flushParagraph();
          flushList();
          inCodeBlock = true;
        }
        return;
      }

      // If we're in a code block, collect lines
      if (inCodeBlock) {
        codeLines.push(line);
        return;
      }

      // Heading detection
      if (trimmed.startsWith('#')) {
        flushParagraph();
        flushList();
        const level = (trimmed.match(/^#+/) || [''])[0].length;
        const heading = trimmed.replace(/^#+\s*/, '');
        sections.push({
          id: this.generateId(),
          type: 'heading',
          content: heading,
          level: level,
          originalContent: heading,
          isEdited: false,
          editHistory: []
        });
        return;
      }

      // Quote detection
      if (trimmed.startsWith('>')) {
        flushParagraph();
        flushList();
        const quote = trimmed.replace(/^>\s*/, '');
        sections.push({
          id: this.generateId(),
          type: 'quote',
          content: quote,
          originalContent: quote,
          isEdited: false,
          editHistory: []
        });
        return;
      }

      // List detection
      if (trimmed.match(/^(\d+\.|-|\*)\s/)) {
        flushParagraph();
        inList = true;
        listItems.push(trimmed);
        return;
      }

      // Empty line handling
      if (trimmed === '') {
        if (inList) {
          flushList();
        } else {
          flushParagraph();
        }
        return;
      }

      // Regular paragraph
      if (inList) {
        flushList();
      }
      currentParagraph.push(line);
    });

    // Flush any remaining content
    flushParagraph();
    flushList();
    flushCodeBlock();

    return sections;
  }

  sectionsToText(sections: ContentSection[]): string {
    return sections.map(section => {
      switch (section.type) {
        case 'heading':
          const hashPrefix = '#'.repeat(section.level || 1);
          return `${hashPrefix} ${section.content}`;
        case 'quote':
          return `> ${section.content}`;
        case 'code':
          return `\`\`\`\n${section.content}\n\`\`\``;
        case 'list':
        case 'paragraph':
        default:
          return section.content;
      }
    }).join('\n\n');
  }

  updateSection(sections: ContentSection[], sectionId: string, newContent: string, prompt: string): ContentSection[] {
    return sections.map(section => {
      if (section.id === sectionId) {
        const edit: import('../models/canvas.model').SectionEdit = {
          timestamp: new Date(),
          prompt: prompt,
          previousContent: section.content,
          newContent: newContent
        };

        return {
          ...section,
          content: newContent,
          isEdited: true,
          editHistory: [...section.editHistory, edit]
        };
      }
      return section;
    });
  }
}
