import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { CanvasDocument, CanvasState, ContentSection } from '../models/canvas.model';
import { SectionParserService } from './section-parser.service';

interface HistoryEntry {
  sections: ContentSection[];
  timestamp: Date;
}

export interface CanvasContentUpdate {
  messageId: string;
  updatedContent: string;
}

@Injectable({
  providedIn: 'root'
})
export class CanvasStateService {
  
  constructor(private sectionParser: SectionParserService) {}
  private stateSubject = new BehaviorSubject<CanvasState>({
    document: null,
    selectedSectionId: null,
    isEditing: false,
    canUndo: false,
    canRedo: false,
    isOpen: false
  });

  public state$: Observable<CanvasState> = this.stateSubject.asObservable();
  
  // Subject to emit content updates back to chat
  private contentUpdateSubject = new Subject<CanvasContentUpdate>();
  public contentUpdate$: Observable<CanvasContentUpdate> = this.contentUpdateSubject.asObservable();

  private history: HistoryEntry[] = [];
  private currentHistoryIndex: number = -1;
  private maxHistorySize: number = 50;

  get currentState(): CanvasState {
    return this.stateSubject.value;
  }

  loadDocument(document: CanvasDocument): void {
    this.history = [{ sections: [...document.sections], timestamp: new Date() }];
    this.currentHistoryIndex = 0;
    
    this.updateState({
      document: document,
      selectedSectionId: null,
      isEditing: false,
      canUndo: false,
      canRedo: false,
      isOpen: true
    });
  }

  loadFromContent(content: string, title: string, contentType: 'article' | 'blog' | 'white_paper' | 'executive_brief', messageId?: string): void {
    const sections = this.sectionParser.parseArticle(content);
    
    const document: CanvasDocument = {
      id: `doc_${Date.now()}`,
      title: title,
      contentType: contentType,
      sections: sections,
      fullText: content,
      createdAt: new Date(),
      updatedAt: new Date(),
      messageId: messageId
    };
    
    this.loadDocument(document);
  }

  selectSection(sectionId: string | null): void {
    this.updateState({
      ...this.currentState,
      selectedSectionId: sectionId
    });
  }

  updateSections(sections: ContentSection[]): void {
    if (!this.currentState.document) return;

    // Add to history
    this.currentHistoryIndex++;
    this.history = this.history.slice(0, this.currentHistoryIndex);
    this.history.push({ sections: [...sections], timestamp: new Date() });

    // Limit history size
    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
      this.currentHistoryIndex--;
    }

    const updatedDocument: CanvasDocument = {
      ...this.currentState.document,
      sections: sections,
      updatedAt: new Date()
    };

    this.updateState({
      ...this.currentState,
      document: updatedDocument,
      canUndo: this.currentHistoryIndex > 0,
      canRedo: false
    });
    
    // Emit content update if messageId exists
    if (updatedDocument.messageId) {
      const updatedContent = this.sectionParser.sectionsToText(sections);
      this.contentUpdateSubject.next({
        messageId: updatedDocument.messageId,
        updatedContent: updatedContent
      });
    }
  }

  undo(): void {
    if (this.currentHistoryIndex > 0 && this.currentState.document) {
      this.currentHistoryIndex--;
      const previousEntry = this.history[this.currentHistoryIndex];

      const updatedDocument: CanvasDocument = {
        ...this.currentState.document,
        sections: [...previousEntry.sections],
        updatedAt: new Date()
      };

      this.updateState({
        ...this.currentState,
        document: updatedDocument,
        canUndo: this.currentHistoryIndex > 0,
        canRedo: true
      });
      
      // Emit content update if messageId exists
      if (updatedDocument.messageId) {
        const updatedContent = this.sectionParser.sectionsToText(previousEntry.sections);
        this.contentUpdateSubject.next({
          messageId: updatedDocument.messageId,
          updatedContent: updatedContent
        });
      }
    }
  }

  redo(): void {
    if (this.currentHistoryIndex < this.history.length - 1 && this.currentState.document) {
      this.currentHistoryIndex++;
      const nextEntry = this.history[this.currentHistoryIndex];

      const updatedDocument: CanvasDocument = {
        ...this.currentState.document,
        sections: [...nextEntry.sections],
        updatedAt: new Date()
      };

      this.updateState({
        ...this.currentState,
        document: updatedDocument,
        canUndo: true,
        canRedo: this.currentHistoryIndex < this.history.length - 1
      });
      
      // Emit content update if messageId exists
      if (updatedDocument.messageId) {
        const updatedContent = this.sectionParser.sectionsToText(nextEntry.sections);
        this.contentUpdateSubject.next({
          messageId: updatedDocument.messageId,
          updatedContent: updatedContent
        });
      }
    }
  }

  setEditing(isEditing: boolean): void {
    this.updateState({
      ...this.currentState,
      isEditing: isEditing
    });
  }

  close(): void {
    this.updateState({
      ...this.currentState,
      isOpen: false,
      selectedSectionId: null,
      isEditing: false
    });
  }

  clear(): void {
    this.history = [];
    this.currentHistoryIndex = -1;
    this.updateState({
      document: null,
      selectedSectionId: null,
      isEditing: false,
      canUndo: false,
      canRedo: false,
      isOpen: false
    });
  }

  private updateState(newState: CanvasState): void {
    this.stateSubject.next(newState);
  }
}
