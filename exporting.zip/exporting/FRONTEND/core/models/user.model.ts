export interface User {
  id?: string;
  name?: string;
  email?: string;
  firstName?: string;
  // add other fields you need
}
