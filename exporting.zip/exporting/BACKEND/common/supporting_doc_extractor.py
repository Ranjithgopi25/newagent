import logging
import json
from typing import Optional, AsyncGenerator

logger = logging.getLogger(__name__)


class SupportingDocExtractor:
    """Service for extracting relevant content from supporting documents using LLM"""
    
    def __init__(self, llm_service):
        """
        Initialize extractor with LLM service
        
        Args:
            llm_service: Service with stream_response method for LLM calls
        """
        self.llm_service = llm_service
    
    async def extract_relevant_content(
        self, 
        doc_content: str, 
        focus_area: str
    ) -> Optional[str]:
        """
        Extract relevant content from document based on focus area
        
        Args:
            doc_content: Full document content to extract from
            focus_area: Specific area/topic to focus on
            
        Returns:
            Extracted content as string, or None if extraction fails
        """
        if not doc_content or not focus_area:
            logger.warning("[SupportingDocExtractor] Missing doc_content or focus_area")
            return None
        
        logger.info(f"[SupportingDocExtractor] Extracting content for area: {focus_area}")
        
        try:
            extraction_prompt = self._build_extraction_prompt(doc_content, focus_area)
            
            extraction_messages = [
                {"role": "user", "content": extraction_prompt}
            ]
            
            # Call LLM for extraction
            extracted_content = await self._call_llm_extraction(extraction_messages)
            
            if extracted_content and extracted_content.strip():
                logger.info(f"[SupportingDocExtractor] Successfully extracted {len(extracted_content)} characters")
                return extracted_content.strip()
            else:
                logger.warning("[SupportingDocExtractor] No content extracted")
                return None
                
        except Exception as e:
            logger.error(f"[SupportingDocExtractor] Error during extraction: {e}", exc_info=True)
            return None
    
    def _build_extraction_prompt(self, doc_content: str, focus_area: str) -> str:
        """Build the extraction prompt for LLM"""
        return f"""Extract and summarize the relevant information from the following document that is specifically related to: {focus_area}

Document Content:
{doc_content}

Instructions:
- Focus only on content related to: {focus_area}
- Provide a concise summary of the relevant information
- Maintain key facts, figures, and insights
- If the specified area is not found in the document, state that clearly

Extracted Content:"""
    
    async def _call_llm_extraction(self, messages: list) -> str:
        """Call LLM service and collect response"""
        extracted_content = ""
        
        async for chunk in self.llm_service.stream_response(messages):
            # Parse SSE format to get actual content
            if chunk.startswith("data: "):
                try:
                    data = json.loads(chunk[6:])
                    if data.get("type") == "content":
                        extracted_content += data.get("content", "")
                except json.JSONDecodeError:
                    continue
                except Exception as e:
                    logger.debug(f"[SupportingDocExtractor] Error parsing chunk: {e}")
                    continue
        
        return extracted_content
    
    @staticmethod
    def merge_into_user_message(
        messages: list, 
        extracted_content: str, 
        focus_area: str
    ) -> bool:
        """
        Merge extracted content into the last user message
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            extracted_content: Content to merge
            focus_area: Description of what was focused on
            
        Returns:
            True if merged successfully, False otherwise
        """
        if not extracted_content or not messages:
            return False
        
        # Find last user message
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                original_content = messages[i].get("content", "")
                messages[i]["content"] = f"""{original_content}

Supporting Document Context (focused on {focus_area}):
{extracted_content}"""
                logger.info("[SupportingDocExtractor] Merged extracted content into user message")
                return True
        
        logger.warning("[SupportingDocExtractor] No user message found to merge into")
        return False