"""
Connectivity checker API for external services.
"""

import logging
import os
from typing import Dict, Any
from fastapi import APIRouter

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Connectivity"])


# ===== DEV CONFIGURATION =====
DEV_CONFIG = {
    "sql": {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "u2zlmzgxsdsp0001.database.windows.net",
        "database": "bsm_mcx_appdb_dev",
        "username": "bsmmcxsqladmindev",
        "password": "{N=HYLyKn_v=wIXzMgvqM6tV9IyIW}",
    },
    "azure_search": {
        "endpoint": "https://srch-bsmxsrch-ufk5x.search.windows.net",
        "index": "rag-s-b-index",
        "api_key": "sDp2cl4M7JRScpkTVDDCEJtxsFoOOxr2a5T3RQ1HT3AzSeDVtLVj",
    },
    "sharepoint": {
        "tenant_id": "d4093791-9818-48dc-8880-35d134b8c79d",
        "client_id": "6e658362-b527-4141-8fa1-17c4ac17ce3d",
        "client_secret": "kvi8Q~L5hY6Tw21TNPITB3Hl~xh22sOuprz0PaF3",
        "site_url": "https://devpwc365.sharepoint.com/sites/US-xLoS-PwC-Intelligence_Dev",
    },
    "speech": {
        "subscription_key": "3GpR5r0xsB68DHt9dfxjOHsftVwLoxeQqJWaI3hDlLEFhbgkCmRpJQQJ99BKACYeBjFXJ3w3AAAYACOGRdW3",
        # "region": "eastus",
        "endpoint": "https://u2lmzgxdss001.cognitiveservices.azure.com/"

    },
    "cdo_database": {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "pzi-gxus-p-mssq-thpd-p002.database.windows.net",
        "database": "SNL_XF",  # Available databases: SNL_XF, Audit_Analytics, IDDSDATA, CapIQ_XF
        "username": "US_adv_DataPlatform-CDO_MCX_p001",
        "password": "+CYcG3l$(W7@]y{#a*86",
    },
    "cdo_databricks": {
        "host": "adb-2215734503437142.2.azuredatabricks.net",
        "http_path": "/sql/1.0/warehouses/36a379266063cb38",
        "access_token": "dapi67ef85a2cff273251aa0ee1d4d39c344",
        "catalog": "thirdpartydata_dev",
        "schema": "Boardex",
    },
    "tavily": {
        "api_key": "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",
    },
    "azure_blob": {
        "tenant_id": "513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_id": "23a54384-5b81-40a3-98b6-edab832199f4",
        "client_secret": "ESY8Q~FHDXh1QuUPkY1_VegwVW44IyOF47ucTc.0",
        "account_name": "stbsmmcxyrehq",
    },
    "css": {
        "tenant_id": "513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_id": "a9782dc9-ba67-4dad-95c4-0b3c366cb4a5@513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_secret": "cD98Q~l.trolt6ChB2WZWrMkWtJHicwVPxHHbbaf",
        "scope": "https://pwc-us-ifs-prod.api.crm.dynamics.com/.default",
        "auth_url": "https://login.microsoftonline.com/513294a0-3e20-41b2-a970-6d30bf1546fa/oauth2/v2.0/token",
        "api_endpoint": "https://pwc-us-ifs-prod.api.crm.dynamics.com/api/data/v9.2/csstory_csswinstorieses",
    },
}

def check_passage_retrieval_connection() -> Dict[str, Any]:
    """Check PwC GenAI Passage Retrieval API connection."""
    try:
        import requests
    except ImportError:
        return {"status": "error", "message": "requests package not installed", "stable": False}
    
    try:
        url = "https://gif-apim.pwc.com/cs-genai/api/genaiv2/passageretrieval?subscription-key=45ccdc950cad4d3fb873c2dc7804b373"
        headers = {
            "accept": "application/json",
            "sc_apikey": "34D44659-6E16-4792-A506-1E0C98B44A4C",
            "Content-Type": "application/json"
        }
        payload = {
            "input": "test connection",
            "additionalFields": "entityurl"
        }
        
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        
        if response.status_code == 200:
            return {"status": "success", "message": "Passage Retrieval API connection successful", "stable": True}
        return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text}", "stable": False}
    except Exception as e:
        return {"status": "failed", "message": str(e), "stable": False}
    
# ===== STAGE CONFIGURATION =====
STAGE_CONFIG = {
    "sql": {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "u2zlmzgxsssp0001.database.windows.net",  # Update for stage
        "database": "bsm_mcx_appdb_stg",  # Update for stage
        "username": "bsmmcxsqladminstg",  # Update for stage
        "password": "V[J3eKf4P-.Pd_c}HRp{g9qa*!u^Q}",  # Update for stage
    },
    "azure_search": {
        "endpoint": "https://srch-mcxaisch-gbygh.privatelink.search.windows.net",
        "index": "rag-s-b-index",
        "api_key": "OkDaG5F6bo19Y4DCE9dfB70VDzFmIR7Of5o9wBbrBAAzSeCaIv22",
    },
    "sharepoint": {
        "tenant_id": "d4093791-9818-48dc-8880-35d134b8c79d",
        "client_id": "6e658362-b527-4141-8fa1-17c4ac17ce3d",
        "client_secret": "kvi8Q~L5hY6Tw21TNPITB3Hl~xh22sOuprz0PaF3",
        "site_url": "https://devpwc365.sharepoint.com/sites/US-xLoS-PwC-Intelligence_Dev",
    },
    "speech": {
        "subscription_key": "3GpR5r0xsB68DHt9dfxjOHsftVwLoxeQqJWaI3hDlLEFhbgkCmRpJQQJ99BKACYeBjFXJ3w3AAAYACOGRdW3",  # Update for stage
        # "region": "eastus",
        "endpoint": "https://u2lmzgxdss001.cognitiveservices.azure.com/"

    },
    "cdo_database": {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "pzi-gxus-p-mssq-thpd-p002.database.windows.net",  # Update for stage if different
        "database": "SNL_XF",  # Available databases: SNL_XF, Audit_Analytics, IDDSDATA, CapIQ_XF
        "username": "US_adv_DataPlatform-CDO_MCX_p001",  # Update for stage if different
        "password": "+CYcG3l$(W7@]y{#a*86",  # Update for stage
    },
    "cdo_databricks": {
        "host": "adb-2215734503437142.2.azuredatabricks.net",
        "http_path": "/sql/1.0/warehouses/36a379266063cb38",
        "access_token": "dapi67ef85a2cff273251aa0ee1d4d39c344",
        "catalog": "thirdpartydata_dev",
        "schema": "Boardex",
    },
    "tavily": {
        "api_key": "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",  # Update for stage
    },
    "azure_blob": {
        "tenant_id": "513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_id": "2530de0e-4a52-457f-a115-f97d6a3dcd96",
        "client_secret": "umV8Q~FoQzN.ldrxT37Gaa_Hs3eVPxAKi3zNgcp5",
        "account_name": "stmcxaischgbygh",
    },
    "css": {
        "tenant_id": "513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_id": "a9782dc9-ba67-4dad-95c4-0b3c366cb4a5@513294a0-3e20-41b2-a970-6d30bf1546fa",
        "client_secret": "cD98Q~l.trolt6ChB2WZWrMkWtJHicwVPxHHbbaf",
        "scope": "https://pwc-us-ifs-prod.api.crm.dynamics.com/.default",
        "auth_url": "https://login.microsoftonline.com/513294a0-3e20-41b2-a970-6d30bf1546fa/oauth2/v2.0/token",
        "api_endpoint": "https://pwc-us-ifs-prod.api.crm.dynamics.com/api/data/v9.2/csstory_csswinstorieses",
    },
}


# def get_sql_connection_string(config: dict) -> str:
#     return (
#         f"DRIVER={config['driver']};"
#         f"SERVER={config['server']};"
#         f"DATABASE={config['database']};"
#         f"UID={config['username']};"
#         f"PWD={config['password']};"
#         "Encrypt=yes;"
#         "TrustServerCertificate=yes;"
#         "HostNameInCertificate=*.database.windows.net;"
#         "LoginTimeout=60;"
#         "ConnectionTimeout=60;"
#     )

# def check_tavily_connection(config: dict) -> Dict[str, Any]:
#     """Check Tavily API connection."""
#     try:
#         from tavily import TavilyClient
#     except ImportError:
#         return {"status": "error", "message": "tavily-python package not installed", "stable": False}
 
#     try:
#         client = TavilyClient(config["api_key"])
#         response = client.search(query="test")
#         if response:
#             return {"status": "success", "message": "Tavily API connection successful", "stable": True}
#         return {"status": "failed", "message": "No response from Tavily API", "stable": False}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_azure_blob_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure Blob Storage connectivity and list up to 50 containers."""
#     try:
#         from azure.storage.blob import BlobServiceClient
#         from azure.core.exceptions import ResourceNotFoundError
#     except ImportError:
#         return {
#             "status": "error",
#             "message": "azure-storage-blob package not installed",
#             "stable": False,
#         }

#     try:
#         blob_service_client = BlobServiceClient.from_connection_string(
#             config["connection_string"],
#             connection_verify=False
#         )

#         # Verify account connection
#         account_info = blob_service_client.get_account_information()
        
#         # List containers
#         container_names = []
#         for i, container in enumerate(blob_service_client.list_containers()):
#             if i >= 50:
#                 break
#             container_names.append(container["name"])

#         return {
#             "status": "success",
#             "message": f"Azure Blob Storage connection successful ({config['account_name']})",
#             "stable": True,
#             "containers": container_names,
#             "container_count": len(container_names),
#             "container_limit": 50,
#             "account_info": str(account_info)
#         }

#     except ResourceNotFoundError as e:
#         return {
#             "status": "failed",
#             "message": f"Resource not found: {str(e)}",
#             "stable": False,
#         }
#     except Exception as e:
#         return {
#             "status": "failed",
#             "message": str(e),
#             "stable": False,
#         }

# def check_sql_connection(config: dict) -> Dict[str, Any]:
#     """Check SQL Server database connection."""
#     try:
#         import pyodbc
#     except ImportError:
#         return {"status": "error", "message": "pyodbc package not installed", "stable": False}

#     try:
#         conn_str = get_sql_connection_string(config)
#         conn = pyodbc.connect(conn_str, timeout=60)
#         cursor = conn.cursor()
#         cursor.execute("SELECT 1")
#         cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return {"status": "success", "message": "SQL database connection successful", "stable": True}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}

def check_azure_blob_connection(config: dict) -> Dict[str, Any]:
    """Check Azure Blob Storage connectivity and list up to 50 containers using Azure AD authentication."""
    try:
        from azure.storage.blob import BlobServiceClient
        from azure.identity import ClientSecretCredential
    except ImportError:
        return {
            "status": "error",
            "message": "azure-storage-blob or azure-identity package not installed",
            "stable": False,
        }

    try:
        # Create credential using Azure AD
        credential = ClientSecretCredential(
            tenant_id=config["tenant_id"],
            client_id=config["client_id"],
            client_secret=config["client_secret"]
        )
        
        # Create BlobServiceClient using account URL and credential
        account_url = f"https://{config['account_name']}.blob.core.windows.net"
        blob_service_client = BlobServiceClient(
            account_url=account_url,
            credential=credential
        )

        container_names = []
        for i, container in enumerate(blob_service_client.list_containers()):
            if i >= 50:
                break
            container_names.append(container["name"])

        return {
            "status": "success",
            "message": f"Azure Blob Storage connection successful ({config['account_name']})",
            "stable": True,
            "containers": container_names,
            "container_count": len(container_names),
            "container_limit": 50,
        }

    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
            "stable": False,
        }


def check_css_connection(config: dict) -> Dict[str, Any]:
    """Check Client Success Stories (CSS) API connection via Dynamics CRM."""
    try:
        import requests
    except ImportError:
        return {
            "status": "error",
            "message": "requests package not installed",
            "stable": False,
        }

    try:
        # Step 1: Get access token from Azure AD
        auth_payload = {
            "grant_type": "client_credentials",
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "scope": config["scope"],
        }
        
        auth_response = requests.post(
            config["auth_url"],
            data=auth_payload,
            timeout=30
        )
        
        if auth_response.status_code != 200:
            return {
                "status": "failed",
                "message": f"Failed to authenticate: {auth_response.status_code} - {auth_response.text}",
                "stable": False,
            }
        
        access_token = auth_response.json().get("access_token")
        if not access_token:
            return {
                "status": "failed",
                "message": "No access token received from authentication",
                "stable": False,
            }
        
        # Step 2: Call CSS API with access token
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        
        api_url = f"{config['api_endpoint']}?$select=csstory_preferredclientname,csstory_engagementtitle,csstory_publisheddate&$orderby=csstory_publisheddate desc&$filter=(csstory_restricted eq 'Unrestricted')&$top=3"
        
        api_response = requests.get(
            api_url,
            headers=headers,
            timeout=30
        )
        
        if api_response.status_code != 200:
            return {
                "status": "failed",
                "message": f"Failed to retrieve CSS data: {api_response.status_code} - {api_response.text}",
                "stable": False,
            }
        
        response_data = api_response.json()
        record_count = len(response_data.get("value", []))
        
        return {
            "status": "success",
            "message": "Client Success Stories API connection successful",
            "stable": True,
            "records_retrieved": record_count,
            "api_endpoint": config["api_endpoint"],
        }
    
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
            "stable": False,
        }

# def check_azure_search_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure AI Search connection."""
#     try:
#         from azure.search.documents import SearchClient
#         from azure.core.credentials import AzureKeyCredential
#     except ImportError:
#         return {"status": "error", "message": "azure-search-documents package not installed", "stable": False}

#     try:
#         client = SearchClient(
#             endpoint=config["endpoint"],
#             index_name=config["index"],
#             credential=AzureKeyCredential(config["api_key"]),
#         )
#         results = client.search(search_text="*", top=1, include_total_count=True)
#         _ = results.get_count()
#         return {"status": "success", "message": "Azure AI Search connection successful", "stable": True}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_sharepoint_connection(config: dict) -> Dict[str, Any]:
#     """Check SharePoint connection using MSAL."""
#     try:
#         from msal import ConfidentialClientApplication
#     except ImportError:
#         return {"status": "error", "message": "msal package not installed", "stable": False}

#     try:
#         authority = f"https://login.microsoftonline.com/{config['tenant_id']}"
#         app = ConfidentialClientApplication(
#             client_id=config["client_id"],
#             client_credential=config["client_secret"],
#             authority=authority,
#         )
#         result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])

#         if "access_token" not in result:
#             error_msg = result.get("error_description", "Failed to acquire access token")
#             return {"status": "failed", "message": error_msg, "stable": False}

#         return {"status": "success", "message": "SharePoint connection successful", "stable": True}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_speech_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure Speech Service connection."""
#     try:
#         import azure.cognitiveservices.speech as speechsdk
#     except ImportError:
#         return {"status": "error", "message": "azure-cognitiveservices-speech package not installed", "stable": False}

#     try:       
#         speech_config = speechsdk.SpeechConfig(subscription=config["subscription_key"], endpoint=config["endpoint"])
#         audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
#         speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"

#         synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
#         result = synthesizer.speak_text_async("test").get()

#         if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
#             return {"status": "success", "message": "Azure Speech Service connection successful", "stable": True}
#         else:
#             cancellation = result.cancellation_details
#             return {"status": "failed", "message": cancellation.error_details, "stable": False}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_cdo_database_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure CDO Database connection."""
#     try:
#         import pyodbc
#     except ImportError:
#         return {"status": "error", "message": "pyodbc package not installed", "stable": False}

#     try:
#         conn_str = get_sql_connection_string(config)
#         conn = pyodbc.connect(conn_str, timeout=30)
#         cursor = conn.cursor()
#         cursor.execute("SELECT 1")
#         cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return {"status": "success", "message": "Azure CDO Database connection successful", "stable": True}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_cdo_databricks_connection(config: dict) -> Dict[str, Any]:
#     """Check Azure CDO Databricks connection."""
#     try:
#         from databricks import sql as databricks_sql
#     except ImportError:
#         return {"status": "error", "message": "databricks-sql-connector package not installed", "stable": False}

#     try:
#         connection = databricks_sql.connect(
#             server_hostname=config["host"],
#             http_path=config["http_path"],
#             access_token=config["access_token"]
#         )
#         cursor = connection.cursor()
#         cursor.execute("SELECT 1")
#         cursor.fetchone()
#         cursor.close()
#         connection.close()
#         return {"status": "success", "message": "Azure CDO Databricks connection successful", "stable": True}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}

# def check_phoenix_oauth_connection() -> Dict[str, Any]:
#     """Check PwC Phoenix OAuth API connection."""
#     print("inside aouth function")
#     try:
#         import requests
#     except ImportError:
#         return {"status": "error", "message": "requests package not installed", "stable": False}
    
#     try:
#         url = "https://api-test.us.pwc.com/oauth/getaccesstoken"
#         headers = {
#             "authorization": "Basic ellFeXlwNnJkazRBZEVKejFZQVkwWjN2V3RocW12dld5ejJJUEFzbG92eGNzYUl6OkhUcGJISFZjemFHYmhQSXZXajZHUTV3SUI3R3FOdWJLcXcwblpTRFU2aWtvam1mYmdJWndXNVhIUXd4QllHeXM="
#         }
#         response = requests.post(url, headers=headers, timeout=30)
        
#         if response.status_code == 200 and "access_token" in response.json():
#             return {"status": "success", "message": "PwC Phoenix OAuth API connection successful", "stable": True}
#         return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text}", "stable": False}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_phoenix_ifs_config_connection(access_token: str) -> Dict[str, Any]:
#     """Check PwC Phoenix IFS Config API connection."""
#     print('inside check_phoenix_ifs_config_connection')
#     try:
#         import requests
#     except ImportError:
#         return {"status": "error", "message": "requests package not installed", "stable": False}
    
#     try:
#         url = "https://api-test.us.pwc.com/sdp-uat/api/v2/requests/ifsConfigData?source=692977a0b6e512f4a612e514&configId=691e34c5f186e4dd0add04f4"
#         headers = {"authorization": f"Bearer {access_token}"}
#         response = requests.get(url, headers=headers, timeout=30)
        
#         if response.status_code == 200:
#             return {"status": "success", "message": "PwC Phoenix IFS Config API connection successful", "stable": True}
#         return {"status": "failed", "message": f"HTTP {response.status_code}: {response.text}", "stable": False}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_phoenix_ifs_request_connection(access_token: str) -> Dict[str, Any]:
#     """Check PwC Phoenix IFS Create Request API connection (dry run)."""
#     print('inside check_phoenix_ifs_request_connection')
#     try:
#         import requests
#     except ImportError:
#         return {"status": "error", "message": "requests package not installed", "stable": False}
    
#     try:
#         url = "https://api-test.us.pwc.com/sdp-uat/api/v2/requests/createIFSRequest"
#         headers = {"authorization": f"Bearer {access_token}"}
        
#         response = requests.head(url, headers=headers, timeout=30)
        
#         if response.status_code in [200, 405]:
#             return {"status": "success", "message": "PwC Phoenix IFS Create Request API endpoint reachable", "stable": True}
#         return {"status": "failed", "message": f"HTTP {response.status_code}", "stable": False}
#     except Exception as e:
#         return {"status": "failed", "message": str(e), "stable": False}


# def check_phoenix_apis() -> Dict[str, Any]:
    """Check all PwC Phoenix APIs in sequence."""
    print('inside phoniex main function')
    oauth_result = check_phoenix_oauth_connection()
    print('after oauth function')
    if oauth_result["status"] != "success":
        return {
            "oauth": oauth_result,
            "ifs_config": {"status": "skipped", "message": "OAuth failed", "stable": False},
            "ifs_request": {"status": "skipped", "message": "OAuth failed", "stable": False}
        }
    
    try:
        import requests
        url = "https://api-test.us.pwc.com/oauth/getaccesstoken"
        headers = {
            "authorization": "Basic ellFeXlwNnJkazRBZEVKejFZQVkwWjN2V3RocW12dld5ejJJUEFzbG92eGNzYUl6OkhUcGJISFZjemFHYmhQSXZXajZHUTV3SUI3R3FOdWJLcXcwblpTRFU2aWtvam1mYmdJWndXNVhIUXd4QllHeXM="
        }
        response = requests.post(url, headers=headers, timeout=30)
        access_token = response.json()["access_token"]
    except Exception as e:
        return {
            "oauth": oauth_result,
            "ifs_config": {"status": "failed", "message": f"Token retrieval error: {str(e)}", "stable": False},
            "ifs_request": {"status": "failed", "message": f"Token retrieval error: {str(e)}", "stable": False}
        }
    
    return {
        "oauth": oauth_result,
        "ifs_config": check_phoenix_ifs_config_connection(access_token),
        "ifs_request": check_phoenix_ifs_request_connection(access_token)
    }

@router.get("/api/connectivity")
async def check_all_connections():
    """Check all external service connections for dev and stage."""
    # return {
    #     "dev": {
    #         "sql_database": check_sql_connection(DEV_CONFIG["sql"]),
    #         "azure_search": check_azure_search_connection(DEV_CONFIG["azure_search"]),
    #         "sharepoint": check_sharepoint_connection(DEV_CONFIG["sharepoint"]),
    #         "speech_service": check_speech_connection(DEV_CONFIG["speech"]),
    #         "cdo_database": check_cdo_database_connection(DEV_CONFIG["cdo_database"]),
    #         "cdo_databricks": check_cdo_databricks_connection(DEV_CONFIG["cdo_databricks"]),
    #         "tavily": check_tavily_connection(DEV_CONFIG["tavily"]),
    #         "azure_blob_storage": check_azure_blob_connection(DEV_CONFIG["azure_blob"]),
    #         "phoenix_apis": check_phoenix_apis(),
    #     },
    #     "stage": {
    #         "sql_database": check_sql_connection(STAGE_CONFIG["sql"]),
    #         "azure_search": check_azure_search_connection(STAGE_CONFIG["azure_search"]),
    #         "sharepoint": check_sharepoint_connection(STAGE_CONFIG["sharepoint"]),
    #         "speech_service": check_speech_connection(STAGE_CONFIG["speech"]),
    #         "cdo_database": check_cdo_database_connection(STAGE_CONFIG["cdo_database"]),
    #         "cdo_databricks": check_cdo_databricks_connection(STAGE_CONFIG["cdo_databricks"]),
    #         "tavily": check_tavily_connection(STAGE_CONFIG["tavily"]),
    #         "azure_blob_storage": check_azure_blob_connection(STAGE_CONFIG["azure_blob"]),
    #         "phoenix_apis": check_phoenix_apis(),
    #     },
    # }
    return {
        "dev": {
            "azure_blob_storage": check_azure_blob_connection(DEV_CONFIG["azure_blob"]),
            "css_api": check_css_connection(DEV_CONFIG["css"]),
            "connected_source": check_passage_retrieval_connection()
        },
        "stage": {
            "azure_blob_storage": check_azure_blob_connection(STAGE_CONFIG["azure_blob"]),
            "css_api": check_css_connection(STAGE_CONFIG["css"]),
            "connected_source": check_passage_retrieval_connection()
        },
        
    }


def get_router():
    return router