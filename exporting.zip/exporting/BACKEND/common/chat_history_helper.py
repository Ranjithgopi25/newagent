"""
Helper utilities for integrating chat history into workflows.
Provides non-intrusive methods to save chat interactions without modifying base functions.
Optimized for high concurrency (1000+ users) with connection pooling.
"""
import uuid
from typing import Optional, Dict, Any
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)


class ChatHistoryHelper:
    """
    Helper class for workflows to save chat history.
    Designed to be used as an optional add-on without modifying existing base functions.
    One session = one complete conversation.
    """
    
    def __init__(
        self, 
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        source: str = "Chat"
    ):
        """
        Initialize helper with user/session info.
        
        Args:
            user_id: User email or identifier
            session_id: Session identifier (simple string)
            source: Source of conversation (Chat, DDDC, Market_Intelligence, Thought_Leadership, Export)
        """
        self.user_id = user_id
        self.session_id = session_id
        self.source = source
        self._service = None
        self._enabled = user_id is not None and session_id is not None
    
    def _get_service(self):
        """Lazy load chat history service to avoid import errors if not configured."""
        if not self._enabled:
            return None
            
        if self._service is None:
            try:
                from app.repositories.chat_history_repository import ChatHistoryRepository
                from app.services.chat_history_service import ChatHistoryService
                from app.core.config import get_settings
                from app.infrastructure.database.pool_manager import DatabasePoolManager
                
                settings = get_settings()
                connection_string = settings.chat_db_connection_string
                
                # Initialize pool on first use
                try:
                    DatabasePoolManager.initialize(connection_string)
                except:
                    pass  # Already initialized
                
                # Create repository and service directly
                repository = ChatHistoryRepository(connection_string)
                self._service = ChatHistoryService(repository)
                logger.info("ChatHistoryHelper successfully initialized service with connection pool")
            except Exception as e:
                logger.warning(f" Chat history service not available: {str(e)}")
                self._enabled = False
                return None
        return self._service
    
    async def _save_with_pool(self, role: str, content: str) -> bool:
        """
        Save message using connection pool (optimized for high concurrency).
        Uses the existing service layer which handles JSON conversation format.
        
        Args:
            role: 'user' or 'assistant'
            content: Message content
            
        Returns:
            True if saved successfully
        """
        if not self._enabled or not content:
            return False
        
        try:
            # Use the existing service to handle proper JSON serialization
            service = self._get_service()
            if not service:
                logger.warning("Service not available for pool save")
                return False
            
            # Add message to session using existing service (handles JSON properly)
            service.add_message_to_session_or_create(
                session_id=self.session_id,
                role=role,
                content=content,
                user_id=uuid.uuid5(uuid.NAMESPACE_DNS, self.user_id) if isinstance(self.user_id, str) else self.user_id,
                source=self.source,
                user_email=self.user_id if isinstance(self.user_id, str) else None
            )
            
            logger.info(f" {role} message saved with pool (session: {self.session_id})")
            return True
        
        except Exception as e:
            logger.error(f" Error saving {role} message with pool: {e}")
            return False
    
    async def save_user_message(self, content: str) -> Optional[str]:
        """
        Save a user message asynchronously using connection pool.
        Non-blocking - returns immediately after queuing.
        
        Args:
            content: Message content
            
        Returns:
            Session ID
        """
        if not self._enabled or not content:
            logger.debug(f"Chat history disabled - skipping save")
            return self.session_id
        
        # Fire and forget - save in background without blocking
        asyncio.create_task(self._save_with_pool("user", content))
        logger.debug(f"User message queued for async save (session: {self.session_id})")
        
        return self.session_id
    
    async def save_assistant_message(self, content: str) -> bool:
        """
        Save an assistant/AI response message asynchronously using connection pool.
        Non-blocking - returns immediately after queuing.
        
        Args:
            content: Message content
            
        Returns:
            True (always, since saving is async)
        """
        if not self._enabled or not self.session_id or not content:
            logger.debug(f"Chat history disabled - skipping assistant message save")
            return False
        
        # Fire and forget - save in background without blocking
        asyncio.create_task(self._save_with_pool("assistant", content))
        logger.debug(f"Assistant message queued for async save (session: {self.session_id})")
        
        return True
    
    async def get_context_messages(self) -> list:
        """
        Get conversation history formatted for LLM context.
        Uses the same session_id from frontend.
        
        Returns:
            List of messages with role and content, or empty list if disabled
        """
        if not self._enabled or not self.session_id:
            logger.debug(f"Chat history disabled or no session_id - returning empty context")
            return []
            
        service = self._get_service()
        if not service:
            logger.warning("Service not available - cannot retrieve context messages")
            return []
            
        try:
            logger.info(f"[Helper] Retrieving context messages for session: {self.session_id}")
            messages = service.format_messages_for_llm(self.session_id)
            logger.info(f"[Helper] ✓ Retrieved {len(messages)} messages from session {self.session_id}")
            return messages
        except Exception as e:
            logger.error(f"Error retrieving context messages for session {self.session_id}: {str(e)}")
            return []