from pydantic import BaseModel
from typing import Optional

class ExportRequest(BaseModel):
    content: str
    title: str
    format: Optional[str] = None
    subtitle: Optional[str] = None
    content_type: Optional[str] = None  # article, whitepaper, executive-brief, blog
    references: list[dict] | None = None