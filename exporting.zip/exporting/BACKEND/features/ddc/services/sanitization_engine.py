import re
import logging
import os
import asyncio
from lxml import etree
import tempfile
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE_TYPE
from io import BytesIO
# from datetime import datetime
from collections import defaultdict
# from PIL import Image, ImageDraw, ImageFont

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
class PPTSanitizer:
    """
    Comprehensive PowerPoint Sanitizer for removing sensitive information
    while preserving document structure and readability.
    """

    def __init__(
        self, client_names=None, product_names=None, competitor_names=None, business_units=None, options=None, additional_guidelines=""
    ):
        self.client_names = client_names or []
        self.product_names = product_names or []
        self.business_units = business_units or []
        self.competitor_names = competitor_names or []
        self.replacement_map = defaultdict(dict)

        # Add this line to store additional guidelines safely
        self.additional_guidelines = additional_guidelines

        # Sanitization options (all enabled by default)
        self.options = options or {
            "numeric_data": False,
            "personal_info": False,
            "financial_data": False,
            "locations": False,
            "identifiers": False, #Removing client specific numerical data
            "names":False,
            "business_units": False,  # toggle button state
            "logos": False,
            "metadata": False,
            "llm_detection": False,
            "hyperlinks": False,
            "embedded_objects": False,
            "competitor": False,        }

        self.sanitization_stats = {
            "numeric_replacements": 0,
            "name_replacements": 0,
            "hyperlinks_removed": 0,
            "notes_removed": 0,
            "logos_removed": 0,
            "slides_processed": 0,
            "grammar_corrections": 0,
            "personal_info_removed": 0,
            "financial_data_removed": 0,
            "locations_redacted": 0,
            "identifiers_redacted": 0,
            "person_names_removed": 0,
            "embedded_files_disconnected": 0,
            "charts_converted_to_images": 0,
            "competitor_sanitized": 0,
        }

        self._compile_patterns()

    def _compile_patterns(self):
        """Compile all regex patterns for efficient reuse"""
        self.patterns = {
            # Currency patterns
            "currency": re.compile(r"([$€£¥])\s*(\d+(?:,\d{3})*(?:\.\d+)?)\s*([KMB]?)"),
            "number_word": re.compile(r"\b(\d+(?:,\d{3})*(?:\.\d+)?)\s*(million|m|Mil|billion|Million|Billion|thousand|crore|cr|lakh|lac)\b",
            re.IGNORECASE
        ),

            "currency_word": re.compile(
                r"([$€£¥])\s*(\d+(?:,\d{3})*(?:\.\d+)?)\s*(million|billion|thousand)",
                re.IGNORECASE,
            ),
            "currency_range": re.compile(
                r"([$€£¥])\s*(\d+(?:,\d{3})*(?:\.\d+)?)\s*([KMB]?)\s*(?:-|to)\s*([$€£¥])?\s*(\d+(?:,\d{3})*(?:\.\d+)?)\s*([KMB]?)"
            ),
            # Percentage patterns
            "percentage": re.compile(r"\b(\d+(?:\.\d+)?)\s*%"),
            "percentage_range": re.compile(
                r"\b(\d+(?:\.\d+)?)\s*%\s*(?:-|to)\s*(\d+(?:\.\d+)?)\s*%"
            ),
            # FTE patterns
            "fte": re.compile(
                r"\b(\d+(?:\.\d+)?)\s*(?:-\s*(\d+(?:\.\d+)?)\s*)?FTE?s?", re.IGNORECASE
            ),
            "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
            "ip_address": re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),
            # Financial data
            "credit_card": re.compile(r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b"),
            "bank_account": re.compile(
                r"\b(?:Account|Acct|A/C)[\s#:]*\d{8,17}\b", re.IGNORECASE
            ),
            "routing_number": re.compile(
                r"\b(?:Routing|RTN)[\s#:]*\d{9}\b", re.IGNORECASE
            ),
            "tax_id": re.compile(
                r"\b(?:EIN|TIN|Tax ID)[\s#:]*\d{2}-\d{7}\b", re.IGNORECASE
            ),

            # Business identifiers
            "project_id": re.compile(
                r"\b(?:PROJ|PRJ|PROJECT)[-_]?\d+[-_]?\d*\b", re.IGNORECASE
            ),
            "deal_code": re.compile(r"\b(?:DEAL|DL)[-_]?\d+\b", re.IGNORECASE),
            "invoice": re.compile(r"\b(?:INV|INVOICE)[-_]?\d+\b", re.IGNORECASE),
            "po_number": re.compile(r"\bPO[-_]?\d+\b", re.IGNORECASE),
            "account_number": re.compile(
                r"\b(?:Account|Acct)[\s#:]*[A-Z0-9]{6,}\b", re.IGNORECASE
            ),
            # Person names (common title patterns)
            "person_name": re.compile(
                r"\b(?:Mr\.|Mrs\.|Ms\.|Dr\.|Prof\.)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b"
            ),
            # Numbers with commas
            "number_with_commas": re.compile(r"\b(\d{1,3}(?:,\d{3})+)\b"),
        }

    def sanitize_numeric_data(self, text):
        """Apply all numeric sanitization rules"""
        if not text:
            return text

        original_text = text

        # Currency ranges first (more specific)
        def replace_currency_range(match):
            self.sanitization_stats["numeric_replacements"] += 1
            symbol1, num1, suffix1, symbol2, num2, suffix2 = match.groups()
            x1 = self._number_to_x(num1 + (suffix1 or ""))
            x2 = self._number_to_x(num2 + (suffix2 or ""))
            return f"{symbol1}{x1}-{symbol2 or symbol1}{x2}"

        text = self.patterns["currency_range"].sub(replace_currency_range, text)

        # Currency with words
        def replace_currency_word(match):
            self.sanitization_stats["numeric_replacements"] += 1
            symbol, num, word = match.groups()
            x = self._number_to_x(num)
            return f"{symbol}{x} {word}"

        text = self.patterns["currency_word"].sub(replace_currency_word, text)

        # Single currency values
        def replace_currency(match):
            self.sanitization_stats["numeric_replacements"] += 1
            symbol, num, suffix = match.groups()
            x = self._number_to_x(num + (suffix or ""))
            return f"{symbol}{x}"

        text = self.patterns["currency"].sub(replace_currency, text)

        # Number + magnitude WITHOUT currency (23 Million)
        def replace_number_word(match):
            self.sanitization_stats["numeric_replacements"] += 1
            num, word = match.groups()
            x = self._number_to_x(num)
            return f"{x} {word}"

        text = self.patterns["number_word"].sub(replace_number_word, text)

        # Percentage ranges
        def replace_percentage_range(match):
            self.sanitization_stats["numeric_replacements"] += 1
            num1, num2 = match.groups()
            x1 = self._number_to_x(num1)
            x2 = self._number_to_x(num2)
            return f"{x1}%-{x2}%"

        text = self.patterns["percentage_range"].sub(replace_percentage_range, text)

        # Single percentages
        def replace_percentage(match):
            self.sanitization_stats["numeric_replacements"] += 1
            num = match.group(1)
            x = self._number_to_x(num)
            return f"{x}%"

        text = self.patterns["percentage"].sub(replace_percentage, text)

        # FTE counts
        def replace_fte(match):
            self.sanitization_stats["numeric_replacements"] += 1
            num1, num2 = match.groups()
            if num2:
                x1 = self._number_to_x(num1)
                x2 = self._number_to_x(num2)
                return f"{x1}-{x2} FTE"
            else:
                x = self._number_to_x(num1)
                return f"{x} FTE"

        text = self.patterns["fte"].sub(replace_fte, text)
        # Numbers with commas
        def replace_number_with_commas(match):
            num = match.group(1)
            if num.count(",") > 0:
                self.sanitization_stats["numeric_replacements"] += 1
                return self._number_to_x(num)
            return match.group(0)

        text = self.patterns["number_with_commas"].sub(replace_number_with_commas, text)

        return text

    def _number_to_x(self, num_str):
        """Convert a number to X pattern maintaining digit count"""
        if not num_str:
            return "X"

        # Remove commas for processing
        clean_num = num_str.replace(",", "")

        # Handle decimals
        if "." in clean_num:
            parts = clean_num.split(".")
            integer_part = parts[0]
            decimal_part = parts[1] if len(parts) > 1 else ""

            # Count actual digits
            integer_digits = sum(c.isdigit() for c in integer_part)
            decimal_digits = sum(c.isdigit() for c in decimal_part)

            # Get suffix (K, M, B) if present
            suffix = "".join(c for c in clean_num if c.isalpha())

            result = "X" * integer_digits
            if decimal_part:
                result += "." + "X" * decimal_digits
            result += suffix

            # Re-add commas if original had them
            if "," in num_str and integer_digits > 3:
                # Simple comma placement for X's
                if integer_digits == 4:
                    result = result[0] + "," + result[1:]
                elif integer_digits >= 5:
                    result = result[0] + "," + result[1:]

            return result
        else:
            # Count actual digits
            digit_count = sum(c.isdigit() for c in clean_num)
            suffix = "".join(c for c in clean_num if c.isalpha())

            result = "X" * digit_count + suffix

            # Re-add commas for readability
            if "," in num_str:
                if digit_count == 4:
                    result = result[0] + "," + result[1:4] + suffix
                elif digit_count >= 5:
                    # Add comma after first digit for X,XXX pattern
                    result = result[0] + "," + result[1:] + suffix

            return result

    def sanitize_financial_data(self, text):
        """Remove financial information"""
        if not text:
            return text

        # Remove credit card numbers
        if self.patterns["credit_card"].search(text):
            text = self.patterns["credit_card"].sub("[Credit Card Removed]", text)
            self.sanitization_stats["financial_data_removed"] += 1

        # Remove bank account numbers
        if self.patterns["bank_account"].search(text):
            text = self.patterns["bank_account"].sub("[Account Removed]", text)
            self.sanitization_stats["financial_data_removed"] += 1

        # Remove routing numbers
        if self.patterns["routing_number"].search(text):
            text = self.patterns["routing_number"].sub("[Routing Removed]", text)
            self.sanitization_stats["financial_data_removed"] += 1

        # Remove tax IDs
        if self.patterns["tax_id"].search(text):
            text = self.patterns["tax_id"].sub("[Tax ID Removed]", text)
            self.sanitization_stats["financial_data_removed"] += 1

        return text

    def _contains_numeric_data(self, text: str) -> bool:
        """
        Returns True if text contains numeric/structured data
        that should NOT be grammar-corrected.
        """
        if not text:
            return False

        NUMERIC_PATTERNS = [
            # Core numeric / financial
            "currency",
            "currency_word",
            "currency_range",
            "number_word",
            "percentage",
            "percentage_range",
            "fte",
            "number_with_commas",

            # Business identifiers
            "project_id",
            "deal_code",
            "invoice",
            "po_number",
            "account_number",
        ]

        for key in NUMERIC_PATTERNS:
            pattern = self.patterns.get(key)
            if pattern and pattern.search(text):
                return True

        return False


    def _parse_llm_sanitization_response(self, llm_output, original_text):
        """
        Parse LLM sanitization response to extract only the sanitized text.
        LLM sometimes returns formats like:
        - "original → sanitized"
        - "original text\nsanitized text" (duplicated lines)
        - Just the sanitized text (correct format)
        
        This method extracts only the sanitized portion and removes duplicates.
        """
        if not llm_output or llm_output == original_text:
            return llm_output
        
        # Check for arrow notation: "original → sanitized" or "original->sanitized"
        if '→' in llm_output or '->' in llm_output:
            # Split on arrow and take the last part (sanitized portion)
            parts = re.split(r'\s*(?:→|->)\s*', llm_output)
            if len(parts) > 1:
                llm_output = parts[-1].strip()
        
        # Check for colon notation: "Original: ... Sanitized: ..." or "Result: ..."
        if ':' in llm_output and any(keyword in llm_output.lower() for keyword in ['sanitized', 'result', 'output']):
            # Extract text after the last colon
            parts = llm_output.split(':')
            if len(parts) > 1:
                llm_output = parts[-1].strip()
        
        # Remove duplicate lines (LLM sometimes repeats the sanitized text)
        lines = llm_output.split('\n')
        unique_lines = []
        seen = set()
        for line in lines:
            line_normalized = line.strip().lower()
            if line_normalized and line_normalized not in seen:
                unique_lines.append(line.rstrip())
                seen.add(line_normalized)
            elif not line_normalized:  # Preserve blank lines
                unique_lines.append(line)
        
        result = '\n'.join(unique_lines)
        
        # If result is substantially longer than original, it might be duplicated
        # Keep only result if it looks clean
        if len(result) > len(original_text) * 2.5:
            # Check if it contains the original text repeated
            if original_text in result and result.count(original_text) > 1:
                # Remove the original text occurrences, keep placeholders
                result = result.replace(original_text, '', 1).strip()
        
        return result.strip() if result else llm_output
    
    def get_slide_number_from_guideline(self, guideline_text):
        """
        Extract the slide number from the guideline text.
        Returns integer slide number or None if not found.
        """
        match = re.search(r'\bslide\s+(\d+)\b', guideline_text, re.IGNORECASE)
        if match:
            return int(match.group(1))
        return None
    
    async def sanitize_with_llm(self, text, client, slide_number=None):
        """Sanitize text intelligently with a single LLM call based on selected options."""
        
        if not text or not client or len(text.strip()) < 3:
            return text

        # Check which sanitization tasks are enabled
        sanitize_clients = self.options.get("names", False)
        sanitize_locations = self.options.get("locations", False)
        sanitize_personal_info = self.options.get("personal_info", False)
        competitor = self.options.get("competitor", False)
        business_units = self.options.get("business_units", False)

        # If no sanitization enabled, return original text
        if not any([sanitize_clients, sanitize_locations, competitor, business_units, sanitize_personal_info]):
            return text

        try:
            # Base system prompt
            system_prompt = (
                "You are a data sanitization expert. Your job is to identify and replace sensitive information in text with placeholders.\n"
                "CONTEXT: This sanitization is being done for PwC. Treat PwC as the company performing the masking, not a client.\n"
                "ABSOLUTE RULES:\n"
                "- Only replace the actual sensitive values, NOT generic or descriptor context.\n"
                "- Only apply masking when the term 'program' or 'project' appears as part of a proper noun or client-specific identifier(e.g.,'ABC Transformation Program').\n"
                "- Do NOT modify already sanitized placeholders like [Client], [Product], [BU], [Location X]\n"
                "- Preserve formatting, spacing, and meaning.\n"
                "- Return ONLY the sanitized text without explanations or comments.\n"
                "- Do NOT replace PwC, dates, generic terms (IT, HR, Finance), industry terms, percentages, or masked amounts (e.g., with X's)\n"            )

            task_lines = []

            # CLIENT SANITIZATION
            if sanitize_clients:
                task_lines.append (
                    "TASK: Mask client/company names ONLY.\n"
                    "REPLACE:\n"
                    "- Client/company names → [CLIENT]\n"
                    "- Client subsidiaries → [CLIENT SUBSIDARY]\n"
                    "- Client parent companies → [CLIENT PARENT]\n"
                    "- Multiple client companies → [CLIENT LIST]\n"
                    "- Client website URLs → [LINK]\n"
                    "ABSOLUTE DO NOT MASK:\n"
                    "- Consumer brands or packaged goods (e.g., Doritos, Pepsi, Lays, Coke)\n"
                    "- Retail or food brands unless explicitly stated as a client\n"
                    "- Software or platform names (Windows, SAP, Oracle)\n"
                    "- Person names\n"
                    "- Locations\n"
                    "- Emails\n"
                    "- Phone numbers\n"
                    "- Project/Deal IDs\n"
                    "- Dates\n"
                    "- Generic terms like IT, HR, Finance\n"
                    "- PwC or other global consulting firms such as Deloitte, EY, KPMG, BCG, McKinsey\n"
                    "- Already sanitized placeholders ([CLIENT], [BU], etc.)\n"
                    "\n"
                    "DISAMBIGUATION RULE:\n"
                    "- If a name could be either a product/brand, DO NOT mask it as [CLIENT] unless the text explicitly states it is a client (e.g., 'our client Doritos')."
                    "EXAMPLES:\n"
                    "- 'ABC Transformation Program' → '[CLIENT] Transformation Program'\n"
                    "- 'Our client Doritos launched..' → '[CLIENT] launched...'\n"
                    "- 'Windows OS rollout' → no masking"
                
                )
            # LOCATION SANITIZATION
            if sanitize_locations:
                task_lines.append(
                    "TASK: Mask location information ONLY.\n"
                    "REPLACE:\n"
                    "- Address → [ADDRESS]\n"
                    "- City/state/country → [LOCATION X]\n"
                    "- Zip code/pin code → [ZIP CODE]\n"
                    "- House number → [HOUSE NUMBER]\n"
                    "DO NOT MASK:\n"
                    "- Person names\n"
                    "- Emails\n"
                    "- Phone numbers\n"
                    "- Product names\n"
                    "- Project/Deal IDs\n"
                    "- Client names\n"
                    "- Dates\n"
                    "- Generic terms (IT, HR, Finance)\n"
                    "- Numeric IDs like employee IDs, project IDs, client codes, invoice numbers"
                    "- Numbers not explicitly part of an address or zip code"
                    "- Already sanitized placeholders ([CLIENT], [BU], etc.)"
                )
            # PERSONAL INFO / CLIENT INTERNAL STRUCTURE SANITIZATION
            if sanitize_personal_info:
                task_lines.append("TASK: Mask client-related and personal information.\n\n"

                "ABSOLUTE RULES:\n"
                "- Replace ONLY the sensitive values, NOT labels, headings, or descriptors\n"
                "- Preserve formatting, spacing, punctuation, casing, and line breaks exactly\n"
                "- Do NOT invent or infer missing information\n"
                "- Do NOT modify PwC, dates, percentages, industry terms, or generic words\n"
                "- Do NOT modify already-sanitized placeholders\n"
                "- Return ONLY the sanitized text, no explanations or comments\n\n"

                "STRICT REMOVALS:\n"
                "- Remove all occurrences of 'Booz & Company' completely (no placeholder)\n\n"

                "PLACEHOLDER MAPPINGS (AUTHORITATIVE):\n\n"

                "COMPANY & CLIENT STRUCTURE:\n"
                "- Client company names like Spire → [CLIENT]\n"
                "- Client IDs (e.g., MS-REF-####) → [CLIENT ID] (do NOT replace descriptor words like 'client reference')\n"
                "- Multiple client companies → [CLIENT LIST]\n"
                "- Client parent companies → [CLIENT PARENT]\n"
                "- Client affiliates or subsidiaries → [CLIENT SUBSIDIARY]\n\n"

                "CLIENT INTERNAL STRUCTURE:\n"
                "- Client departments → [CLIENT DEPARTMENT]\n"
                "- Client descriptions or classifications (project/product/program labels) → [CLIENT DESCRIPTION]\n"
                "- Client products → [CLIENT PRODUCT]\n"
                "- Client programs → [CLIENT PROGRAM]\n"
                "- Client projects → [CLIENT PROJECT]\n"
                "- Client systems, tools, portals, or networks → [CLIENT SYSTEM]\n"
                "- Client trust names → [CLIENT TRUST]\n"
                "- Client fund names → [CLIENT FUND]\n\n"

                "PEOPLE & ROLES:\n"
                "- Client employee names → [CLIENT EMPLOYEE]\n"
                "- Client reference contacts → [CONTACT]\n"
                "- Titles/designations ONLY when tied to a client employee name → [TITLE]\n"
                "- Individual names not tied to the client → [NAME]\n\n"

                "CONTACT DETAILS:\n"
                "- Client or client-reference email addresses → [EMAIL]\n"
                "- Client or client-reference phone numbers → [PHONE]\n\n"

                "DIGITAL PRESENCE:\n"
                "- Client websites or portals → [CLIENT WEBSITE]\n\n"

                "OTHER:\n"
                "- Client slogans or marketing taglines → [CLIENT SLOGAN]\n"
                "- Client suppliers, vendors, or third-party service providers → [VENDOR]\n"
                "- Client IDs → [CLIENT ID]\n\n"

                "IMPORTANT DISAMBIGUATION:\n"
                "- Use context, labels, and sentence meaning to choose the correct placeholder\n"
                "- Do NOT replace generic descriptors like 'project','client department', 'project name'\n"
                "- If classification is unclear, default to [COMPANY]")

            # BUSINESS UNIT SANITIZATION
            if business_units:
                task_lines.append(
                    "TASK: Mask **only specific client Business Unit names**, not the generic term 'Business Unit'.\n"
                        "REPLACE:\n"
                        "- Specific BUs like 'Pixel Business Unit', 'Global Finance BU', 'Retail BU', 'Technology BU' → [BU]\n"
                        "DO NOT MASK:\n"
                        "- Generic word 'Business Unit' when not preceded by a specific BU name\n"
                        "- Locations\n"
                        "- Person names\n"
                        "- Emails\n"
                        "- Phone numbers\n"
                        "- Product names\n"
                        "- Project/Deal IDs\n"
                        "- Client names\n"
                        "- Dates\n"
                        "- Generic terms (IT, HR)\n"
                        "- Already sanitized placeholders ([CLIENT], [BU], etc.)\n"
                        "EXAMPLES:\n"
                        "- 'Pixel Business Unit' → '[BU]'\n"
                        "- 'Business Unit meeting scheduled' → leave 'Business Unit' as is"
                )
            if competitor:
                task_lines.append(
                    "TASK: Mask competitor company names and product name of PwC.\n"
                    "REPLACE:\n"
                    "- Competitor company names → [COMPETITOR]\n"
                    "- Product names (e.g., Lays, Pepsi, Doritos, Windows) → [PRODUCT]\n"
                    "- Auditor names (EY, Deloitte, KPMG, etc.) except PwC → [AUDITOR]\n"
                    "DO NOT MASK:\n"
                    "- Client/company names\n"
                    "- Person names\n"
                    "- Locations\n"
                    "- Emails\n"
                    "- Phone numbers\n"
                    "- Project/Deal IDs\n"
                    "- Dates\n"
                    "- Generic terms like IT, HR, Finance\n"
                    "- Already sanitized placeholders ([CLIENT], [BU], etc.)"
                )
    
            # Append additional guidelines if relevant
            if self.additional_guidelines:
                guideline_slide_number = self.get_slide_number_from_guideline(self.additional_guidelines)
                if guideline_slide_number is None or guideline_slide_number == slide_number:
                    task_lines.append(f"Additional Client-Specific Guidelines:\n{self.additional_guidelines.strip()}")

            # Combine enabled tasks
            system_prompt += "\n\n".join(task_lines)
            # User prompt
            user_prompt = f"Sanitize this text:\n{text.strip()}"

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]

            # LLM call
            response = await asyncio.to_thread( client.chat.completions.create,
                model="azure.gpt-5.1",
                messages=messages,
                temperature=0.3,
                max_tokens=1500,
            )

            sanitized = response.choices[0].message.content.strip()
            # ---------------------
            # Stats Tracking
            # ---------------------
            PLACEHOLDER_STATS = {
                "[CLIENT]": "client_names_masked",
                "[CLIENT LIST]": "client_lists_masked",
                "[CLIENT SUBSIDIARY]": "client_subsidiaries_masked",
                "[CLIENT PARENT]": "client_parents_masked",
                "[CLIENT DEPARTMENT]": "client_departments_masked",
                "[CLIENT PRODUCT]": "client_products_masked",
                "[CLIENT PROGRAM]": "client_programs_masked",
                "[CLIENT PROJECT]": "client_projects_masked",
                "[CLIENT SYSTEM]": "client_systems_masked",
                "[CLIENT EMPLOYEE]": "client_employees_masked",
                "[CONTACT]": "client_contacts_masked",
                "[EMAIL]": "personal_info_removed",
                "[PHONE]": "personal_info_removed",
                "[CLIENT ID]": "identifiers_redacted",
                "[BU]": "business_units_masked",
                "[LOCATION X]": "locations_redacted",
                "[COMPETITOR]": "competitor_masked",
                "[PRODUCT]": "products_masked",
                "[AUDITOR]": "auditors_masked",
            }

            for placeholder, stat in PLACEHOLDER_STATS.items():
                if placeholder in sanitized and placeholder not in text:
                    self.sanitization_stats[stat] = self.sanitization_stats.get(stat, 0) + 1

            logger.info(f"LLM Sanitized: {text[:100]} → {sanitized[:100]}")
            return sanitized

        except Exception as e:
            logger.warning(f"Error in LLM sanitization: {e}")
            return text

        
    async def sanitize_text_frame(self, text_frame, client_name=None, llm_client=None, force_llm=False, slide_number=None):
        """
        Sanitize text within a text frame while preserving formatting
        
        Args:
            text_frame: PowerPoint text frame to sanitize
            client_name: Optional client name for targeted replacement
            force_llm: If True, forces LLM sanitization even if llm_detection option is disabled
                      (used to ensure product names are caught on slides where logos were removed)
        """
        if not text_frame or not text_frame.text:
            return
        for paragraph in text_frame.paragraphs:
            #combine all runs in the paragraph
            full_text = "".join(run.text for run in paragraph.runs)

            if not full_text.strip():
                continue

            sanitized = full_text

            if self.options.get("numeric_data", True):
                sanitized = self.sanitize_numeric_data(sanitized)
        
            if self.options.get("financial_data", True):
                sanitized = self.sanitize_financial_data(sanitized)

            #LLM-based sanitization (ONCE per paragraph)
            llm_needed = any([
                self.options.get("names", False),
                self.options.get("personal_info", False),
                self.options.get("locations", False),
                self.options.get("competitor", False),
                self.options.get("business_units", False),
                self.options.get("llm_detection", False) or force_llm
            ])
            # Single LLM call per paragraph if needed
            if llm_client and llm_needed and len(sanitized.strip()) > 5:
                sanitized = await self.sanitize_with_llm(sanitized, llm_client, slide_number=slide_number)

            #write back ONCE
            if sanitized != full_text:
                for run in paragraph.runs:
                    run.text = ""
                paragraph.runs[0].text = sanitized

    def remove_hyperlinks(self, shape):
        """Remove hyperlinks from shapes"""
        try:
            if hasattr(shape, "text_frame") and shape.text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        if hasattr(run, "hyperlink") and run.hyperlink:
                            try:
                                run.hyperlink.address = None
                                self.sanitization_stats["hyperlinks_removed"] += 1
                            except:
                                pass
        except Exception as e:
            logger.warning(f"Error removing hyperlinks: {e}")

    def remove_speaker_notes(self, slide):
        """Remove speaker notes and comment XML parts safely."""
        try:
            if hasattr(slide, "notes_slide") and slide.notes_slide:
                notes_text_frame = slide.notes_slide.notes_text_frame
                if notes_text_frame is not None and notes_text_frame.text.strip():
                    original_text = notes_text_frame.text
                    notes_text_frame.clear()

                    logger.info(
                        f"[NOTES REMOVED] Slide {slide.slide_id}: '{original_text[:80]}'"
                    )
                    self.sanitization_stats["notes_removed"] += 1
            rels_to_remove = [
                (rId, rel)
                for rId, rel in slide.part.rels.items()
                if "comments" in rel.target_ref  # comments1.xml
            ]

            removed_comment_files = []

            for rId, rel in rels_to_remove:
                comment_part = rel._target
                partname = str(comment_part.partname)

                # Drop relationship
                slide.part.drop_rel(rId)

                # Drop the underlying XML part from the package
                if comment_part.package and comment_part.package.parts:
                    try:
                        comment_part.package.drop_part(comment_part)
                        removed_comment_files.append(partname)
                    except Exception:
                        # Fallback: mark deletion failure
                        removed_comment_files.append(f"{partname} (could not delete XML)")

                logger.info(f"[COMMENT REL REMOVED] Slide {slide.slide_id}: rId={rId}")
                self.sanitization_stats["notes_removed"] += 1

            # Logging summary
            if removed_comment_files:
                logger.info(
                    f"[COMMENTS REMOVED] Slide {slide.slide_id}: {removed_comment_files}"
                )

        except Exception as e:
            logger.warning(f"Error removing notes/comments on slide {slide.slide_id}: {e}")


    def remove_logos(self, slide):
        """
        Remove logo images (PICTURE shapes, PLACEHOLDER with PICTURE type, and grouped logos) from a slide.
        NOTE: This does NOT delete the slide itself - only logo images are removed.
        Product names and other text on the slide are preserved and sanitized separately.
        """
        from pptx.enum.shapes import MSO_SHAPE_TYPE, PP_PLACEHOLDER
        shapes_to_remove = []
        total_shapes_before = len(slide.shapes)

        # Get slide dimensions from presentation (not from first shape)
        try:
            slide_width = slide.part.slide.cSld.extent[0]
            slide_height = slide.part.slide.cSld.extent[1]
        except:
            # Fallback to default PowerPoint dimensions
            slide_width = Inches(10)
            slide_height = Inches(7.5)

        for shape in slide.shapes:
            try:
                is_logo_candidate = False
                
                # Check regular PICTURE shapes
                if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    is_logo_candidate = True
                
                # Check PLACEHOLDER shapes with PICTURE type (PwC templates use these for logos)
                elif shape.shape_type == MSO_SHAPE_TYPE.PLACEHOLDER:
                    try:
                        if hasattr(shape, 'placeholder_format'):
                            if shape.placeholder_format.type == PP_PLACEHOLDER.PICTURE:
                                is_logo_candidate = True
                    except:
                        pass
                
                # Check GROUP shapes for nested picture/placeholder logos
                elif shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                    try:
                        # Check if group contains picture children
                        for child_shape in shape.shapes:
                            if child_shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                                is_logo_candidate = True
                                break
                            elif child_shape.shape_type == MSO_SHAPE_TYPE.PLACEHOLDER:
                                if hasattr(child_shape, 'placeholder_format'):
                                    if child_shape.placeholder_format.type == PP_PLACEHOLDER.PICTURE:
                                        is_logo_candidate = True
                                        break
                    except:
                        pass
                
                # If this could be a logo, check position and size heuristics
                if is_logo_candidate:
                    top = shape.top
                    left = shape.left
                    width = shape.width
                    height = shape.height

                    # Logo is typically small and in corners
                    is_small = width < Inches(2) and height < Inches(2)
                    is_top = top < Inches(1.5)
                    is_corner = left < Inches(1) or left > (slide_width - Inches(2))

                    if is_small and (is_top or is_corner):
                        shapes_to_remove.append(shape)
                        self.sanitization_stats["logos_removed"] += 1
                        logger.info(
                            f"Identified logo to remove - Type: {shape.shape_type}, Size: {width}/{height}, Position: {top}/{left}"
                        )

            except Exception as e:
                logger.warning(f"Error checking shape for logo: {e}")

        # Remove identified logo images (NOT the entire slide)
        for shape in shapes_to_remove:
            try:
                sp = shape.element
                sp.getparent().remove(sp)
                logger.info("Successfully removed logo from slide")
            except Exception as e:
                logger.warning(f"Error removing logo: {e}")
        
        total_shapes_after = len(slide.shapes)
        logger.info(
            f"Logo removal complete - Shapes before: {total_shapes_before}, after: {total_shapes_after}, "
            f"removed: {total_shapes_before - total_shapes_after}. Slide preserved."
        )

    
    def remove_chart_data_labels_xml(self, slide):
        """
        Remove all chart data labels by deleting <c:dLbls> and <c:dLbl> nodes.
        Works with all chart types, including pie charts.
        """
        for shape in slide.shapes:
            if not shape.has_chart:
                continue

            chart_part = shape.chart.part
            chart_el = chart_part._element  

            # Remove all grouped label nodes (<dLbls>)
            dLbls_nodes = chart_el.xpath(".//*[local-name()='dLbls']")
            for dLbls in dLbls_nodes:
                parent = dLbls.getparent()
                if parent is not None:
                    parent.remove(dLbls)

            # Remove all individual label nodes (<dLbl>)
            dLbl_nodes = chart_el.xpath(".//*[local-name()='dLbl']")
            for dLbl in dLbl_nodes:
                parent = dLbl.getparent()
                if parent is not None:
                    parent.remove(dLbl)

            # 🔑 Remove all <a:fld> nodes containing numeric values
            fld_nodes = chart_el.xpath(".//*[local-name()='fld']")
            removed_fld_count = 0
            for fld in fld_nodes:
                # Check if the field contains numeric text anywhere
                text_nodes = fld.xpath(".//*[local-name()='t']")
                contains_number = any(re.search(r"(\$)?\d+(\.\d+)?", t.text or "") for t in text_nodes)
                if contains_number:
                    parent = fld.getparent()
                    if parent is not None:
                        parent.remove(fld)
                        removed_fld_count += 1

            # Update stats
            total_removed = len(dLbls_nodes) + len(dLbl_nodes) + removed_fld_count
            if total_removed:
                self.sanitization_stats["numeric_replacements"] += total_removed
                logger.info(
                    f"Removed {total_removed} chart data-label / numeric field nodes (namespace-agnostic)"
                )


    def disconnect_embedded_files(self, slide):
        """Disconnect embedded files (Excel, Word, PDF, etc.) from slide"""
        shapes_to_remove = []

        for shape in slide.shapes:
            try:
                # Check if shape is an OLE object (embedded file)
                if shape.shape_type == MSO_SHAPE_TYPE.EMBEDDED_OLE_OBJECT:
                    shapes_to_remove.append(shape)
                    self.sanitization_stats["embedded_files_disconnected"] += 1
                    logger.info(f"Found embedded OLE object to disconnect")

                # Also check for linked OLE objects
                elif shape.shape_type == MSO_SHAPE_TYPE.LINKED_OLE_OBJECT:
                    shapes_to_remove.append(shape)
                    self.sanitization_stats["embedded_files_disconnected"] += 1
                    logger.info(f"Found linked OLE object to disconnect")

            except Exception as e:
                logger.warning(f"Error checking shape for embedded files: {e}")

        # Remove identified embedded objects
        for shape in shapes_to_remove:
            try:
                sp = shape.element
                sp.getparent().remove(sp)
                logger.info(f"Successfully disconnected embedded file")
            except Exception as e:
                logger.warning(f"Error removing embedded file: {e}")

    async def sanitize_slide(
        self, slide, client_name=None, fix_grammar=False, llm_client=None, slide_number=None
    ):
        """Sanitize a single slide"""
        try:
            self.sanitization_stats["slides_processed"] += 1

            # Track if logos were removed to ensure product sanitization
            logos_removed = False
            if self.options.get("logos", True):
                shapes_before = len(slide.shapes)
                self.remove_logos(slide)
                shapes_after = len(slide.shapes)
                logos_removed = shapes_after < shapes_before
            
            # If logos were removed, force product name sanitization on this slide
            # This ensures products are concealed even if not in predefined list
            force_product_sanitization = logos_removed

            # 🔐 HARD removal of chart numeric labels
            if self.options.get("numeric_data", True):
                self.remove_chart_data_labels_xml(slide)



            # Convert charts to static images if enabled
            # Must be done BEFORE other shape processing to preserve exact positioning
            if self.options.get("convert_charts_to_images", False):
                self.convert_charts_to_images(slide)

            # Disconnect embedded files if enabled
            if self.options.get("embedded_objects", True):
                self.disconnect_embedded_files(slide)

            # Process all shapes
            for shape in slide.shapes:
                try:
                    # Remove hyperlinks if enabled
                    if self.options.get("hyperlinks", True):
                        self.remove_hyperlinks(shape)    

                    # Sanitize text in shape
                    if hasattr(shape, "text_frame") and shape.text_frame:
                        # Force LLM detection on slides where logos were removed
                        # to ensure product names are caught even if not in predefined list
                        await self.sanitize_text_frame(
                            shape.text_frame, client_name, llm_client, force_llm=force_product_sanitization,slide_number=slide_number
                        )

                        # Fix grammar if requested
                        if fix_grammar and llm_client:
                            await self.fix_grammar_in_text_frame(
                                shape.text_frame, llm_client
                            )

                                    # Sanitize text in table cells
                    if hasattr(shape, "table"):
                        for row in shape.table.rows:
                            for cell in row.cells:
                                await self.sanitize_text_frame(
                                    cell.text_frame, client_name, llm_client, force_llm=force_product_sanitization,slide_number=slide_number
                                )
                                if fix_grammar and llm_client:
                                    await self.fix_grammar_in_text_frame(
                                        cell.text_frame, llm_client
                                    )
                    
                    # Sanitize text in charts (titles, data labels, axes)
                    if shape.has_chart:
                        try:
                            chart = shape.chart
                            
                            # Sanitize chart title
                            if chart.has_title and hasattr(chart.chart_title, 'text_frame'):
                                await self.sanitize_text_frame(
                                    chart.chart_title.text_frame, client_name, llm_client, force_llm=force_product_sanitization, slide_number=slide_number
                                )
                            
                            # Sanitize category axis title
                            if hasattr(chart, 'category_axis') and chart.category_axis.has_title:
                                if hasattr(chart.category_axis.axis_title, 'text_frame'):
                                    await self.sanitize_text_frame(
                                        chart.category_axis.axis_title.text_frame, client_name, llm_client, force_llm=force_product_sanitization, slide_number=slide_number
                                    )
                            
                            # Sanitize value axis title
                            if hasattr(chart, 'value_axis') and chart.value_axis.has_title:
                                if hasattr(chart.value_axis.axis_title, 'text_frame'):
                                    await self.sanitize_text_frame(
                                        chart.value_axis.axis_title.text_frame, client_name, llm_client, force_llm=force_product_sanitization, slide_number=slide_number
                                    )
                            
                            # Sanitize series names and data labels
                            for series in chart.series:
                                # Series name
                                if hasattr(series, 'name') and series.name:
                                    original_name = series.name
                                    sanitized_name = original_name
                                    
                                    if self.options.get("names", True):
                                        sanitized_name = await self.sanitize_with_llm(sanitized_name, client_name)
                                    if self.options.get("numeric_data", True):
                                        sanitized_name = self.sanitize_numeric_data(sanitized_name)
                                    
                                    if sanitized_name != original_name:
                                        try:
                                            series.name = sanitized_name
                                        except:
                                            pass
                                
                                # Data labels
                                if hasattr(series, 'has_data_labels') and series.has_data_labels:
                                    try:
                                        for point in series.points:
                                            if hasattr(point, 'data_label') and point.data_label.has_text_frame:
                                                await self.sanitize_text_frame(
                                                    point.data_label.text_frame, client_name, llm_client, force_llm=force_product_sanitization, slide_number=slide_number
                                                )
                                    except:
                                        pass
                            
                            logger.debug(f"Sanitized chart in shape")
                        except Exception as e:
                            logger.warning(f"Error sanitizing chart: {e}")

                except Exception as e:
                    logger.warning(f"Error processing shape: {e}")

            # Remove speaker notes if metadata option is enabled
            if self.options.get("metadata", True):
                self.remove_speaker_notes(slide)
            # --- Sanitize header, footer, date-time, slide number ---
            for attr in ["header", "footer", "date_time", "slide_number"]:
                try:
                    placeholder = getattr(slide, attr, None)
                    if placeholder and hasattr(placeholder, "text_frame") and placeholder.text_frame:
                        await self.sanitize_text_frame(
                            placeholder.text_frame,
                            client_name,
                            llm_client,
                            force_llm=force_product_sanitization,
                            slide_number=slide_number
                        )

                        if fix_grammar and llm_client:
                            await self.fix_grammar_in_text_frame(
                                placeholder.text_frame,
                                llm_client
                            )

                        logger.info(f"Sanitized slide {attr}")
                except Exception as e:
                    logger.warning(f"Error sanitizing slide {attr}: {e}")

        except Exception as e:
            logger.error(f"Error sanitizing slide: {e}")

    async def fix_grammar_in_text_frame(self, text_frame, llm_client):
        """Fix grammar and spelling in a text frame using  AI"""
        try:
            for paragraph in text_frame.paragraphs:
                # Combine full paragraph text
                paragraph_text = "".join(run.text for run in paragraph.runs).strip()
                if not paragraph_text:
                    continue

                # Attempt correction with validation and retry logic
                corrected_text = await self._get_clean_grammar_correction(paragraph_text, llm_client)
                
                # If different, replace all runs with corrected text
                if corrected_text and corrected_text != paragraph_text:
                    self.sanitization_stats["grammar_corrections"] += 1

                    # Clear old paragraph runs
                    for run in paragraph.runs:
                        run.text = ""

                    # Add corrected text in one new run
                    if paragraph.runs:
                        paragraph.runs[0].text = corrected_text
                    else:
                        run = paragraph.add_run()
                        run.text = corrected_text

        except Exception as e:
            logger.warning(f"Error fixing grammar in text frame: {e}")

    async def _get_clean_grammar_correction(self, text: str, llm_client, max_retries: int = 2):
        """
        Get clean grammar correction with validation and retry logic.
        Returns corrected text or original text if validation fails.
        """
        masked_pattern = re.compile(r"^\$[Xx]+(\.[Xx]{2})?$")

        # HARD SKIP: skip numeric-only or currency-only text
        text_stripped = text.strip()

        # Check if text is fully numeric or a currency
        if (
            not re.search(r"[A-Za-z]", text_stripped)  # numeric-only
            or self.patterns["currency"].fullmatch(text_stripped)  # single currency
            or self.patterns["currency_word"].fullmatch(text_stripped)  # currency with word
            or self.patterns["currency_range"].fullmatch(text_stripped)  # currency range
            or masked_pattern.fullmatch(text_stripped)
        ):
            logger.info("Skipping grammar correction for numeric or currency-only text")
            return text

        for attempt in range(max_retries):
            try:
                response = await asyncio.to_thread( llm_client.chat.completions.create,
                    model="azure.gpt-5.1",
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a professional editor. Your ONLY job is to fix spelling and grammar mistakes.\n\n"
                                "CRITICAL RULES:\n"
                                "1. Output EXACTLY the corrected text with identical line breaks\n"
                                "2. NO explanations, commentary, or meta-text whatsoever\n"
                                "3. If no corrections needed, echo the input verbatim\n"
                                "4. Preserve original spacing and formatting\n"
                                "5. Wrap your output in <<text>>...<</text>> tags\n\n"
                                "VIOLATING THESE RULES BREAKS THE WORKFLOW.\n\n"
                                "Example input: 'The compny profit was -$5.2M'\n"
                                "Example output: <<text>>The company profit was -$5.2M<</text>>"
                            ),
                        },
                        {
                            "role": "user",
                            "content": text,
                        },
                    ],
                    temperature=0.7,
                    max_tokens=1500,
                )

                raw_response = response.choices[0].message.content.strip()
                
                # STRICT schema validation: MUST contain tags
                if "<<text>>" not in raw_response or "<</text>>" not in raw_response:
                    logger.warning(
                        f"Grammar correction attempt {attempt + 1} failed - missing schema tags"
                    )
                    if attempt < max_retries - 1:
                        continue
                    else:
                        logger.warning("Grammar correction schema validation failed, keeping original text")
                        return text
                # Extract text from schema wrapper
                try:
                    start = raw_response.index("<<text>>") + 8
                    end = raw_response.index("<</text>>")
                    corrected_text = raw_response[start:end]
                except (ValueError, IndexError) as e:
                    logger.warning(f"Grammar correction schema parsing failed: {e}")
                    if attempt < max_retries - 1:
                        continue
                    else:
                        return text

                # STRICT validation: check for ANY explanatory content patterns
                # Check for colons followed by explanations (e.g., "Explanation:", "Note:")
                has_colon_explanation = bool(re.search(r'\b(explanation|note|correction|however|assuming|if we|could be|possible|without context|please provide|hard to|consider|accurate|suggestion|alternative|option):', corrected_text, re.IGNORECASE))
                
                # Check for question marks (explanations often ask questions)
                has_questions = '?' in corrected_text and '?' not in text
                
                # Check for multiple sentences when original was single sentence
                original_sentences = len([s for s in re.split(r'[.!?]+', text) if s.strip()])
                corrected_sentences = len([s for s in re.split(r'[.!?]+', corrected_text) if s.strip()])
                sentence_inflation = corrected_sentences > max(original_sentences * 2, original_sentences + 2)
                
                # Check for suspiciously long response
                length_inflation = len(corrected_text) > len(text) * 3
                
                if has_colon_explanation or has_questions or sentence_inflation or length_inflation:
                    logger.warning(
                        f"Grammar correction attempt {attempt + 1} failed validation - appears to contain explanations"
                    )
                    if attempt < max_retries - 1:
                        # Retry with a stern reminder
                        continue
                    else:
                        # Final attempt failed, return original text
                        logger.warning("Grammar correction validation failed after retries, keeping original text")
                        return text
                
                # Validation passed
                logger.info(f"Grammar correction: '{text}' -> '{corrected_text}'")
                return corrected_text

            except Exception as e:
                logger.warning(f"Error in grammar correction attempt {attempt + 1}: {e}")
                if attempt < max_retries - 1:
                    continue
                else:
                    # All attempts failed, return original text
                    return text
        
        # Fallback: return original text
        return text

    def clear_metadata(self, prs):
        """Clear presentation metadata"""
        try:
            core_props = prs.core_properties
            core_props.author = "PwC"
            core_props.title = "Sanitized Presentation"
            core_props.subject = ""
            core_props.keywords = ""
            core_props.comments = ""
            core_props.last_modified_by = "PwC"
            core_props.company = "PwC"
        except Exception as e:
            logger.warning(f"Error clearing metadata: {e}")

    async def sanitize_presentation(self, input_file, client_name=None, fix_grammar=False, llm_service=None):
        """
        Main method to sanitize a PowerPoint presentation

        Args:
            input_file: File object or path to PPTX
            client_name: Optional client name to replace
            fix_grammar: Whether to fix grammar and spelling errors
            llm_service: Optional LLMService for intelligent detection and grammar fixing

        Returns:
            BytesIO object containing sanitized presentation
        """
        try:
            # Load presentation
            if isinstance(input_file, (str, bytes)):
                prs = Presentation(input_file)
            else:
                prs = Presentation(BytesIO(input_file.read()))

            logger.info(f"Processing presentation with {len(prs.slides)} slides")

            # For backward compatibility: extract llm_client from llm_service if provided
            llm_client = llm_service.client if llm_service else None

            # Initialize llm client if not provided and grammar fixing is requested
            if llm_client is None and fix_grammar:
                try:
                    import os
                    from openai import AzureOpenAI  # Use Azure SDK

                    azure_endpoint = os.getenv("AI_ENDPOINT")
                    azure_key = os.getenv("AI_API_KEY")
                    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")
                    model_name = os.getenv("AI_MODEL", "azure.gpt-5.1")

                    if azure_endpoint and azure_key:
                        llm_client = AzureOpenAI(
                            azure_endpoint=azure_endpoint,
                            api_key=azure_key,
                            api_version=api_version,
                            model=model_name
                        )
                        logger.info("Using Azure OpenAI for sanitization and grammar correction")

                except Exception as e:
                    logger.warning(
                        f"Could not initialize Azure LLM client for grammar fixing: {e}"
                    )

            # Clear metadata if enabled
            if self.options.get("metadata", True):
                self.clear_metadata(prs)

            # Process each slide
            for idx, slide in enumerate(prs.slides, 1):
                logger.info(f"Processing slide {idx}/{len(prs.slides)}")
                # Determine which slide the guideline applies to
                if self.additional_guidelines:
                    guideline_slide_number = self.get_slide_number_from_guideline(self.additional_guidelines)
                    logger.info(f"Additional guideline applies to slide: {guideline_slide_number}")
                await self.sanitize_slide(slide, client_name, fix_grammar, llm_client, slide_number=idx)
            # Save to BytesIO
            output = BytesIO()
            prs.save(output)
            output.seek(0)

            # Log statistics
            logger.info(f"Sanitization complete. Stats: {self.sanitization_stats}")

            return output

        except Exception as e:
            logger.error(f"Error during sanitization: {e}")
            raise

    def get_stats(self):
        """Return sanitization statistics"""
        return self.sanitization_stats

