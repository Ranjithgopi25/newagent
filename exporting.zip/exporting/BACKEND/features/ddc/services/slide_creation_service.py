from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import requests
import time
import json
import sys
from typing import Optional, Dict, Any


logger = logging.getLogger(__name__)

class SlideCreationService(BaseTLStreamingService):

    """Service for Slide Creation workflow"""
    
    async def create_slides(self, prompt: str, image_bytes: Optional[bytes] = None):
        """Generate slide outlines from prompt and optional image"""
        system_prompt = """You are a PwC presentation designer.
        
Create professional slide outlines with clear structure and executive-level content."""
        
        image_note = "Image provided for analysis" if image_bytes else "No image provided"
        user_message = f"""Create a slide outline based on this request:

{prompt}

{image_note}

Provide a structured slide outline with titles and key points for each slide."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk
    
    async def execute(self, *args, **kwargs):
        return await self.create_slides(*args, **kwargs)

class PlusDocsClient:
    """Client for interacting with PlusDocs API"""

    def __init__(self, api_token: str):
        """
        Initialize the PlusDocs client
        Args:
            api_token: Bearer token for API authentication
        """
        self.api_token = api_token
        self.base_url = "https://api.plusdocs.com/r/v0"
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_token}"
        }

    def create_presentation(self, prompt: str, template_id: str, isImage: bool) -> Optional[str]:
        """
        Create a new presentation
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
        Returns:
            Presentation ID if successful, None otherwise
        """
        url = f"{self.base_url}/presentation"
        payload = ""

        if(isImage == True):
            payload = {
                "prompt": prompt,
                "templateId": template_id,
                "numberOfSlides": 1
            }
        
        else:
            payload = {
                "prompt": prompt,
                "templateId": template_id
            }

        try:
            print(f"Creating presentation with prompt: '{prompt}'")
            response = requests.post(url, headers=self.headers, json=payload)
            response.raise_for_status()

            data = response.json()
            presentation_id = data.get('id')

            if presentation_id:
                print(f"✓ Presentation created successfully!")
                print(f"  Presentation ID: {presentation_id}")
                return presentation_id
            else:
                print("✗ No presentation ID returned")
                return None

        except requests.exceptions.RequestException as e:
            print(f"✗ Error creating presentation: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"  Response: {e.response.text}")
            return None

    def get_presentation_status(self, presentation_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the status of a presentation
        Args:
            presentation_id: ID of the presentation to check
        Returns:
            Presentation data if successful, None otherwise
        """
        url = f"{self.base_url}/presentation/{presentation_id}"

        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            print(f"✗ Error getting presentation status: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"  Response: {e.response.text}")
            return None

    def poll_until_complete(
        self,
        presentation_id: str,
        poll_interval: int = 5,
        max_attempts: int = 60
    ) -> Optional[str]:
        """
        Poll the API until the presentation is complete
        Args:
            presentation_id: ID of the presentation to poll
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 60)
        Returns:
            Download URL if successful, None otherwise
        """
        print(f"\nPolling for completion (checking every {poll_interval}s)...")

        for attempt in range(1, max_attempts + 1):
            print(f"  Attempt {attempt}/{max_attempts}...", end=" ")

            data = self.get_presentation_status(presentation_id)
            if data is None:
                print("failed to get status")
                time.sleep(poll_interval)
                continue

            status = data.get('status', 'unknown')
            print(f"status: {status}")

            # Check if completed
            if status == 'GENERATED' or status == 'success':
                download_url = (
                    data.get('downloadUrl')
                    or data.get('download_url')
                    or data.get('url')
                )
                if download_url:
                    print(f"\n✓ Presentation completed successfully!")
                    return download_url
                else:
                    print(f"\n✓ Presentation completed but no download URL found")
                    print(f"  Full response: {json.dumps(data, indent=2)}")
                    return None

            # Check if failed
            if status in ['failed', 'error']:
                print(f"\n✗ Presentation generation failed")
                print(f"  Response: {json.dumps(data, indent=2)}")
                return None

            # Still processing
            time.sleep(poll_interval)

        print(f"\n✗ Timeout: Presentation did not complete after {max_attempts} attempts")
        return None

    def create_and_wait(
        self,
        prompt: str,        
        template_id: str,
        isImage: bool,
        poll_interval: int = 5,
        max_attempts: int = 60
    ) -> Optional[str]:
        """
        Create a presentation and wait for it to complete
        Args:
            prompt: Description of the presentation to create
            template_id: ID of the template to use
            poll_interval: Seconds between each poll (default: 5)
            max_attempts: Maximum number of polling attempts (default: 60)
        Returns:
            Download URL if successful, None otherwise
        """
        presentation_id = self.create_presentation(prompt, template_id, isImage)
        if not presentation_id:
            return None

        return self.poll_until_complete(
            presentation_id,
            poll_interval,
            max_attempts
        )
