from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse
from app.features.ddc.services.slide_creation_service import PlusDocsClient
from app.features.ddc.utils.text_refiner import (
    extract_text_from_any,
    refine_text_for_slides,
    extract_meaning_from_image
)
from typing import Optional
import logging
import pandas as pd
from io import BytesIO
import base64

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def slide_creation_workflow(
    additional_guidelines: str = Form(...),

    # Optional uploads
    file: Optional[UploadFile] = File(None),
    custom_template_file: Optional[UploadFile] = File(None),
    chart_data_file: Optional[UploadFile] = File(None),

    # Optional dropdown choice
    template: Optional[str] = Form(None),
):
    """
    New Slide Creation workflow:
    - Extract text from uploaded file (PDF/DOCX/PPTX/etc)
    - Refine using Azure OpenAI
    - Combine with user guidelines
    - Send to PlusDocs
    """
    try:
        logger.info("[SlideCreation] Incoming request")

        # ------------------------
        # 1. Extract & refine text
        # ------------------------
        refined_text = ""
        isImage = False
        raw_text= ""

        if file:
            
            file_bytes = await file.read()
            
            ext = file.filename.lower().split(".")[-1]
            try:                
                
                if(ext == "png" or ext == "jpg" or ext == "jpeg"):
                    
                    img_bytes = base64.b64encode(file_bytes).decode("utf-8")                                 
                    raw_text = extract_meaning_from_image(img_bytes, ext)
                    logger.info(f"[SlideCreation] raw_text: {raw_text}")
                    isImage = True

                else:
                    raw_text = extract_text_from_any(file.filename, file_bytes)
                    logger.info(f"[SlideCreation] raw_text: {raw_text}")

                # refined_text = refine_text_for_slides(raw_text)
                #logger.error(f"[SlideCreation] refined_text: {refined_text}")
                logger.info("[SlideCreation] Document text extracted and /not/ refined.")

            except Exception as e:
                logger.error(f"[SlideCreation] Extraction/Refinement failed: {e}")
                raise HTTPException(status_code=400, detail="Failed to process uploaded file.")
            
        # ------------------------
        # 2. Extract chart data
        # ------------------------
        raw_text_chart = ""

        if chart_data_file:
            chart_data_file_bytes = await chart_data_file.read()

            try:
                sheets = pd.read_excel(BytesIO(chart_data_file_bytes), sheet_name=None, engine="openpyxl")
                raw_text_chart = "".join(f"=== {name} ===\n{df.to_csv(index=False)}" for name, df in sheets.items())
            except Exception as e:
                logger.error(f"\n[SlideCreation] raw_text_chart issues: {e}")
            """
            try:
                raw_text_chart = extract_text_from_any(chart_data_file.filename,chart_data_file_bytes)
                logger.error(f"[SlideCreation] raw_text_chart: {raw_text_chart}")
            except Exception as e:
                logger.error(f"[SlideCreation] raw_text_chart: {e}")
                """
                

        # ------------------------
        # 3. Compose final prompt
        # ------------------------
        prompt_parts = []

        if additional_guidelines:
            prompt_parts.append("User wants to create a presentation with this topic and guidelines:\n" + additional_guidelines+"\n"+raw_text)

        # if refined_text:
        #     prompt_parts.append("While creating the presentation make sure to use the CONTENT EXTRACTED FROM DOCUMENT:\n" + refined_text)

        if raw_text_chart:
            prompt_parts.append("While creating this presentation use this chart data"+ raw_text_chart + "to build graphs or charts.Make sure to create a visual which properly explain the data.")

        

        prompt = "\n\n".join(prompt_parts).strip()

        # ------------------------
        # 4. Template ID
        # ------------------------
        template_id = "YGw8kjq05qPFKRUpe2cOjY"  # replace later with dropdown mapping

        # ------------------------
        # 5. PlusDocs Client
        # ------------------------
        API_TOKEN = "v1,25g5CI5ZTGyy5m8Rp43BNWL774Mjl8ln2mywgJYpEyA,cm01dho7w0004134q3dfol5vl_cmiqiek6k000fmtgypmd0u2eg,YU644eaMtl5jYdHAWatzT9RzartlZiFE-PfStIHDDrU"
        client = PlusDocsClient(API_TOKEN)

        # ------------------------
        # 6. Generate Slides
        # ------------------------
        download_url = client.create_and_wait(
            prompt=prompt,
            template_id=template_id,
            isImage=isImage,
            poll_interval=5,
            max_attempts=60
        )

        if not download_url:
            raise HTTPException(status_code=500, detail="Slide generation failed")
        #print("Download URL:", download_url)
        return JSONResponse({
            "status": "success",
            "download_url": download_url
        })

    except Exception as e:
        logger.error(f"[SlideCreation] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
