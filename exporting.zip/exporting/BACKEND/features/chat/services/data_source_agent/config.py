"""
Configuration for data source connections.
"""

import os
import pyodbc
# SQL Server Configuration (CapitalIQ)
# SQLSERVER_CONFIG = {
#     "server": "pzi-gxus-p-mssq-thpd-p002.database.windows.net",
#     "database": "CapIQ_XF",
#     "username": "US_adv_DataPlatform-CDO_MCX_p001",
#     "password": "+CYcG3l$(W7@]y{#a*86"
# }

# # Databricks Configuration (BoardEx)
# DATABRICKS_CONFIG = {
#     "host": os.getenv("DATABRICKS_HOST", "adb-2215734503437142.2.azuredatabricks.net"),
#     "http_path": os.getenv("DATABRICKS_HTTP_PATH", "/sql/1.0/warehouses/36a379266063cb38"),
#     "access_token": os.getenv("DATABRICKS_TOKEN", "dapi67ef85a2cff273251aa0ee1d4d39c344"),
#     "catalog": "thirdpartydata_dev",
#     "schema": "boardex"
# }

# PLUSDOCS_CONFIG = {
#     "api_token": "v1,25g5CI5ZTGyy5m8Rp43BNWL774Mjl8ln2mywgJYpEyA,cm01dho7w0004134q3dfol5vl_cmiqiek6k000fmtgypmd0u2eg,YU644eaMtl5jYdHAWatzT9RzartlZiFE-PfStIHDDrU",
#     "template_id": "YGw8kjq05qPFKRUpe2cOjY",
#     "poll_interval": 5,
#     "max_attempts": 60  # 5 minutes max wait time
# }
# # Factiva API Configuration
# FACTIVA_CONFIG = {
#     "auth_url": "https://accounts.dowjones.com/oauth2/v1/token",
#     "content_url": "https://api.dowjones.com/content/gen-ai/retrieve",
#     "username": "9PRI033400-svcaccount@dowjones.com",
#     "client_id": "bbFvlCtgXICfEAky3cIihoLH2dPWhUxcjE7YRA72",
#     "password": "xFJoVBwoStvcvF47"
# }
# # Azure AI Search Configuration
# AI_SEARCH_CONFIG = {
#     "endpoint":"https://srch-bsmxsrch-ufk5x.search.windows.net",
#     "index_name":"rag-s-b-index",
#     "api_key":"sDp2cl4M7JRScpkTVDDCEJtxsFoOOxr2a5T3RQ1HT3AzSeDVtLVj"
# }

# Schema Registry for database tables
SCHEMA_REGISTRY = {
    "capitaliq": {
        "vw_CompanyIncomeStatementFinancials": {
            "description": "Company financial statements including income statement metrics",
            "columns": {
                "companyName": "Name of the company",
                "CapIQ_Id": "Capital IQ identifier",
                "periodEndDate": "End date of the financial period",
                "calendarYear": "Calendar year",
                "periodTypeName": "Type of period (Annual, Quarterly)",
                "dataItemName": "Name of the financial metric",
                "dataItemValue": "Value of the financial metric"
            },
            "data_items": [
                "Net Income - (IS)",
                "Total Revenues", 
                "Gross Profit",
                "Cost Of Revenues",
                "Depreciation & Amortization, Total - (IS)"
            ]
        },
        "vw_CompanyBalanceSheetFinancials": {
            "description": "Company balance sheet data including assets, liabilities, and equity",
            "columns": {
                "companyName": "Name of the company",
                "CapIQ_Id": "Capital IQ identifier",
                "SEC_CIK": "SEC CIK number",
                "DUNS": "DUNS number",
                "periodEndDate": "End date of the financial period",
                "filingDate": "Date of filing",
                "periodTypeName": "Type of period (Annual)",
                "calendarYear": "Calendar year",
                "dataItemId": "ID of the financial data item",
                "dataItemName": "Name of the balance sheet metric",
                "dataItemValue": "Value of the balance sheet metric"
            },
            "data_items": [
                "Total Assets",
                "Total Current Assets",
                "Total Cash And Short Term Investments",
                "Total Receivables",
                "Net Property Plant And Equipment",
                "Total Liabilities And Equity",
                "Total Equity",
                "Total Common Equity",
                "Total Current Liabilities",
                "Total Liabilities - (Standard / Utility Template)",
                "Gain (Loss) on Sale of Investment, Total (Rev)"
            ]
        }
    },
    "boardex": {
        "company_profile_advisors": {
            "description": "Company advisor relationships including auditors",
            "columns": {
                "BoardName": "Name of the company",
                "AdvisorName": "Name of the advisory firm",
                "AdvTypeDesc": "Type of advisor (Auditors, Corporate Advisors)"
            },
            "advisor_types": ["Auditors", "Corporate Advisors", "Investor Relations Advisors"]
        },
        "director_profile_achievements": {
            "description": "Director achievements and awards",
            "columns": {
                "DirectorName": "Name of the director",
                "CompanyName": "Name of the company",
                "Achievement": "Description of the achievement",
                "AchievementDate": "Date of achievement"
            }
        }
    }
}