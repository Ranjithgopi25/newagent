"""
Chat Service - With LangGraph Agent Support
"""

import logging
import json
from typing import List, AsyncIterator, Dict, Optional
from app.infrastructure.llm.llm_service import LLMService
from app.features.chat.services.data_source_agent import DataSourceLangGraphAgent

logger = logging.getLogger(__name__)


class ChatService:
    """Chat service with LLM and optional LangGraph agent for tool calling"""

    def __init__(self, llm_service: LLMService, langgraph_agent: Optional[DataSourceLangGraphAgent] = None):
        self.llm = llm_service
        self.agent = langgraph_agent
    
    async def generate_response(self, messages: List[Dict]) -> str:
        """Generate non-streaming response, using agent if available"""
        try:
            if self.agent:
                logger.info("[ChatService] Using LangGraph agent for response generation")
                response = await self.agent.invoke(messages)
                return response
            else:
                logger.info("[ChatService] Using llm for response generation")
                return await self.llm.chat_completion(messages)
        except Exception as e:
            logger.error(f"Generate response failed: {e}")
            raise

    async def stream_response(self, messages: List[Dict]) -> AsyncIterator[str]:
        """Stream response as SSE, using agent if available"""
        try:
            if self.agent:
                logger.info("[ChatService] Using LangGraph agent for streaming")
                async for chunk in self.agent.stream_invoke(messages):
                    yield chunk
            else:
                logger.info("[ChatService] Using llm for streaming")
                async for chunk in self.llm.stream_completion(messages):
                    yield chunk
        except Exception as e:
            logger.error(f"Stream response failed: {e}")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
