"""
Pydantic schemas for chat history management.
"""
from pydantic import BaseModel, Field
from typing import Optional


class CreateSessionRequest(BaseModel):
    """Request model for creating a new chat session."""
    source: str = Field(..., description="Source of conversation (DDDC, Market_Intelligence, Thought_Leadership, Export, Chat)")
    initial_message: Optional[str] = Field(None, description="Optional initial user message")
    title: Optional[str] = Field(None, description="Optional session title")


class AddMessageRequest(BaseModel):
    """Request model for adding a message to a session."""
    role: str = Field(..., description="Message role (user, assistant, system)")
    content: str = Field(..., description="Message content")


class SessionResponse(BaseModel):
    """Response model for session data."""
    session_id: str
    source: str
    title: Optional[str] = None
    conversation: dict
    created_at: str
    updated_at: Optional[str] = None


class SessionSummary(BaseModel):
    """Response model for session list."""
    session_id: str
    source: str
    title: Optional[str] = None
    preview: str
    message_count: int
    created_at: str
    updated_at: str


class MessageResponse(BaseModel):
    """Response model after adding a message."""
    session_id: str
    conversation: dict
    updated_at: str
