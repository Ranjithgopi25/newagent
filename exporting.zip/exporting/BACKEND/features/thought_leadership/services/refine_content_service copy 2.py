from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import re
import json
from fastapi import HTTPException
from typing import Any

logger = logging.getLogger(__name__)


class RefineContentService(BaseTLStreamingService):
    """Service for Refine Content workflow with multiple refinement capabilities"""
    
    # Service type constants
    SERVICE_EXPAND_COMPRESS = "Expand or Compress Content"
    SERVICE_TONE = "Adjust for Audience / Tone"
    SERVICE_RESEARCH = "Enhance with Additional Research"
    SERVICE_EDIT = "Edit Content"
    SERVICE_SUGGESTIONS = "Provide Suggestions on Improving Content"
    
    # Document section markers
    PRIMARY_DOCUMENT_MARKER = "PRIMARY DOCUMENT (BASE CONTENT):"
    SUPPORTING_DOCUMENT_MARKER = "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):"
    INSTRUCTION_MARKER = "INSTRUCTION:"
    
    # Configuration constants
    ACTIVE_SERVICE_KEYS = ['compress', 'expand', 'tone', 'research', 'edit', 'suggestions']
    
    # Compiled regex patterns for performance
    _PATTERNS = {
        'word_limit': re.compile(r'Word limit:\s*(\d+)', re.IGNORECASE),
        'compress_pattern': re.compile(r'(?:Compress|Expand|Word\s+limit)[^\d]*(\d+)\s*words?', re.IGNORECASE),
        'tone': re.compile(r'Audience and tone:\s*([^\n\r]+)', re.IGNORECASE | re.MULTILINE),
        'research_topics': re.compile(r'Research Topics:\s*([^\n]+)', re.IGNORECASE),
        'content_to_refine': re.compile(r'Content to Refine:\s*(.+)$', re.DOTALL | re.IGNORECASE),
        'instruction_removal': re.compile(r'^\s*\[.*?\]\s*\n*', re.IGNORECASE | re.MULTILINE),
    }
    


    def _get_suggestions_prompt_template(self) -> str:
        """Get the detailed PwC suggestions prompt template"""
        return """
ROLE & OBJECTIVE
You are a Senior PwC Brand & Content Strategist and Executive Editor. Your role is NOT to rewrite the content, but to act as a critical writing coach. Provide specific, actionable, and high-value suggestions to help the author elevate their draft to meet PwC's thought leadership standards.

I. CORE ANALYSIS FRAMEWORK (PwC Tone Pillars)
Evaluate the draft against these three tone pillars and identify specific opportunities for improvement:

BOLD (Assertive, Decisive, Clear)
- Standard: Lead with a strong point of view; avoid safe, academic language.
- Watch For: Soft qualifiers (e.g., "somewhat," "arguably," "it seems that"), passive voice, dense jargon
- Fix: Encourage decisive language. Replace banned word "catalyst" with driver, enabler, accelerator.

COLLABORATIVE (Human, Conversational, Partnership-Focused)
- Standard: Write to the reader, not at them.
- Watch For: Third-person distancing ("PwC helps clients…"), formal stiffness (lack of contractions, overly complex sentences)
- Fix: Use first-person and direct address ("We help you…"). Replace "clients" with "you" or "your organization."

OPTIMISTIC (Future-Forward, Outcome-Focused)
- Standard: Emphasize solutions and possibilities.
- Watch For: Problem-only framing, static language
- Fix: Pivot to outcomes. Use movement words (transform, evolve, reshape) and energy words (propel, spark, accelerate).

II. COMPLIANCE CHECKS
Flag and correct any prohibited terms or style violations:
- "Catalyst" → driver/enabler/accelerator
- "Clients" → you/your organization
- "PwC Network" → PwC network (lowercase 'n')
- "Mainland China" → Chinese Mainland
- Exclamation marks
- Buzzwords/fillers: leverage, synergy, at the end of the day, in order to, moving forward

III. EXPANDED ANALYSIS
- Logic & Depth (MECE): Check argument flow, gaps, and redundancy.
- Thought Leadership: Suggest proprietary PwC data or examples to strengthen authority.
- Visual Opportunities: Identify text-heavy sections for charts/infographics.
- Differentiation: Flag generic content; push for unique PwC insights.
- Consistency & Risk: Spot contradictions or cultural sensitivities.

IV. OUTPUT FORMAT
Provide feedback in this structured format:

✓ Brand Voice Alignment
- Observation: [Quote problematic phrase]
- Fix: [Explain why and suggest bold/collaborative alternative]

✓ Vocabulary & Terminology
- Flagged Terms: [List prohibited words only if used]
- Recommended Swaps: [Suggest PwC-approved alternatives]

✓ Structural Clarity
- Observation: [Identify long or buried sentences]
- Fix: [Give specific restructuring advice]

✓ Strategic Lift (So What?)
- Observation: [Generic statement]
- Fix: [Push for business impact and specificity]

✓ Logic & Evidence Gaps
- Observation: [Weak or unsupported argument]
- Fix: [Suggest data or examples]

✓ Visual Opportunities
- Observation: [Text-heavy section]
- Fix: [Recommend visual format]

✓ Differentiation
- Observation: [Generic content]
- Fix: [Suggest unique PwC angle]

⚠ Risk & Sensitivity
- Flagged Items: [Contradictions or sensitivities]
- Action: [Resolution guidance]

**CONTENT TO ANALYZE:**
{content}"""

    def _get_tone_instruction(self, tone: str) -> str:
        """Generate tone instruction dynamically based on the provided tone parameter"""
        return f"""Match '{tone}' tone in vocabulary, sentence structure, formality level, and overall voice throughout.

CRITICAL POINTS:
  - Ensure consistency: Apply '{tone}' tone to every sentence and paragraph
  - Adjust language register: Use appropriate vocabulary and phrasing for '{tone}' tone
  - Maintain clarity: Keep content clear and understandable while matching the tone
  - Preserve meaning: Only change HOW things are expressed, not WHAT is expressed"""
    
    def _extract_word_limit(self, content: str) -> int | None:
        """Extract word limit from content using compiled regex"""
        # Try flexible pattern first
        match = self._PATTERNS['compress_pattern'].search(content)
        if match:
            return int(match.group(1))
        
        # Fall back to explicit "Word limit:" pattern
        match = self._PATTERNS['word_limit'].search(content)
        return int(match.group(1)) if match else None
    
    def _count_actual_words(self, content: str) -> int:
        """Calculate word count excluding instruction markers"""
        clean_content = self._PATTERNS['instruction_removal'].sub('', content).strip()
        return len(clean_content.split()) if clean_content else 0
    
    def _parse_document_structure(self, content: str) -> dict[str, Any]:
        """Parse primary and supporting documents from content"""
        docs = {
            'primary': None,
            'secondary': None,
            'has_supporting': False
        }
        
        if self.PRIMARY_DOCUMENT_MARKER not in content:
            return docs
        
        try:
            primary_start = content.index(self.PRIMARY_DOCUMENT_MARKER) + len(self.PRIMARY_DOCUMENT_MARKER)
            logger.debug(f"[Refine Content] Primary document found at index {primary_start}")
            
            if self.SUPPORTING_DOCUMENT_MARKER in content:
                supporting_start = content.index(self.SUPPORTING_DOCUMENT_MARKER)
                docs['primary'] = content[primary_start:supporting_start].strip()
                
                secondary_start = supporting_start + len(self.SUPPORTING_DOCUMENT_MARKER)
                instruction_start = content.find(self.INSTRUCTION_MARKER, secondary_start)
                secondary_end = instruction_start if instruction_start != -1 else len(content)
                
                docs['secondary'] = content[secondary_start:secondary_end].strip()
                docs['has_supporting'] = True
                logger.debug(f"[Refine Content] Supporting document found, primary length: {len(docs['primary'])}, secondary length: {len(docs['secondary'])}")
            else:
                docs['primary'] = content[primary_start:].strip()
                logger.debug(f"[Refine Content] Primary document only, length: {len(docs['primary'])}")
        except Exception as e:
            logger.warning(f"[Refine Content] Failed to parse document structure: {e}")
        
        return docs
    
    def _detect_services(self, content: str) -> dict[str, Any]:
        """Extract all services and their parameters from the content"""
        services = {
            'compress': None,
            'expand': None,
            'tone': None,
            'research': False,
            'edit': False,
            'suggestions': False,
            'requested_word_limit': None,
            'is_expand': False
        }
        
        # Detect compress/expand service
        word_limit = self._extract_word_limit(content)
        if word_limit:  # Detect if word limit is present
            services['requested_word_limit'] = word_limit
            # Will determine expand vs compress after counting current words
            services['compress'] = str(word_limit)  # Set as default, will change if expand
        
        # Detect tone service
        tone_match = self._PATTERNS['tone'].search(content)
        if tone_match:
            tone = tone_match.group(1).strip()
            services['tone'] = ' '.join(tone.split())
        
        # Detect research service
        if self.SERVICE_RESEARCH in content:
            services['research'] = True
            research_match = self._PATTERNS['research_topics'].search(content)
            if research_match:
                services['research_topics'] = research_match.group(1).strip()
        
        # Detect other services
        services['edit'] = self.SERVICE_EDIT in content
        services['suggestions'] = self.SERVICE_SUGGESTIONS in content
        
        return services
    
    def _generate_title(self, services: dict[str, Any]) -> str:
        """Generate descriptive title based on active services"""
        # Count active services
        active_services = self._get_active_service_count(services)
        
        if active_services == 0:
            return "Refined Content"
        
        if active_services > 1:
            return "All-in-One Content Refinement"
        
        # Single service
        if services['compress']:
            return f"Refined Content ({services['compress']} words)"
        if services['expand']:
            return f"Expanded Content ({services['expand']} words)"
        if services['tone']:
            tone_title = ' '.join(services['tone'].split()).title()
            return f"Refined Content - {tone_title} Tone"
        if services['research']:
            return "Enhanced Content with Additional Research"
        if services['edit']:
            return "Edited Content"
        if services['suggestions']:
            return "Content with Improvement Suggestions"
        
        return "Refined Content"
    
    def _get_active_service_count(self, services: dict[str, Any]) -> int:
        """Count the number of active services"""
        return sum(bool(services.get(key)) for key in self.ACTIVE_SERVICE_KEYS)
    
    def _build_tone_critical_points(self, tone: str) -> str:
        """Format tone critical points for display"""
        tone_instruction = self._get_tone_instruction(tone)
        return tone_instruction
    
    def _build_compression_instructions(self, word_limit: str, current_count: int = 0) -> str:
        """Build detailed compression instructions"""
        current_info = f"\n   - Current Word Count: {current_count} words" if current_count > 0 else ""
        reduction_info = f"\n   - Reduction Needed: {int(word_limit) - current_count} words" if current_count > 0 else ""
        
        return f"""1. WORD COUNT (HIGHEST PRIORITY):
   - Target: EXACTLY {word_limit} words{current_info}{reduction_info}
   - Method: Compress WITHIN each paragraph by:
     • Tightening sentences
     • Removing redundancy and filler words
     • Using more concise phrasing
   - Preserve: ALL paragraphs, their order, and structure
   - DO NOT: Delete paragraphs, conclusions, or sections to meet word count
   - Validation: Count every single word - must be exactly {word_limit}, not {int(word_limit)-1}, not {int(word_limit)+1}"""
    
    def _build_expansion_instructions(self, word_limit: str, current_count: int) -> str:
        """Build detailed expansion instructions"""
        return f"""1. WORD COUNT (HIGHEST PRIORITY):
   - Current Word Count: {current_count} words
   - Target: EXACTLY {word_limit} words
   - Expansion Needed: {int(word_limit) - current_count} words
   - Method: Expand WITHIN each paragraph by:
     • Adding relevant details and examples
     • Developing key concepts more thoroughly
     • Providing deeper analysis and context
     • Using supporting documents if available
   - Preserve: ALL original content, paragraphs, and structure
   - DO NOT: Remove any original paragraphs or content
   - DO NOT: Invent facts or contradict existing content
   - Validation: Count every single word - must be exactly {word_limit}, not {int(word_limit)-1}, not {int(word_limit)+1}"""
    
    def _build_expansion_guidelines(self) -> str:
        """Build comprehensive expansion guidelines for author material"""
        return """
EXPANSION PRINCIPLES & GUIDELINES:

PRIMARY OBJECTIVE:
Expand existing author material with new quantitative and qualitative support to strengthen existing objectives, arguments, and perspectives.

CORE REQUIREMENTS:

1. PRESERVE AUTHOR'S VOICE & INTENT:
   - Maintain the author's original tone, style, and voice throughout
   - Do NOT change the fundamental perspective or viewpoint
   - Do NOT rewrite sentences for stylistic preferences
   - Ensure all additions align with author's established arguments

2. STRUCTURAL INTEGRITY (NON-NEGOTIABLE):
   - Do NOT fundamentally change or reorganize the original structure
   - Keep ALL original paragraphs in their exact order
   - Do NOT move paragraphs, sections, or content blocks
   - Do NOT merge or split existing paragraphs unless adding substantial context
   - Maintain the logical flow and progression of ideas as authored

3. SENTENCE & CONTENT EXPANSION STRATEGY:
   - Do NOT arbitrarily increase existing sentence length
   - Only extend sentences if adding new sources, examples, evidence, or support
   - Create new sentences/paragraphs to support and strengthen existing points
   - Add supporting details, examples, and evidence between existing content
   - Use natural spacing to integrate new material seamlessly

4. RESEARCH & DATA INTEGRATION (MANDATORY):
   - Conduct research on the topic to find supporting evidence
   - Incorporate at least 2-3 new sources or cite data points
   - If insufficient valid sources exist, explicitly note: "No additional valid sources found for [specific claim]"
   - Ensure all sources are credible, relevant, and properly contextualized
   - Prioritize quantitative data, case studies, and industry benchmarks
   - Include real-world examples that illustrate author's existing arguments

5. SUPPORTING EVIDENCE STRATEGY:
   - Add data points that validate and strengthen existing claims
   - Include real-world examples that demonstrate author's perspectives
   - Provide statistical support or case study evidence where applicable
   - Use quotes from authoritative sources sparingly and strategically
   - Ensure evidence directly supports the paragraph's main point

6. CONTENT SECTION RECOMMENDATIONS:
   - Analyze if new arguments or content sections would strengthen author's original intent
   - Suggest (in a separate "Recommendations" section) any missing content areas
   - Include suggestions for new arguments that naturally extend the author's thesis
   - Note where additional depth or coverage would benefit the original intent
   - Only recommend additions that align with author's established perspective
   - Do NOT recommend contradictory viewpoints or alternative frameworks

7. TONE & STYLE CONSISTENCY:
   - Match sentence structure patterns from the original text
   - Use similar vocabulary and terminology as the author
   - Maintain formality level and professional standard throughout
   - Keep paragraph length and density consistent with original

OUTPUT FORMAT EXPECTATIONS:
- Expanded content maintaining ALL original structure
- New data points, sources, and examples naturally embedded
- Author's original arguments strengthened with supporting evidence
- (Optional) "Expansion Recommendations" section if new sections would strengthen original intent
"""
    
    def _build_validation_checklist(self, services: dict[str, Any], active_count: int) -> str:
        """Build validation checklist based on active services"""
        items = []
        if services['compress']:
            items.append(f"✓ Word count = EXACTLY {services['compress']} words (verify by counting)")
        if services['expand']:
            items.append(f"✓ Word count = EXACTLY {services['expand']} words (verify by counting)")
        if services['tone']:
            items.append(f"✓ Every sentence uses '{services['tone']}' tone consistently")
        if active_count > 1:
            items.append(f"✓ All {active_count} services applied simultaneously")
        return "\n".join(items)
    
    def _build_tone_instructions(self, tone: str) -> str:
        """Build detailed tone adjustment instructions"""
        tone_instruction = self._build_tone_critical_points(tone)
        return f"""2. TONE (SECOND PRIORITY):
   - Style: '{tone}' tone throughout entire content
   - Requirements:
{tone_instruction}
   - Apply: Every sentence must reflect '{tone}' tone
   - Maintain: Original meaning and key points while changing expression"""
    
    def _build_multi_service_prompt(self, title: str, services: dict[str, Any], active_count: int, has_supporting: bool, current_word_count: int = 0) -> tuple[str, str]:
        """Build system and user prompts for multiple services"""
        detailed_instructions = []
        task_list = []
        
        if services['compress']:
            task_list.append(f"compress to exactly {services['compress']} words")
            detailed_instructions.append(self._build_compression_instructions(services['compress'], current_word_count))
        
        if services['expand']:
            task_list.append(f"expand to exactly {services['expand']} words")
            detailed_instructions.append(self._build_expansion_instructions(services['expand'], current_word_count))
        
        if services['tone']:
            task_list.append(f"adjust tone to: {services['tone']}")
            detailed_instructions.append(self._build_tone_instructions(services['tone']))
        
        if services['research']:
            task_list.append("add research insights and data")
            detailed_instructions.append("3. RESEARCH: Add relevant research insights, data points, and evidence-based information")
        
        if services['edit']:
            task_list.append("apply professional editing")
            detailed_instructions.append("4. EDIT: Apply professional editing for grammar, clarity, and flow")
        
        if services['suggestions']:
            task_list.append("include improvement suggestions")
            detailed_instructions.append("5. SUGGESTIONS: Provide strategic feedback using PwC Brand & Content framework in a separate section")
        
        tasks_description = " AND ".join(task_list)
        detailed_text = "\n\n".join(detailed_instructions)
        
        # Build validation checklist
        validation_checklist = self._build_validation_checklist(services, active_count)
        
        suggestions_format = ""
        suggestions_framework = ""
        if services['suggestions']:
            suggestions_format = "\n\n## Suggestions for Improvement\n\n[Strategic feedback using PwC framework]"
            suggestions_framework = f"\n\nSUGGESTIONS FRAMEWORK:\n{self._get_suggestions_prompt_template()}"
        
        system_prompt = f"""You are a PwC content refinement expert.
{'MANDATORY: A supporting document is provided. You MUST explicitly incorporate concepts, terminology, or insights from the SUPPORTING DOCUMENT into the final content.' if has_supporting else ''}

TASK: Apply {active_count} services SIMULTANEOUSLY: {tasks_description}

SERVICE PRIORITY ORDER:
1. Word Count (if requested) - STRICTEST requirement
2. Tone (if requested) - Must be consistent throughout
3. Other services (research, edit, suggestions)

DETAILED INSTRUCTIONS:
{detailed_text}

STRUCTURE PRESERVATION (NON-NEGOTIABLE):
- Keep ALL original paragraphs in their exact order
- The number of paragraphs in output MUST match input
- No paragraph may be removed, merged, or skipped
- Conclusions and final sections MUST be retained
- Compress/Expand by improving efficiency WITHIN paragraphs

OUTPUT FORMAT:
**{title}**

[Refined content - all services applied together]{suggestions_format}
{suggestions_framework}

VALIDATION CHECKLIST (Verify before submitting):
{validation_checklist}

CRITICAL REMINDERS:
- Apply ALL {active_count} services in ONE unified output
- Do NOT create separate sections for each service (except suggestions)
- Every sentence must satisfy ALL requirements simultaneously
- Word count is the PRIMARY constraint - tone and other services must work within this limit"""
        
        return system_prompt, detailed_text
    
    def _build_compression_prompt(self, word_limit: str, title: str) -> str:
        """Build system prompt for compression only"""
        return f"""You are a PwC content compression expert.

TASK: Compress content to EXACTLY {word_limit} words.

METHOD:
- Tighten sentences within each paragraph
- Remove redundancy, filler words, and unnecessary adjectives
- Use more concise phrasing and stronger verbs
- Keep ALL paragraphs and structure intact
- Maintain original meaning, tone, and key points

STRUCTURE RULES:
- Preserve ALL paragraphs in their original order
- Do NOT delete, merge, or skip any paragraphs
- Do NOT remove conclusions or final sections
- Compress by improving efficiency WITHIN each paragraph

VALIDATION (CRITICAL):
- Count every single word in your output
- Final count MUST be EXACTLY {word_limit} words
- Not {int(word_limit)-1} words
- Not {int(word_limit)+1} words
- But EXACTLY {word_limit} words

OUTPUT FORMAT:
**{title}**

[Compressed content - exactly {word_limit} words]"""
    
    def _build_expansion_prompt(self, word_limit: str, title: str, current_count: int, has_supporting: bool = False) -> str:
        """Build system prompt for expansion only"""
        supporting_instruction = ""
        if has_supporting:
            supporting_instruction = """
SUPPORTING DOCUMENTS AVAILABLE:
- You have access to supporting materials (marked as SUPPORTING DOCUMENT)
- Use supporting documents to add relevant information and context
- Extract insights, examples, and data that strengthen the main content
- Seamlessly integrate supporting content without contradicting the primary document"""
        
        return f"""You are a PwC content expansion expert specializing in author-centric material enhancement.

TASK: Expand content to EXACTLY {word_limit} words while strengthening author's arguments with research-backed evidence.

CURRENT STATUS:
- Current Word Count: {current_count} words
- Target Word Count: {word_limit} words
- Expansion Needed: {int(word_limit) - current_count} words
{supporting_instruction}

{self._build_expansion_guidelines()}

DETAILED EXPANSION STRATEGY:

1. ANALYZE EXISTING CONTENT:
   - Identify author's main arguments and perspectives
   - Map existing claims that need quantitative/qualitative support
   - Note areas where additional evidence would strengthen arguments
   - Understand author's tone, style, and structural approach

2. RESEARCH & EVIDENCE GATHERING:
   - Conduct research to find supporting data, case studies, examples
   - Target: Find and incorporate at least 2-3 new sources/data points
   - Prioritize recent, credible, industry-relevant evidence
   - If sources are limited, explicitly note any gaps with: "No additional valid sources found for [claim]"

3. STRATEGIC EXPANSION:
   - Add quantitative data (statistics, benchmarks, metrics) supporting existing arguments
   - Include qualitative support (expert perspectives, case studies, real-world examples)
   - Insert supporting evidence between relevant paragraphs or within them
   - Create new paragraphs for substantial supporting evidence/examples
   - Maintain natural flow and logical progression

4. CONTENT RECOMMENDATIONS:
   - At the end (marked as "EXPANSION RECOMMENDATIONS:"), suggest:
     • New arguments that would strengthen author's original intent
     • Additional content sections that naturally fit the author's thesis
     • Missing perspectives or coverage areas aligned with author's viewpoint
   - Format: Bulleted list with brief explanations
   - Do NOT recommend contradictory frameworks or alternative viewpoints

VALIDATION CHECKLIST:
✓ Word count = EXACTLY {word_limit} words (verify by counting)
✓ Author's original tone and voice maintained throughout
✓ ALL original paragraphs preserved in original order
✓ No fundamental restructuring of original content
✓ At least 2-3 new sources or data points incorporated
✓ New evidence directly supports existing arguments
✓ Sentences expanded only when adding substance/evidence
✓ Real-world examples included where applicable
✓ Expansion Recommendations section included (if applicable)

OUTPUT FORMAT:
**{title}**

[Expanded content - exactly {word_limit} words, maintaining author's structure and voice]

---

EXPANSION RECOMMENDATIONS:
[List of suggested new arguments/sections that would strengthen original intent (if any)]"""
    
    def _build_tone_prompt(self, tone: str, title: str, word_limit: int | None = None) -> str:
        """Build system prompt for tone adjustment only"""
        tone_instruction = self._get_tone_instruction(tone)
        length_constraint = f"\n- Target length: {word_limit} words (±10% acceptable)" if word_limit else ""
        
        return f"""You are a PwC tone adjustment expert.

TASK: Rewrite content in '{tone}' tone.

TONE REQUIREMENTS:
{tone_instruction}

CONSTRAINTS:
- Preserve original structure and paragraph count
- Keep ALL paragraphs in their original order
- Keep original meaning and key points{length_constraint}
- Only change HOW things are said, not WHAT is said

METHOD:
- Adjust vocabulary to match tone
- Modify sentence structure for tone
- Change formality level as needed
- Maintain consistent tone from first word to last

OUTPUT FORMAT:
**{title}**

[Content in {tone} tone - preserve structure and meaning]"""
    
    def _build_suggestions_prompt(self, content: str) -> str:
        """Build system prompt for suggestions only"""
        # Extract actual content if marked
        content_match = self._PATTERNS['content_to_refine'].search(content)
        actual_content = content_match.group(1).strip() if content_match else content
        
        return f"""ROLE: Senior PwC Brand & Content Strategist and Executive Editor

TASK: Analyze content and provide strategic feedback (NOT rewrite)

{self._get_suggestions_prompt_template().format(content=actual_content)}"""
    
    def _build_generic_prompt(self, title: str) -> str:
        """Build system prompt for generic refinement"""
        return f"""You are a PwC content optimization expert.

TASK: Refine the content according to the provided instructions.

GUIDELINES:
- Preserve original structure and paragraph order
- Maintain key points and meaning
- Apply professional editing standards
- Ensure clarity and readability

OUTPUT FORMAT:
**{title}**

[Refined content]"""
    
    async def refine_content(self, content: str) -> None:
        """Refine content for quality and impact"""
        
        # Detect and extract services
        services = self._detect_services(content)
        docs = self._parse_document_structure(content)
        
        # Calculate word counts
        current_word_count = self._count_actual_words(content)
        
        # Determine if expand or compress based on word counts
        if services.get('requested_word_limit'):
            requested = services['requested_word_limit']
            if requested > current_word_count:
                services['is_expand'] = True
                services['expand'] = str(requested)
                services['compress'] = None  # Clear compress if it's expand
                logger.info(f"[Refine Content] Operation Type: EXPAND (from {current_word_count} to {requested} words)")
            else:
                services['is_expand'] = False
                logger.info(f"[Refine Content] Operation Type: COMPRESS (from {current_word_count} to {requested} words)")
        
        title = self._generate_title(services)
        
        logger.info(f"[Refine Content] Generated title: {title}")
        logger.info(f"[Refine Content] Services detected: {services}")
        logger.info(f"[Refine Content] Total Word Count: {current_word_count}")
        
        logger.info(
            f"[Refine Content] Parsed documents | "
            f"Primary={'YES' if docs['primary'] else 'NO'}, "
            f"Secondary={'YES' if docs['secondary'] else 'NO'}"
        )
        
        # Prepare content for LLM
        llm_input_content = content
        
        # Handle expansion with supporting documents
        if services.get('is_expand') and docs['has_supporting']:
            requested = services['requested_word_limit']
            llm_input_content = f"""
PRIMARY DOCUMENT (BASE CONTENT):
{docs['primary']}

SUPPORTING DOCUMENT (FOR EXPANSION ONLY):
{docs['secondary']}

INSTRUCTION:
Use the supporting document ONLY to add new substance where needed.
Do NOT invent facts.
Do NOT contradict the primary document.
""".strip()
            logger.info(
                f"[Refine Content] Expansion with supporting documents. "
                f"Original={current_word_count}, Requested={requested}. "
                f"Using merged documents."
            )
        
        # Count active services
        active_services_count = self._get_active_service_count(services)
        
        # Build prompts based on service combination
        if active_services_count > 1:
            system_prompt, _ = self._build_multi_service_prompt(
                title, services, active_services_count, docs['has_supporting'], current_word_count
            )
            
            # Build user prompt for multiple services
            task_list = []
            if services['compress']:
                task_list.append(f"✓ compress to exactly {services['compress']} words")
            if services['expand']:
                task_list.append(f"✓ expand to exactly {services['expand']} words")
            if services['tone']:
                task_list.append(f"✓ adjust tone to: {services['tone']}")
            if services['research']:
                task_list.append("✓ add research insights and data")
            if services['edit']:
                task_list.append("✓ apply professional editing")
            if services['suggestions']:
                task_list.append("✓ include improvement suggestions")
            
            tasks_list_text = "\n".join(task_list)
            
            reminders = []
            if services['compress']:
                reminders.append(f"- WORD COUNT: Final content MUST be EXACTLY {services['compress']} words")
            if services['expand']:
                reminders.append(f"- WORD COUNT: Final content MUST be EXACTLY {services['expand']} words")
            if services['tone']:
                reminders.append(f"- TONE: Every sentence MUST use '{services['tone']}' tone consistently")
            if active_services_count > 1:
                reminders.append(f"- COMBINATION: All {active_services_count} services must be applied simultaneously")
            
            reminders_text = "\n".join(reminders)
            
            user_prompt = f"""Apply these {active_services_count} services TOGETHER in ONE output:

{tasks_list_text}

PRIORITY REQUIREMENTS:
{reminders_text}

Content to refine:
{llm_input_content}

REMEMBER:
- Combine ALL services together in a single unified output
- Do NOT apply them separately or in sequence
- Every sentence must satisfy ALL requirements
- Word count takes priority, then tone, then other services"""
        
        elif services['suggestions']:
            system_prompt = self._build_suggestions_prompt(content)
            user_prompt = "Please analyze the content provided and provide strategic feedback using the PwC framework."
        
        elif services['expand']:
            system_prompt = self._build_expansion_prompt(services['expand'], title, current_word_count, docs['has_supporting'])
            user_prompt = llm_input_content
        
        elif services['compress']:
            system_prompt = self._build_compression_prompt(services['compress'], title)
            user_prompt = llm_input_content
        
        elif services['tone']:
            system_prompt = self._build_tone_prompt(services['tone'], title, current_word_count)
            user_prompt = llm_input_content
        
        else:
            system_prompt = self._build_generic_prompt(title)
            user_prompt = llm_input_content
        
        # Build messages for LLM
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            logger.info(f"[Refine Content] Active services: {active_services_count}")
            logger.info(f"[Refine Content] Title: {title}")
            
            if active_services_count > 1:
                task_descriptions = []
                if services['compress']:
                    task_descriptions.append(f"compress to {services['compress']} words")
                if services['expand']:
                    task_descriptions.append(f"expand to {services['expand']} words")
                if services['tone']:
                    task_descriptions.append(f"adjust tone to {services['tone']}")
                if services['research']:
                    task_descriptions.append("add research")
                if services['edit']:
                    task_descriptions.append("edit")
                if services['suggestions']:
                    task_descriptions.append("suggest improvements")
                logger.info(f"[Refine Content] MULTIPLE SERVICES - Combining: {', '.join(task_descriptions)}")
            
            async for chunk in self.stream_response(messages):
                yield chunk
                
        except Exception as e:
            logger.error(f"[Refine Content] Error: {e}", exc_info=True)
            error_message = f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
            yield error_message
    
    async def execute(self, *args, **kwargs):
        """Execute the refine content workflow"""
        return await self.refine_content(*args, **kwargs)

