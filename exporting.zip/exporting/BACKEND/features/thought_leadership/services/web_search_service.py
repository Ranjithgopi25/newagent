"""
Web Search Service for Thought Leadership
Performs web searches and validates URLs for citations in articles
"""
import httpx
import logging
from typing import List, Dict, Optional
from urllib.parse import urlparse, quote_plus
import asyncio
from bs4 import BeautifulSoup
import re
import tavily
import os
from dotenv import load_dotenv
import ssl
import urllib3
from app.core.config import config

# Disable SSL warnings for the workaround
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv(".env", override=True)
logger = logging.getLogger(__name__)


class WebSearchService:
    """Service for performing web searches and validating URLs"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
    
    async def search_topic(self, topic: str, max_results: int = 5, fetch_content: bool = False) -> List[Dict[str, str]]:
        """
        Perform web search for a topic and return validated results
        
        Args:
            topic: The topic to search for
            max_results: Maximum number of results to return
            fetch_content: If True, content is fetched directly from Tavily API (ignored - always included)
            
        Returns:
            List of dictionaries with 'title', 'url', 'snippet', and 'full_content' keys
        """
        logger.info(f"[WebSearch] Searching for topic: {topic}")
        
        search_results = await self._tavily_search(topic, max_results)
        
        logger.info(f"[WebSearch] Found {len(search_results)} results from Tavily")
        return search_results
    
    async def _tavily_search(self, query: str, max_results: int) -> List[Dict[str, str]]:
        """
        Perform search using Tavily AI search API
        First searches for pwc.com results, then falls back to broader search if needed
        """
        try:
            api_key = config.TAVILY_API_KEY
            if not api_key:
                logger.error("[WebSearch] TAVILY_API_KEY not found in configuration")
                return []
            
            # Create SSL context that doesn't verify certificates
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            # Create Tavily client
            client = tavily.TavilyClient(api_key=api_key)
            
            # Override httpx client with custom SSL context
            client._session = httpx.Client(verify=False)
            
            # First, search specifically for pwc.com results
            logger.info(f"[WebSearch] Tavily search initiated for query: {query} (pwc.com domain only)")
            pwc_query = f"site:pwc.com {query}"
            response = client.search(
                query=pwc_query,
                max_results=max_results * 2,  # Request more to account for filtering
                search_depth="basic",  # Options: "basic" or "advanced"
                include_answer=False,  # We only need search results
                include_raw_content=True  # Include full page content from Tavily
            )
            
            # Process PWC results - pick top 3 regardless of score
            pwc_results = self._process_tavily_results(response.get('results', []), max_results=3, enforce_score_filter=False)
            results = pwc_results
            
            logger.info(f"[WebSearch] Found {len(pwc_results)} PWC results")
            
            # If we need more results, perform fallback search without domain restriction
            if len(results) < max_results:
                remaining_needed = max_results - len(results)
                logger.info(f"[WebSearch] Need {remaining_needed} more results, performing fallback search for all domains")
                fallback_response = client.search(
                    query=query,
                    max_results=max_results * 2,
                    search_depth="basic",
                    include_answer=False,
                    include_raw_content=True
                )
                fallback_results = self._process_tavily_results(fallback_response.get('results', []), max_results=remaining_needed, enforce_score_filter=True)
                
                # Append fallback results
                results.extend(fallback_results)
                logger.info(f"[WebSearch] Added {len(fallback_results)} results from fallback search")
            
            logger.info(f"[WebSearch] Tavily returned {len(results)} total results")
            return results
        
        except Exception as e:
            logger.error(f"[WebSearch] Tavily search failed: {e}")
            return []
    
    def _process_tavily_results(self, raw_results: List[Dict], max_results: int, enforce_score_filter: bool = True) -> List[Dict[str, str]]:
        """
        Process and filter Tavily search results
        
        Args:
            raw_results: Raw results from Tavily API
            max_results: Maximum number of results to return
            enforce_score_filter: If True, filter by score >= 0.7. If False, pick top results regardless of score
            
        Returns:
            Processed and filtered results
        """
        results = []
        
        for result in raw_results:
            try:
                title = result.get('title', '')
                url = result.get('url', '')
                snippet = result.get('content', '')
                score = result.get('score', 0)  # Get relevance score from Tavily
                raw_content = result.get('raw_content', '')  # Get raw content from Tavily
                
                # Skip results with low relevance score (< 0.7) if enforcing score filter
                if enforce_score_filter and score < 0.7:
                    logger.info(f"[WebSearch] Filtered: Low score ({score:.2f}): {title} | URL: {url}")
                    continue
                
                if not title or not url:
                    continue
                
                if self._is_competitor_site(url):
                    logger.debug(f"[WebSearch] Filtered competitor site: {url}")
                    continue
                
                # Limit content length to avoid token overflow
                if len(raw_content) > 2000:
                    raw_content = raw_content[:2000] + "..."
                
                results.append({
                    'title': title,
                    'url': url,
                    'snippet': snippet,
                    'full_content': raw_content,  # Content from Tavily API
                    'score': score  # Include score for reference
                })
                
                logger.info(f"[WebSearch] Added result (score: {score:.2f}): {title} | URL: {url}")
                
                if len(results) >= max_results:
                    break
            
            except Exception as e:
                logger.warning(f"[WebSearch] Error parsing Tavily result: {e}")
                continue
        
        return results
    
    def _is_competitor_site(self, url: str) -> bool:
        """
        Check if URL is from a competitor site (Deloitte, McKinsey, EY, KPMG, BCG)
        
        Args:
            url: URL to check
            
        Returns:
            True if URL is from a competitor, False otherwise
        """
        competitor_domains = [
            'deloitte.com',
            'mckinsey.com',
            'ey.com',
            'kpmg.com',
            'bcg.com'
        ]
        
        try:
            parsed = urlparse(url.lower())
            domain = parsed.netloc
            
            # Remove 'www.' prefix if present
            if domain.startswith('www.'):
                domain = domain[4:]
            
            return any(comp_domain in domain for comp_domain in competitor_domains)
        
        except Exception:
            return False
    
    def format_citations(self, results: List[Dict[str, str]]) -> str:
        """
        Format search results as citations for inclusion in article
        
        Args:
            results: List of validated search results
            
        Returns:
            Formatted citations string
        """
        if not results:
            return ""
        
        citations = []
        for idx, result in enumerate(results, 1):
            title = result.get('title', '')
            url = result.get('url', '')
            
            # Remove duplicate URL from title if it exists (Tavily sometimes includes it)
            # Pattern: (URL: https://...) or (url: https://...)
            title = re.sub(r'\s*\(URL?:\s*https?://[^\)]+\)\s*$', '', title, flags=re.IGNORECASE)
            
            citation = f"{idx}. {title} (URL: {url})"
            citations.append(citation)
        
        return "\n".join(citations)
    
    async def search_and_format(self, topic: str, max_results: int = 5, fetch_content: bool = False) -> Dict[str, any]:
        """
        Perform search and return both raw results and formatted citations
        
        Args:
            topic: Topic to search for
            max_results: Maximum number of results
            fetch_content: If True, fetch full content from URLs
            
        Returns:
            Dictionary with 'results', 'formatted_citations', 'count', and 'web_content' keys
        """
        results = await self.search_topic(topic, max_results, fetch_content=fetch_content)
        formatted = self.format_citations(results)
        
        logger.info(f"[WebSearch] Formatted {len(results)} citations:")
        for line in formatted.split('\n'):
            if line.strip():
                logger.info(f"[WebSearch] {line}")
        
        # Compile all fetched content into a single string
        web_content = ""
        if fetch_content:
            content_parts = []
            for idx, result in enumerate(results, 1):
                if result.get('full_content'):
                    content_parts.append(f"\n\n=== Source {idx}: {result['title']} ===")
                    content_parts.append(f"URL: {result['url']}")
                    content_parts.append(result['full_content'])
                    logger.info(f"[WebSearch] Source {idx} content compiled: {result['title']} | URL: {result['url']}")
            web_content = "\n".join(content_parts)
            logger.info(f"[WebSearch] Total web content compiled: {len(web_content)} characters")
        
        logger.info(f"[WebSearch] search_and_format completed - {len(results)} results with citations")
        
        return {
            'results': results,
            'formatted_citations': formatted,
            'count': len(results),
            'web_content': web_content
        }
        
    