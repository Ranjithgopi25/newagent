from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging

logger = logging.getLogger(__name__)

class UpdateSectionService(BaseTLStreamingService):
    """Service for Canvas Update Section functionality"""
    
    async def update_section(
        self, 
        full_article: str, 
        section_content: str, 
        user_prompt: str, 
        content_type: str
    ):
        """Update a specific section based on user instructions"""
        system_prompt = """You are a PwC content editor specializing in section-level refinement.

Your task is to revise a specific section of a larger article based on user instructions while maintaining:
- Consistency with the overall article tone and style
- Professional PwC standards and branding
- Coherent flow and transitions
- Factual accuracy and clarity

Respond ONLY with the revised section content, not the entire article."""
        
        user_message = f"""Content Type: {content_type}

User's Instructions for this section:
{user_prompt}

Current Section Content:
{section_content}

Full Article Context (for reference):
{full_article}

Please revise the section according to the user's instructions. Return ONLY the updated section content."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk
    
    async def execute(self, *args, **kwargs):
        return await self.update_section(*args, **kwargs)
