from app.infrastructure.llm.base_services import BaseTLStreamingService
from typing import AsyncGenerator, Optional, List, Dict
import logging

logger = logging.getLogger(__name__)

class DraftArticleService(BaseTLStreamingService):
    """Service for draft article with supporting materials"""
    
    async def draft_article(
        self, 
        topic: str, 
        format_type: str, 
        audience: str, 
        context: str,
        outline: Optional[str] = None,
        supporting_docs: Optional[List[Dict]] = None
    ) -> AsyncGenerator[str, None]:
        """Draft article with outline and supporting documents"""
        
        system_prompt = self._get_draft_article_system_prompt(format_type, audience)
        
        user_message = f"Create a {format_type} about: {topic}\nTarget Audience: {audience}"
        
        if context:
            user_message += f"\n\nAdditional Context: {context}"
        
        if outline:
            user_message += f"\n\nFollow this outline:\n{outline}"
        
        if supporting_docs:
            user_message += "\n\nSupporting Documents:"
            for doc in supporting_docs:
                user_message += f"\n\n{doc['filename']}:\n{doc['content'][:3000]}"
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        
        async for chunk in self.stream_response(messages):
            yield chunk
    
    def _get_draft_article_system_prompt(self, format_type: str, audience: str) -> str:
        """Get system prompt for article drafting"""
        return f"""You are an expert content writer for PwC thought leadership.

Create a comprehensive, in-depth {format_type} for {audience}.

Content Length Targets:
- Article/White Paper: 3000-5000 words with thorough analysis and multiple perspectives
- Blog Post: 1500-2500 words with detailed insights and practical examples
- Executive Brief: 1000-1500 words with strategic depth
- Unless specified otherwise, provide comprehensive coverage of the topic

Writing Excellence:
- Professional PwC tone with authoritative, evidence-backed insights
- Clear, logical structure with compelling narrative flow throughout
- Include and explain relevant PwC frameworks and methodologies in detail
- Provide actionable recommendations with implementation steps and expected outcomes
- Use multiple data points, statistics, examples, and case studies to support every major argument
- Incorporate industry-specific terminology and demonstrate deep sector knowledge
- Develop each section thoroughly - avoid surface-level treatment

Comprehensive Structure by Format:
- Article: Strong hook → Detailed context and background → Multi-faceted analysis with evidence → Comprehensive recommendations with rationale → Impactful conclusion (3000-5000 words)
- Blog: Engaging opening with clear value proposition → 4-6 key points each with examples → Multiple real-world applications → Strong actionable CTA (1500-2500 words)
- White Paper: Executive summary → Problem statement with data → Comprehensive solution framework → 3-4 detailed case studies → Strategic recommendations with roadmap (3000-5000 words)
- Executive Brief: Context-rich key insights → Multi-layered strategic implications → Prioritized action items with rationale and timelines (1000-1500 words)

Quality Standards:
- Include proper headings, subheadings, and smooth transitions between sections
- Maintain credibility through citations and evidence while remaining accessible
- Provide depth and nuance - thought leadership requires substantive content
- Cover multiple angles and consider counterarguments where relevant

Remember: If outline or supporting documents are provided, integrate them thoroughly and expand on them with additional insights."""
    
    async def execute(self, *args, **kwargs):
        """Execute draft article generation"""
        return await self.draft_article(*args, **kwargs)
