from pydantic import BaseModel, Field
from typing import Optional, List

class TLWorkflowRequest(BaseModel):
    """Base request for TL workflow operations"""
    pass

class ContentRequest(BaseModel):
    """Request for content generation workflows"""
    topic: str = Field(..., description="Content topic")
    format: str = Field(..., description="Content format")
    context: Optional[str] = Field(None, description="Additional context")

class ResearchRequest(BaseModel):
    """Request for research workflows"""
    query: str = Field(..., description="Research query")
    sources: Optional[List[str]] = Field(None, description="Source URLs or documents")

class EditRequest(BaseModel):
    """Request for editing workflows"""
    content: str = Field(..., description="Content to edit")
    edit_type: str = Field(..., description="Type of edit")
    guidelines: Optional[str] = Field(None, description="Editing guidelines")

class TLResponse(BaseModel):
    """Base response for TL workflow operations"""
    success: bool
    message: str
    data: Optional[dict] = None
