"""Utilities for thought leadership features"""
