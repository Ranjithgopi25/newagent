from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.refine_content_service import RefineContentService
from app.features.thought_leadership.schemas.refine_content import RefineContentRequest
from app.core.deps import get_tl_service
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def refine_content_workflow(
    request: RefineContentRequest,
    service: RefineContentService = Depends(get_tl_service(RefineContentService))
):
    """Refine Content workflow with JSON-based service configuration
    
    Supports: Expand/Compress, Tone Adjustment, Research Enhancement (PWC-first strategy),
    Edit Content, and Improvement Suggestions
    
    Request format:
    {
        "original_content": "content to refine",
        "messages": [...],  // optional, for compatibility
        "services": [
            {
                "isSelected": true,
                "type": "expand",
                "original_word_count": 1649,
                "expected_word_count": 3330,
                "supportingDoc": "supporting content"
            },
            ...
        ],
        "stream": true
    }
    """
    try:
        # Validate original content
        original_content = request.original_content
        if not original_content or not original_content.strip():
            raise HTTPException(status_code=400, detail="Original content is required")
        
        # Validate services array
        if not request.services:
            logger.warning("[Refine Content] No services selected in request")
        
        # Check if at least one service is selected
        selected_services = [s for s in request.services if s.get('isSelected', False)]
        if not selected_services:
            raise HTTPException(status_code=400, detail="At least one service must be selected")
        
        logger.info(f"[Refine Content] Processing request: {len(selected_services)} services selected")
        logger.info(f"[Refine Content] Content length: {len(original_content)} characters")
        
        # Convert request to dict for service
        request_data = request.model_dump()
        
        return StreamingResponse(
            service.refine_content(request_data),
            media_type="text/event-stream"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Refine Content] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred while refining content")
