from fastapi import APIRouter, Form, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from app.features.thought_leadership.services.draft_article_service import DraftArticleService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.core.deps import get_tl_service
from typing import Optional, List
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("")
async def draft_article_workflow(
    topic: str = Form(...),
    format_type: str = Form(...),
    audience: str = Form(""),
    context: str = Form(""),
    outline: Optional[UploadFile] = File(None),
    supporting_docs: Optional[List[UploadFile]] = File(None),
    service: DraftArticleService = Depends(get_tl_service(DraftArticleService))
):
    """Draft Article workflow: Create articles with outline and supporting documents"""
    try:
        logger.info(f"[Draft Article] Topic: {topic}, Format: {format_type}")
        
        # Apply audience defaults if not provided by user
        audience = apply_audience_tone_defaults(format_type, audience)
        
        outline_content = None
        if outline:
            content = await outline.read()
            outline_content = content.decode('utf-8', errors='ignore')
        
        docs_content = None
        if supporting_docs:
            docs_content = []
            for doc in supporting_docs:
                content = await doc.read()
                docs_content.append({
                    'filename': doc.filename,
                    'content': content.decode('utf-8', errors='ignore')
                })
        
        return StreamingResponse(
            service.draft_article(topic, format_type, audience, context, outline_content, docs_content),
            media_type="text/event-stream"
        )
    except Exception as e:
        logger.error(f"[Draft Article] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
