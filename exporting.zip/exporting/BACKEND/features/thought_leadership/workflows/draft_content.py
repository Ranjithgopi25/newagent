from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.draft_content_service import DraftContentService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.deps import get_tl_service, get_factiva_client, get_settings, get_llm_service
from app.common.factiva_client import FactivaClient
from app.core.config import Settings, config
from app.infrastructure.llm.llm_service import LLMService
import logging
import re
import json

router = APIRouter()
logger = logging.getLogger(__name__)

class DraftContentRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    improvement_prompt: Optional[str] = None  
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[str] = None
    audience_tone: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    use_factiva_research: Optional[bool] = None
    #additional_guidelines: Optional[str] = None


class SatisfactionAnalysisRequest(BaseModel):
    """Request to analyze user satisfaction with generated content"""
    user_input: str
    generated_content: str
    content_type: str
    topic: str


class SatisfactionAnalysisResponse(BaseModel):
    """Response from satisfaction analysis"""
    is_satisfied: bool
    confidence: float  # 0.0 to 1.0
    reasoning: str
    improvement_suggestions: Optional[str] = None


def extract_research_info(content: str) -> dict:
    """Extract research-related information from content."""
    research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)
    research_topics = re.search(r'Research Topics:\s*(.+?)(?:\n|$)', content)
    research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
    additional_guidelines = re.search(r'Additional Guidelines:\s*(.+?)(?:\n|$)', content)
    
    return {
        'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False,
        'topics': research_topics.group(1).strip() if research_topics else None,
        'sources': research_sources.group(1).strip() if research_sources else None,
        'additional_guidelines': additional_guidelines.group(1).strip() if additional_guidelines else None
    }

def should_use_langgraph_agent(sources: str) -> bool:
    """Check if LangGraph agent should be called"""
    if not sources:
        return False
    
    # Triggers for LangGraph agent with multi-source integration
    triggers = [
        'PwC Content or Link', 
        'PwC Proprietary Research', 
        'PwC Licensed Third Party Tools', 
        'External Research',
        'CapIQ',
        'BoardEx',
        'Financial Data',
        'Corporate Data',
        'Director Data',
        'Advisor Data',
        'Factiva',
        'News',
        'Market Data'
    ]
    
    return any(trigger.lower() in sources.lower() for trigger in triggers)

def should_use_sql_agent(sources: str) -> bool:
    """Check if SQL agent should be called"""
    return sources and 'PwC Licensed Third Party Tools' in sources

def is_improvement_request(improvement_prompt: Optional[str]) -> bool:
    """Check if this is an improvement request"""
    return improvement_prompt is not None and improvement_prompt.strip()

def build_improvement_prompt(original_prompt: str, improvement_feedback: str, original_content: str) -> str:
    """Build enhanced prompt with improvement feedback"""
    improvement_message = f"""This is an improvement iteration. The user has provided specific improvement instructions along with previously generated content. Please apply ONLY the requested improvements while regenerating the entire content.

User Improvement Request:
{improvement_feedback}

Original Generated Content:
{original_content}

Please regenerate the content with the following approach:
1. Read the user's improvement request carefully
2. Preserve the overall structure and length expectations
3. Apply the requested improvements throughout
4. Maintain consistency with the original topic and audience
5. Ensure the improved content flows naturally

{original_prompt}"""
    return improvement_message

@router.post("")
async def draft_content_workflow(
    request: DraftContentRequest,
    service: DraftContentService = Depends(get_tl_service(DraftContentService)),
    factiva_client: Optional[FactivaClient] = Depends(get_factiva_client),
    settings: Settings = Depends(get_settings)
):
    """Draft Content workflow: Create articles, blogs, white papers, executive briefs"""
    try:
        user_prompt = ""
        if request.messages:
            user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[Draft Content] User prompt length: {len(user_prompt)}")
        #logger.info(f"[Draft Content] Full user prompt: {user_prompt}")
        logger.debug(f"[Draft Content] Full user prompt:\n{user_prompt}")

        # Check if this is an improvement request
        is_improvement = is_improvement_request(request.improvement_prompt)
        if is_improvement:
            logger.info(f"[Draft Content] Improvement request detected")
            logger.info(f"[Draft Content] Improvement feedback: {request.improvement_prompt}")
        
        # Initialize variables
        content_type = ''
        topic = ''
        word_limit = ''
        audience = ''
        supporting_doc = ''
        outline_doc = ''
        #use_factiva_research = False
        #additional_guidelines = ''
        original_generated_content = ""
        
        # Check if this is an improvement request
        is_improvement = is_improvement_request(request.improvement_prompt)
        if is_improvement:
            logger.info(f"[Draft Content] Improvement request detected")
            logger.info(f"[Draft Content] Improvement feedback: {request.improvement_prompt}")
        
        # For improvement iterations, use provided parameters; otherwise parse from prompt
        if is_improvement and request.content_type:
            logger.info(f"[Draft Content] Using preserved parameters for improvement iteration")
            content_type = request.content_type
            topic = request.topic or ''
            word_limit = request.word_limit or ''
            audience = request.audience_tone or ''
            outline_doc = request.outline_doc or ''
            supporting_doc = request.supporting_doc or ''
            #additional_guidelines = request.additional_guidelines or ''
            #use_factiva_research = request.use_factiva_research or False
            
            logger.info(f"[Draft Content] Improvement iteration params - content_type='{content_type}', topic='{topic}', word_limit='{word_limit}', audience='{audience}'")
        else:
            # Parse user prompt for initial draft
            for line in user_prompt.splitlines():
                logger.debug(f"[PARSE] Processing line: {repr(line[:80])}")
                if line.startswith("Content Type:"):
                    content_type = line.split(":", 1)[1].strip()
                if line.startswith("Topic:"):
                    topic = line.split(":", 1)[1].strip()
                if line.startswith("Word Limit:"):
                    word_limit = line.split(":",1)[1].strip()
                if line.startswith("Audience/Tone:"):
                    audience = line.split(":",1)[1].strip()
                if line.startswith("Initial Outline/Concept:"):
                    outline_doc = line.split(":",1)[1].strip()
                if line.startswith("Supporting Documents:"):
                    supporting_doc = line.split(":",1)[1].strip()
                if line.startswith("Additional Guidelines:"):
                    additional_guidelines = line.split(":",1)[1].strip()
                # if line.startswith("Use Factiva Research:"):
                #     use_factiva_research_str = line.split(":", 1)[1].strip().lower()
                #     logger.info(f"[PARSE] Found 'Use Factiva Research:' with value: '{use_factiva_research_str}'")
                #     use_factiva_research = use_factiva_research_str in ["true", "yes", "1"]
            
            logger.info(f"[PARSE] Parsed values - Content Type: '{content_type}', Topic: '{topic}', Word Limit: '{word_limit}', Audience: '{audience}'")
        
        # Fetch Factiva sources if requested
        # factiva_sources = []
        # if use_factiva_research:
        #     logger.info(f"[FACTIVA WORKFLOW] User requested Factiva Research: TRUE")
        #     logger.info(f"[FACTIVA WORKFLOW] Checking prerequisites - factiva_client={factiva_client is not None}, topic='{topic}'")
        #     if not factiva_client:
        #         logger.warning(f"[FACTIVA WORKFLOW] Factiva requested but client not initialized. Skipping Factiva research.")
        #     elif not topic:
        #         logger.warning(f"[FACTIVA WORKFLOW] Factiva requested but no topic provided. Skipping Factiva research.")
        #     else:
        #         try:
        #             logger.info(f"[FACTIVA WORKFLOW] Initiating Factiva search for topic: '{topic}'")
        #             service.factiva_client = factiva_client
                    
        #             # Use hardcoded limits from config (not from UI)
        #             response_limits = settings.FACTIVA_RESPONSE_LIMITS.copy()
        #             logger.debug(f"[FACTIVA WORKFLOW] Response limits: {response_limits}")
                    
        #             factiva_sources = await service.fetch_factiva_sources(
        #                 query=topic,
        #                 content_type=content_type,
        #                 response_limits=response_limits,
        #                 language_filters=settings.FACTIVA_SEARCH_FILTERS
        #             )
        #             if factiva_sources:
        #                 logger.info(f"[FACTIVA WORKFLOW] SUCCESS: Retrieved {len(factiva_sources)} Factiva sources for content generation")
        #             else:
        #                 logger.warning("[FACTIVA WORKFLOW] No Factiva sources found, continuing with outline/supporting docs only")
        #         except Exception as e:
        #             logger.error(f"[FACTIVA WORKFLOW] ERROR: Factiva research failed: {type(e).__name__}: {str(e)}")
        #             logger.info(f"[FACTIVA WORKFLOW] Full error traceback: {repr(e)}")
        #             logger.warning(f"[FACTIVA WORKFLOW] Continuing without Factiva research")
        #             factiva_sources = []
        # else:
        #     logger.info(f"[FACTIVA WORKFLOW] User did NOT request Factiva Research: FALSE")

        # Extract research information
        research_info = extract_research_info(user_prompt)
        enhanced_user_prompt = user_prompt
        langgraph_context = ""
        
        # Handle Multi-Source LangGraph Agent
        #if should_use_langgraph_agent(research_info['sources']):
        if True:
            try:
                logger.info(f"[Draft Content] Initializing LangGraph Agent for multi-source query")
                
                # Create LangGraph agent instance
                langgraph_agent = create_data_source_agent(
                    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                    api_key=config.AZURE_OPENAI_API_KEY,
                    api_version=config.AZURE_OPENAI_API_VERSION,
                    deployment_name=config.AZURE_OPENAI_DEPLOYMENT
                )
                
                # Build the query message for the agent
                search_query = research_info['topics'] or topic
                additional_guidelines = research_info['additional_guidelines'] or ''
                agent_messages = [
                    {
                        "role": "user",
                        "content": f"Research query: {search_query}\n\nPlease search relevant data sources and provide comprehensive information.Refer {additional_guidelines}"
                    }
                ]
                
                logger.info(f"[Draft Content] Calling LangGraph Agent with query: {search_query}")
                
                # Get response from LangGraph agent
                agent_response = await langgraph_agent.process_query(agent_messages)
                
                if agent_response:
                    logger.info(f"[Draft Content] LangGraph Agent returned {len(agent_response)} characters")
                    langgraph_context = f"""

--- Research Results from Multi-Source Data Integration ---
Sources automatically queried by AI Agent:
- Factiva News (external news and media coverage)
- Internal Knowledge Base (company documents and reports)
- CapitalIQ Financials (income statements and balance sheets)
- BoardEx Intelligence (advisors and executive achievements)

{agent_response}

--- End of Research Results ---
"""
                    logger.info("[Draft Content] LangGraph Agent context added to research")
                else:
                    logger.warning("[Draft Content] LangGraph Agent returned empty response")
                
                # Close agent connections
                langgraph_agent.close()
                
            except Exception as e:
                logger.error(f"[Draft Content] LangGraph Agent error: {e}", exc_info=True)
                # Continue without agent context - don't break the workflow
                logger.warning("[Draft Content] Continuing draft without LangGraph Agent data")

        # Apply default word limits if not provided by user
        word_limit_source = 'user'
        if not word_limit or not word_limit.strip():
            word_limit_source = 'default'
            # Set defaults based on content type (1000 words per page)
            if content_type == 'Article':
                word_limit = '2000'
            elif content_type == 'Blog':
                word_limit = '1500'
            elif content_type == 'Executive Brief':
                word_limit = '500'
            elif content_type == 'White Paper':
                word_limit = '5000'
            else:
                word_limit = '2000'

        # Apply default audience/tone if not provided by user
        audience = apply_audience_tone_defaults(content_type, audience)

        # Convert word_limit to int
        try:
            word_limit_int = int(word_limit)
        except (ValueError, TypeError):
            word_limit_int = 2000
            word_limit_source = 'default-conversion-failed'
            logger.warning(f"[Draft Content] Failed to convert word_limit '{word_limit}' to int, using default 2000")

        logger.info(f"[Draft Content] Analytics - content_type={content_type}, word_limit_source={word_limit_source}, word_limit_value={word_limit_int}")

        if content_type == 'White Paper':
            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for White Paper (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.draft_whitepaper_system_prompt(
                    final_prompt, topic, word_limit_int, audience, outline_doc, supporting_doc
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        if content_type == 'Article':
            # logger.info(f"[CONTENT GENERATION] Article invoked - use_factiva_request={use_factiva_research}, sources_fetched={len(factiva_sources) if factiva_sources else 0}")
            # if use_factiva_research and not factiva_sources:
            #     logger.warning(f"[CONTENT GENERATION] Factiva was requested but NO sources were found. Will proceed without Factiva research.")
            # if factiva_sources:
            #     logger.info(f"[CONTENT GENERATION] Passing {len(factiva_sources)} Factiva sources to Article generator with citation instructions")
            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Article (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.draft_article_system_prompt(
                    final_prompt, topic, word_limit_int, audience, outline_doc, supporting_doc
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        if content_type == 'Blog':
            # logger.info(f"[CONTENT GENERATION] Blog invoked - use_factiva_request={use_factiva_research}, sources_fetched={len(factiva_sources) if factiva_sources else 0}")
            # if use_factiva_research and not factiva_sources:
            #     logger.warning(f"[CONTENT GENERATION] Factiva was requested but NO sources were found. Will proceed without Factiva research.")
            # if factiva_sources:
            #     logger.info(f"[CONTENT GENERATION] Passing {len(factiva_sources)} Factiva sources to Blog generator with citation instructions")
            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Blog (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.draft_blog_system_prompt(
                    final_prompt, topic, word_limit_int, audience, outline_doc, supporting_doc
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        if content_type == 'Executive Brief':
            # logger.info(f"[CONTENT GENERATION] Executive Brief invoked - use_factiva_request={use_factiva_research}, sources_fetched={len(factiva_sources) if factiva_sources else 0}")
            # if use_factiva_research and not factiva_sources:
            #     logger.warning(f"[CONTENT GENERATION] Factiva was requested but NO sources were found. Will proceed without Factiva research.")
            # if factiva_sources:
            #     logger.info(f"[CONTENT GENERATION] Passing {len(factiva_sources)} Factiva sources to Executive Brief generator with citation instructions")
            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for Executive Brief (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.draft_executivebrief_system_prompt(
                    final_prompt, topic, word_limit_int, audience, outline_doc, supporting_doc
                ),
                media_type="text/event-stream",
                headers={"X-Content-Type": content_type}
            )
        else:
            # logger.info(f"[CONTENT GENERATION] Default/Unknown content type invoked - use_factiva_request={use_factiva_research}, sources_fetched={len(factiva_sources) if factiva_sources else 0}")
            # if use_factiva_research and not factiva_sources:
            #     logger.warning(f"[CONTENT GENERATION] Factiva was requested but NO sources were found. Will proceed without Factiva research.")
            # if factiva_sources:
            #     logger.info(f"[CONTENT GENERATION] Passing {len(factiva_sources)} Factiva sources with citation instructions")
            
            # Use improvement prompt if this is an improvement iteration
            final_prompt = enhanced_user_prompt
            if is_improvement and original_generated_content:
                final_prompt = build_improvement_prompt(enhanced_user_prompt, request.improvement_prompt, original_generated_content)
                logger.info(f"[CONTENT GENERATION] Using improvement prompt for default content type (original content: {len(original_generated_content)} chars)")
            
            # Add LangGraph context if available
            if langgraph_context:
                supporting_doc += langgraph_context
            
            return StreamingResponse(
                service.draft_content_from_prompt(final_prompt),
                media_type="text/event-stream"
            )
    except Exception as e:
        logger.error(f"[Draft Content] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/analyze-satisfaction", response_model=SatisfactionAnalysisResponse)
async def analyze_satisfaction(
    request: SatisfactionAnalysisRequest,
    llm_service: LLMService = Depends(get_llm_service)
) -> SatisfactionAnalysisResponse:
    """
    Use LLM to analyze whether user is satisfied with generated content.
    
    This is more robust than keyword matching because the LLM can understand:
    - Nuanced responses like "not bad", "could be better", "okay I guess"
    - Context and sentiment
    - Implicit improvement suggestions
    """
    
    logger.info(f"[Satisfaction Analysis] ✓✓✓ ENDPOINT CALLED ✓✓✓")
    
    prompt = f"""You are analyzing whether a user is satisfied with AI-generated content.

CONTEXT:
- Content Type: {request.content_type}
- Topic: {request.topic}
- Generated Content Preview: {request.generated_content[:500]}...

USER'S RESPONSE: "{request.user_input}"

TASK: Determine if the user is satisfied with the content or if they want improvements.

DECISION RULES (apply in order):

1. EXPLICIT SATISFACTION PHRASES (is_satisfied=true, confidence=0.95):
   - "yes", "yeah", "yep", "looks good", "perfect", "great", "that works", "that's perfect", "love it", "excellent", "exactly what I needed", "approved", "accepted", "ok", "okay", "good job"

2. EXPLICIT IMPROVEMENT/CHANGE REQUESTS (is_satisfied=false, confidence=0.95):
   - Starts with "can you": e.g., "can you make it shorter", "can you concise that article"
   - Contains action verbs: "make it", "make it [adjective]", "add", "remove", "change", "rewrite", "improve", "fix", "shorten", "expand", "simplify"
   - Improvement keywords: "concise", "shorter", "longer", "better", "simpler", "clearer", "more", "less"
   - Explicit negatives: "no", "nope", "don't like", "not happy", "not satisfied"
   - Regeneration requests: "regenerate", "redo", "try again", "different"

3. AMBIGUOUS RESPONSES (analyze context):
   - "okay", "it's fine", "not bad", "could be better", "alright"
   - If contains improvement keywords or action verbs → is_satisfied=false, confidence=0.7
   - If pure acceptance with no action verbs → is_satisfied=true, confidence=0.6

OUTPUT FORMAT (respond ONLY with this JSON, no markdown, no extra text):
{{
    "is_satisfied": true or false,
    "confidence": 0.0-1.0 (float),
    "reasoning": "Brief one-sentence explanation",
    "improvement_suggestions": null or "extracted improvement request"
}}

EXAMPLES:
- Input: "can you concise that article for me" → is_satisfied=false, confidence=0.95, improvement="make it more concise"
- Input: "yes, looks good" → is_satisfied=true, confidence=0.95, improvement=null
- Input: "not bad" → is_satisfied=true, confidence=0.6, improvement=null
- Input: "make it shorter and clearer" → is_satisfied=false, confidence=0.95, improvement="make it shorter and clearer"

Respond ONLY with valid JSON."""

    try:
        response_text = await llm_service.chat_completion(
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert at analyzing user satisfaction with generated content. Respond ONLY with valid JSON, no markdown, no extra text."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3,  # Lower temperature for consistent analysis
            max_tokens=200
        )
        
        logger.info(f"[Satisfaction Analysis] Raw LLM response: {response_text}")
        
        # Parse JSON response
        analysis = json.loads(response_text.strip())
        
        logger.info(f"[Satisfaction Analysis] Parsed JSON: {analysis}")
        logger.info(f"[Satisfaction Analysis] User input: '{request.user_input}'")
        
        return SatisfactionAnalysisResponse(
            is_satisfied=analysis.get("is_satisfied", False),
            confidence=float(analysis.get("confidence", 0.5)),
            reasoning=analysis.get("reasoning", ""),
            improvement_suggestions=analysis.get("improvement_suggestions")
        )
        
    except json.JSONDecodeError as e:
        logger.error(f"[Satisfaction Analysis] JSON Parse Error: {e}")
        logger.error(f"[Satisfaction Analysis] Raw response was: {response_text}")
        # Fallback: treat as not satisfied if we can't parse
        return SatisfactionAnalysisResponse(
            is_satisfied=False,
            confidence=0.3,
            reasoning="Unable to parse analysis, treating as improvement request",
            improvement_suggestions=request.user_input
        )
    except Exception as e:
        logger.error(f"[Satisfaction Analysis] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Satisfaction analysis failed: {str(e)}")