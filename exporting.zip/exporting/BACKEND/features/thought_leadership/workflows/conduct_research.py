from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from app.features.thought_leadership.services.conduct_research_service import ConductResearchService,Source
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.features.chat.schemas import Message
from app.core.deps import get_tl_service, get_settings
from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Dict, Any
import logging
import re
from fastapi import File, UploadFile, Form
import json
import io
from app.common.document_utils import extract_text_from_pdf
from app.common.ppt_utils import extract_text_from_ppt
import pandas as pd
from app.core.config import config
from app.common.supporting_doc_extractor import SupportingDocExtractor

router = APIRouter()
logger = logging.getLogger(__name__)


class ConductResearchRequest(BaseModel):
    messages: List[Dict[str, Any]]
    source_groups: Optional[List[str]] = None
    stream: Optional[bool] = True
    additional_guidelines: Optional[str] = ""
    model_config = ConfigDict(extra="allow")


def extract_research_info_from_content(content: str) -> dict:
    """Extract research topic and sources from content."""
    research_topic = re.search(r'Research Topic:\s*(.+?)(?:\n|$)', content)
    research_sources = re.search(r'Research Sources:\s*(.+?)(?:\n|$)', content)
    
    return {
        'topic': research_topic.group(1).strip() if research_topic else None,
        'sources': research_sources.group(1).strip() if research_sources else None
    }


def should_use_langgraph_agent(sources: str) -> bool:
    """Check if LangGraph agent should be called"""
    if not sources:
        return False
    
    # Triggers for LangGraph agent with multi-source integration
    triggers = [
        'PwC Licensed Third Party Tools',
        'CapIQ',
        'BoardEx',
        'Financial Data',
        'Corporate Data',
        'Director Data',
        'Advisor Data',
        'Factiva',
        'News',
        'Market Data'
    ]
    
    return any(trigger.lower() in sources.lower() for trigger in triggers)


def extract_text_from_excel(file_obj, filename: str) -> str:
    import pandas as pd

    filename = filename.lower()

    if filename.endswith(".xlsx"):
        sheets = pd.read_excel(file_obj, sheet_name=None, engine="openpyxl")

    elif filename.endswith((".xls", ".xlsb")):
        raise ValueError(
            "Unsupported Excel format. Please upload .xlsx files only."
        )

    else:
        raise ValueError("Unsupported Excel format")

    text_chunks = []
    for sheet_name, df in sheets.items():
        text_chunks.append(f"\n=== Sheet: {sheet_name} ===\n")
        text_chunks.append(df.to_csv(index=False))

    return "\n".join(text_chunks)


@router.post("")
async def conduct_research_workflow(
    messages: str = Form(...),
    source_groups: Optional[str] = Form(default=None),
    additional_guidelines: Optional[str] = Form(default=""),
    stream: bool = Form(default=True),
    supporting_doc_content: Optional[str] = Form(default=None),
    supporting_doc_area: Optional[str] = Form(default=None),
    service: ConductResearchService = Depends(get_tl_service(ConductResearchService)),
    settings = Depends(get_settings),
    files: List[UploadFile] = File(default=[])
):
    """Conduct Research workflow: Multi-document synthesis with citations"""
    request = ConductResearchRequest(
        messages=json.loads(messages),
        source_groups=json.loads(source_groups) if source_groups else None,
        stream=stream,
        additional_guidelines=additional_guidelines
    )
    
    try:
        logger.info(f"[Conduct Research] Received request with {len(request.messages)} messages")
        logger.debug(f"[Conduct Research] Request data: messages={len(request.messages)}, source_groups={request.source_groups}")
        logger.info("[Conduct Research] Additional guidelines received: %s", request.additional_guidelines)
        additional_guidelines = (request.additional_guidelines or "").strip()
        logger.info("[Conduct Research] Additional guidelines normalized: %r", additional_guidelines)
        
        # Handle supporting document content extraction
        if supporting_doc_content and supporting_doc_area:
            extractor = SupportingDocExtractor(service.llm_service)
            extracted_content = await extractor.extract_relevant_content(
                doc_content=supporting_doc_content,
                focus_area=supporting_doc_area
            )
            
            if extracted_content:
                SupportingDocExtractor.merge_into_user_message(
                    messages=request.messages,
                    extracted_content=extracted_content,
                    focus_area=supporting_doc_area
                )
        
        # Log uploaded files
        for file in files:
            if file:
                logger.info(f"[Conduct Research] Uploaded file received: {file.filename}")
            else:
                logger.warning("[Conduct Research] No file uploaded.")
       
        # Handle file upload
        uploaded_file_text = None
        for file in files:
            if file:
                try:
                    file_bytes = await file.read()

                    if file.filename.lower().endswith(".pdf"):
                        logger.info("[Conduct Research] Extracting text from uploaded PDF...")
                        uploaded_file_text = extract_text_from_pdf(file_bytes, max_chars=15000)

                    elif file.filename.lower().endswith(".docx"):
                        from docx import Document
                        logger.info("[Conduct Research] Extracting text from uploaded DOCX...")
                        doc = Document(io.BytesIO(file_bytes))
                        uploaded_file_text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])

                    elif file.filename.lower().endswith((".pptx")):
                        from pptx import Presentation
                        prs = Presentation(io.BytesIO(file_bytes))
                        logger.info("[Conduct Research] Extracting text from uploaded PPT...")
                        uploaded_file_text = extract_text_from_ppt(prs)
                
                    elif file.filename.lower().endswith((".xlsx", ".xls", ".xlsb")):
                        logger.info("[Conduct Research] Extracting text from uploaded Excel...")
                        try:
                            uploaded_file_text = extract_text_from_excel(
                                io.BytesIO(file_bytes),
                                file.filename
                            )
                        except ValueError as e:
                            logger.warning(f"[Conduct Research] {str(e)}")
                            uploaded_file_text = None   
                    else:
                        logger.warning(f"[Conduct Research] Unsupported file type: {file.filename}")
                    
                    if uploaded_file_text:
                        logger.info(f"[Conduct Research] Extracted {len(uploaded_file_text)} characters from uploaded file")

                        service.source_counter += 1
                        service.sources.append(
                        Source(
                            id=service.source_counter,
                            url=file.filename,
                            title=f"Uploaded Document: {file.filename}",
                            content=uploaded_file_text
                        ))
                        logger.info(f"[Conduct Research] Added uploaded file as Source {service.source_counter}")

                    else:
                        logger.warning("[Conduct Research] No text extracted from uploaded file.")

                except Exception as e:
                    logger.error(f"[Conduct Research] Error processing uploaded file: {e}", exc_info=True)
        
        # Extract query and research info from messages
        query = ""
        research_info = {'topic': None, 'sources': None}
        
        if request.messages and len(request.messages) > 0:
            for msg in reversed(request.messages):
                if isinstance(msg, dict) and msg.get("role") == "user":
                    content = msg.get("content", "")
                    research_info = extract_research_info_from_content(content)
                    
                    if research_info['topic']:
                        query = research_info['topic']
                    elif "Research Topic:" in content:
                        lines = content.split('\n')
                        for line in lines:
                            if "Research Topic:" in line:
                                query = line.split("Research Topic:")[-1].strip()
                                break
                    if not query:
                        query = content
                    break
        
        if not query:
            logger.warning(f"[Conduct Research] No query found in messages: {request.messages}")
            raise HTTPException(status_code=400, detail="No query found in messages")
        
        logger.info(f"[Conduct Research] Query: {query[:100]}...")
        
        # Log existing sources (uploaded files)
        logger.info(f"[Conduct Research] Current sources: {len(service.sources)} (uploaded files)")
        for s in service.sources:
            if isinstance(s, dict):
                logger.info(f"Source {s.get('id')}: {s.get('title')} ({len(s.get('content', ''))} chars)")
            else:
                logger.info(f"Source {s.id}: {s.title} ({len(s.content)} chars)")
        
        # Handle Multi-Source LangGraph Agent
        langgraph_context = ""
        # if should_use_langgraph_agent(research_info['sources']):
        try:
            logger.info(f"[Conduct Research] Initializing LangGraph Agent for multi-source query")
            
            # Create LangGraph agent instance
            langgraph_agent = create_data_source_agent(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            deployment_name=config.AZURE_OPENAI_DEPLOYMENT
        )
            
            # Build the query message for the agent
            search_query = research_info['topic'] or query
            agent_messages = [
                {
                    "role": "user",
                    "content": f"please call all the necessary tools to provide answer to this user query: {content}"
                }
            ]
            
            logger.info(f"[Conduct Research] Calling LangGraph Agent with query: {search_query}")
            
            # Get response from LangGraph agent (non-streaming for research context)
            agent_response = await langgraph_agent.process_query(agent_messages)
            
            if agent_response:
                logger.info(f"[Conduct Research] LangGraph Agent returned {len(agent_response)} characters")
                langgraph_context = f"""

--- Research Results from Multi-Source Data Integration ---
Sources automatically queried by AI Agent:
- Factiva News (external news and media coverage)
- Internal Knowledge Base (company documents and reports)
- CapitalIQ Financials (income statements and balance sheets)
- BoardEx Intelligence (advisors and executive achievements)

{agent_response}

--- End of Research Results ---
"""
                logger.info("[Conduct Research] LangGraph Agent context added to research")
            else:
                logger.warning("[Conduct Research] LangGraph Agent returned empty response")
            
            # Close agent connections
            langgraph_agent.close()
            
        except Exception as e:
            logger.error(f"[Conduct Research] LangGraph Agent error: {e}", exc_info=True)
            # Continue without agent context - don't break the workflow
            logger.warning("[Conduct Research] Continuing research without LangGraph Agent data")
        
        return StreamingResponse(
            service.conduct_research(
                query=query,
                sources=service.sources,
                messages=request.messages,
                sql_context=langgraph_context,
                additional_guidelines=additional_guidelines,
                use_factiva_research=False,  # No longer needed - LangGraph handles it
                factiva_context=""  # No longer needed - LangGraph handles it
            ),
            media_type="text/event-stream"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Conduct Research] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    