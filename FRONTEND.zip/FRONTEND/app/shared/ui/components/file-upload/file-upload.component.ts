import { Component, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';

import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { forwardRef } from '@angular/core';

@Component({
    selector: 'app-file-upload',
    imports: [],
    templateUrl: './file-upload.component.html',
    styleUrls: ['./file-upload.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FileUploadComponent),
            multi: true
        }
    ]
})
export class FileUploadComponent implements ControlValueAccessor {
  @Input() accept: string = '*';
  @Input() required: boolean = false;
  @Input() size: 'small' | 'normal' = 'normal';
  @Input() label: string = 'Upload File';
  @Input() multiple: boolean = false;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() filesSelected = new EventEmitter<File[]>();
  @Output() fileRemoved = new EventEmitter<File>();

  uploadedFile: File | null = null;
  uploadedFiles: File[] = [];
  @ViewChild('fileInput', { static: false }) fileInput?: ElementRef<HTMLInputElement>;
  private onChange: (file: File | File[] | null) => void = () => {};
  private onTouched: () => void = () => {};

  writeValue(value: File | File[] | null): void {
    if (value === null) {
      this.uploadedFile = null;
      this.uploadedFiles = [];
    } else if (Array.isArray(value)) {
      this.uploadedFile = null;
      this.uploadedFiles = value;
    } else {
      this.uploadedFiles = [];
      this.uploadedFile = value;
    }
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.onTouched();
    
    if (input.files && input.files.length > 0) {
      if (this.multiple) {
        this.uploadedFiles = Array.from(input.files);
        this.onChange(this.uploadedFiles);
        this.filesSelected.emit(this.uploadedFiles);
      } else {
        this.uploadedFile = input.files[0];
        this.onChange(this.uploadedFile);
        this.fileSelected.emit(this.uploadedFile);
      }
    }
  }

  // remove file (single or multiple). keep behaviour same but reset native file input
  removeFile(event: Event, index?: number): void {
    event.stopPropagation();

    if (this.multiple) {
      if (typeof index === 'number' && index >= 0 && index < this.uploadedFiles.length) {
        const removed = this.uploadedFiles.splice(index, 1)[0];
        this.fileRemoved.emit(removed);
      }
    } else {
      if (this.uploadedFile) {
        const removed = this.uploadedFile;
        this.uploadedFile = null;
        this.fileRemoved.emit(removed);
      }
    }

    // Reset the underlying <input type="file"> so the same file can be re-selected
    try {
      if (this.fileInput?.nativeElement) {
        this.fileInput.nativeElement.value = '';
        // dispatch change so any bindings/listeners update if needed
        this.fileInput.nativeElement.dispatchEvent(new Event('change', { bubbles: true }));
      }
    } catch {
      // best-effort: ignore any platform errors
    }
  }

  getFormData(fieldName: string = 'file'): FormData {
    const formData = new FormData();
    
    if (this.multiple) {
      this.uploadedFiles.forEach(file => {
        formData.append(fieldName, file);
      });
    } else if (this.uploadedFile) {
      formData.append(fieldName, this.uploadedFile);
    }
    
    return formData;
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';

    // Show exact size in KB (no rounding)
    if (bytes < 1024) {
      return bytes + ' Bytes';
    } else if (bytes < 1024 * 1024) {
      // Exact KB with decimal precision
      const kb = bytes / 1024;
      return kb.toFixed(2) + ' KB';
    } else {
      // For MB and above, show with 2 decimal places
      const mb = bytes / (1024 * 1024);
      return mb.toFixed(2) + ' MB';
    }
  }

  reset(): void {
    this.uploadedFile = null;
    this.uploadedFiles = [];
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
    this.onChange(null);
    this.onTouched();
  }
}

