import { Component, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';


@Component({
    selector: 'app-file-upload',
    imports: [],
    templateUrl: './file-upload.component.html',
    styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent {
  @Input() accept: string = '*';
  @Input() label: string = 'Upload File';
  @Input() maxSizeMB: number = 100;
  @Input() uploadedFile: File | null = null;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() fileRemoved = new EventEmitter<void>();
  
  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;

  triggerFileUpload(): void {
    this.fileInput?.nativeElement.click();
  }

  onFileSelected(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      const fileSizeMB = file.size / (1024 * 1024);
      if (fileSizeMB > this.maxSizeMB) {
        alert(`File size exceeds ${this.maxSizeMB}MB limit`);
        return;
      }
      this.fileSelected.emit(file);
    }
  }

  removeFile(): void {
    this.fileRemoved.emit();
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
