import { Component, Input, Output, EventEmitter } from '@angular/core';


export type DownloadFormat = 'pptx' | 'word' | 'pdf' | 'txt' | 'mp3';

@Component({
  selector: 'app-download-actions',
  standalone: true,
  imports: [],
  templateUrl: './download-actions.component.html',
  styleUrls: ['./download-actions.component.scss']
})
export class DownloadActionsComponent {
  @Input() formats: DownloadFormat[] = ['word', 'pdf', 'txt'];
  @Input() downloadUrl: string = '';
  @Input() filename: string = 'document';
  @Output() download = new EventEmitter<{ format: DownloadFormat; url: string; filename: string }>();
  @Output() preview = new EventEmitter<string>();

  onDownload(format: DownloadFormat): void {
    const formattedFilename = this.getFormattedFilename(format);
    this.download.emit({
      format,
      url: this.downloadUrl,
      filename: formattedFilename
    });
  }

  onPreview(): void {
    this.preview.emit(this.downloadUrl);
  }

  getFormattedFilename(format: DownloadFormat): string {
    const baseName = this.filename.replace(/\.[^/.]+$/, '');
    return `${baseName}.${format}`;
  }

  getFormatLabel(format: DownloadFormat): string {
    const labels: Record<DownloadFormat, string> = {
      'pptx': 'PowerPoint',
      'word': 'Word',
      'pdf': 'PDF',
      'txt': 'Text',
      'mp3': 'MP3'
    };
    return labels[format] || format.toUpperCase();
  }

  getFormatIcon(format: DownloadFormat): string {
    return format;
  }
}
