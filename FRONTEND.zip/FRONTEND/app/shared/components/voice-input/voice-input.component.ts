import { Component, Output, EventEmitter, OnDestroy, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';


@Component({
    selector: 'app-voice-input',
    imports: [],
    templateUrl: './voice-input.component.html',
    styleUrls: ['./voice-input.component.scss']
})
export class VoiceInputComponent implements OnDestroy {
  @Output() transcriptChange = new EventEmitter<string>();
  @Output() listeningChange = new EventEmitter<boolean>();
  
  @ViewChild('visualizer') visualizerCanvas?: ElementRef<HTMLCanvasElement>;
  
  isListening = false;
  transcript = '';
  interimTranscript = '';
  
  private recognition: any;
  private audioContext?: AudioContext;
  private analyser?: AnalyserNode;
  private dataArray?: Uint8Array<ArrayBuffer>;
  private animationId?: number;
  private stream?: MediaStream;
  private silenceTimeout?: any;
  private lastSpeechTime: number = 0;
  private readonly SILENCE_DURATION = 2000; // Auto-stop after 2 seconds of silence
  private silenceTimerStarted: boolean = false;
  private recognitionState: 'stopped' | 'starting' | 'running' | 'stopping' = 'stopped';

  constructor(private cdr: ChangeDetectorRef) {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true; // Keep listening to detect silence
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;
      
      this.recognition.onstart = () => {
        console.log('[VoiceInput] Recognition started');
        this.recognitionState = 'running';
        this.isListening = true;
        this.listeningChange.emit(true);
        this.lastSpeechTime = Date.now();
        // Do NOT start silence detection here. Start it only after the first word is detected
        this.silenceTimerStarted = false;
        this.cdr.detectChanges();
      };
      
      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcriptText = event.results[i][0].transcript;
          
          if (event.results[i].isFinal) {
            final += transcriptText + ' ';
          } else {
            interim += transcriptText;
          }
        }
        
        if (final) {
          this.transcript += final;
          this.transcriptChange.emit(this.transcript);
        }
        
        this.interimTranscript = interim;
        
        // Start the silence detection only after we have received the first piece of speech
        const hasContent = interim.trim().length > 0 || final.trim().length > 0;
        
        if (!this.silenceTimerStarted && hasContent) {
          console.log('[VoiceInput] First word detected, starting silence timer');
          this.silenceTimerStarted = true;
          this.startSilenceDetection();
        } else if (this.silenceTimerStarted && hasContent) {
          // Reset/restart detection when subsequent speech is detected
          console.log('[VoiceInput] Continuing speech detected, resetting timer');
          this.startSilenceDetection();
        }
      };
      
      this.recognition.onerror = (event: any) => {
        console.error('[VoiceInput] Error:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          alert('Microphone access was denied. Please enable microphone permissions.');
        }
        this.stopListening();
      };
      
      this.recognition.onend = () => {
        console.log('[VoiceInput] Recognition ended, state:', this.recognitionState, 'isListening:', this.isListening);
        
        // Only restart if we're in running state and still want to listen
        // Don't restart if we're in stopping state (user manually stopped)
        if (this.recognitionState === 'running' && this.isListening) {
          console.log('[VoiceInput] Recognition ended unexpectedly, restarting...');
          this.recognitionState = 'starting';
          // Small delay to ensure clean state
          setTimeout(() => {
            if (this.isListening && this.recognitionState === 'starting') {
              try {
                this.recognition.start();
              } catch (error) {
                console.error('[VoiceInput] Failed to restart recognition:', error);
                this.stopListening();
              }
            }
          }, 100);
        } else {
          console.log('[VoiceInput] Recognition ended normally');
          this.recognitionState = 'stopped';
        }
      };
    }
  }

  private startSilenceDetection(): void {
    // Clear any existing timeout
    if (this.silenceTimeout) {
      clearTimeout(this.silenceTimeout);
      this.silenceTimeout = undefined;
    }
    
    // Update the last speech time to NOW (since we just detected speech)
    this.lastSpeechTime = Date.now();
    
    // Set a timeout that will fire after SILENCE_DURATION
    // When it fires, check if enough time has passed without new speech
    this.silenceTimeout = setTimeout(() => {
      const timeSinceLastSpeech = Date.now() - this.lastSpeechTime;
      console.log('[VoiceInput] Silence check - time since last speech:', timeSinceLastSpeech, 'ms');
      
      // Use >= to handle timing precision issues
      // Also check that we're still listening (user didn't manually stop)
      if (timeSinceLastSpeech >= this.SILENCE_DURATION && this.isListening) {
        console.log('[VoiceInput] Auto-stopping due to silence');
        this.stopListening();
      } else if (this.isListening) {
        // Still listening but timer fired early (edge case) - reschedule
        console.log('[VoiceInput] Timer fired early, rescheduling...');
        this.startSilenceDetection();
      }
    }, this.SILENCE_DURATION);
  }

  async startListening(): Promise<void> {
    if (!this.recognition) {
      alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
      return;
    }
    
    // Prevent starting if already starting or running
    if (this.recognitionState === 'starting' || this.recognitionState === 'running') {
      console.log('[VoiceInput] Already starting or running, ignoring start request');
      return;
    }
    
    // If stopping, wait for it to finish
    if (this.recognitionState === 'stopping') {
      console.log('[VoiceInput] Currently stopping, waiting...');
      await new Promise(resolve => setTimeout(resolve, 300));
      // After waiting, check if we're now stopped
      if (this.recognitionState === 'stopping' || this.recognitionState === 'running') {
        console.error('[VoiceInput] Failed to stop previous session, state:', this.recognitionState);
        // Force stop
        this.recognitionState = 'stopped';
      }
    }
    
    try {
      console.log('[VoiceInput] Starting new listening session');
      this.recognitionState = 'starting';
      
      // Reset state
      this.transcript = '';
      this.interimTranscript = '';
      this.silenceTimerStarted = false;
      this.lastSpeechTime = Date.now();
      
      // Clear any existing timeout (safety check)
      if (this.silenceTimeout) {
        clearTimeout(this.silenceTimeout);
        this.silenceTimeout = undefined;
      }
      
      // Start listening
      this.isListening = true;
      this.recognition.start();
      
      // Start audio visualization
      await this.startVisualization();
    } catch (error) {
      console.error('[VoiceInput] Error starting:', error);
      this.recognitionState = 'stopped';
      this.isListening = false;
      this.listeningChange.emit(false);
    }
  }

  stopListening(): void {
    console.log('[VoiceInput] Stopping listening, current state:', this.recognitionState);
    
    // Prevent multiple stop calls
    if (this.recognitionState === 'stopped' || this.recognitionState === 'stopping') {
      console.log('[VoiceInput] Already stopped or stopping');
      return;
    }
    
    this.recognitionState = 'stopping';
    
    // Set flag first to prevent race conditions
    const wasListening = this.isListening;
    this.isListening = false;
    this.silenceTimerStarted = false;
    
    // Clear timeout
    if (this.silenceTimeout) {
      clearTimeout(this.silenceTimeout);
      this.silenceTimeout = undefined;
    }
    
    // Force change detection to update the view immediately
    this.cdr.detectChanges();
    
    // Emit only if we were actually listening (avoid duplicate emissions)
    if (wasListening) {
      this.listeningChange.emit(false);
    }
    
    // Stop recognition
    if (this.recognition) {
      try {
        this.recognition.stop();
        // State will be set to 'stopped' in onend handler
      } catch (error) {
        console.log('[VoiceInput] Recognition already stopped:', error);
        this.recognitionState = 'stopped';
      }
    } else {
      this.recognitionState = 'stopped';
    }
    
    this.stopVisualization();
  }

  private async startVisualization(): Promise<void> {
    try {
      // Get microphone stream
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Create audio context and analyser
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = this.audioContext.createMediaStreamSource(this.stream);
      this.analyser = this.audioContext.createAnalyser();
      
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.8;
      const bufferLength = this.analyser.frequencyBinCount;
      this.dataArray = new Uint8Array(bufferLength);
      
      source.connect(this.analyser);
      
      // Start animation loop
      this.draw();
    } catch (error) {
      console.error('[VoiceInput] Microphone access error:', error);
    }
  }

  private stopVisualization(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = undefined;
    }
    
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = undefined;
    }
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = undefined;
    }
  }

  private draw(): void {
    if (!this.isListening || !this.analyser || !this.dataArray) {
      return;
    }
    
    this.animationId = requestAnimationFrame(() => this.draw());
    
    this.analyser.getByteTimeDomainData(this.dataArray);
    
    const canvas = this.visualizerCanvas?.nativeElement;
    if (!canvas) return;
    
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;
    
    const width = canvas.width;
    const height = canvas.height;
    
    // Clear canvas
    canvasCtx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    canvasCtx.fillRect(0, 0, width, height);
    
    // Draw waveform
    canvasCtx.lineWidth = 2;
    canvasCtx.strokeStyle = '#D04A02'; // PwC orange
    canvasCtx.beginPath();
    
    const sliceWidth = width / this.dataArray.length;
    let x = 0;
    
    for (let i = 0; i < this.dataArray.length; i++) {
      const v = this.dataArray[i] / 128.0;
      const y = (v * height) / 2;
      
      if (i === 0) {
        canvasCtx.moveTo(x, y);
      } else {
        canvasCtx.lineTo(x, y);
      }
      
      x += sliceWidth;
    }
    
    canvasCtx.lineTo(width, height / 2);
    canvasCtx.stroke();
  }

  ngOnDestroy(): void {
    this.stopListening();
    this.stopVisualization();
  }
}
