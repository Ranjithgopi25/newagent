export interface DraftData {
  topic: string;
  objective: string;
  audience: string;
  additional_context: string;
  reference_document: string;
  reference_link: string;
}

export interface SanitizeData {
  clientName: string;
  products: string;
  options: {
    detectClient?: boolean;
    pageRange?: string;
    services?: string[];
  };
}

export interface SanitizeResponse {
  blob: Blob;
  stats?: {
    numeric_replacements: number;
    name_replacements: number;
    hyperlinks_removed: number;
    notes_removed: number;
    logos_removed: number;
    slides_processed: number;
    llm_replacements?: number;
  };
}

export interface PPTUploadData {
  file: File;
  operation: 'improve' | 'sanitize' | 'validate' | 'draft';
  additionalData?: any;
}
