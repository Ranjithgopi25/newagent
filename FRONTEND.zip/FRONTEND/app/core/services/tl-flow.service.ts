import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export type TLFlowType = 'draft-content' | 'conduct-research' | 'edit-content' | 'refine-content' | 'format-translator' | 'generate-podcast' | null;

@Injectable({
  providedIn: 'root'
})
export class TlFlowService {
  private activeFlowSubject = new BehaviorSubject<TLFlowType>(null);
  public activeFlow$: Observable<TLFlowType> = this.activeFlowSubject.asObservable();

  private guidedDialogSubject = new BehaviorSubject<boolean>(false);
  public guidedDialog$: Observable<boolean> = this.guidedDialogSubject.asObservable();


  private preselectedContentTypeSubject = new BehaviorSubject<string | null>(null);
  public preselectedContentType$: Observable<string | null> = this.preselectedContentTypeSubject.asObservable();

  private preselectedTopicSubject = new BehaviorSubject<string | null>(null);
  public preselectedTopic$: Observable<string | null> = this.preselectedTopicSubject.asObservable();


  openFlow(flowType: TLFlowType, contentType?: string, topic?: string): void {
    console.log('[TlFlowService] openFlow called with:', { flowType, contentType, topic });
    
    // Only update content type if explicitly provided (not undefined)
    if (contentType !== undefined) {
      if (contentType) {
        this.preselectedContentTypeSubject.next(contentType);
      } else {
        this.preselectedContentTypeSubject.next(null);
      }
    }
    // If contentType is undefined, preserve the existing value
    
    // Only update topic if explicitly provided (not undefined)
    if (topic !== undefined) {
      if (topic !== null && topic.trim() !== '') {
        console.log('[TlFlowService] Setting preselected topic:', topic);
        this.preselectedTopicSubject.next(topic);
      } else {
        console.log('[TlFlowService] Clearing preselected topic (topic was:', topic, ')');
        this.preselectedTopicSubject.next(null);
      }
    }
    // If topic is undefined, preserve the existing value
    
    this.activeFlowSubject.next(flowType);
  }


  closeFlow(): void {
    this.activeFlowSubject.next(null);
    this.preselectedContentTypeSubject.next(null);
    this.preselectedTopicSubject.next(null);
  }

  openGuidedDialog(): void {
    this.guidedDialogSubject.next(true);
  }

  closeGuidedDialog(): void {
    this.guidedDialogSubject.next(false);
  }

  get currentFlow(): TLFlowType {
    return this.activeFlowSubject.value;
  }

  get isGuidedDialogOpen(): boolean {
    return this.guidedDialogSubject.value;
  }


  get preselectedContentType(): string | null {
    return this.preselectedContentTypeSubject.value;
  }

  get preselectedTopic(): string | null {
    return this.preselectedTopicSubject.value;
  }
}
