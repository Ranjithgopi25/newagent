import { Injectable, inject } from '@angular/core';
import { renderAsync } from 'docx-preview';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
import { BehaviorSubject, Observable, Subject, firstValueFrom } from 'rxjs';
import { Message, DraftWorkflowMetadata, ContentTypeOption } from '../models';
import { ChatService } from './chat.service';
import { TlFlowService } from './tl-flow.service';
import { environment } from '../../../environments/environment';
import { AuthFetchService } from './auth-fetch.service';

// Configure PDF.js worker for browser build
GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.js', import.meta.url).toString();

export type DraftWorkflowStep = 'idle' | 'awaiting_topic' | 'awaiting_content_type' | 'awaiting_word_limit' | 'awaiting_audience' | 'awaiting_outline_doc' | 'awaiting_supporting_doc' | 'processing';

export interface DraftWorkflowState {
 step: DraftWorkflowStep;
 topic: string;
 contentType: string;
 wordLimit: string;
 audienceTone: string;
 outlineDoc?: string;
 supportingDoc?: string;
}
export interface DraftWorkflowMessage {
 type: 'prompt' | 'result';
 message: Message;
}
@Injectable({
 providedIn: 'root'
})
export class ChatDraftWorkflowService {
 private chatService = inject(ChatService);
 private tlFlowService = inject(TlFlowService);
 private authFetchService = inject(AuthFetchService);
 private stateSubject = new BehaviorSubject<DraftWorkflowState>({
   step: 'idle',
   topic: '',
   contentType: '',
   wordLimit: '',
   audienceTone: '',
   outlineDoc: '',
   supportingDoc: ''
 });
 public state$: Observable<DraftWorkflowState> = this.stateSubject.asObservable();
 private messageSubject = new Subject<DraftWorkflowMessage>();
 public message$: Observable<DraftWorkflowMessage> = this.messageSubject.asObservable();
 private workflowCompletedSubject = new Subject<void>();
 public workflowCompleted$: Observable<void> = this.workflowCompletedSubject.asObservable();
 private uploadedOutlineFile: File | null = null;
 private uploadedSupportingFile: File | null = null;
 private lastDraftState: DraftWorkflowState | null = null;
 
 // Satisfaction feedback properties
 private generatedDraftContent: string = '';
 private iterationCount: number = 0;
 private maxIterations: number = 5;
 private awaitingSatisfactionFeedback: boolean = false;
 private lastGeneratedPrompt: string = '';
 
 // Store original draft parameters for improvements (like guided journey)
 private originalContentType: string = '';
 private originalTopic: string = '';
 private originalWordLimit: string = '';
 private originalAudienceTone: string = '';
 private originalOutlineDoc: string = '';
 private originalSupportingDoc: string = '';
 
 get currentState(): DraftWorkflowState {
   return this.stateSubject.value;
 }
 get isActive(): boolean {
   return this.currentState.step !== 'idle';
 }
 
 /**
  * Getter to check if we're awaiting satisfaction feedback on quick start draft
  */
 get isAwaitingSatisfactionFeedback(): boolean {
   return this.awaitingSatisfactionFeedback;
 }
 
 readonly contentTypeOptions: ContentTypeOption[] = [
   {
     id: 'article',
     name: 'Article',
     icon: '📄',
     description: 'Professional article with in-depth analysis and insights',
     selected: false
   },
   {
     id: 'blog',
     name: 'Blog',
     icon: '✍️',
     description: 'Engaging blog post with conversational tone',
     selected: false
   },
   {
     id: 'white_paper',
     name: 'White Paper',
     icon: '📋',
     description: 'Comprehensive research document with detailed findings',
     selected: false
   },
   {
     id: 'executive_brief',
     name: 'Executive Brief',
     icon: '📊',
     description: 'Concise summary for executive decision-making',
     selected: false
   }
 ];
 async detectDraftIntent(input: string): Promise<{ hasDraftIntent: boolean, detectedTopic?: string, detectedContentType?: string[], wordLimit?: string, audienceTone?: string }> {
   if (!input || !input.trim()) {
     return { hasDraftIntent: false };
   }
   try {
     const result = await firstValueFrom(
       this.chatService.detectDraftIntent(input.trim())
     );
     console.log('[DraftWorkflow] Backend response:', result);
     const hasDraftIntent = result.is_draft_intent && result.confidence >= 0.7;
     console.log('[DraftWorkflow] hasDraftIntent calculation: is_draft_intent=', result.is_draft_intent, 'confidence=', result.confidence, 'hasDraftIntent=', hasDraftIntent);
     const detectedContentType = result.detected_content_type && result.detected_content_type.length > 0 
        ? result.detected_content_type 
        : undefined;
     const resultAny = result as any;
     const returnValue = {
       hasDraftIntent,
       detectedTopic: result.detected_topic || undefined,
       detectedContentType: Array.isArray(result.detected_content_type) && result.detected_content_type.length > 0
                            ? result.detected_content_type
                            : result.detected_content_type && !Array.isArray(result.detected_content_type)
                            ? [result.detected_content_type]
                            : undefined,
       wordLimit: (resultAny.word_limit || resultAny['word_limit']) || undefined,
       audienceTone: (resultAny.audience_tone || resultAny['audience_tone']) || undefined
     };
     console.log('[DraftWorkflow] Processed intent result:', returnValue);

     // Do NOT prompt here - let the workflow initialization handle prompting
     // beginWorkflow() or startQuickDraftConversation() will handle the prompts

     return returnValue;
   } catch (error) {
     console.error('Error in LLM draft intent detection:', error);
     return { hasDraftIntent: false };
   }
 }
 beginWorkflow(initialTopic?: string, initialContentType?: string, initialWordLimit?: string, initialAudienceTone?: string): void {
   console.log('[DraftWorkflow] beginWorkflow called with topic:', initialTopic, 'contentType:', initialContentType, 'wordLimit:', initialWordLimit, 'audienceTone:', initialAudienceTone);
   
   // Determine initial step based on what we have
   let initialStep: DraftWorkflowStep = 'awaiting_topic';
   
   // If we already have topic and content type, proceed to processing
   if (initialTopic && initialContentType) {
     console.log('[DraftWorkflow] Both topic and content type provided, proceeding to processing');
     this.updateState({
       step: 'processing',
       topic: initialTopic,
       contentType: initialContentType,
       wordLimit: initialWordLimit || '',
       audienceTone: initialAudienceTone || '',
       outlineDoc: '',
       supportingDoc: ''
     });
     this.processDraft();
     return;
   }
   
   // If we have topic but no content type, ask for content type
   if (initialTopic && !initialContentType) {
     console.log('[DraftWorkflow] Topic provided but no content type, asking for content type');
     initialStep = 'awaiting_content_type';
   }
   
   // If we have content type but no topic, ask for topic
   if (!initialTopic && initialContentType) {
     console.log('[DraftWorkflow] Content type provided but no topic, asking for topic');
     initialStep = 'awaiting_topic';
   }
   
   console.log('[DraftWorkflow] Setting initial step to:', initialStep);
   
   // Update state once with the correct initial step
   this.updateState({
     step: initialStep,
     topic: initialTopic || '',
     contentType: initialContentType || '',
     wordLimit: initialWordLimit || '',
     audienceTone: initialAudienceTone || '',
     outlineDoc: '',
     supportingDoc: ''
   });
   
   // Prompt based on the step and what's provided
   if (initialStep === 'awaiting_topic') {
     console.log('[DraftWorkflow] Prompting for topic');
     this.askForTopic();
   } else if (initialStep === 'awaiting_content_type') {
     console.log('[DraftWorkflow] Prompting for content type');
     this.askForContentType();
     // After content type is provided, we'll check what's needed
   }
 }
 private askForTopic(): void {
   const message: Message = {
     role: 'assistant',
     content: 'I can help you draft new content. What topic would you like to write about?',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }
 private askForContentType(): void {
   const message = this.createContentTypeSelectionMessage(
     `Great! What type of content should I create for **"${this.currentState.topic}"**?\n\n**Select a content type: article/ blog/ executive brief/ whitepaper**`
   );
   this.messageSubject.next({ type: 'prompt', message });
 }
 private createContentTypeSelectionMessage(content: string, contentTypeOptions?: ContentTypeOption[]): Message {
   const options = contentTypeOptions || this.cloneContentTypeOptions();
   return {
     role: 'assistant',
     content,
     timestamp: new Date(),
     draftWorkflow: {
       step: 'awaiting_content_type',
       topic: this.currentState.topic,
       showContentTypeSelection: true,  // Enable visual UI component
       showCancelButton: false,
       showSimpleCancelButton: true,
       contentTypeOptions: options
     }
   };
 }
 private cloneContentTypeOptions(): ContentTypeOption[] {
   return this.contentTypeOptions.map(opt => ({ ...opt }));
 }
 private getNumberedContentTypeList(contentTypeOptions?: ContentTypeOption[]): string {
   const options = contentTypeOptions || this.contentTypeOptions;
   return options.map((option, index) => {
     const num = index + 1;
     return `${num}. **${option.name}** ${option.icon} — ${option.description}`;
   }).join('\n');
 }
 handleContentTypeSelection(selectedId: string): void {
   if (this.currentState.step !== 'awaiting_content_type') {
     return;
   }
   const selectedOption = this.contentTypeOptions.find(opt => opt.id === selectedId);
   if (!selectedOption) {
     return;
   }
   this.updateState({
     ...this.currentState,
     contentType: selectedOption.name
   });
   this.processDraft();
 }
 handleChatInput(input: string): void {
   const trimmedInput = input.trim();
   if (!trimmedInput) return;
   
   // Check for rewrite intent even if workflow is not active
   if (this.isRewriteIntent(trimmedInput)) {
     console.log('[DraftWorkflow] Rewrite intent detected');
     if (this.lastDraftState) {
       this.handleRewriteRequest(trimmedInput);
       return;
     }
   }
   
   if (!this.isActive) return;
   if (trimmedInput.toLowerCase() === 'cancel') {
     this.cancelWorkflow();
     return;
   }
   switch (this.currentState.step) {
     case 'awaiting_topic':
       this.updateState({ ...this.currentState, topic: trimmedInput });
      // If content type is missing, ask for it before other fields
      if (!this.currentState.contentType || !this.currentState.contentType.trim()) {
        this.updateState({ ...this.currentState, step: 'awaiting_content_type' });
        this.askForContentType();
        break;
      }
      // After topic is provided, proceed to next step based on available data
       if (this.currentState.wordLimit && this.currentState.audienceTone) {
         // Both already provided, go to outline
         this.updateState({ ...this.currentState, step: 'awaiting_outline_doc' });
         this.askForOutlineDoc();
       } else if (this.currentState.wordLimit) {
         // Word limit provided, ask for audience
         this.updateState({ ...this.currentState, step: 'awaiting_audience' });
         this.askForAudience();
       } else if (this.currentState.audienceTone) {
         // Audience provided, ask for word limit
         this.updateState({ ...this.currentState, step: 'awaiting_word_limit' });
         this.askForWordLimit();
       } else {
         // Neither provided, ask for word limit first
         this.updateState({ ...this.currentState, step: 'awaiting_word_limit' });
         this.askForWordLimit();
       }
       break;
     case 'awaiting_content_type':
       // Parse numeric selection (1-4)
       const numMatch = trimmedInput.match(/^\d+$/);
       let contentType = '';
       if (numMatch) {
         const num = parseInt(numMatch[0]);
         if (num >= 1 && num <= 4) {
           const selectedOption = this.contentTypeOptions[num - 1];
           contentType = selectedOption.name;
         }
       } else {
         // Simple mapping for content type
         const lowerInput = trimmedInput.toLowerCase();
         if (lowerInput.includes('blog')) contentType = 'Blog';
         else if (lowerInput.includes('brief') || lowerInput.includes('memo')) contentType = 'Executive Brief';
         else if (lowerInput.includes('white') || lowerInput.includes('paper')) contentType = 'White Paper';
         else if (lowerInput.includes('article')) contentType = 'Article';
         else contentType = 'Article'; // fallback
       }
       // Set content type and proceed to next step
       console.log('[DraftWorkflow] Content type selected:', contentType);
       
       // Check what's already provided from detection
       const hasWordLimit = this.currentState.wordLimit && this.currentState.wordLimit.trim();
       const hasAudience = this.currentState.audienceTone && this.currentState.audienceTone.trim();
       
       console.log('[DraftWorkflow] After content type - hasWordLimit:', hasWordLimit, 'hasAudience:', hasAudience);
       
       // If both word limit and audience are already provided, skip to outline doc
       if (hasWordLimit && hasAudience) {
         console.log('[DraftWorkflow] Both word limit and audience already provided, proceeding to outline doc');
         this.updateState({ ...this.currentState, contentType, step: 'awaiting_outline_doc' });
         this.askForOutlineDoc();
       }
       // If word limit is provided but not audience, ask for audience
       else if (hasWordLimit) {
         console.log('[DraftWorkflow] Word limit provided but no audience, asking for audience');
         this.updateState({ ...this.currentState, contentType, step: 'awaiting_audience' });
         this.askForAudience();
       }
       // Otherwise ask for word limit
       else {
         console.log('[DraftWorkflow] No word limit provided, asking for it');
         this.updateState({ ...this.currentState, contentType, step: 'awaiting_word_limit' });
         this.askForWordLimit();
       }
       break;
     case 'awaiting_word_limit':
       this.handleWordLimitResponse(trimmedInput);
       break;
     case 'awaiting_audience':
       this.handleAudienceResponse(trimmedInput);
       break;
     case 'awaiting_outline_doc':
       this.handleOutlineDocResponse(trimmedInput);
       break;
     case 'awaiting_supporting_doc':
       this.handleSupportingDocResponse(trimmedInput);
       break;
   }
 }

 /**
  * Handle file upload during draft workflow
  */
 handleFileUpload(file: File): void {
   if (!this.isActive) return;

   const currentStep = this.currentState.step;
   
   if (currentStep === 'awaiting_outline_doc') {
     this.uploadedOutlineFile = file;
     this.readFileContent(file).then(content => {
       const combinedContent = `File: ${file.name}\n${content}`;
       this.updateState({ ...this.currentState, outlineDoc: combinedContent });
       // Auto-proceed to next step after file upload
       const message: Message = {
         role: 'assistant',
         content: `Outline document "${file.name}" uploaded successfully. Proceeding...`,
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'prompt', message });
       this.updateState({ ...this.currentState, step: 'awaiting_supporting_doc' });
       this.askForSupportingDoc();
     }).catch(error => {
       console.error('Error reading outline file:', error);
       const errorMsg: Message = {
         role: 'assistant',
        content: error?.message || 'Error reading the file. Please try again with a .docx/.pdf/.txt/.md file or type "no" to skip.',
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'prompt', message: errorMsg });
     });
   } else if (currentStep === 'awaiting_supporting_doc') {
     this.uploadedSupportingFile = file;
     this.readFileContent(file).then(content => {
       const combinedContent = `File: ${file.name}\n${content}`;
       this.updateState({ ...this.currentState, supportingDoc: combinedContent });
       // Auto-proceed to execution after file upload
       const message: Message = {
         role: 'assistant',
         content: `Supporting document "${file.name}" uploaded successfully. Starting draft...`,
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'prompt', message });
       this.updateState({ ...this.currentState, step: 'processing' });
       this.executeQuickDraftInternal();
     }).catch(error => {
       console.error('Error reading supporting file:', error);
       const errorMsg: Message = {
         role: 'assistant',
        content: error?.message || 'Error reading the file. Please try again with a .docx/.pdf/.txt/.md file or type "no" to skip.',
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'prompt', message: errorMsg });
     });
   }
 }

 private processDraft(): void {
   this.updateState({ ...this.currentState, step: 'processing' });
   const message: Message = {
     role: 'assistant',
     content: `Generating **${this.currentState.contentType}** about "**${this.currentState.topic}**"...`,
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
   this.generateDraftInChat();
 }
 private async generateDraftInChat(): Promise<void> {
   // Construct the prompt similar to DraftContentFlowComponent
   let prompt = `Please draft the following type of content:\n\n`;
   prompt += `Content Type: ${this.currentState.contentType}\n`;
   prompt += `Topic: ${this.currentState.topic}\n`;
   prompt += `Word Limit: ${this.currentState.wordLimit}\n`;
   prompt += `Audience/Tone: ${this.currentState.audienceTone}\n`;
    if (this.currentState.outlineDoc) {
      prompt += `Initial Outline/Concept: ${this.currentState.outlineDoc}\n`;
    }
    if (this.currentState.supportingDoc) {
      prompt += `Supporting Documents: ${this.currentState.supportingDoc}\n`;
    }
   const messages = [{
     role: 'user' as const,
     content: prompt
   }];
   let fullResponse = '';
   this.chatService.streamDraftContent(messages).subscribe({
     next: (data: any) => {
       let chunk = '';
       if (typeof data === 'string') {
         chunk = data;
       } else if (data.type === 'content' && data.content) {
         chunk = data.content;
       }
       fullResponse += chunk;
     },
     error: (error: any) => {
       console.error('Error generating draft:', error);
       const errorMsg: Message = {
         role: 'assistant',
         content: 'Sorry, there was an error generating your draft. Please try again.',
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'result', message: errorMsg });
       this.completeWorkflow();
     },
     complete: () => {
       // Send the result to chat
       const resultMsg: Message = {
         role: 'assistant',
         content: fullResponse,
         timestamp: new Date(),
         thoughtLeadership: {
           contentType: this.mapContentType(this.currentState.contentType),
           topic: this.currentState.topic,
           fullContent: fullResponse,
           showActions: true
         }
       };
       this.messageSubject.next({ type: 'result', message: resultMsg });
       this.completeWorkflow();
     }
   });
 }
 private mapContentType(type: string): 'article' | 'blog' | 'white_paper' | 'executive_brief' {
   const lower = type.toLowerCase();
   if (lower.includes('blog')) return 'blog';
   if (lower.includes('white')) return 'white_paper';
   if (lower.includes('brief')) return 'executive_brief';
   return 'article';
 }
 
 /**
  * Get satisfaction prompt text - matches DraftContentFlowComponent logic
  */
 private getSatisfactionPromptText(): string {
   if (this.iterationCount === 0) {
     return 'Are you satisfied with the generated content, or do you need additional improvements?';
   }
   return `Are you satisfied with this revision (Iteration ${this.iterationCount}), or do you need additional improvements?`;
 }
 
 /**
  * Handle draft satisfaction response from user
  * Reuses the same logic as DraftContentFlowComponent.onSatisfactionResponse
  */
 public async handleDraftSatisfaction(input: string): Promise<void> {
   if (!this.awaitingSatisfactionFeedback) {
     console.log('[QuickDraft] Not awaiting satisfaction feedback');
     return;
   }

   const trimmedInput = input.trim();
   
   // Use LLM to analyze satisfaction
   const isSatisfied = await this.analyzeSatisfactionWithLLM(trimmedInput);

   if (isSatisfied.isPositive) {
     // User is satisfied - end workflow
     console.log('[QuickDraft] User SATISFIED with draft');
     const acknowledgment: Message = {
       role: 'assistant',
       content: 'Great! I\'m glad you\'re satisfied with the content. You can now use it in your documents or make further edits as needed.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'result', message: acknowledgment });
     this.awaitingSatisfactionFeedback = false;
     this.iterationCount = 0;
     this.generatedDraftContent = '';
     this.completeWorkflow();
   } else if (isSatisfied.hasImprovementRequest) {
     // User wants improvements
     console.log('[QuickDraft] User wants IMPROVEMENTS - Input:', isSatisfied.improvementText);
     this.awaitingSatisfactionFeedback = false;
     this.handleDraftImprovement(isSatisfied.improvementText || '');
   } else {
     // Unclear response
     console.log('[QuickDraft] Unclear satisfaction response, asking again');
     const satisfactionMsg: Message = {
       role: 'system',
       content: this.getSatisfactionPromptText(),
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'prompt', message: satisfactionMsg });
   }
 }
 
 /**
  * Analyze if user is satisfied or has improvement request
  * Reuses same logic as ChatComponent.analyzeDraftSatisfactionResponse
  */
 private analyzeSatisfactionResponse(input: string): { isPositive: boolean; hasImprovementRequest: boolean; improvementText?: string } {
   const positiveKeywords = ['yes', 'satisfied', 'good', 'great', 'perfect', 'looks good', 'works', 'done', 'ok', 'okay', 'looks great', 'love it', 'like it', 'happy', 'excellent', 'amazing', 'approve'];
   const negativeKeywords = ['no', 'not satisfied', 'improve', 'change', 'fix', 'better', 'different', 'more', 'less', 'shorter', 'longer', 'adjust', 'modify', 'rewrite', 'revise', 'update', 'enhance'];

   const lowerInput = input.toLowerCase();

   // Check for explicit positive sentiment
   if (positiveKeywords.some(keyword => lowerInput.includes(keyword))) {
     return { isPositive: true, hasImprovementRequest: false };
   }

   // Check for improvement request or negative sentiment
   if (negativeKeywords.some(keyword => lowerInput.includes(keyword))) {
     // Extract improvement suggestion from the input
     // Remove common negation phrases to get the improvement request
     let improvementText = input;
     const negPhrases = ['no, ', 'no, ', 'not satisfied with ', 'not happy with ', 'not good enough', 'could be better', 'needs '];
     for (const phrase of negPhrases) {
       if (improvementText.toLowerCase().startsWith(phrase)) {
         improvementText = improvementText.substring(phrase.length).trim();
       }
     }
     return {
       isPositive: false,
       hasImprovementRequest: true,
       improvementText: improvementText || input
     };
   }

   // Unclear
   return { isPositive: false, hasImprovementRequest: false };
 }
 
 /**
  * Analyze user satisfaction with LLM
  */
 private async analyzeSatisfactionWithLLM(input: string): Promise<{ isPositive: boolean; hasImprovementRequest: boolean; improvementText?: string }> {
   try {
     const response = await this.chatService.analyzeSatisfaction({
       user_input: input,
       generated_content: this.generatedDraftContent,
       content_type: this.stateSubject.value.contentType,
       topic: this.stateSubject.value.topic
     }).toPromise();
     
     if (!response) {
       console.error('[QuickDraft] LLM Response is null, using keyword fallback');
       return this.analyzeSatisfactionResponse(input.toLowerCase());
     }
     
     // If confidence is high (>0.6), trust the LLM
     if (response.confidence > 0.6) {
       return {
         isPositive: response.is_satisfied,
         hasImprovementRequest: !response.is_satisfied,
         improvementText: input
       };
     }
     
     // Medium confidence - treat as unclear
     if (response.confidence >= 0.3 && response.confidence <= 0.6) {
       return { isPositive: false, hasImprovementRequest: false };
     }
     
     // Low confidence - treat as improvement request
     return {
       isPositive: false,
       hasImprovementRequest: true,
       improvementText: input
     };
   } catch (error) {
     console.error('[QuickDraft] Error calling LLM endpoint:', (error as any)?.message);
     return this.analyzeSatisfactionResponse(input.toLowerCase());
   }
 }
 
 /**
  * Handle improvement request for draft content
  * Regenerates content with improvement feedback using all original parameters
  * This matches the guided journey approach
  */
 private handleDraftImprovement(improvementText: string): void {
   if (this.iterationCount >= this.maxIterations) {
     const maxIterMsg: Message = {
       role: 'assistant',
       content: `You have reached the maximum number of iterations (${this.maxIterations}). Please start a new draft if you need further changes.`,
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'result', message: maxIterMsg });
     this.completeWorkflow();
     return;
   }

   const nextIteration = this.iterationCount + 1;
   console.log(`[QuickDraft] Processing improvement request (Iteration ${nextIteration})`);

   // Build full improvement prompt with all original parameters (like guided journey)
   // This ensures the LLM regenerates with the same context
   let improvementPrompt = `Please draft the following type of content:\n\n`;
   improvementPrompt += `Content Type: ${this.originalContentType}\n`;
   improvementPrompt += `Topic: ${this.originalTopic}\n`;
   
   if (this.originalWordLimit) {
     improvementPrompt += `Word Limit: ${this.originalWordLimit}\n`;
   }
   
   if (this.originalAudienceTone) {
     improvementPrompt += `Audience/Tone: ${this.originalAudienceTone}\n`;
   }

   if (this.originalOutlineDoc) {
     improvementPrompt += `Initial Outline/Concept: ${this.originalOutlineDoc}\n`;
   }

   if (this.originalSupportingDoc) {
     improvementPrompt += `Supporting Documents: ${this.originalSupportingDoc}\n`;
   }

   // Add improvement feedback
   improvementPrompt += `\n=== IMPROVEMENT REQUEST ===\n`;
   improvementPrompt += `Please review the following previously generated content and apply these improvements:\n\n`;
   improvementPrompt += `${improvementText}\n\n`;
   improvementPrompt += `Previously Generated Content:\n${this.generatedDraftContent}`;

   const messages = [{
     role: 'user' as const,
     content: improvementPrompt
   }];

   // Show processing message
   const processingMsg: Message = {
     role: 'assistant',
     content: `Processing your improvement request (Iteration ${nextIteration})...`,
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message: processingMsg });

   let improvedResponse = '';

   // Stream the improved content
   this.chatService.streamDraftContent(messages).subscribe({
     next: (data: any) => {
       let chunk = '';
       if (typeof data === 'string') {
         chunk = data;
       } else if (data.type === 'content' && data.content) {
         chunk = data.content;
       }
       improvedResponse += chunk;
     },
     error: (error: any) => {
       console.error('[QuickDraft] Error during improvement:', error);
       const errorMsg: Message = {
         role: 'assistant',
         content: 'Sorry, there was an error processing your improvement request. Please try again.',
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'result', message: errorMsg });
       this.awaitingSatisfactionFeedback = true;
     },
     complete: () => {
       console.log(`[QuickDraft] Improvement iteration ${nextIteration} complete`);
       // Update the stored content with the improved version
       this.generatedDraftContent = improvedResponse;
       this.iterationCount = nextIteration;

       // Send the improved content
       const resultMsg: Message = {
         role: 'assistant',
         content: improvedResponse,
         timestamp: new Date(),
         thoughtLeadership: {
           contentType: this.mapContentType(this.originalContentType),
           topic: this.originalTopic,
           fullContent: improvedResponse,
           showActions: true
         }
       };
       this.messageSubject.next({ type: 'result', message: resultMsg });

       // Ask for satisfaction again
       const satisfactionMsg: Message = {
         role: 'system',
         content: this.getSatisfactionPromptText(),
         timestamp: new Date()
       };
       this.messageSubject.next({ type: 'prompt', message: satisfactionMsg });
       this.awaitingSatisfactionFeedback = true;
     }
   });
 }
 
 cancelWorkflow(): void {
   this.updateState({
     step: 'idle',
     topic: '',
     contentType: '',
     wordLimit: '',
      audienceTone: '',
      outlineDoc: '',
      supportingDoc: ''
   });
   this.awaitingSatisfactionFeedback = false;
   this.generatedDraftContent = '';
   this.iterationCount = 0;
   this.originalContentType = '';
   this.originalTopic = '';
   this.originalWordLimit = '';
   this.originalAudienceTone = '';
   this.originalOutlineDoc = '';
   this.originalSupportingDoc = '';
   this.workflowCompletedSubject.next();
 }
 private completeWorkflow(): void {
   // Save the current state before clearing for potential "rewrite" requests
   this.lastDraftState = { ...this.currentState };
   console.log('[DraftWorkflow] Saved draft state for rewrite:', this.lastDraftState);
   
   this.updateState({
     step: 'idle',
     topic: '',
     contentType: '',
     wordLimit: '',
      audienceTone: '',
      outlineDoc: '',
      supportingDoc: ''
   });
   
   // Reset satisfaction and original parameters
   this.awaitingSatisfactionFeedback = false;
   this.generatedDraftContent = '';
   this.iterationCount = 0;
   this.originalContentType = '';
   this.originalTopic = '';
   this.originalWordLimit = '';
   this.originalAudienceTone = '';
   this.originalOutlineDoc = '';
   this.originalSupportingDoc = '';
   
   this.workflowCompletedSubject.next();
 }
 private updateState(newState: DraftWorkflowState): void {
   this.stateSubject.next(newState);
 }

 /**
  * Detect if user input is a rewrite/regenerate intent
  */
 private isRewriteIntent(input: string): boolean {
   const lowerInput = input.toLowerCase();
   const rewriteKeywords = ['rewrite', 'regenerate', 'again', 'try again', 'different', 'change it', 'redo', 'remake', 'rethink'];
   return rewriteKeywords.some(keyword => lowerInput.includes(keyword));
 }

 /**
  * Handle rewrite request using the last draft context
  */
 private handleRewriteRequest(input: string): void {
   if (!this.lastDraftState) {
     const msg: Message = {
       role: 'assistant',
       content: 'No previous draft found. Please start a new draft by describing what you want to write.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'prompt', message: msg });
     return;
   }

   console.log('[DraftWorkflow] Handling rewrite request with state:', this.lastDraftState);

   // Extract new word limit if provided in the rewrite request
   const wordLimitMatch = input.match(/(\d+)\s*(word|words)/i);
   let newWordLimit = this.lastDraftState.wordLimit;
   
   if (wordLimitMatch) {
     newWordLimit = wordLimitMatch[1];
     console.log('[DraftWorkflow] Extracted new word limit from rewrite request:', newWordLimit);
   }

   // Extract new audience/tone if provided
   let newAudienceTone = this.lastDraftState.audienceTone;
   const audienceKeywords = {
     'c suite|executive|cxo|ceo|cfo|coo|cto': 'C-suite executives',
     'technical|developer|engineer|programmer': 'Technical professionals',
     'general audience|layman|non technical': 'General audience',
     'student|academic|education': 'Students',
     'business|corporate|professional': 'Business professionals',
     'healthcare|medical|doctor|nurse': 'Healthcare professionals',
     'sales|marketing|commerce': 'Sales and marketing',
     'legal|lawyer|attorney': 'Legal professionals',
     'finance|accountant|cpa': 'Finance professionals'
   };

   const lowerInput = input.toLowerCase();
   for (const [patterns, audience] of Object.entries(audienceKeywords)) {
     const patternArray = patterns.split('|');
     if (patternArray.some(pattern => lowerInput.includes(pattern))) {
       newAudienceTone = audience;
       console.log('[DraftWorkflow] Extracted new audience from rewrite request:', newAudienceTone);
       break;
     }
   }

   // Restore the last draft state with potentially updated parameters and regenerate
   const updatedState = {
     ...this.lastDraftState,
     wordLimit: newWordLimit,
     audienceTone: newAudienceTone,
     step: 'processing' as DraftWorkflowStep
   };
   
   this.updateState(updatedState);
   
   // Build message showing what changed
   const changes: string[] = [];
   if (newWordLimit !== this.lastDraftState.wordLimit) {
     changes.push(`**${newWordLimit} words**`);
   }
   if (newAudienceTone !== this.lastDraftState.audienceTone) {
     changes.push(`**${newAudienceTone}**`);
   }
   
   const changesText = changes.length > 0 ? ` with ${changes.join(' and ')}` : '';
   
   const message: Message = {
     role: 'assistant',
     content: `Regenerating **${this.lastDraftState.contentType}** about "**${this.lastDraftState.topic}**"${changesText}...`,
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
   this.generateDraftInChat();
 }

 /**
  * Start conversational quick draft workflow
  * Extracts word limit and audience from backend intent detection
  * Only asks for missing fields
  */
 startQuickDraftConversation(topic: string, contentType: string, initialInput?: string, wordLimit?: string, audienceTone?: string): void {
   // If topic is missing, ask for it first
   if (!topic || !topic.trim()) {
     this.updateState({
       step: 'awaiting_topic',
       topic: '',
       contentType,
       wordLimit: wordLimit || '',
       audienceTone: audienceTone || '',
       outlineDoc: '',
       supportingDoc: ''
     });
     this.askForTopic();
     return;
   }

   // If content type is missing, ask for it explicitly before other fields
   if (!contentType || !contentType.trim()) {
     this.updateState({
       step: 'awaiting_content_type',
       topic,
       contentType: '',
       wordLimit: wordLimit || '',
       audienceTone: audienceTone || '',
       outlineDoc: '',
       supportingDoc: ''
     });
     this.askForContentType();
     return;
   }

   // Topic exists, determine next step based on what's missing
   let nextStep: DraftWorkflowStep = 'awaiting_word_limit';
   let message: Message | null = null;

   // Update state first
   this.updateState({
     step: 'awaiting_word_limit', // temporary, will be updated below
     topic,
     contentType,
     wordLimit: wordLimit || '',
     audienceTone: audienceTone || '',
     outlineDoc: '',
     supportingDoc: ''
   });

   // Determine what's missing and show appropriate message
   const hasTopic = topic && topic.trim();
   const hasWordLimit = wordLimit && wordLimit.trim();
   const hasAudience = audienceTone && audienceTone.trim();

   if (hasTopic && hasWordLimit && hasAudience) {
     // All provided, go to outline
     nextStep = 'awaiting_outline_doc';
     message = {
       role: 'assistant',
       content: `Perfect! I'll create a **${contentType}** about "${topic}" with **${wordLimit} words** for **${audienceTone}**.\n\nPlease provide an outline or initial concept for this content (required). You can either type your outline or upload a PDF/document file.`,
       timestamp: new Date()
     };
   } else if (hasTopic && hasWordLimit) {
     // Missing audience
     nextStep = 'awaiting_audience';
     message = {
       role: 'assistant',
       content: `Great! I'll use **${wordLimit} words** for this content.\n\nWhat audience or tone should I use? (e.g., C-suite executives, Technical professionals, General audience)`,
       timestamp: new Date()
     };
   } else if (hasTopic && hasAudience) {
     // Missing word limit
     nextStep = 'awaiting_word_limit';
     message = {
       role: 'assistant',
       content: `Got it! I'll use **${audienceTone}** as the audience/tone.\n\nWhat word limit would you like for this content? (e.g., 2000, 2500). Reply 'no' to use the default.`,
       timestamp: new Date()
     };
   } else if (hasTopic) {
     // Missing both word limit and audience
     nextStep = 'awaiting_word_limit';
     message = {
       role: 'assistant',
       content: `What word limit would you like for this content? (e.g., 2000, 2500). Reply 'no' to use the default.`,
       timestamp: new Date()
     };
   } else {
     // Shouldn't reach here, but fallback
     nextStep = 'awaiting_word_limit';
     message = {
       role: 'assistant',
       content: `What word limit would you like for this content? (e.g., 2000, 2500). Reply 'no' to use the default.`,
       timestamp: new Date()
     };
   }

   this.updateState({ ...this.currentState, step: nextStep });
   if (message) {
     this.messageSubject.next({ type: 'prompt', message });
   }
 }

 private askForWordLimit(): void {
   // Guard: ensure content type chosen before word limit
   if (!this.currentState.contentType || !this.currentState.contentType.trim()) {
     this.updateState({ ...this.currentState, step: 'awaiting_content_type' });
     this.askForContentType();
     return;
   }
   const message: Message = {
     role: 'assistant',
      content: "What word limit would you like for this content? (e.g., 2000, 2500). Reply 'no' to use the default.",
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private askForAudience(): void {
   console.log('[DraftWorkflow] Asking for audience');
   const message: Message = {
     role: 'assistant',
     content: 'What audience or tone should I use? (e.g., C-suite executives, Technical professionals, General audience)',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private handleWordLimitResponse(input: string): void {
   const trimmedInput = input.trim();
    const lowered = trimmedInput.toLowerCase();

    console.log('[DraftWorkflow] handleWordLimitResponse input:', trimmedInput);

    // Allow user to skip and use backend defaults
    if (lowered === 'no' || lowered === 'skip' || lowered === 'default') {
      console.log('[DraftWorkflow] User skipping word limit, proceeding to audience');
      // If audience already known, proceed to outline
      if (this.currentState.audienceTone && this.currentState.audienceTone.trim()) {
        this.updateState({ ...this.currentState, wordLimit: '', step: 'awaiting_outline_doc' });
        this.askForOutlineDoc();
      } else {
        this.updateState({ ...this.currentState, wordLimit: '', step: 'awaiting_audience' });
        this.askForAudience();
      }
      return;
    }

    // Try to extract a number
    const numMatch = trimmedInput.match(/\d+/);
    console.log('[DraftWorkflow] Number match:', numMatch, 'numMatch[0]:', numMatch ? numMatch[0] : 'none');
    
    if (numMatch) {
      const wordLimit = numMatch[0];
      console.log('[DraftWorkflow] Word limit extracted:', wordLimit, 'Current audienceTone:', this.currentState.audienceTone);
      
      // If audience already known, proceed directly to outline doc
      if (this.currentState.audienceTone && this.currentState.audienceTone.trim()) {
        console.log('[DraftWorkflow] Audience already set, proceeding to outline doc');
        this.updateState({ ...this.currentState, wordLimit, step: 'awaiting_outline_doc' });
        this.askForOutlineDoc();
      } else {
        console.log('[DraftWorkflow] No audience set, asking for audience');
        this.updateState({ ...this.currentState, wordLimit, step: 'awaiting_audience' });
        this.askForAudience();
      }
    } else {
      console.log('[DraftWorkflow] No valid number found in input, re-asking for word limit');
      // No valid number found, ask again
      const message: Message = {
        role: 'assistant',
        content: "Please provide a valid word limit (a number like 2000 or 2500), or reply 'no' to use the default.",
        timestamp: new Date()
      };
      this.messageSubject.next({ type: 'prompt', message });
    }
 }

 private handleAudienceResponse(input: string): void {
   const trimmedInput = input.trim();
   const lowered = trimmedInput.toLowerCase();

   // Allow user to skip and use backend defaults
   if (lowered === 'no' || lowered === 'skip' || lowered === 'default') {
     this.updateState({ ...this.currentState, audienceTone: '', step: 'awaiting_outline_doc' });
     this.askForOutlineDoc();
     return;
   }

   this.updateState({ ...this.currentState, audienceTone: trimmedInput, step: 'awaiting_outline_doc' });
   
   // Ask about outline documents
   this.askForOutlineDoc();
 }

 private askForOutlineDoc(): void {
   const message: Message = {
     role: 'assistant',
     content: 'Please provide an outline or initial concept for this content (required). You can either type your outline or upload a PDF/document file.',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private handleOutlineDocResponse(input: string): void {
   const trimmedInput = input.trim();
   const lowered = trimmedInput.toLowerCase();

   // Outline is mandatory - do not allow skipping with "no" or "skip"
   if (lowered === 'no' || lowered === 'skip') {
     const message: Message = {
       role: 'assistant',
       content: 'An outline or initial concept is required. Please provide your outline, upload a document, or reply "done" when you\'ve finished providing your outline.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'prompt', message });
     return;
   }

   // If yes, prompt for input
   if (lowered === 'yes' || lowered === 'y') {
     const message: Message = {
       role: 'assistant',
       content: 'Please provide your outline or initial concept, then reply "done" when finished.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'prompt', message });
     return;
   }

   // If they say "done" or provide outline content, save it
   if (lowered === 'done' || trimmedInput.length > 10) {
     this.updateState({ ...this.currentState, outlineDoc: trimmedInput, step: 'awaiting_supporting_doc' });
     this.askForSupportingDoc();
     return;
   }

   // If input is substantial enough, save it as outline
   if (trimmedInput.length > 0) {
     this.updateState({ ...this.currentState, outlineDoc: trimmedInput, step: 'awaiting_supporting_doc' });
     this.askForSupportingDoc();
     return;
   }

   // Invalid response
   const message: Message = {
     role: 'assistant',
     content: 'Please provide your outline content, upload a document, or reply "done" when finished. Outline is mandatory.',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private askForSupportingDoc(): void {
   const message: Message = {
     role: 'assistant',
     content: 'Do you want to upload supporting documents to help with research? (yes/no) - You can also upload PDF, Word, or text files.',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private handleSupportingDocResponse(input: string): void {
   const trimmedInput = input.trim();
   const lowered = trimmedInput.toLowerCase();

   // If no, proceed to execution
   if (lowered === 'no' || lowered === 'skip') {
     this.updateState({ ...this.currentState, step: 'processing' });
     this.executeQuickDraftInternal();
     return;
   }

   // If yes, they need to upload via file manager
   if (lowered === 'yes' || lowered === 'y') {
     const message: Message = {
       role: 'assistant',
       content: 'Great! Please upload your supporting documents using the file upload button, then reply "done" when finished.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'prompt', message });
     return;
   }

   // If they say "done", proceed to execution
   if (lowered === 'done') {
     this.updateState({ ...this.currentState, step: 'processing' });
     this.executeQuickDraftInternal();
     return;
   }

   // Invalid response
   const message: Message = {
     role: 'assistant',
     content: 'Please reply "yes" to upload documents, "no" to skip, or "done" when finished uploading.',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 private askForOnlineDoc(): void {
   const message: Message = {
     role: 'assistant',
     content: 'Do you want to upload any online documents or references? (yes/no)',
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message });
 }

 /**
  * Internal execution method for draft content
  * Called after gathering all parameters conversationally
  */
 private async executeQuickDraftInternal(): Promise<void> {
    const { topic, contentType, wordLimit, audienceTone, outlineDoc, supportingDoc } = this.currentState;

   // Show processing message
   const processingMessage: Message = {
     role: 'assistant',
     content: `Generating **${contentType}** about "**${topic}**"...`,
     timestamp: new Date()
   };
   this.messageSubject.next({ type: 'prompt', message: processingMessage });

   try {
     // Construct the prompt matching backend expectations
     let prompt = `Please draft the following type of content:\n\n`;
     prompt += `Content Type: ${contentType}\n`;
     prompt += `Topic: ${topic}\n`;
     
     console.log('[QuickDraft] Constructed prompt:', prompt);
     console.log('[QuickDraft] Content Type:', contentType);
     console.log('[QuickDraft] Topic:', topic);
     
     if (wordLimit) {
       prompt += `Word Limit: ${wordLimit}\n`;
     }
     
     if (audienceTone) {
       prompt += `Audience/Tone: ${audienceTone}\n`;
     }

    if (outlineDoc) {
      prompt += `Initial Outline/Concept: ${outlineDoc}\n`;
    }

    if (supportingDoc) {
      prompt += `Supporting Documents: ${supportingDoc}\n`;
    }

     const messages = [{
       role: 'user' as const,
       content: prompt
     }];
     
     console.log('[QuickDraft] Sending messages to API:', JSON.stringify(messages));

     let fullResponse = '';

     // Stream the content
     this.chatService.streamDraftContent(messages).subscribe({
       next: (data: any) => {
         let chunk = '';
         if (typeof data === 'string') {
           chunk = data;
         } else if (data.type === 'content' && data.content) {
           chunk = data.content;
         }
         if (chunk) {
           console.log('[QuickDraft] Received chunk:', chunk);
         }
         fullResponse += chunk;
       },
       error: (error: any) => {
         console.error('[QuickDraft] Error generating draft:', error);
         const errorMsg: Message = {
           role: 'assistant',
           content: 'Sorry, there was an error generating your draft. Please try again.',
           timestamp: new Date()
         };
         this.messageSubject.next({ type: 'result', message: errorMsg });
         this.completeWorkflow();
       },
       complete: () => {
         console.log('[QuickDraft] Stream complete. Full response length:', fullResponse.length);
         console.log('[QuickDraft] Full response:', fullResponse.substring(0, 200) + '...');
         
         // Store the generated content and prompt for satisfaction feedback
         this.generatedDraftContent = fullResponse;
         this.lastGeneratedPrompt = prompt;
         this.awaitingSatisfactionFeedback = true;
         
         // Store original draft parameters for improvements (like guided journey)
         this.originalContentType = contentType;
         this.originalTopic = topic;
         this.originalWordLimit = wordLimit;
         this.originalAudienceTone = audienceTone;
         this.originalOutlineDoc = outlineDoc || '';
         this.originalSupportingDoc = supportingDoc || '';
         console.log('[QuickDraft] Stored original parameters for improvements:', {
           contentType, topic, wordLimit, audienceTone
         });
         
         // Send the result to chat with satisfaction question
         const resultMsg: Message = {
           role: 'assistant',
           content: fullResponse,
           timestamp: new Date(),
           thoughtLeadership: {
             contentType: this.mapContentType(contentType),
             topic: topic,
             fullContent: fullResponse,
             showActions: true
           }
         };
         this.messageSubject.next({ type: 'result', message: resultMsg });
         
         // Send satisfaction question as a system message
         const satisfactionMsg: Message = {
           role: 'system',
           content: this.getSatisfactionPromptText(),
           timestamp: new Date()
         };
         this.messageSubject.next({ type: 'prompt', message: satisfactionMsg });
       }
     });
   } catch (error) {
     console.error('[QuickDraft] Error in executeQuickDraft:', error);
     const errorMsg: Message = {
       role: 'assistant',
       content: 'Sorry, there was an error processing your request. Please try again.',
       timestamp: new Date()
     };
     this.messageSubject.next({ type: 'result', message: errorMsg });
     this.completeWorkflow();
   }
 }

 /**
  * Helper method to read file content as text
  */
 private readFileContent(file: File): Promise<string> {
   const lowerName = file.name.toLowerCase();
    // Prefer server-side extraction for rich formats
    if (lowerName.endsWith('.docx') || lowerName.endsWith('.pdf')) {
      return this.extractFileText(file);
    }

   // Legacy .doc files are binary; prompt user to upload docx/pdf/txt instead
   if (lowerName.endsWith('.doc')) {
     return Promise.reject(new Error('Legacy .doc files are not supported. Please upload .docx, .pdf, .txt, or .md.'));
   }

   return new Promise((resolve, reject) => {
     const reader = new FileReader();
     reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve(this.sanitizeTextContent(content || ''));
     };
     reader.onerror = () => {
       reject(new Error('Failed to read file'));
     };
     reader.readAsText(file);
   });
 }

  /**
   * Extracts text from a .docx file using docx-preview
   */
  private async readDocxFile(file: File): Promise<string> {
    const buffer = await file.arrayBuffer();
    const container = document.createElement('div');
    await renderAsync(buffer, container, undefined, { inWrapper: false });
    return this.sanitizeTextContent(container.innerText || '');
  }

  /**
   * Uses backend extract-text endpoint for consistent parsing (doc, docx, pdf, etc.)
   */
  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);

    const apiUrl = (window as any)._env?.apiUrl || environment.apiUrl || '';
    const response = await this.authFetchService.authenticatedFetchFormData(`${apiUrl}/api/v1/export/extract-text`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }

    const data = await response.json();
    const text = data?.text || '';
    return this.sanitizeTextContent(text);
  }

  /**
   * Extracts text from a PDF file using pdfjs-dist
   */
  private async readPdfFile(file: File): Promise<string> {
    const buffer = await file.arrayBuffer();
    const pdf = await getDocument({ data: buffer }).promise;
    let text = '';

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => ('str' in item ? item.str : ''))
        .join(' ');
      text += pageText + '\n';
    }

    return this.sanitizeTextContent(text);
  }

  /**
   * Normalize text to plain content (collapse whitespace, trim)
   */
  private sanitizeTextContent(content: string): string {
    return content.replace(/\s+/g, ' ').trim();
  }
}