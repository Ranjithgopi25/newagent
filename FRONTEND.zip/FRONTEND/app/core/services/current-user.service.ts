import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root' // singleton across the app
})
export class CurrentUserService {
  // BehaviorSubject holds the latest value and emits it to new subscribers
  private _user$ = new BehaviorSubject<User | null>(null);

  // Public observable for components to subscribe / use async pipe
  public readonly user$: Observable<User | null> = this._user$.asObservable();

  // Optional: convenience getter
  get currentUser(): User | null {
    return this._user$.getValue();
  }

  //convenience method to get first name
  private extractFirstName(fullName: string): string {
  // Removes anything inside parentheses and trims spaces
  return fullName.replace(/\(.*?\)/g, '').trim().split(' ')[0];
}

  // Set or update the user
  setUser(user: User | null) {
  if (user && user.name) {
    const firstName = this.extractFirstName(user.name);

    // Add new key to user object
    user = { ...user, firstName };
  }

  this._user$.next(user);
}


  // Clear user (logout)
  clearUser() {
    this._user$.next(null);
  }
}