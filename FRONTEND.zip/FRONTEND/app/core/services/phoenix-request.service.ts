// request.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse  } from '@angular/common/http';
import { Observable, switchMap, catchError, throwError, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RequestService {
  private tokenUrl =
    'https://api-test.us.pwc.com/oauth/getaccesstoken';

  private createRequestUrl =
    'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/createIFSRequest';

  private basicAuth =
    'Basic ellFeXlwNnJkazRBZEVKejFZQVkwWjN2V3RocW12dld5ejJJUEFzbG92eGNzYUl6OkhUcGJISFZjemFHYmhQSXZXajZHUTV3SUI3R3FOdWJLcXcwblpTRFU2aWtvam1mYmdJWndXNVhIUXd4QllHeXM=';
  
  private getConfigTLUrl = 
  //'https://publicgateway-sdp.uat.pwcinternal.com/api/v2/requests/ifsConfigData?configId=65bbf3faa00e6a0cab28f969&source=69244907b6aaf264b9629e14&configName=Thought%20Leadership%20-%20Article%20Ideation%20and%20Review';

  'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/ifsConfigData?source=69244907b6aaf264b9629e14&configId=691e34c5f186e4dd0add04f4';

  private getConfigDDCUrl = 
  //'https://publicgateway-sdp.uat.pwcinternal.com/api/v2/requests/ifsConfigData?configId=65bbf3faa00e6a0cab28f969&source=69244907b6aaf264b9629e14&configName=Document%20Development%20Center%20%28DDC%29%20Support';

 
   'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/ifsConfigData?source=69244907b6aaf264b9629e14&configId=65bbf3faa00e6a0cab28f969'

  constructor(private http: HttpClient) {}

  /** Get OAuth token */
  private getAccessToken(): Observable<any> {
    const headers = new HttpHeaders({
      Authorization: this.basicAuth
    });

    return this.http.post(this.tokenUrl, null, { headers });
  }

  /** Create request using token */
  createRequest(requestConfig: any, files: File[]): Observable<any> {
  return this.getAccessToken().pipe(
    switchMap((tokenResponse: any) => {
      const accessToken = tokenResponse.access_token; // ✅ correct

      const formData = new FormData();
      formData.append('request', JSON.stringify(requestConfig));

      files.forEach(file => {
        formData.append('files', file); // backend usually expects "files"
      });

      const headers = new HttpHeaders({
        Authorization: `Bearer ${accessToken}`
      });

      return this.http.post(this.createRequestUrl, formData, { headers }).pipe(
  catchError(err =>
    of({
      success: false,
      requestId: "0",
      status: err.status,
      errorMessage:
        err.error?.message || 'Request failed. Please try again.'
    })
  )
);
    })
  );
}

/** Get request config by configId + source */
getRequestConfig(): Observable<any> {
  return this.getAccessToken().pipe(
    switchMap((tokenResponse: any) => {
      const accessToken = tokenResponse.access_token;
      
      const headers = new HttpHeaders({
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json'
      });
      
      return this.http.get(this.getConfigTLUrl, { headers });
    })
  );
}

getRequestConfigDDC(): Observable<any> {
  return this.getAccessToken().pipe(
    switchMap((tokenResponse: any) => {
      const accessToken = tokenResponse.access_token;

      const headers = new HttpHeaders({
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json'
      });
      
      return this.http.get(this.getConfigDDCUrl, { headers });
    })
  );
}

private handleError(error: HttpErrorResponse) {
    return throwError(() => ({
      status: error.status,
      message: error.message,
      error: error.error,
      url: error.url
    }));
  }
//, catchError(this.handleError)
}
