import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

interface Source {
  number: number;
  url: string;
  title: string;
}

@Pipe({
  name: 'sourceCitation',
  standalone: true
})
export class SourceCitationPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string, sources?: Source[]): SafeHtml {
    if (!value) return this.sanitizer.bypassSecurityTrustHtml('');
    
    try {
      let text = value;
      const markers: Array<{ marker: string; html: string }> = [];
      const usedSources = new Set<number>();
      
      // Step 0: Extract and preserve existing HTML links before processing
      const htmlLinks: Array<{ placeholder: string; original: string; url: string; linkText: string }> = [];
      let linkIndex = 0;
      text = text.replace(/<a\s+[^>]*href=["']([^"']+)["'][^>]*>([^<]*)<\/a>/gi, (match, url, linkText) => {
        const placeholder = `\uE200${linkIndex}\uE201`;
        htmlLinks.push({ placeholder, original: match, url, linkText });
        linkIndex++;
        return placeholder; // Use placeholder that won't be escaped
      });
    
    // Step 1: Replace citation formats with unique Unicode markers
    if (sources && sources.length > 0) {
      const sourceMap = new Map(sources.map(s => [s.number, s]));
      // Create URL to citation number mapping (with multiple variations)
      const urlToCitationMap = new Map<string, number>();
      sources.forEach(source => {
        const url = source.url;
        // Store multiple variations for better matching
        const variations = [
          url,
          url.replace(/\/$/, ''), // without trailing slash
          url.replace(/^https?:\/\//, ''), // without protocol
          url.replace(/^https?:\/\//, '').replace(/\/$/, ''), // without protocol and trailing slash
          url.replace(/^https:\/\//, 'http://'), // http instead of https
          url.replace(/^http:\/\//, 'https://'), // https instead of http
        ];
        variations.forEach(variation => {
          urlToCitationMap.set(variation, source.number);
          urlToCitationMap.set(variation.toLowerCase(), source.number);
        });
      });
      
      // First, convert markdown links that match our sources to citations
      text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, (match, linkText, url) => {
        // Try multiple URL variations
        const variations = [
          url,
          url.replace(/\/$/, ''),
          url.replace(/^https?:\/\//, ''),
          url.replace(/^https?:\/\//, '').replace(/\/$/, ''),
          url.replace(/^https:\/\//, 'http://'),
          url.replace(/^http:\/\//, 'https://'),
        ];
        
        let citationNum: number | undefined;
        for (const variation of variations) {
          citationNum = urlToCitationMap.get(variation) || urlToCitationMap.get(variation.toLowerCase());
          if (citationNum) break;
        }
        
        if (citationNum) {
          usedSources.add(citationNum);
          // Replace markdown link with text followed by citation number
          return `${linkText} [${citationNum}.]`;
        }
        // If URL doesn't match our sources, keep the original markdown link
        return match;
      });
      
      // Handle [1.], [2.], etc. format
      text = text.replace(/\[(\d+)\.\]/g, (match, num) => {
        const sourceNum = parseInt(num, 10);
        const source = sourceMap.get(sourceNum);
        
        if (source) {
          usedSources.add(sourceNum);
          const displayTitle = source.title.length > 50 
            ? source.title.substring(0, 50) + '...' 
            : source.title;
          
          // Create unique marker using Unicode private-use area
          const marker = `\uE000${markers.length}\uE001`;
          
          // Build HTML
          const escapedUrl = this.escapeHtml(source.url);
          const escapedTitle = this.escapeHtml(source.title);
          const escapedDisplayTitle = this.escapeHtml(displayTitle);
          
          const html = `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="source-citation" title="${escapedTitle}" data-source-title="${escapedTitle}" data-source-url="${escapedUrl}"><span class="source-number">[${sourceNum}.]</span><span class="source-title-tooltip"><span class="tooltip-title">${escapedDisplayTitle}</span><span class="tooltip-url">${escapedUrl}</span></span></a>`;
          
          markers.push({ marker, html });
          return marker;
        }
        
        return match;
      });
      
      // Also handle "Web Source X" format for backward compatibility
      text = text.replace(/\(?Web Source (\d+)\)?/gi, (match, num) => {
        const sourceNum = parseInt(num, 10);
        const source = sourceMap.get(sourceNum);
        
        if (source) {
          usedSources.add(sourceNum);
          const displayTitle = source.title.length > 50 
            ? source.title.substring(0, 50) + '...' 
            : source.title;
          
          // Create unique marker using Unicode private-use area
          const marker = `\uE000${markers.length}\uE001`;
          
          // Build HTML
          const escapedUrl = this.escapeHtml(source.url);
          const escapedTitle = this.escapeHtml(source.title);
          const escapedDisplayTitle = this.escapeHtml(displayTitle);
          
          const html = `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="source-citation" title="${escapedTitle}" data-source-title="${escapedTitle}" data-source-url="${escapedUrl}"><span class="source-number">${sourceNum}</span><span class="source-title-tooltip"><span class="tooltip-title">${escapedDisplayTitle}</span><span class="tooltip-url">${escapedUrl}</span></span></a>`;
          
          markers.push({ marker, html });
          return marker;
        }
        
        return match;
      });
    }
    
    // Step 2: Escape HTML (Unicode markers survive escaping)
    text = this.escapeHtml(text);
    
    // Step 3: Replace markers with actual HTML
    markers.forEach(({ marker, html }) => {
      text = text.replace(marker, html);
    });
    
    // Step 4: Protect HTML tags from markdown processing
    // Temporarily replace HTML tags with Unicode placeholders
    const htmlTags: Array<{ placeholder: string; tag: string }> = [];
    let tagIndex = 0;
    
    // Find and replace all HTML tags
    text = text.replace(/<[^>]+>/g, (tag) => {
      // Use Unicode private-use area for placeholders (different range from source markers)
      const placeholder = `\uE100${tagIndex}\uE101`;
      htmlTags.push({ placeholder, tag });
      tagIndex++;
      return placeholder;
    });
    
    // Step 5: Convert markdown formatting (HTML tags are protected)
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/__(.*?)__/g, '<strong>$1</strong>');
    text = text.replace(/(?<!\*)\*([^*]+?)\*(?!\*)/g, '<em>$1</em>');
    text = text.replace(/(?<!_)_([^_]+?)_(?!_)/g, '<em>$1</em>');
    text = text.replace(/`(.*?)`/g, '<code>$1</code>');
    
    // Step 6: Restore HTML tags
    // Unicode placeholders weren't escaped, so direct replacement works
    htmlTags.forEach(({ placeholder, tag }) => {
      // Replace placeholder with original tag
      text = text.split(placeholder).join(tag);
    });
    
    // Step 7: Line breaks
    text = text.replace(/\n/g, '<br>');
    
    // Step 8: Add citations list at the end if sources are available
    if (sources && sources.length > 0 && usedSources.size > 0) {
      const citationsList: string[] = [];
      const sortedSources = sources
        .filter(s => usedSources.has(s.number))
        .sort((a, b) => a.number - b.number);
      
      sortedSources.forEach(source => {
        const urlWithoutProtocol = source.url.replace(/^https?:\/\//, '');
        citationsList.push(
          `<div class="citation-item"><span class="citation-number">[${source.number}.]</span><br><span class="citation-url">${this.escapeHtml(urlWithoutProtocol)}</span></div>`
        );
      });
      
      if (citationsList.length > 0) {
        text += '<div class="citations-section"><h4>Sources:</h4>' + citationsList.join('') + '</div>';
      }
    }
    
    // Step 9: Restore any HTML links that were preserved
    // The placeholders should still be in the text (they use Unicode private-use area)
    htmlLinks.forEach(({ placeholder, url, linkText }) => {
      const escapedLinkText = this.escapeHtml(linkText);
      const escapedUrl = this.escapeHtml(url);
      const restoredLink = `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer">${escapedLinkText}</a>`;
      text = text.replace(placeholder, restoredLink);
    });
    
    // Step 10: Return as trusted HTML
    return this.sanitizer.bypassSecurityTrustHtml(text);
    } catch (error) {
      console.error('Error in sourceCitation pipe:', error);
      // Fallback to simple HTML escape and line breaks
      const escaped = this.escapeHtml(value);
      return this.sanitizer.bypassSecurityTrustHtml(escaped.replace(/\n/g, '<br>'));
    }
  }
  
  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  private escapeRegex(text: string): string {
    return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
}

