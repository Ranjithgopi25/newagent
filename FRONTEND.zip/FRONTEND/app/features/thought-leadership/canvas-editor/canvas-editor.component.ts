import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { CanvasStateService } from '../../../core/services/canvas-state.service';
import { SectionParserService } from '../../../core/services/section-parser.service';
import { ChatService } from '../../../core/services/chat.service';
import { CanvasState, ContentSection, CanvasDocument } from '../../../core/models/canvas.model';

@Component({
    selector: 'app-canvas-editor',
    imports: [CommonModule, FormsModule],
    templateUrl: './canvas-editor.component.html',
    styleUrls: ['./canvas-editor.component.scss']
})
export class CanvasEditorComponent implements OnInit, OnDestroy {
  canvasState: CanvasState | null = null;
  selectedSection: ContentSection | null = null;
  showSectionEditor = false;
  editingPrompt = '';
  isStreamingUpdate = false;
  streamedContent = '';
  
  suggestedPrompts = [
    'Make this more concise',
    'Add data and statistics',
    'Change tone to formal',
    'Expand with examples',
    'Simplify the language'
  ];

  private destroy$ = new Subject<void>();

  constructor(
    private canvasStateService: CanvasStateService,
    private sectionParser: SectionParserService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.canvasStateService.state$
      .pipe(takeUntil(this.destroy$))
      .subscribe(state => {
        this.canvasState = state;
        
        if (state.selectedSectionId && state.document) {
          this.selectedSection = state.document.sections.find(
            s => s.id === state.selectedSectionId
          ) || null;
        } else {
          this.selectedSection = null;
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onSectionClick(section: ContentSection): void {
    this.canvasStateService.selectSection(section.id);
    this.showSectionEditor = true;
    this.editingPrompt = '';
    this.streamedContent = '';
  }

  onCloseSectionEditor(): void {
    this.showSectionEditor = false;
    this.canvasStateService.selectSection(null);
    this.editingPrompt = '';
    this.streamedContent = '';
  }

  onSuggestedPromptClick(prompt: string): void {
    this.editingPrompt = prompt;
  }

  onUpdateSection(): void {
    if (!this.selectedSection || !this.editingPrompt || !this.canvasState?.document) {
      return;
    }

    this.isStreamingUpdate = true;
    this.streamedContent = '';
    this.canvasStateService.setEditing(true);

    const fullArticle = this.sectionParser.sectionsToText(this.canvasState.document.sections);
    const sectionIndex = this.canvasState.document.sections.findIndex(
      s => s.id === this.selectedSection!.id
    );

    const request = {
      fullArticle: fullArticle,
      sectionIndex: sectionIndex,
      sectionContent: this.selectedSection.content,
      userPrompt: this.editingPrompt,
      contentType: this.canvasState.document.contentType
    };

    this.chatService.streamSectionUpdate(request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (chunk: string) => {
          this.streamedContent += chunk;
        },
        complete: () => {
          this.applyUpdate();
        },
        error: (error: any) => {
          console.error('Error updating section:', error);
          this.isStreamingUpdate = false;
          this.canvasStateService.setEditing(false);
        }
      });
  }

  private applyUpdate(): void {
    if (!this.selectedSection || !this.canvasState?.document) return;

    const updatedSections = this.sectionParser.updateSection(
      this.canvasState.document.sections,
      this.selectedSection.id,
      this.streamedContent,
      this.editingPrompt
    );

    this.canvasStateService.updateSections(updatedSections);
    this.isStreamingUpdate = false;
    this.canvasStateService.setEditing(false);
    this.onCloseSectionEditor();
  }

  onUndo(): void {
    this.canvasStateService.undo();
  }

  onRedo(): void {
    this.canvasStateService.redo();
  }

  onExport(format: 'word' | 'pdf' | 'text'): void {
    if (!this.canvasState?.document) return;

    const content = this.sectionParser.sectionsToText(this.canvasState.document.sections);
    
    switch (format) {
      case 'word':
        this.chatService.exportToWord({ content, title: this.canvasState.document.title }).subscribe();
        break;
      case 'pdf':
        this.chatService.exportToPDF({ content, title: this.canvasState.document.title }).subscribe();
        break;
      case 'text':
        this.chatService.exportToText({ content, title: this.canvasState.document.title }).subscribe();
        break;
    }
  }

  onClose(): void {
    this.canvasStateService.close();
  }

  getSectionTypeClass(section: ContentSection): string {
    return `section-${section.type}`;
  }

  getSectionIcon(section: ContentSection): string {
    const icons = {
      heading: '📌',
      paragraph: '📄',
      list: '📋',
      quote: '💬',
      code: '💻'
    };
    return icons[section.type] || '📄';
  }
}
