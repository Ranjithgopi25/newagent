import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

@Component({
    selector: 'app-brand-format-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './brand-format-flow.component.html',
    styleUrls: ['./brand-format-flow.component.scss']
})
export class BrandFormatFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  // Download state
  isDownloading = false;
  downloadUrl: string | null = null;
  downloadFilename = '';
  
  uploadedFile: File | null = null;
  selectedTemplate: string = 'existing';
  customTemplateFile: File | null = null;
  
  // Service toggles
  formatBullets = true;
  selectSpecificServices = false;
  consistencyInBullets = true;
  standardPracticesForBullets = true;
  removalOfPeriods = true;
  noBulletForSingle = true;
  standardizeLayout = true;
  applyChartStyling = true;
  ensureFontConsistency = true;
  improveClarity = true;
  alignToPwC = true;
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.selectedTemplate = 'existing';
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'brand-format';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    // Revoke any created object URL
    if (this.downloadUrl) {
      try { URL.revokeObjectURL(this.downloadUrl); } catch (e) {}
    }
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[BrandFormatFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = 'existing';
    this.customTemplateFile = null;
    this.formatBullets = true;
    this.selectSpecificServices = false;
    this.consistencyInBullets = true;
    this.standardPracticesForBullets = true;
    this.removalOfPeriods = true;
    this.noBulletForSingle = true;
    this.standardizeLayout = true;
    this.applyChartStyling = true;
    this.ensureFontConsistency = true;
    this.improveClarity = true;
    this.alignToPwC = true;
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
    if (this.downloadUrl) {
      try { URL.revokeObjectURL(this.downloadUrl); } catch (e) {}
    }
    this.downloadUrl = null;
    this.downloadFilename = '';
    this.isDownloading = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }
  
  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('template_file', this.customTemplateFile);
      }
      
      formData.append('align_to_pwc', String(this.alignToPwC));
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const servicesConfig = [];
      
      if (this.formatBullets) {
        const bulletService: any = { 
          id: 'format-bullets', 
          label: 'Format Bullets Using Best Practices',
          subServices: []
        };
        
        if (this.selectSpecificServices) {
          if (this.consistencyInBullets) {
            bulletService.subServices.push({ id: 'consistency-bullets', label: 'Consistency in Bullets' });
          }
          if (this.standardPracticesForBullets) {
            bulletService.subServices.push({ id: 'standard-practices', label: 'Standard Practices for Type of Bullets' });
          }
          if (this.removalOfPeriods) {
            bulletService.subServices.push({ id: 'removal-periods', label: 'Removal of Periods From Bullets' });
          }
          if (this.noBulletForSingle) {
            bulletService.subServices.push({ id: 'no-bullet-single', label: 'No Bullet for Single statement' });
          }
        }
        
        servicesConfig.push(bulletService);
      }
      
      if (this.standardizeLayout) {
        servicesConfig.push({ id: 'standardize-layout', label: 'Standardize the Layout and Space of all Elements' });
      }
      if (this.applyChartStyling) {
        servicesConfig.push({ id: 'chart-styling', label: 'Apply Consistent Styling and Colors to Charts' });
      }
      if (this.ensureFontConsistency) {
        servicesConfig.push({ id: 'font-consistency', label: 'Ensure Consistency in Fonts, Spacing, and Sizing' });
      }
      if (this.improveClarity) {
        servicesConfig.push({ id: 'improve-clarity', label: 'Improve Clarity and Finalize Document' });
      }
      if (this.alignToPwC) {
        servicesConfig.push({ id: 'pwc-brand', label: 'Align to PwC Brand Guidelines' });
      }
      
      formData.append('services', JSON.stringify(servicesConfig));

      console.log('[BrandFormatFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        template: this.selectedTemplate,
        hasCustomTemplate: !!this.customTemplateFile,
        alignToPwC: this.alignToPwC,
        services: servicesConfig
      });

      this.streamSubscription = this.chatService.streamDdcBrandFormat(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[BrandFormatFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error processing your presentation. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[BrandFormatFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[BrandFormatFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    if (!this.uploadedFile) {
      console.warn('[BrandFormatFlow] No uploaded file to download');
      return;
    }

    const formData = new FormData();
    formData.append('file', this.uploadedFile, this.uploadedFile.name);

    this.isDownloading = true;
    // Call backend endpoint that returns the formatted pptx as attachment
    this.chatService.downloadDdcFormatted(formData).subscribe({
      next: (response: any) => {
        try {
          const cd = response.headers?.get?.('Content-Disposition') || '';
          let filename = this.uploadedFile!.name.replace(/\.pptx?$/i, '') + '_formatted.pptx';
          const match = cd.match(/filename="?([^";]+)"?/);
          if (match) filename = match[1];

          const blob = new Blob([response.body], { type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' });
          const url = URL.createObjectURL(blob);

          // Store URL and filename and let user click Download
          if (this.downloadUrl) {
            try { URL.revokeObjectURL(this.downloadUrl); } catch (e) {}
          }
          this.downloadUrl = url;
          this.downloadFilename = filename;
        } catch (e) {
          console.error('[BrandFormatFlow] Download error', e);
          alert('Failed to prepare formatted file for download');
        } finally {
          this.isDownloading = false;
        }
      },
      error: (err) => {
        console.error('[BrandFormatFlow] Download failed', err);
        this.isDownloading = false;
        alert('Failed to download formatted file: ' + (err?.message || err));
      }
    });
  }

  triggerDownload(): void {
    if (!this.downloadUrl) return;
    const a = document.createElement('a');
    a.href = this.downloadUrl;
    a.download = this.downloadFilename || 'formatted.pptx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    // Optionally revoke after download
    try { URL.revokeObjectURL(this.downloadUrl); } catch (e) {}
    this.downloadUrl = null;
    this.downloadFilename = '';
  }
}
