import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

@Component({
    selector: 'app-rfp-response-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './rfp-response-flow.component.html',
    styleUrls: ['./rfp-response-flow.component.scss']
})
export class RfpResponseFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  selectedTemplate = '';
  customTemplateFile: File | null = null;
  clientName = '';
  
  // Service toggles
  harmonizeFormatting = false;
  replaceNamesAndInsights = false;
  recommendImprovements = false;
  
  // Harmonize Formatting sub-services (from Brand & Formatting)
  formatBullets = false;
  selectSpecificServices = false;
  consistencyInBullets = false;
  standardPracticesForBullets = false;
  removalOfPeriods = false;
  noBulletForSingle = false;
  standardizeLayout = false;
  applyChartStyling = false;
  ensureFontConsistency = false;
  improveClarity = false;
  
  // Additional fields
  researchTopics = '';
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'rfp-response';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[RfpResponseFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = '';
    this.customTemplateFile = null;
    this.clientName = '';
    this.harmonizeFormatting = false;
    this.replaceNamesAndInsights = false;
    this.recommendImprovements = false;
    this.formatBullets = false;
    this.selectSpecificServices = false;
    this.consistencyInBullets = false;
    this.standardPracticesForBullets = false;
    this.removalOfPeriods = false;
    this.noBulletForSingle = false;
    this.standardizeLayout = false;
    this.applyChartStyling = false;
    this.ensureFontConsistency = false;
    this.improveClarity = false;
    this.researchTopics = '';
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  onTemplateChange(): void {
    if (!this.needsCustomTemplate) {
      this.customTemplateFile = null;
    }
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (!this.selectedTemplate.trim()) return false;
    if (!this.clientName.trim()) return false;
    if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile || !this.clientName.trim()) {
      console.error('Missing required fields');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('template_file', this.customTemplateFile);
      }
      
      formData.append('client_name', this.clientName);
      formData.append('research_topics', this.researchTopics);
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const servicesConfig = [];
      
      if (this.harmonizeFormatting) {
        const harmonizeService: any = {
          id: 'harmonize-formatting',
          label: 'Harmonize Formatting',
          subServices: []
        };
        
        if (this.formatBullets) {
          const formatBulletsService: any = {
            id: 'format-bullets',
            label: 'Format Bullets Using Best Practices',
            subServices: []
          };
          
          if (this.selectSpecificServices) {
            if (this.consistencyInBullets) {
              formatBulletsService.subServices.push({ id: 'consistency-bullets', label: 'Consistency in Bullets' });
            }
            if (this.standardPracticesForBullets) {
              formatBulletsService.subServices.push({ id: 'standard-practices-bullets', label: 'Standard Practices for Type of Bullets' });
            }
            if (this.removalOfPeriods) {
              formatBulletsService.subServices.push({ id: 'removal-periods', label: 'Removal of Periods From Bullets' });
            }
            if (this.noBulletForSingle) {
              formatBulletsService.subServices.push({ id: 'no-bullet-single', label: 'No Bullet for Single statement' });
            }
          }
          
          harmonizeService.subServices.push(formatBulletsService);
        }
        
        if (this.standardizeLayout) {
          harmonizeService.subServices.push({ id: 'standardize-layout', label: 'Standardize the Layout and Space of all Elements' });
        }
        if (this.applyChartStyling) {
          harmonizeService.subServices.push({ id: 'apply-chart-styling', label: 'Apply Consistent Styling and Colors to Charts' });
        }
        if (this.ensureFontConsistency) {
          harmonizeService.subServices.push({ id: 'ensure-font-consistency', label: 'Ensure Consistency in Fonts, Spacing, and Sizing' });
        }
        if (this.improveClarity) {
          harmonizeService.subServices.push({ id: 'improve-clarity', label: 'Improve Clarity and Finalize Document' });
        }
        
        servicesConfig.push(harmonizeService);
      }
      
      if (this.replaceNamesAndInsights) {
        servicesConfig.push({ id: 'replace-names-insights', label: 'Replace Names and Insights' });
      }
      if (this.recommendImprovements) {
        servicesConfig.push({ id: 'recommend-improvements', label: 'Recommend Improvements' });
      }
      
      formData.append('services', JSON.stringify(servicesConfig));

      console.log('[RfpResponseFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        template: this.selectedTemplate,
        clientName: this.clientName,
        hasCustomTemplate: !!this.customTemplateFile,
        services: servicesConfig
      });

      this.streamSubscription = this.chatService.streamDdcRfpResponse(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[RfpResponseFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error processing your RFP response. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[RfpResponseFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[RfpResponseFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    console.log('[RfpResponseFlow] Download triggered');
  }
}
