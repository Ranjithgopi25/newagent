import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

@Component({
    selector: 'app-client-customization-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './client-customization-flow.component.html',
    styleUrls: ['./client-customization-flow.component.scss']
})
export class ClientCustomizationFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  selectedTemplate = '';
  customTemplateFile: File | null = null;
  clientName = '';
  
  // Service toggles
  updateNameAndLogo = false;
  updateQuantitativeData = false;
  updateQualitativeAssessments = false;
  outsideInTesting = false;
  
  // Additional fields
  additionalResearch = '';
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'client-customization';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[ClientCustomizationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = '';
    this.customTemplateFile = null;
    this.clientName = '';
    this.updateNameAndLogo = false;
    this.updateQuantitativeData = false;
    this.updateQualitativeAssessments = false;
    this.outsideInTesting = false;
    this.additionalResearch = '';
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  onTemplateChange(): void {
    if (!this.needsCustomTemplate) {
      this.customTemplateFile = null;
    }
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (!this.selectedTemplate.trim()) return false;
    if (!this.clientName.trim()) return false;
    if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile || !this.clientName.trim()) {
      console.error('Missing required fields');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('template_file', this.customTemplateFile);
      }
      
      formData.append('client_name', this.clientName);
      formData.append('additional_research', this.additionalResearch);
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const servicesConfig = [];
      
      if (this.updateNameAndLogo) {
        servicesConfig.push({ id: 'update-name-logo', label: 'Update Name and Logo' });
      }
      if (this.updateQuantitativeData) {
        servicesConfig.push({ id: 'update-quantitative', label: 'Update Quantitative Data Points' });
      }
      if (this.updateQualitativeAssessments) {
        servicesConfig.push({ id: 'update-qualitative', label: 'Update Qualitative Assessments' });
      }
      if (this.outsideInTesting) {
        servicesConfig.push({ id: 'outside-in-testing', label: 'Outside-in Hypothesis Testing' });
      }
      
      formData.append('services', JSON.stringify(servicesConfig));

      console.log('[ClientCustomizationFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        template: this.selectedTemplate,
        clientName: this.clientName,
        hasCustomTemplate: !!this.customTemplateFile,
        services: servicesConfig
      });

      this.streamSubscription = this.chatService.streamDdcClientCustomization(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[ClientCustomizationFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error customizing your presentation. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[ClientCustomizationFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[ClientCustomizationFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    console.log('[ClientCustomizationFlow] Download triggered');
  }
}
