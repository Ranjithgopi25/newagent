import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';

@Component({
    selector: 'app-professional-polish-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './professional-polish-flow.component.html',
    styleUrls: ['./professional-polish-flow.component.scss']
})
export class ProfessionalPolishFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  selectedTemplate = 'existing';
  customTemplateFile: File | null = null;
  
  // Service toggles
  improveLanguageAndVisuals = false;
  selectSpecificServices = false;
  underStorytellingVisuals1 = false;
  underStorytellingVisuals2 = false;
  performVisualTouchUps = false;
  validateAccuracyCharts = false;
  professionalizeWriting = false;
  provideAdditionalGuidelines = true;
  additionalGuidelines = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'professional-polish';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[ProfessionalPolishFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = 'existing';
    this.customTemplateFile = null;
    this.improveLanguageAndVisuals = false;
    this.selectSpecificServices = false;
    this.underStorytellingVisuals1 = false;
    this.underStorytellingVisuals2 = false;
    this.performVisualTouchUps = false;
    this.validateAccuracyCharts = false;
    this.professionalizeWriting = false;
    this.provideAdditionalGuidelines = true;
    this.additionalGuidelines = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return true;
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  back(): void{
    this.cancelStream();
    this.ddcFlowService.closeFlow();
    this.ddcFlowService.openGuidedDialog();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('template_file', this.customTemplateFile);
      }
      
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const servicesConfig = [];
      
      if (this.improveLanguageAndVisuals) {
        const languageService: any = { 
          id: 'improve-language-visuals', 
          label: 'Improve Language in Bullets and Enhance Visuals with Best Practices',
          subServices: []
        };
        
        if (this.selectSpecificServices) {
          if (this.underStorytellingVisuals1) {
            languageService.subServices.push({ id: 'storytelling-visuals-1', label: 'Under Storytelling Through Visuals' });
          }
          if (this.underStorytellingVisuals2) {
            languageService.subServices.push({ id: 'storytelling-visuals-2', label: 'Under Storytelling Through Visuals' });
          }
        }
        
        servicesConfig.push(languageService);
      }
      
      if (this.performVisualTouchUps) {
        servicesConfig.push({ id: 'visual-touch-ups', label: 'Perform Visual Touch-Ups' });
      }
      if (this.validateAccuracyCharts) {
        servicesConfig.push({ id: 'validate-charts', label: 'Validate Accuracy and Enhance Visuals for Charts' });
      }
      if (this.professionalizeWriting) {
        servicesConfig.push({ id: 'professionalize-writing', label: 'Professionalize Document with Consistent Writing Quality' });
      }
      if (this.provideAdditionalGuidelines) {
        servicesConfig.push({ id: 'additional-guidelines', label: 'Provide Additional Guidelines to Improve Deck' });
      }
      
      formData.append('services', JSON.stringify(servicesConfig));

      console.log('[ProfessionalPolishFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        template: this.selectedTemplate,
        hasCustomTemplate: !!this.customTemplateFile,
        services: servicesConfig
      });

      this.streamSubscription = this.chatService.streamDdcProfessionalPolish(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[ProfessionalPolishFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error processing your presentation. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[ProfessionalPolishFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[ProfessionalPolishFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    console.log('[ProfessionalPolishFlow] Download triggered');
  }
}
