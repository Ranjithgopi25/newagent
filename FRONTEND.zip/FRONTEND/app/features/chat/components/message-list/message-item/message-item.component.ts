import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Message, EditorOption } from '../../../../../core/models';
import { SourceCitationPipe } from '../../../../../core/pipes';
import { TlActionButtonsComponent } from '../tl-action-buttons/tl-action-buttons.component';
import { EditorSelectionComponent } from '../../editor-selection/editor-selection.component';

@Component({
  selector: 'app-message-item',
  standalone: true,
  imports: [SourceCitationPipe, TlActionButtonsComponent, EditorSelectionComponent],
  templateUrl: './message-item.component.html',
  styleUrls: ['./message-item.component.scss']
})
export class MessageItemComponent {
  @Input() message!: Message;
  @Input() selectedFlow?: 'ppt' | 'thought-leadership' | 'market-intelligence';
  @Output() editorsSubmitted = new EventEmitter<string[]>();

  onEditorsSubmitted(selectedIds: string[]): void {
    this.editorsSubmitted.emit(selectedIds);
  }

  onSelectionChanged(editors: EditorOption[]): void {
    if (this.message.editWorkflow?.editorOptions) {
      this.message.editWorkflow.editorOptions = editors;
    }
  }

  triggerDownload(url: string, filename: string): void {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  openPreview(url: string): void {
    window.open(url, '_blank');
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  /**
   * Format simple text for display (convert newlines to <br> tags)
   * Used for messages that are not already HTML formatted
   */
  formatSimpleText(text: string): string {
    if (!text) return '';
    // Escape HTML first to prevent XSS, then convert newlines to <br>
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML.replace(/\n/g, '<br>');
  }

  /**
   * Get formatted content for display
   * If message is HTML, return as-is. Otherwise, format as simple text.
   */
  getFormattedContent(message: Message): string {
    if (message.isHtml) {
      return message.content;
    }
    return this.formatSimpleText(message.content);
  }
}
