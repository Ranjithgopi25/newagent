import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
    selector: 'app-mi-action-buttons',
    imports: [],
    templateUrl: './mi-action-buttons.component.html',
    styleUrls: ['./mi-action-buttons.component.scss']
})
export class MiActionButtonsComponent {
  @Input() metadata: any;
  @Output() editContent = new EventEmitter<void>();
  @Output() refineContent = new EventEmitter<void>();
  @Output() formatTranslate = new EventEmitter<void>();
  @Output() generatePodcast = new EventEmitter<void>();

  onEdit(): void {
    this.editContent.emit();
  }

  onRefine(): void {
    this.refineContent.emit();
  }

  onFormat(): void {
    this.formatTranslate.emit();
  }

  onPodcast(): void {
    this.generatePodcast.emit();
  }
}
