import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';
import { MiChatBridgeService, MarketIntelligenceMetadata } from '../mi-chat-bridge.service';
import { FileUploadComponent } from '../../../shared/components/file-upload/file-upload.component';

interface EditForm {
  outlineFile: File | null;
  supportingDocsFile: File | null;
}

/**
 * Market Intelligence Draft Content Flow Component
 * Completely isolated from Thought Leadership draft content flow
 */
@Component({
    selector: 'app-mi-draft-content-flow',
    imports: [FormsModule, FileUploadComponent],
    templateUrl: './draft-content-flow.component.html',
    styleUrls: ['./draft-content-flow.component.scss']
})
export class MiDraftContentFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;

  // Form properties
  topicInput = '';
  contentTypeArticle = false;
  contentTypeBlog = false;
  contentTypeExecutiveBrief = false;
  contentTypeWhitePaper = false;
  wordLimit = '';
  audienceTone = '';
  outlineTextInput = '';
  formData: EditForm = {
    outlineFile: null,
    supportingDocsFile: null
  };

  // Research options
  conductResearch = false;
  researchTopics = '';
  pwcContentLink = false;
  pwcProprietaryResearch = false;
  pwcLicensedThirdParty = false;
  externalResearch = false;
  researchDocumentFile: File | null = null;
  researchLinks = '';
  selectSpecificPwcSources = false;
  allPwcProprietarySources = false;
  allPwcThirdPartySources = false;

  // PwC sources arrays
  pwcProprietarySources = [
    { name: 'Policy on Demand', selected: false },
    { name: 'PwC Advisory Commercial Hub', selected: false },
    { name: 'PwC Benchmarking', selected: false },
    { name: 'PwC Connected Source', selected: false },
    { name: 'Source 5', selected: false },
    { name: 'Source 6', selected: false },
    { name: 'Source 7', selected: false },
    { name: 'Source 8', selected: false },
    { name: 'Source 9', selected: false },
    { name: 'Source 10', selected: false },
    { name: 'Source 11', selected: false },
    { name: 'Source 12', selected: false },
    { name: 'Source 13', selected: false },
    { name: 'Source 14', selected: false },
    { name: 'Source 15', selected: false },
    { name: 'Source 16', selected: false },
    { name: 'Source 17', selected: false },
    { name: 'Source 18', selected: false }
  ];

  pwcThirdPartySources = [
    { name: 'Third Party Source 1', selected: false },
    { name: 'Third Party Source 2', selected: false },
    { name: 'Third Party Source 3', selected: false },
    { name: 'Third Party Source 4', selected: false },
    { name: 'Third Party Source 5', selected: false },
    { name: 'Third Party Source 6', selected: false },
    { name: 'Third Party Source 7', selected: false },
    { name: 'Third Party Source 8', selected: false },
    { name: 'Third Party Source 9', selected: false },
    { name: 'Third Party Source 10', selected: false },
    { name: 'Third Party Source 11', selected: false },
    { name: 'Third Party Source 12', selected: false },
    { name: 'Third Party Source 13', selected: false },
    { name: 'Third Party Source 14', selected: false },
    { name: 'Third Party Source 15', selected: false },
    { name: 'Third Party Source 16', selected: false },
    { name: 'Third Party Source 17', selected: false },
    { name: 'Third Party Source 18', selected: false }
  ];

  additionalGuidelines = '';
  draftContent = '';

  private destroy$ = new Subject<void>();

  constructor(
    private miFlowService: MiFlowService,
    private miChatBridge: MiChatBridgeService
  ) {}

  ngOnInit(): void {
    console.log('[MiDraftContentFlow] Component initialized');
    this.miFlowService.draftContentFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => {
        this.isOpen = isOpen;
        console.log('[MiDraftContentFlow] Flow state changed:', isOpen);
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.miFlowService.closeDraftContentFlow();
  }

  get canGenerateDraft(): boolean {
    // Must have topic
    if (!this.topicInput.trim()) return false;

    // Must have selected a content type
    if (!this.contentTypeArticle && !this.contentTypeBlog &&
      !this.contentTypeExecutiveBrief && !this.contentTypeWhitePaper) {
      return false;
    }

    // Must have EITHER outline file OR outline text input (mandatory)
    if (!this.formData.outlineFile && !this.outlineTextInput.trim()) {
      return false;
    }

    // If research is enabled, must have research topics AND at least one source
    if (this.conductResearch) {
      if (!this.researchTopics.trim()) {
        return false;
      }
      // Must have at least one research source selected
      if (!this.pwcContentLink && !this.pwcProprietaryResearch &&
        !this.pwcLicensedThirdParty && !this.externalResearch) {
        return false;
      }
    }

    return true;
  }

  get showPwcSourceSelection(): boolean {
    return this.selectSpecificPwcSources && 
           (this.pwcProprietaryResearch || this.pwcLicensedThirdParty);
  }

  get showPwcProprietarySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcProprietaryResearch;
  }

  get showPwcThirdPartySources(): boolean {
    return this.selectSpecificPwcSources && this.pwcLicensedThirdParty;
  }

  onOutlineFileSelected(file: File): void {
    this.formData.outlineFile = file;
    console.log('[MiDraftContentFlow] Outline file selected:', file.name);
  }

  onSupportingDocsFileSelected(file: File): void {
    this.formData.supportingDocsFile = file;
    console.log('[MiDraftContentFlow] Supporting docs file selected:', file.name);
  }

  onResearchDocumentSelected(file: File): void {
    this.researchDocumentFile = file;
    console.log('[MiDraftContentFlow] Research document selected:', file.name);
  }

  onAllPwcProprietaryToggle(value: boolean): void {
    this.allPwcProprietarySources = value;
    this.pwcProprietarySources.forEach(source => source.selected = value);
  }

  onPwcProprietarySourceChange(): void {
    this.allPwcProprietarySources = this.pwcProprietarySources.every(s => s.selected);
  }

  onAllPwcThirdPartyToggle(value: boolean): void {
    this.allPwcThirdPartySources = value;
    this.pwcThirdPartySources.forEach(source => source.selected = value);
  }

  onPwcThirdPartySourceChange(): void {
    this.allPwcThirdPartySources = this.pwcThirdPartySources.every(s => s.selected);
  }

  generateDraftContent(): void {
    if (!this.canGenerateDraft) {
      console.warn('[MiDraftContentFlow] Cannot generate draft - validation failed');
      return;
    }

    this.isGenerating = true;
    console.log('[MiDraftContentFlow] Starting draft generation...');

    // Simulate API call - replace with actual service call
    setTimeout(() => {
      this.draftContent = this.generateSampleContent();
      this.isGenerating = false;

      // Send to chat
      this.sendToChatWindow();
    }, 2000);
  }

  private generateSampleContent(): string {
    return `# ${this.topicInput}\n\nThis is a sample Market Intelligence draft content for demonstration.\n\n## Overview\n\nYour market research begins here.\n\n## Key Findings\n\n- Point 1\n- Point 2\n- Point 3`;
  }

  private sendToChatWindow(): void {
    let metadataContentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast' = 'article';
    if (this.contentTypeBlog) metadataContentType = 'blog';
    else if (this.contentTypeWhitePaper) metadataContentType = 'white_paper';
    else if (this.contentTypeExecutiveBrief) metadataContentType = 'executive_brief';

    const formattedContent = this.formatContentWithSpacing(this.draftContent);
    const contentWithHeader = `**Generated ${this.getContentTypeLabel(metadataContentType)}**\n\n${formattedContent}`;

    const metadata: MarketIntelligenceMetadata = {
      contentType: metadataContentType,
      topic: this.topicInput,
      fullContent: this.draftContent,
      showActions: true
    };

    console.log('[MiDraftContentFlow] Sending to chat with metadata:', metadata);
    this.miChatBridge.sendToChat(contentWithHeader, metadata);

    this.onClose();
  }

  private formatContentWithSpacing(content: string): string {
    let formatted = content
      .replace(/\n{2,}/g, '\n')
      .replace(/([^\n-*#\d])\n([^\n-*#\d])/g, '$1 $2')
      .replace(/([^\n])\n(#{1,6}\s)/g, '$1\n$2')
      .replace(/(#{1,6}\s[^\n]+)\n([^\n-*])/g, '$1\n$2')
      .replace(/([-*]\s[^\n]*)\n\n([-*]\s)/g, '$1\n$2')
      .replace(/(\d+\.\s[^\n]*)\n\n(\d+\.\s)/g, '$1\n$2')
      .trim();

    return formatted;
  }

  private getContentTypeLabel(type: string): string {
    const labels: { [key: string]: string } = {
      'article': 'Article',
      'blog': 'Blog Post',
      'white_paper': 'White Paper',
      'executive_brief': 'Executive Brief',
      'podcast': 'Podcast'
    };
    return labels[type] || 'Content';
  }

  resetForm(): void {
    this.topicInput = '';
    this.contentTypeArticle = false;
    this.contentTypeBlog = false;
    this.contentTypeExecutiveBrief = false;
    this.contentTypeWhitePaper = false;
    this.wordLimit = '';
    this.audienceTone = '';
    this.outlineTextInput = '';
    this.formData = { outlineFile: null, supportingDocsFile: null };
    this.conductResearch = false;
    this.clearResearchFields();
    this.additionalGuidelines = '';
    this.draftContent = '';
  }

  private clearResearchFields(): void {
    this.researchTopics = '';
    this.pwcContentLink = false;
    this.pwcProprietaryResearch = false;
    this.pwcLicensedThirdParty = false;
    this.externalResearch = false;
    this.researchDocumentFile = null;
    this.researchLinks = '';
    this.selectSpecificPwcSources = false;
    this.clearPwcSources();
  }

  private clearPwcSources(): void {
    this.allPwcProprietarySources = false;
    this.pwcProprietarySources.forEach(source => source.selected = false);
    this.allPwcThirdPartySources = false;
    this.pwcThirdPartySources.forEach(source => source.selected = false);
  }

  onClose(): void {
    this.miFlowService.closeDraftContentFlow();
    this.resetForm();
  }
}
