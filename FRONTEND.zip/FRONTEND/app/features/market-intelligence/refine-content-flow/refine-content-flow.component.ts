import { Component, OnInit, OnDestroy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MiFlowService } from '../mi-flow.service';

@Component({
    selector: 'app-mi-refine-content-flow',
    imports: [FormsModule],
    templateUrl: './refine-content-flow.component.html',
    styleUrls: ['./refine-content-flow.component.scss']
})
export class MiRefineContentFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  private destroy$ = new Subject<void>();

  constructor(private miFlowService: MiFlowService) {}

  ngOnInit(): void {
    this.miFlowService.refineContentFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isOpen => this.isOpen = isOpen);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onClose(): void {
    this.miFlowService.closeRefineContentFlow();
  }
}
