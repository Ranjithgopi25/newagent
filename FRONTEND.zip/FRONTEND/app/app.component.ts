import { ChangeDetectorRef, Component, inject, OnDestroy, OnInit } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
//import { OauthAdapterService } from './auth/oauth-adapter.service';
import { ChatComponent } from './components/chat/chat.component';
import { CanvasEditorComponent } from './features/thought-leadership/canvas-editor/canvas-editor.component';
import { MsalBroadcastService } from '@azure/msal-angular';
import { AuthService } from './auth/auth.service';
import { filter, Subject, Subscription, take, takeUntil, tap } from 'rxjs';
import { InteractionStatus } from '@azure/msal-browser';
import { environment } from '../environments/environment';
import { CurrentUserService } from './core/services/current-user.service';
import { User } from './core/models/user.model';


const ENABLE_AUTH = environment.useAuth;
@Component({
    selector: 'app-root',
    imports: [RouterOutlet, ChatComponent, CanvasEditorComponent],
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss'
})
/*
export class AppComponent {
  title = 'MCX AI - PwC Presentation Assistant';
 
}
*/


  export class AppComponent implements OnInit, OnDestroy {
    title = 'MCX AI - PwC Presentation Assistant';
  

  // Inject services
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);
  private msalBroadcastService = ENABLE_AUTH ? inject(MsalBroadcastService) : null;//change when login implemented
  private authService = inject(AuthService);
  private currentUserService = inject(CurrentUserService);

  //public loadingService = inject(LoadingService);
  authInitialized = false;  
  currentUrl: string = '';
 // chatOpen = false;
 // chatOpenTimeEntry = false;
  currentUser: any = { name: 'Test' }; //change when login implemented
  isLoading = true;
  loginComplete = false; //change when login implemented
  loginprogress=false;
 // private routerSubscription: Subscription;
  private readonly _destroying$ = new Subject<void>();

  
  constructor() {
    /*
    this.currentUrl = this.router.url;
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.currentUrl = event.url;
      });
      */
  }

 ngOnInit() {
  
  // Check if returning from redirect
  const urlParams = new URLSearchParams(window.location.search);
  const hasCode = urlParams.has('code');
  const hasError = urlParams.has('error');
  const hasState = urlParams.has('state');
  

 // this.loadingService.setLoading(true);
  
  if (ENABLE_AUTH && this.msalBroadcastService) {
    let subscriptionId = Math.random().toString(36).substr(2, 9);
    
    let emissionCount = 0;
    
    this.msalBroadcastService.inProgress$
      .pipe(
        tap((status) => {
          emissionCount++;
        }),
        filter((status: InteractionStatus) => {
          const isNone = status === InteractionStatus.None;
          return isNone;
        }),
        take(1),
        takeUntil(this._destroying$)
      )
      .subscribe({
        next: () => {

          this.handleMsalCallback(subscriptionId);
        },
        error: (error) => {

        },
        complete: () => {

        }
      });
  }
}

private async handleMsalCallback(subscriptionId: string) {
  
  this.authInitialized = true;
  
  if (this.authService.isLoggedIn()) {
    this.loginComplete = true;
    this.currentUser = this.authService.getUserInfo();
    console.log('User info:', this.currentUser);
    // push it into the shared service
    this.currentUserService.setUser(this.currentUser as User);
    const token = await this.authService.getAccessToken();
      
      if (token) {
        //console.log(token);
      }
    this.isLoading = false;
   // this.loadingService.setLoading(false);
  } else if (!this.loginprogress) {
    
    this.loginprogress = true;

    setTimeout(() => {
      this.authService.login();
    }, 500);
  } else {

  }
  
  this.cdr.detectChanges();
}

  ngOnDestroy() {
    this._destroying$.next(undefined);
    this._destroying$.complete();
    /*
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
      */
  }

  logout() {
    this.authService.logout();
    this.currentUserService.clearUser();
  }

  shouldShowChatWidget(): boolean {
    return this.currentUrl === '/calendar-management' && this.loginComplete;
  }

  shouldShowTimeEntryWidget(): boolean {
    return (this.currentUrl === '/' || this.currentUrl === '/time-entry') && this.loginComplete;
  }
}