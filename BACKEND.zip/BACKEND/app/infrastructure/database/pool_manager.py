"""
Database connection pool manager for optimized high-concurrency operations.
Provides connection pooling for 1000+ concurrent users with minimal latency.
"""
import logging
from sqlalchemy.pool import QueuePool
import pyodbc

logger = logging.getLogger(__name__)


class SQLServerPoolManager:
    """Manages SQL Server connection pools for chat history persistence."""
    
    _pool = None
    _initialized = False
    
    @classmethod
    def initialize(cls, connection_string: str):
        """
        Initialize connection pool with optimized settings.
        
        Args:
            connection_string: SQL Server ODBC connection string
        """
        if cls._initialized and cls._pool is not None:
            logger.info("✅ SQL Server connection pool already initialized")
            return
        
        try:
            def create_connection():
                """Create new connection from pool."""
                conn = pyodbc.connect(connection_string, timeout=20)
                conn.setdecoding(pyodbc.SQL_CHAR, encoding='utf-8')
                conn.setdecoding(pyodbc.SQL_WCHAR, encoding='utf-8')
                conn.setencoding(encoding='utf-8')
                return conn
            
            cls._pool = QueuePool(
                create_connection,
                max_overflow=30,        # Max additional connections beyond pool_size
                pool_size=20,           # Base pool size
                timeout=30,             # Wait up to 30s for connection
                recycle=3600            # Recycle connections every hour
            )
            
            cls._initialized = True
            logger.info("✅ SQL Server connection pool initialized (size: 20, overflow: 30)")
        
        except Exception as e:
            logger.error(f"❌ Failed to initialize SQL Server pool: {e}")
            raise
    
    @classmethod
    def get_connection(cls):
        """
        Get a connection from the pool (reuses existing connections).
        
        Returns:
            pyodbc connection object
        """
        if cls._pool is None:
            raise RuntimeError("Connection pool not initialized. Call initialize() first.")
        
        return cls._pool.connect()
    
    @classmethod
    def dispose(cls):
        """Close all connections in pool."""
        if cls._pool:
            cls._pool.dispose()
            cls._pool = None
            cls._initialized = False
            logger.info("✅ SQL Server connection pool disposed")


class DatabasePoolManager:
    """Main database pool manager for the application."""
    
    _sqlserver = None
    
    @classmethod
    def initialize(cls, sqlserver_connection_string: str = None):
        """
        Initialize all database pools.
        
        Args:
            sqlserver_connection_string: SQL Server connection string
        """
        if sqlserver_connection_string:
            try:
                SQLServerPoolManager.initialize(sqlserver_connection_string)
                logger.info("✅ DatabasePoolManager initialized successfully")
            except Exception as e:
                logger.error(f"❌ DatabasePoolManager initialization failed: {e}")
                raise
    
    @classmethod
    def get_sqlserver_connection(cls):
        """Get SQL Server connection from pool."""
        return SQLServerPoolManager.get_connection()
    
    @classmethod
    def close(cls):
        """Close all connections."""
        SQLServerPoolManager.dispose()
        logger.info("✅ All database pools closed")
