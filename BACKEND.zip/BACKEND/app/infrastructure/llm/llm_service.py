"""
Unified LLM Service - Single interface for Azure OpenAI.
No providers, no fallback, no threading complexity.
"""

import json
import logging
from typing import List, Dict, Optional, AsyncIterator
from openai import AsyncAzureOpenAI
from app.core.config import config

logger = logging.getLogger(__name__)


class LLMService:
    """Simple, unified LLM service using Azure OpenAI"""

    def __init__(self):
        """Initialize Azure OpenAI async client"""
        if not config.AZURE_OPENAI_API_KEY:
            raise ValueError("AZURE_OPENAI_API_KEY not configured")
        if not config.AZURE_OPENAI_ENDPOINT:
            raise ValueError("AZURE_OPENAI_ENDPOINT not configured")

        self.client = AsyncAzureOpenAI(
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
        )
        self.model = config.AZURE_OPENAI_DEPLOYMENT
        logger.info(f"LLMService initialized with model: {self.model}")

    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """
        Non-streaming chat completion.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature (0-2)
            max_tokens: Max response tokens
            
        Returns:
            Response text string
        """
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Chat completion failed: {e}")
            raise

    async def stream_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """
        Native async streaming chat completion.
        Yields SSE-formatted data chunks in real-time.
        
        Args:
            messages: List of message dicts
            temperature: Sampling temperature
            max_tokens: Max response tokens
            
        Yields:
            SSE-formatted data with type field: {"type": "content", "content": "..."}
        """
        try:
            stream = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )
            async for chunk in stream:
                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    # Yield as SSE format with type field
                    yield f"data: {json.dumps({'type': 'content', 'content': content})}\n\n"

            # Signal completion with type field
            yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"

        except Exception as e:
            logger.error(f"Stream completion failed: {e}")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"

    def sanitize_text(
        self,
        text: str,
        context: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 2000,
    ) -> str:
        """Sanitize text by removing unwanted content"""
        import asyncio
        
        system_prompt = "Remove any unwanted content and return clean text only."
        if context:
            system_prompt += f"\nContext: {context}"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": text},
        ]

        try:
            return asyncio.run(self.chat_completion(messages, temperature, max_tokens))
        except Exception as e:
            logger.warning(f"Text sanitization failed, returning original: {e}")
            return text

    def fix_grammar(
        self,
        text: str,
        temperature: float = 0.0,
        max_tokens: int = 2000,
    ) -> str:
        """Fix grammar and spelling in text"""
        import asyncio
        
        messages = [
            {
                "role": "system",
                "content": "Fix grammar, spelling, and punctuation. Return only corrected text."
            },
            {"role": "user", "content": text},
        ]

        try:
            return asyncio.run(self.chat_completion(messages, temperature, max_tokens))
        except Exception as e:
            logger.warning(f"Grammar fix failed, returning original: {e}")
            return text

# Global singleton instance (created once)
_llm_service: Optional[LLMService] = None


async def get_llm_service() -> LLMService:
    """
    Dependency injection function for FastAPI.
    Returns singleton LLMService instance.
    """
    global _llm_service
    
    if _llm_service is None:
        _llm_service = LLMService()
    
    return _llm_service

