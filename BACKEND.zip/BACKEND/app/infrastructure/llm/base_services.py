"""Base classes for workflow services"""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, AsyncIterator
from app.common.ppt_utils import load_presentation, save_presentation
from app.infrastructure.llm.llm_service import LLMService
from app.core.exceptions import WorkflowException
import logging
import json

logger = logging.getLogger(__name__)


class BaseWorkflowService(ABC):
    """Base class for all workflow services"""
    
    def __init__(self, llm_service: LLMService):
        self.llm_service = llm_service
    
    @abstractmethod
    async def execute(self, *args, **kwargs):
        """Execute the workflow logic"""
        pass


class BasePPTWorkflowService(BaseWorkflowService):
    """Base class for PPT processing workflows"""
    
    def load_ppt(self, ppt_bytes: bytes):
        """Load PowerPoint presentation from bytes"""
        try:
            return load_presentation(ppt_bytes)
        except Exception as e:
            logger.error(f"Failed to load presentation: {e}")
            raise WorkflowException(f"Failed to load presentation: {str(e)}")
    
    def save_ppt(self, prs) -> bytes:
        """Save PowerPoint presentation to bytes"""
        try:
            return save_presentation(prs)
        except Exception as e:
            logger.error(f"Failed to save presentation: {e}")
            raise WorkflowException(f"Failed to save presentation: {str(e)}")


class BaseTLStreamingService(BaseWorkflowService):
    """Base class for Thought Leadership streaming services"""
    
    async def execute(self, *args, **kwargs):
        """Default implementation - override in subclasses"""
        raise NotImplementedError("Subclasses must implement execute()")
    
    async def stream_response(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """Stream LLM response as SSE-formatted chunks with type field"""
        try:
            async for chunk in self.llm_service.stream_completion(messages, temperature, max_tokens):
                yield chunk
        except Exception as e:
            logger.error(f"Stream response failed: {e}")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
    
    async def get_content(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Get raw LLM response content (for internal processing)"""
        try:
            return await self.llm_service.chat_completion(messages, temperature, max_tokens)
        except Exception as e:
            logger.error(f"Get content failed: {e}")
            raise
