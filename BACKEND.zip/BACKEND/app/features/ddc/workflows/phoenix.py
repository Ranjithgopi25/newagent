from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import json
import time
import logging
import requests
from typing import List,Optional

logger = logging.getLogger(__name__)

router = APIRouter()

# -------------------------------------------------------------------
# CONFIG (use env vars in real usage)
# -------------------------------------------------------------------

TOKEN_URL = 'https://api-test.us.pwc.com/oauth/getaccesstoken'
BASIC_AUTH = 'Basic ellFeXlwNnJkazRBZEVKejFZQVkwWjN2V3RocW12dld5ejJJUEFzbG92eGNzYUl6OkhUcGJISFZjemFHYmhQSXZXajZHUTV3SUI3R3FOdWJLcXcwblpTRFU2aWtvam1mYmdJWndXNVhIUXd4QllHeXM='

CREATE_REQUEST_URL = 'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/createIFSRequest'
GET_CONFIG_DDC_URL = 'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/ifsConfigData?source=69244907b6aaf264b9629e14&configId=65bbf3faa00e6a0cab28f969'
GET_CONFIG_TL_URL = 'https://api-test.us.pwc.com/sdp-uat/api/v2/requests/ifsConfigData?source=69244907b6aaf264b9629e14&configId=691e34c5f186e4dd0add04f4'

REQUEST_TIMEOUT = 60

# -------------------------------------------------------------------
# OAUTH TOKEN (cached)
# -------------------------------------------------------------------

_cached_token = None
_token_expiry = 0


def get_access_token() -> str:
    global _cached_token, _token_expiry

    if _cached_token and time.time() < _token_expiry:
        return _cached_token

    headers = {
        "Authorization": BASIC_AUTH
    }

    response = requests.post(TOKEN_URL, headers=headers, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()

    token_response = response.json()
    _cached_token = token_response["access_token"]

    #expires_in = token_response.get("expires_in", 3600)
    expires_in = int(token_response.get("expires_in", 3600))
    _token_expiry = time.time() + expires_in - 60

    return _cached_token

# -------------------------------------------------------------------
# INTERNAL HELPERS
# -------------------------------------------------------------------

def fetch_request_config_ddc():
    access_token = get_access_token()

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }

    response = requests.get(
        GET_CONFIG_DDC_URL,
        headers=headers,
        timeout=REQUEST_TIMEOUT
    )
    response.raise_for_status()
    return response.json()

def fetch_request_config_tl():
    access_token = get_access_token()

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }

    response = requests.get(
        GET_CONFIG_TL_URL,
        headers=headers,
        timeout=REQUEST_TIMEOUT
    )
    response.raise_for_status()
    return response.json()


def create_phoenix_request(request_config: dict, files: List[UploadFile]):
    access_token = get_access_token()

    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    multipart_files = []
    multipart_files.append(
        ("request", (None, json.dumps(request_config), "application/json"))
    )
    if files:
        for file in files:
            multipart_files.append(
                ("files", (file.filename, file.file, file.content_type))
            )

    response = requests.post(
        CREATE_REQUEST_URL,
        headers=headers,        
        files=multipart_files,
        timeout=REQUEST_TIMEOUT
    )

    response.raise_for_status()
    return response.json()

def error_response(status: int, message: str):
    return JSONResponse(
        status_code=status,
        content={
            "success": False,
            "status": status,
            "errorMessage": message
        }
    )


# -------------------------------------------------------------------
# ROUTES
# -------------------------------------------------------------------

@router.get("/request-config-ddc")
async def get_request_config():
    """
    Fetch Phoenix DDC request configuration
    """
    try:
        return fetch_request_config_ddc()

    except requests.HTTPError as e:
        logger.exception("Failed to fetch Phoenix config")
        return {
            "success": False,
            "status": e.response.status_code,
            "errorMessage": e.response.text
        }

    except Exception as e:
        logger.exception("Unexpected error")
        raise HTTPException(status_code=500, detail=str(e))
    

@router.get("/request-config-tl")
async def get_request_config():
    """
    Fetch Phoenix TL request configuration
    """
    try:
        return fetch_request_config_tl()

    except requests.HTTPError as e:
        logger.exception("Failed to fetch Phoenix config")
        return {
            "success": False,
            "status": e.response.status_code,
            "errorMessage": e.response.text
        }

    except Exception as e:
        logger.exception("Unexpected error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/create-request")
async def create_request(
    request: str = Form(...),
    files: Optional[List[UploadFile]] = File(None)
):
    """
    Create Phoenix DDC request
    """
    logger.info("[PhoenixRequest] Creating request")
    
    try:
        request_config = json.loads(request)
        return create_phoenix_request(request_config, files)

    except requests.HTTPError as e:
        logger.exception("Phoenix request creation failed")

        error_message = getattr(e.response, "text", str(e))
        try:
            error_json = e.response.json()
            # Use the "message" field if present
            error_message = error_json.get("message", error_message)
        except Exception:
            pass
        
        return {
            "success": False,
            "requestId": "0",
            "status": e.response.status_code,
            "errorMessage": error_message
        }

    except Exception as e:
        logger.exception("Unexpected error")
        raise HTTPException(status_code=500, detail=str(e))
