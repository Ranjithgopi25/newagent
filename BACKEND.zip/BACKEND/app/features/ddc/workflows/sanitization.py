from fastapi import APIRouter, File, UploadFile, Form, Depends, HTTPException
from fastapi.responses import Response
from app.core.deps import get_llm_service
from app.infrastructure.llm.llm_service import LLMService
from app.features.ddc.services.sanitization.tool import SanitizationService
from typing import Optional
import json
import logging


router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("", include_in_schema=True)
@router.post("/", include_in_schema=True)
async def sanitization_workflow(
    file: UploadFile = File(...),
    template: str = Form("core"),
    custom_template: Optional[UploadFile] = File(None),
    client_identifiers: str = Form(""),
    services: str = Form(...),
    additional_guidelines: str = Form(""),
    llm_service: LLMService = Depends(get_llm_service)
):
    """
    Presentation Sanitization workflow: Actually sanitize and return modified PPTX file
    """
    try:
        logger.info(f"[Sanitization] Processing: {file.filename}")
        
        if not file.filename or not file.filename.endswith('.pptx'):
            raise HTTPException(status_code=400, detail="Only .pptx files are supported")
        
        try:
            selected_services = json.loads(services)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid services format")
        
        if not selected_services:
            raise HTTPException(status_code=400, detail="At least one service must be selected")
        
        ppt_bytes = await file.read()
        template_bytes = await custom_template.read() if custom_template else None
        
        # Initialize service with centralized LLM service
        service = SanitizationService(llm_service)
        
        # Perform actual sanitization
        sanitized_bytes, plan = await service.sanitize_presentation(
            ppt_bytes, 
            file.filename,
            selected_services,
            client_identifiers,
            template,
            template_bytes,
            llm_service,
            additional_guidelines=additional_guidelines
        )
        
        # Generate output filename
        output_filename = file.filename.replace('.pptx', '_sanitized.pptx')
        
        # Log sanitization plan
        logger.info(f"[Sanitization] Plan: {plan['summary']}")
        for item in plan['items']:
            logger.info(f"  - {item['label']}: {item['details']}")
        
        # Return sanitized file with full plan in headers for frontend display
        return Response(
            content=sanitized_bytes,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={
                "Content-Disposition": f'attachment; filename="{output_filename}"',
                "X-Sanitization-Summary": json.dumps(plan['summary']),
                "X-Sanitization-Plan": json.dumps(plan['items'])  # Full plan for frontend display
            }
        )
        
    except Exception as e:
        logger.error(f"[Sanitization] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
