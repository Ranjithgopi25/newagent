from app.features.chat.router import get_router

__all__ = ["get_router"]
