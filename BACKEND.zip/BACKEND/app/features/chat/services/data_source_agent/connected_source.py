"""
Passage Retrieval Service for CS GenAI API.
Fetches relevant passages from the GenAI knowledge base.
"""

import logging
import json
import httpx
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class PassageRetrievalService:
    """Service for retrieving passages from CS GenAI API."""
    
    def __init__(
        self,
        api_url: str = "https://gif-apim.pwc.com/cs-genai/api/genaiv2/passageretrieval",
        subscription_key: str = "45ccdc950cad4d3fb873c2dc7804b373",
        sc_apikey: str = "34D44659-6E16-4792-A506-1E0C98B44A4C"
    ):
        """
        Initialize the passage retrieval service.
        
        Args:
            api_url: CS GenAI API endpoint
            subscription_key: Subscription key for API access
            sc_apikey: Service client API key
        """
        self.api_url = api_url
        self.subscription_key = subscription_key
        self.sc_apikey = sc_apikey
    
    async def retrieve_passages(
        self,
        query: str,
        additional_fields: str = "entityurl"
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant passages for a query.
        
        Args:
            query: Search query text
            additional_fields: Additional fields to return (default: "entityurl")
        
        Returns:
            List of passage dictionaries with text, relevance score, and document info
        """
        try:
            querystring = {"subscription-key": self.subscription_key}
            
            payload = {
                "input": query,
                "additionalFields": additional_fields
            }
            
            headers = {
                "accept": "application/json",
                "sc_apikey": self.sc_apikey,
                "content-type": "application/json"
            }
            
            logger.info(f"[PassageRetrievalService] Fetching passages for: {query}")
            
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    self.api_url,
                    json=payload,
                    headers=headers,
                    params=querystring
                )
                
                response.raise_for_status()
                result = response.json()
            
            # Parse the result string if it's nested JSON
            if isinstance(result, dict) and "result" in result:
                passages = json.loads(result["result"])
            elif isinstance(result, list):
                passages = result
            else:
                passages = []
            
            # logger.info(f"[PassageRetrievalService] Retrieved {len(passages)} passages")
            # logger.info(f"[PassageRetrievalService] Parsed Passages: {json.dumps(passages, indent=2)}")

            return passages
            
        except httpx.HTTPError as e:
            logger.error(f"[PassageRetrievalService] HTTP error: {e}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"[PassageRetrievalService] JSON parse error: {e}")
            raise
        except Exception as e:
            logger.error(f"[PassageRetrievalService] Error: {e}")
            raise
    
    def format_response(self, passages: List[Dict[str, Any]]) -> str:
        """
        Format passages for LLM consumption.
        
        Args:
            passages: List of passage dictionaries
        
        Returns:
            Formatted text response
        """
        if not passages:
            return "No relevant passages found."
        
        formatted_lines = ["**CS GenAI Knowledge Base Results:**\n"]
        
        for idx, passage in enumerate(passages, 1):
            text = passage.get("text", "N/A")
            relevance_score = passage.get("relevanceScore", 0)
            document = passage.get("document", {})
            
            doc_title = document.get("title", "Unknown")
            entity_url = document.get("entityurl", "")
            
            formatted_lines.append(f"\n**Passage {idx}:** (Relevance: {relevance_score:.2%})")
            formatted_lines.append(f"**Source:** {doc_title}")
            
            if entity_url:
                formatted_lines.append(f"**URL:** {entity_url}")
            
            formatted_lines.append(f"\n{text}\n")
            formatted_lines.append("-" * 80)
        
        return "\n".join(formatted_lines)