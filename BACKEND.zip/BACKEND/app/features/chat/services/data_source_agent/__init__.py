"""
Data Source Agent Package.
Provides intelligent data source detection and fetching from Factiva, CapitalIQ, and BoardEx.
"""

# from .agent import DataSourceAgent
from .langgraph_agent import DataSourceLangGraphAgent, create_data_source_agent
from .factiva_service import FactivaService
from .capitaliq_service import CapitalIQService
from .boardex_service import BoardExService
from .connected_source import  PassageRetrievalService
from .benchmarking_service import BenchmarkingAPIClient
from .tools import get_all_tools, set_services
# from .config import FACTIVA_CONFIG, SQLSERVER_CONFIG, DATABRICKS_CONFIG
from app.core.config import get_settings

from .ppt_service import PPTService

settings = get_settings()
FACTIVA_CONFIG = {
    "auth_url": settings.FACTIVA_AUTH_URL,
    "content_url": settings.FACTIVA_CONTENT_URL,
    "username": settings.FACTIVA_USERNAME,
    "client_id": settings.FACTIVA_CLIENT_ID,
    "password": settings.FACTIVA_PASSWORD
}
SQLSERVER_CONFIG = {
    "server": settings.SQLSERVER_SERVER,
    "database": settings.SQLSERVER_DATABASE,
    "username": settings.SQLSERVER_USERNAME,
    "password": settings.SQLSERVER_PASSWORD
}
DATABRICKS_CONFIG = {
    "host": settings.DATABRICKS_HOST,
    "http_path": settings.DATABRICKS_HTTP_PATH,
    "access_token": settings.DATABRICKS_TOKEN,
    "catalog": settings.DATABRICKS_CATALOG,
    "schema": settings.DATABRICKS_SCHEMA
}
PASSAGE_RETRIEVAL_CONFIG = {
    "api_url": settings.PASSAGE_RETRIEVAL_API_URL,
    "subscription_key": settings.PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY,
    "sc_apikey": settings.PASSAGE_RETRIEVAL_SC_APIKEY
}


__all__ = [
    # "DataSourceAgent",
    "DataSourceLangGraphAgent",
    "create_data_source_agent",
    "PPTService",
    "FactivaService", 
    "CapitalIQService",
    "BoardExService",
    "PassageRetrievalService",
    "get_all_tools",
    "set_services",
    "FACTIVA_CONFIG",
    "SQLSERVER_CONFIG",
    "DATABRICKS_CONFIG",
    "PASSAGE_RETRIEVAL_CONFIG",
    "BenchmarkingAPIClient"
]