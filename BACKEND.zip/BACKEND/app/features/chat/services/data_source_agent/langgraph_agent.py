"""
LangGraph Agent for Data Source Integration.
Uses tool calling to intelligently fetch data from multiple sources.
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, AsyncIterator, Annotated, TypedDict
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from app.core.deps import get_llm_service
from app.infrastructure.llm.llm_service import LLMService


from .prompts import SYSTEM_PROMPT
from .tools import get_all_tools, set_services
from .factiva_service import FactivaService
from .capitaliq_service import CapitalIQService
from .boardex_service import BoardExService
from .ai_search_service import AISearchService
from .connected_source import PassageRetrievalService
from .tavily_service import TavilyService
from .benchmarking_service import BenchmarkingAPIClient
from app.features.thought_leadership.services.refine_content_service import RefineContentService
from app.core.config import get_settings
settings = get_settings()
AI_SEARCH_CONFIG = {
    "endpoint": settings.AI_SEARCH_ENDPOINT,
    "index_name": settings.AI_SEARCH_INDEX_NAME,
    "api_key": settings.AI_SEARCH_API_KEY
}

logger = logging.getLogger(__name__)

class AgentState(TypedDict):
    """State for the agent graph."""
    messages: Annotated[List[BaseMessage], add_messages]

llm_service = get_llm_service()

class DataSourceLangGraphAgent:
    """
    LangGraph-based agent for data source integration.
    Uses tool calling for intelligent routing to data sources.
    """
    
    def __init__(
        self,
        azure_endpoint: Optional[str] = None,
        api_key: Optional[str] = None,
        api_version: Optional[str] = None,
        deployment_name: Optional[str] = None
    ):
        """Initialize the agent with Azure OpenAI and data source services."""
        
        # Get config from environment if not provided
        self.azure_endpoint = azure_endpoint or os.getenv("AI_ENDPOINT")
        self.api_key = api_key or os.getenv("AI_API_KEY")
        self.api_version = api_version or os.getenv("AI_API_VERSION", "2024-08-01-preview")
        self.deployment_name = deployment_name or os.getenv("AI_MODEL_NAME", "gpt-4o")
        self.passage_retrieval_service = PassageRetrievalService(
                api_url=settings.PASSAGE_RETRIEVAL_API_URL,
                subscription_key=settings.PASSAGE_RETRIEVAL_SUBSCRIPTION_KEY,
                sc_apikey=settings.PASSAGE_RETRIEVAL_SC_APIKEY
            )
        
        if not self.azure_endpoint or not self.api_key:
            raise ValueError("Azure OpenAI endpoint and API key are required")
        
        # Initialize LLM
        self.llm = AzureChatOpenAI(
            azure_endpoint=self.azure_endpoint,
            api_key=self.api_key,
            api_version=self.api_version,
            azure_deployment=self.deployment_name,
            temperature=0.3,
            streaming=True
        )
        self.ai_search_service = AISearchService(
            endpoint=AI_SEARCH_CONFIG["endpoint"],
            index_name=AI_SEARCH_CONFIG["index_name"],
            api_key=AI_SEARCH_CONFIG["api_key"]
        )
        # Initialize data source services
        self.factiva_service = FactivaService()
        self.capitaliq_service = CapitalIQService()
        self.boardex_service = BoardExService()
        self.refine_service = RefineContentService(llm_service=LLMService())
        self.passage_retrieval_service = PassageRetrievalService()
        self.tavily_service = TavilyService(api_key=settings.TAVILY_API_KEY)
        self.benchmarking_service = BenchmarkingAPIClient()
        logger.info("[DataSourceAgent] Tavily service initialized")
        
        # Inject services into tools
        set_services(
            factiva=self.factiva_service,
            capitaliq=self.capitaliq_service,
            boardex=self.boardex_service,
            ai_search=self.ai_search_service,
            refine=self.refine_service,
            passage_retrieval=self.passage_retrieval_service,
            tavily=self.tavily_service,
            benchmarking=self.benchmarking_service
        )
        
        # Get tools and bind to LLM
        self.tools = get_all_tools()
        tool_names = [tool.name for tool in self.tools]
        logger.info(f"[DataSourceAgent] Tools registered: {tool_names}")
        self.llm_with_tools = self.llm.bind_tools(self.tools)
        
        # Build the graph
        self.graph = self._build_graph()
        
        # logger.info(f"[DataSourceAgent] Initialized with {len(self.tools)} tools")
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow."""
        
        # Create graph
        graph_builder = StateGraph(AgentState)
        
        # Add nodes
        graph_builder.add_node("agent", self._agent_node)
        graph_builder.add_node("tools", ToolNode(tools=self.tools))
        
        # Add edges
        graph_builder.add_edge(START, "agent")
        graph_builder.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "continue": "tools",
                "end": END
            }
        )
        graph_builder.add_edge("tools", "agent")
        
        # Compile
        return graph_builder.compile()
    
    async def _agent_node(self, state: AgentState) -> Dict[str, Any]:
        """Agent node that decides what to do next."""
        messages = state["messages"]
        
        # Add system prompt if not present
        if not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=SYSTEM_PROMPT)] + messages
        
        # Debug: Log what we're sending to LLM
        # logger.info(f"[DataSourceAgent] _agent_node called with {len(messages)} messages")
        for i, msg in enumerate(messages):
            msg_type = type(msg).__name__
            content_preview = msg.content[:150] if hasattr(msg, 'content') else 'no content'
            # logger.info(f"[DataSourceAgent]   Message {i} ({msg_type}): {content_preview}...")
        
        # Check for PPT keywords
        # last_user_message = None
        # for msg in reversed(messages):
        #     if isinstance(msg, HumanMessage):
        #         last_user_message = msg.content.lower()
        #         break
        
        # if last_user_message:
        #     ppt_keywords = ['ppt', 'presentation', 'deck', 'slides', 'powerpoint', 'slideshow']
        #     has_ppt_keyword = any(keyword in last_user_message for keyword in ppt_keywords)
        #     # logger.info(f"[DataSourceAgent] User message contains PPT keywords: {has_ppt_keyword}")
        #     if has_ppt_keyword:
        #         logger.info(f"[DataSourceAgent] 🎯 PPT REQUEST DETECTED: '{last_user_message[:100]}'")
        
        # Call LLM
        # logger.info(f"[DataSourceAgent] Calling LLM with tools...")
        response = await self.llm_with_tools.ainvoke(messages)
        
        # Debug: Log response details
        # logger.info(f"[DataSourceAgent] LLM Response received")
        # logger.info(f"[DataSourceAgent]   Response type: {type(response)}")
        # logger.info(f"[DataSourceAgent]   Has tool_calls attribute: {hasattr(response, 'tool_calls')}")
        
        if hasattr(response, 'tool_calls'):
            logger.info(f"[DataSourceAgent]   Number of tool_calls: {len(response.tool_calls) if response.tool_calls else 0}")
            if response.tool_calls:
                tool_names = [tc.get('name') or tc.get('function', {}).get('name') for tc in response.tool_calls]
                logger.info(f"[DataSourceAgent]   Tools being called: {tool_names}")
            # if response.tool_calls:
            #     for i, tc in enumerate(response.tool_calls):
            #         logger.info(f"[DataSourceAgent]   Tool call {i}: {tc}")
            else:
                logger.warning(f"[DataSourceAgent]   ⚠️ NO TOOL CALLS - LLM decided not to use tools")
        
        if hasattr(response, 'content'):
            content_preview = response.content[:200] if response.content else 'None'
            # logger.info(f"[DataSourceAgent]   Response content: {content_preview}...")
        
        return {"messages": [response]}
    
    def _should_continue(self, state: AgentState) -> str:
        """Determine if we should continue to tools or end."""
        last_message = state["messages"][-1]
        
        # If there are tool calls, continue to tools node
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "continue"
        
        return "end"
    
    def _convert_messages(self, messages: List[Dict[str, Any]]) -> List[BaseMessage]:
        """Convert dict messages to LangChain message objects."""
        converted = []
        
        for msg in messages:
            # Handle both dict and Pydantic message objects
            if isinstance(msg, dict):
                role = msg.get("role", "user")
                content = msg.get("content", "")
            else:
                # Assume it's a Pydantic message object with role and content attributes
                role = getattr(msg, "role", "user")
                content = getattr(msg, "content", "")
            
            if role == "user":
                converted.append(HumanMessage(content=content))
            elif role == "assistant":
                converted.append(AIMessage(content=content))
            elif role == "system":
                converted.append(SystemMessage(content=content))
        
        return converted
    
    async def invoke(self, messages: List[Dict[str, Any]]) -> str:
        """
        Invoke the agent synchronously (non-streaming).
        
        Args:
            messages: List of message dicts with 'role' and 'content'
        
        Returns:
            The agent's final response
        """
        return await self.process_query(messages)
    
    async def process_query(self, messages: List[Dict[str, Any]]) -> str:
        """
        Process a query through the agent.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
        
        Returns:
            The agent's final response
        """
        try:
            langchain_messages = self._convert_messages(messages)
            
            logger.info(f"[DataSourceAgent] Processing {len(messages)} messages")
            
            # Run the graph
            result = await self.graph.ainvoke({
                "messages": langchain_messages
            })
            
            # Extract final response
            if result and "messages" in result:
                for msg in reversed(result["messages"]):
                    if isinstance(msg, AIMessage) and not msg.tool_calls:
                        return msg.content
            
            return "I couldn't process your request. Please try again."
            
        except Exception as e:
            logger.error(f"[DataSourceAgent] Error: {e}", exc_info=True)
            raise
    
    async def stream_query(self, messages: List[Dict[str, Any]]) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream a query through the agent.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
        
        Yields:
            Event dicts with type and content
        """
        try:
            langchain_messages = self._convert_messages(messages)
            
            # logger.info(f"[DataSourceAgent] Streaming {len(messages)} messages")
            
            async for event in self.graph.astream_events(
                {"messages": langchain_messages},
                version="v2"
            ):
                kind = event.get("event")
                
                if kind == "on_chat_model_stream":
                    content = event.get("data", {}).get("chunk")
                    if hasattr(content, "content") and content.content:
                        yield {"type": "content", "data": content.content}
                
                elif kind == "on_tool_start":
                    tool_name = event.get("name", "unknown")
                    yield {"type": "tool_start", "data": f"Searching {tool_name}..."}
                
                elif kind == "on_tool_end":
                    tool_name = event.get("name", "unknown")
                    yield {"type": "tool_end", "data": f"Completed {tool_name}"}
            
            yield {"type": "done", "data": None}
            
        except Exception as e:
            logger.error(f"[DataSourceAgent] Streaming error: {e}", exc_info=True)
            yield {"type": "error", "data": str(e)}
    
    async def stream_invoke(self, messages: List[Dict[str, Any]]) -> AsyncIterator[str]:
        """
        Stream invoke the agent (returns SSE formatted strings for frontend).
        
        Args:
            messages: List of message dicts with 'role' and 'content'
        
        Yields:
            SSE formatted strings: "data: {json}\n\n"
        """
        try:
            async for event in self.stream_query(messages):
                event_type = event.get("type", "")
                event_data = event.get("data", "")
                
                if event_type == "content" and event_data:
                    # Yield content chunks in SSE format
                    yield f"data: {json.dumps({'type': 'content', 'content': event_data})}\n\n"
                elif event_type == "done":
                    # Signal completion
                    yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"
                elif event_type == "error":
                    # Signal error
                    yield f"data: {json.dumps({'type': 'error', 'error': event_data})}\n\n"
        except Exception as e:
            logger.error(f"[DataSourceAgent] Stream invoke error: {e}", exc_info=True)
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
    
    def close(self):
        """Close all service connections."""
        self.capitaliq_service.close()
        self.boardex_service.close()


def create_data_source_agent(
    azure_endpoint: Optional[str] = None,
    api_key: Optional[str] = None,
    api_version: Optional[str] = None,
    deployment_name: Optional[str] = None
) -> DataSourceLangGraphAgent:
    """Factory function to create a DataSourceLangGraphAgent."""
    return DataSourceLangGraphAgent(
        azure_endpoint=azure_endpoint,
        api_key=api_key,
        api_version=api_version,
        deployment_name=deployment_name
    )