from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.features.thought_leadership.services.industry_insights_service import IndustryInsightsService
from app.features.thought_leadership.utils.audience_tone_defaults import apply_audience_tone_defaults
from app.features.chat.services.data_source_agent import create_data_source_agent
from app.core.deps import get_tl_service, get_factiva_client, get_settings, get_llm_service
from app.common.factiva_client import FactivaClient
from app.core.config import Settings, config
from app.infrastructure.llm.llm_service import LLMService
import logging
import re
import json

router = APIRouter()
logger = logging.getLogger(__name__)

class IndustryInsightsRequest(BaseModel):
    messages: List[Dict[str, Any]]
    stream: bool = True
    content_type: Optional[str] = None
    topic: Optional[str] = None
    word_limit: Optional[int] = None
    audience_tone: Optional[str] = None
    clientname: Optional[str] = None
    outline_doc: Optional[str] = None
    supporting_doc: Optional[str] = None
    

class SatisfactionAnalysisRequest(BaseModel):
    """Request to analyze user satisfaction with generated content"""
    user_input: str
    generated_content: str
    content_type: str
    topic: str

class SatisfactionAnalysisResponse(BaseModel):
    """Response from satisfaction analysis"""
    is_satisfied: bool
    confidence: float  # 0.0 to 1.0
    reasoning: str
    improvement_suggestions: Optional[str] = None

def extract_research_info(content: str) -> dict:
    """Extract research-related information from content."""
    research_requested = re.search(r'Research Requested:\s*(.+?)(?:\n|$)', content)    
    return {
        'requested': research_requested.group(1).strip().lower() == 'yes' if research_requested else False
    }

def should_use_langgraph_agent(sources: str) -> bool:
    """Check if LangGraph agent should be called"""
    if not sources:
        return False
    
    # Triggers for LangGraph agent with multi-source integration
    triggers = [
        'PwC Content or Link', 
        'PwC Proprietary Research', 
        'PwC Licensed Third Party Tools', 
        'External Research',
        'CapIQ',
        'BoardEx',
        'Financial Data',
        'Corporate Data',
        'Director Data',
        'Advisor Data',
        'Factiva',
        'News',
        'Market Data'
    ]
    
    return any(trigger.lower() in sources.lower() for trigger in triggers)

def should_use_sql_agent(sources: str) -> bool:
    """Check if SQL agent should be called"""
    return sources and 'PwC Licensed Third Party Tools' in sources

@router.post("")
async def industry_insights_workflow(
    request: IndustryInsightsRequest,
    service: IndustryInsightsService = Depends(get_tl_service(IndustryInsightsService)),
    factiva_client: Optional[FactivaClient] = Depends(get_factiva_client),
    settings: Settings = Depends(get_settings)
):
    try:
        user_prompt = ""
        if request.messages:
            user_prompt = request.messages[-1].get("content", "") if request.messages else ""
        
        logger.info(f"[industry Insights]  User prompt length: {len(user_prompt)}")
        logger.debug(f"[industry Insights] Full user prompt:\n{user_prompt}")

        # Initialize variables
        topic = request.topic or ""
        clientname = request.clientname or ""
        audience = request.audience_tone or ""
        word_limit_int = request.word_limit or 10000
        supporting_doc = request.supporting_doc or ''
        outline_doc = request.outline_doc or ''
        logger.info(f"[PARSE] Parsed values - Topic: '{topic}', Word Limit: '{word_limit_int}', Audience: '{audience}'")
        
        # Extract research information
        research_info = extract_research_info(user_prompt)
        enhanced_user_prompt = user_prompt
        langgraph_context = ""
        
        # Handle Multi-Source LangGraph Agent
        #if should_use_langgraph_agent(research_info['sources']):
        if research_info['requested']:
            try:
                logger.info(f"[industry Insights] Initializing LangGraph Agent for multi-source query")
                
                # Create LangGraph agent instance
                langgraph_agent = create_data_source_agent(
                    azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
                    api_key=config.AZURE_OPENAI_API_KEY,
                    api_version=config.AZURE_OPENAI_API_VERSION,
                    deployment_name=config.AZURE_OPENAI_DEPLOYMENT
                )
                
                # Build the query message for the agent
                search_query = topic
                agent_messages = [
                    {
                        "role": "user",
                        "content": f"Research query: {search_query}\n\nPlease search relevant data sources and provide comprehensive information."
                    }
                ]
                
                logger.info(f"[industry Insights] Calling LangGraph Agent with query: {search_query}")
                
                # Get response from LangGraph agent
                agent_response = await langgraph_agent.process_query(agent_messages)
                
                if agent_response:
                    logger.info(f"[industry Insights] LangGraph Agent returned {len(agent_response)} characters")
                    langgraph_context = f"""

                    --- Research Results from Multi-Source Data Integration ---
                    Sources automatically queried by AI Agent:
                    - Factiva News (external news and media coverage)
                    - Internal Knowledge Base (company documents and reports)
                    - CapitalIQ Financials (income statements and balance sheets)
                    - BoardEx Intelligence (advisors and executive achievements)

                    {agent_response}

                    --- End of Research Results ---
                    """
                    logger.info("[industry Insights] LangGraph Agent context added to research")
                else:
                    logger.warning("[industry Insights] LangGraph Agent returned empty response")

                # Close agent connections
                langgraph_agent.close()
                
            except Exception as e:
                logger.error(f"[industry Insights] LangGraph Agent error: {e}", exc_info=True)
                # Continue without agent context - don't break the workflow
                logger.warning("[industry Insights] Continuing prep without LangGraph Agent data")

        # Apply default word limits if not provided by user
        word_limit_source = 'user'
        word_limit_int = request.word_limit or 10000
        word_limit_source = 'user' if request.word_limit else 'default'

            # Set defaults based on content type (1000 words per page)
        # Apply default audience/tone if not provided by user
        content_type = "Industry Insights"
        audience = apply_audience_tone_defaults(content_type, audience)

        logger.info(f"[industry Insights] Analytics - content_type={content_type}, word_limit_source={word_limit_source}, word_limit_value={word_limit_int}")

        # Use improvement prompt if this is an improvement iteration
        final_prompt = enhanced_user_prompt
        if langgraph_context:
            supporting_doc += langgraph_context
            # final_prompt = f"{final_prompt}\n\n{langgraph_context}"

        return StreamingResponse(
            service.industry_insights_prompt(
                user_prompt=final_prompt,
                clientname=clientname,
                topic=topic,
                audience=audience,
                word_limit=word_limit_int,
                outline_doc=outline_doc,         
                supporting_doc=supporting_doc
            ),
            media_type="text/event-stream"
        )

    except Exception as e:
        logger.error(f"[industry Insights] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/analyze-satisfaction", response_model=SatisfactionAnalysisResponse)
async def analyze_satisfaction(
    request: SatisfactionAnalysisRequest,
    llm_service: LLMService = Depends(get_llm_service)
) -> SatisfactionAnalysisResponse:
    
    logger.info(f"[Satisfaction Analysis] ✓✓✓ ENDPOINT CALLED ✓✓✓")
    
    prompt = f"""You are analyzing whether a user is satisfied with AI-generated content.
        CONTEXT:
        - Content Type: {request.content_type}
        - Topic: {request.topic}
        - Generated Content Preview: {request.generated_content[:500]}...

        USER'S RESPONSE: "{request.user_input}"

        TASK: Determine if the user is satisfied with the content or if they want improvements.

        DECISION RULES (apply in order):

        1. EXPLICIT SATISFACTION PHRASES (is_satisfied=true, confidence=0.95):
        - "yes", "yeah", "yep", "looks good", "perfect", "great", "that works", "that's perfect", "love it", "excellent", "exactly what I needed", "approved", "accepted", "ok", "okay", "good job"

        2. EXPLICIT IMPROVEMENT/CHANGE REQUESTS (is_satisfied=false, confidence=0.95):
        - Starts with "can you": e.g., "can you make it shorter", "can you concise that article"
        - Contains action verbs: "make it", "make it [adjective]", "add", "remove", "change", "rewrite", "improve", "fix", "shorten", "expand", "simplify"
        - Improvement keywords: "concise", "shorter", "longer", "better", "simpler", "clearer", "more", "less"
        - Explicit negatives: "no", "nope", "don't like", "not happy", "not satisfied"
        - Regeneration requests: "regenerate", "redo", "try again", "different"

        3. AMBIGUOUS RESPONSES (analyze context):
        - "okay", "it's fine", "not bad", "could be better", "alright"
        - If contains improvement keywords or action verbs → is_satisfied=false, confidence=0.7
        - If pure acceptance with no action verbs → is_satisfied=true, confidence=0.6

        OUTPUT FORMAT (respond ONLY with this JSON, no markdown, no extra text):
        {{
            "is_satisfied": true or false,
            "confidence": 0.0-1.0 (float),
            "reasoning": "Brief one-sentence explanation",
            "improvement_suggestions": null or "extracted improvement request"
        }}

        EXAMPLES:
        - Input: "can you concise that article for me" → is_satisfied=false, confidence=0.95, improvement="make it more concise"
        - Input: "yes, looks good" → is_satisfied=true, confidence=0.95, improvement=null
        - Input: "not bad" → is_satisfied=true, confidence=0.6, improvement=null
        - Input: "make it shorter and clearer" → is_satisfied=false, confidence=0.95, improvement="make it shorter and clearer"

        Respond ONLY with valid JSON."""

    try:
        response_text = await llm_service.chat_completion(
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert at analyzing user satisfaction with generated content. Respond ONLY with valid JSON, no markdown, no extra text."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3,  # Lower temperature for consistent analysis
            max_tokens=200
        )
        
        logger.info(f"[Satisfaction Analysis] Raw LLM response: {response_text}")
        
        # Parse JSON response
        analysis = json.loads(response_text.strip())
        
        logger.info(f"[Satisfaction Analysis] Parsed JSON: {analysis}")
        logger.info(f"[Satisfaction Analysis] User input: '{request.user_input}'")
        
        return SatisfactionAnalysisResponse(
            is_satisfied=analysis.get("is_satisfied", False),
            confidence=float(analysis.get("confidence", 0.5)),
            reasoning=analysis.get("reasoning", ""),
            improvement_suggestions=analysis.get("improvement_suggestions")
        )
        
    except json.JSONDecodeError as e:
        logger.error(f"[Satisfaction Analysis] JSON Parse Error: {e}")
        logger.error(f"[Satisfaction Analysis] Raw response was: {response_text}")
        # Fallback: treat as not satisfied if we can't parse
        return SatisfactionAnalysisResponse(
            is_satisfied=False,
            confidence=0.3,
            reasoning="Unable to parse analysis, treating as improvement request",
            improvement_suggestions=request.user_input
        )
    except Exception as e:
        logger.error(f"[Satisfaction Analysis] Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Satisfaction analysis failed: {str(e)}")