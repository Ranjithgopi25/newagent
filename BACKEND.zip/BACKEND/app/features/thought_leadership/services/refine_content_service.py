from app.infrastructure.llm.base_services import BaseTLStreamingService
import logging
import json
from typing import Any

logger = logging.getLogger(__name__)


class RefineContentService(BaseTLStreamingService):
    """Service for Refine Content workflow with multiple refinement capabilities"""
    
    # Service type constants
    SERVICE_EXPAND_COMPRESS = "Expand or Compress Content"
    SERVICE_TONE = "Adjust for Audience / Tone"
    SERVICE_RESEARCH = "Enhance with Additional Research"
    SERVICE_EDIT = "Edit Content"
    SERVICE_SUGGESTIONS = "Provide Suggestions on Improving Content"
    
    # Document section markers
    PRIMARY_DOCUMENT_MARKER = "PRIMARY DOCUMENT (BASE CONTENT):"
    SUPPORTING_DOCUMENT_MARKER = "SUPPORTING DOCUMENT (FOR EXPANSION ONLY):"
    INSTRUCTION_MARKER = "INSTRUCTION:"
    
    # Configuration constants
    ACTIVE_SERVICE_KEYS = ['compress', 'expand', 'tone', 'research', 'edit', 'suggestions']
    
    def __init__(self, llm_service=None):
        """Initialize service with optional LLM service and lazy-load data source agent"""
        super().__init__(llm_service)
        self._data_source_agent = None  # Lazy-loaded on first research call
    
    def _get_data_source_agent(self):
        """Lazy-load data source agent only when needed for research service"""
        if self._data_source_agent is None:
            try:
                # Import here to avoid circular dependencies
                from app.features.chat.services.data_source_agent.langgraph_agent import DataSourceLangGraphAgent
                from app.core.config import settings
                
                self._data_source_agent = DataSourceLangGraphAgent(
                    azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                    api_key=settings.AZURE_OPENAI_API_KEY,
                    api_version=settings.AZURE_OPENAI_API_VERSION,
                    deployment_name=settings.AZURE_OPENAI_DEPLOYMENT
                )
                logger.info("[Refine Content] Data source agent lazy-loaded successfully")
            except Exception as e:
                logger.warning(f"[Refine Content] Failed to lazy-load data source agent: {e}")
                self._data_source_agent = None
        return self._data_source_agent

    def _get_suggestions_prompt_template(self) -> str:
        """Get the detailed PwC suggestions prompt template"""
        return """
ROLE & OBJECTIVE
You are a Senior PwC Brand & Content Strategist and Executive Editor. Your role is NOT to rewrite the content, but to act as a critical writing coach. Provide specific, actionable, and high-value suggestions to help the author elevate their draft to meet PwC's thought leadership standards.

I. CORE ANALYSIS FRAMEWORK (PwC Tone Pillars)
Evaluate the draft against these three tone pillars and identify specific opportunities for improvement:

BOLD (Assertive, Decisive, Clear)
- Standard: Lead with a strong point of view; avoid safe, academic language.
- Watch For: Soft qualifiers (e.g., "somewhat," "arguably," "it seems that"), passive voice, dense jargon
- Fix: Encourage decisive language. Replace banned word "catalyst" with driver, enabler, accelerator.

COLLABORATIVE (Human, Conversational, Partnership-Focused)
- Standard: Write to the reader, not at them.
- Watch For: Third-person distancing ("PwC helps clients…"), formal stiffness (lack of contractions, overly complex sentences)
- Fix: Use first-person and direct address ("We help you…"). Replace "clients" with "you" or "your organization."

OPTIMISTIC (Future-Forward, Outcome-Focused)
- Standard: Emphasize solutions and possibilities.
- Watch For: Problem-only framing, static language
- Fix: Pivot to outcomes. Use movement words (transform, evolve, reshape) and energy words (propel, spark, accelerate).

II. COMPLIANCE CHECKS
Flag and correct any prohibited terms or style violations:
- "Catalyst" → driver/enabler/accelerator
- "Clients" → you/your organization
- "PwC Network" → PwC network (lowercase 'n')
- "Mainland China" → Chinese Mainland
- Exclamation marks
- Buzzwords/fillers: leverage, synergy, at the end of the day, in order to, moving forward

III. EXPANDED ANALYSIS
- Logic & Depth (MECE): Check argument flow, gaps, and redundancy.
- Thought Leadership: Suggest proprietary PwC data or examples to strengthen authority.
- Visual Opportunities: Identify text-heavy sections for charts/infographics.
- Differentiation: Flag generic content; push for unique PwC insights.
- Consistency & Risk: Spot contradictions or cultural sensitivities.

IV. OUTPUT FORMAT
Provide feedback in this structured format:

✓ Brand Voice Alignment
- Observation: [Quote problematic phrase]
- Fix: [Explain why and suggest bold/collaborative alternative]

✓ Vocabulary & Terminology
- Flagged Terms: [List prohibited words only if used]
- Recommended Swaps: [Suggest PwC-approved alternatives]

✓ Structural Clarity
- Observation: [Identify long or buried sentences]
- Fix: [Give specific restructuring advice]

✓ Strategic Lift (So What?)
- Observation: [Generic statement]
- Fix: [Push for business impact and specificity]

✓ Logic & Evidence Gaps
- Observation: [Weak or unsupported argument]
- Fix: [Suggest data or examples]

✓ Visual Opportunities
- Observation: [Text-heavy section]
- Fix: [Recommend visual format]

✓ Differentiation
- Observation: [Generic content]
- Fix: [Suggest unique PwC angle]

⚠ Risk & Sensitivity
- Flagged Items: [Contradictions or sensitivities]
- Action: [Resolution guidance]

**CONTENT TO ANALYZE:**
{content}"""

    def _get_tone_instruction(self, tone: str) -> str:
        """Generate tone instruction dynamically based on the provided tone parameter"""
        return f"""Match '{tone}' tone in vocabulary, sentence structure, formality level, and overall voice throughout.

CRITICAL POINTS:
  - Ensure consistency: Apply '{tone}' tone to every sentence and paragraph
  - Adjust language register: Use appropriate vocabulary and phrasing for '{tone}' tone
  - Maintain clarity: Keep content clear and understandable while matching the tone
  - Preserve meaning: Only change HOW things are expressed, not WHAT is expressed"""
    
    def _parse_services_from_json(self, services_list: list[dict], original_content: str) -> dict[str, Any]:
        """Parse services from JSON request array - NO REGEX NEEDED
        
        Strategy: Supporting document FIRST, then external research
        Only processes services where isSelected=true
        """
        services = {
            'compress': None,
            'expand': None,
            'tone': None,
            'research': False,
            'edit': False,
            'suggestions': False,
            'requested_word_limit': None,
            'is_expand': False,
            'current_word_count': 0,
            'expand_supporting_doc': None,
            'expand_supporting_doc_instructions': None,
            'research_supporting_docs': {
                'pwc_content': None,
                'pwc_instructions': None,
                'proprietary_results': None,
                'third_party_results': None,
                'external_results': None
            },
            'research_topics': None,
            'research_guidelines': None
        }
        
        # Count actual words in original content
        current_word_count = len(original_content.split())
        services['current_word_count'] = current_word_count
        logger.info(f"[Refine Content] Current word count from original content: {current_word_count}")
        
        # Process each service in the list - only if isSelected=true
        for service in services_list:
            if not service.get('isSelected', False):
                continue
            
            service_type = service.get('type', '').lower()
            logger.info(f"[Refine Content] Processing service: {service_type}")
            
            # EXPAND/COMPRESS SERVICE - Use API type field as source of truth
            if service_type == 'expand':
                expected_count = service.get('expected_word_count')
                if expected_count:
                    services['requested_word_limit'] = expected_count
                    services['is_expand'] = True
                    services['expand'] = str(expected_count)
                    logger.info(f"[Refine Content] EXPAND service: {current_word_count} → {expected_count} words")
                    
                    supporting_doc = service.get('supportingDoc')
                    supporting_doc_instructions = service.get('supportingDoc_instructions')
                    if supporting_doc:
                        services['expand_supporting_doc'] = supporting_doc
                        services['expand_supporting_doc_instructions'] = supporting_doc_instructions
                        logger.info(f"[Refine Content] Supporting document found for expansion")
                        if supporting_doc_instructions:
                            logger.info(f"[Refine Content] Supporting document instructions found for expansion")
            
            elif service_type == 'compress':
                expected_count = service.get('expected_word_count')
                if expected_count:
                    services['requested_word_limit'] = expected_count
                    services['is_expand'] = False
                    services['compress'] = str(expected_count)
                    logger.info(f"[Refine Content] COMPRESS service: {current_word_count} → {expected_count} words")
            
            # TONE SERVICE
            elif service_type == 'adjust_audience_tone':
                tone = service.get('audience_tone')
                if tone:
                    services['tone'] = tone.strip()
                    logger.info(f"[Refine Content] Tone service: {tone}")
            
            # RESEARCH SERVICE - SUPPORTING DOCUMENT FIRST, THEN EXTERNAL
            elif service_type == 'enhanced_with_research':
                services['research'] = True
                services['research_topics'] = service.get('research_topics')
                services['research_guidelines'] = service.get('research_guidelines')
                logger.info(f"[Refine Content] Research service enabled")
                
                # Extract PWC content - HIGHEST PRIORITY
                pwc_config = service.get('pwc_content', {})
                if pwc_config.get('isSelected'):
                    services['research_supporting_docs']['pwc_content'] = pwc_config.get('supportingDoc')
                    services['research_supporting_docs']['pwc_instructions'] = pwc_config.get('supportingDoc_instructions')
                    logger.info(f"[Refine Content] PWC content extracted (PRIMARY research source)")
                
                # Check if external research needed (lazy-load agent only if needed)
                needs_external_research = False
                if pwc_config.get('isSelected') and not pwc_config.get('supportingDoc'):
                    needs_external_research = True
                
                proprietary_config = service.get('proprietary', {})
                if proprietary_config.get('isSelected'):
                    needs_external_research = True
                
                third_party_config = service.get('thirdParty', {})
                if third_party_config.get('isSelected'):
                    needs_external_research = True
                
                external_config = service.get('externalResearch', {})
                if external_config.get('isSelected'):
                    needs_external_research = True
                
                # Lazy-load data source agent only if external research needed
                if needs_external_research:
                    agent = self._get_data_source_agent()
                    if agent:
                        logger.info(f"[Refine Content] Calling data source agent for external research")
                        # Agent call would happen during prompt building to get async results
                        # For now, mark that external research is needed
                        if proprietary_config.get('isSelected'):
                            logger.info(f"[Refine Content] Proprietary sources requested")
                        if third_party_config.get('isSelected'):
                            logger.info(f"[Refine Content] Third-party sources requested")
                        if external_config.get('isSelected'):
                            logger.info(f"[Refine Content] External research requested")
            
            # SUGGESTIONS SERVICE
            elif service_type == 'improvement_suggestions':
                services['suggestions'] = True
                logger.info(f"[Refine Content] Suggestions service enabled")
            
            # EDIT SERVICE
            elif service_type == 'edit_content':
                services['edit'] = True
                editors = service.get('editors', [])
                logger.info(f"[Refine Content] Edit service enabled with {len(editors)} editors")
        
        logger.info(f"[Refine Content] Services parsed from JSON: {services}")
        return services
    
    def _generate_title(self, services: dict[str, Any]) -> str:
        """Generate descriptive title based on active services"""
        # Count active services
        active_services = self._get_active_service_count(services)
        
        if active_services == 0:
            return "Refined Content"
        
        if active_services > 1:
            return "All-in-One Content Refinement"
        
        # Single service
        if services['compress']:
            return f"Refined Content ({services['compress']} words)"
        if services['expand']:
            return f"Expanded Content ({services['expand']} words)"
        if services['tone']:
            tone_title = ' '.join(services['tone'].split()).title()
            return f"Refined Content - {tone_title} Tone"
        if services['research']:
            return "Enhanced Content with Additional Research"
        if services['edit']:
            return "Edited Content"
        if services['suggestions']:
            return "Content with Improvement Suggestions"
        
        return "Refined Content"
    
    def _get_active_service_count(self, services: dict[str, Any]) -> int:
        """Count the number of active services"""
        return sum(bool(services.get(key)) for key in self.ACTIVE_SERVICE_KEYS)
    
    def _build_tone_critical_points(self, tone: str) -> str:
        """Format tone critical points for display"""
        tone_instruction = self._get_tone_instruction(tone)
        return tone_instruction
    
    def _build_compression_instructions(self, word_limit: str, current_count: int = 0) -> str:
        """Build detailed compression instructions"""
        current_info = f"\n   - Current Word Count: {current_count} words" if current_count > 0 else ""
        reduction_info = f"\n   - Reduction Needed: {int(word_limit) - current_count} words" if current_count > 0 else ""
        
        return f"""1. WORD COUNT (HIGHEST PRIORITY):
   - Target: EXACTLY {word_limit} words{current_info}{reduction_info}
   - Method: Compress WITHIN each paragraph by:
     • Tightening sentences
     • Removing redundancy and filler words
     • Using more concise phrasing
   - Preserve: ALL paragraphs, their order, and structure
   - DO NOT: Delete paragraphs, conclusions, or sections to meet word count
   - Validation: Count every single word - must be exactly {word_limit}, not {int(word_limit)-1}, not {int(word_limit)+1}"""
    
    def _build_expansion_instructions(self, word_limit: str, current_count: int) -> str:
        """Build detailed expansion instructions"""
        return f"""1. WORD COUNT (HIGHEST PRIORITY):
   - Current Word Count: {current_count} words
   - Target: EXACTLY {word_limit} words
   - Expansion Needed: {int(word_limit) - current_count} words
   - Method: Expand WITHIN each paragraph by:
     • Adding relevant details and examples
     • Developing key concepts more thoroughly
     • Providing deeper analysis and context
     • Using supporting documents if available
   - Preserve: ALL original content, paragraphs, and structure
   - DO NOT: Remove any original paragraphs or content
   - DO NOT: Invent facts or contradict existing content
   - Validation: Count every single word - must be exactly {word_limit}, not {int(word_limit)-1}, not {int(word_limit)+1}"""
    
    def _build_expansion_guidelines(self) -> str:
        """Build comprehensive expansion guidelines for author material"""
        return """
EXPANSION PRINCIPLES & GUIDELINES:

PRIMARY OBJECTIVE:
Expand existing author material with new quantitative and qualitative support to strengthen existing objectives, arguments, and perspectives.

CORE REQUIREMENTS:

1. PRESERVE AUTHOR'S VOICE & INTENT:
   - Maintain the author's original tone, style, and voice throughout
   - Do NOT change the fundamental perspective or viewpoint
   - Do NOT rewrite sentences for stylistic preferences
   - Ensure all additions align with author's established arguments

2. STRUCTURAL INTEGRITY (NON-NEGOTIABLE):
   - Do NOT fundamentally change or reorganize the original structure
   - Keep ALL original paragraphs in their exact order
   - Do NOT move paragraphs, sections, or content blocks
   - Do NOT merge or split existing paragraphs unless adding substantial context
   - Maintain the logical flow and progression of ideas as authored

3. SENTENCE & CONTENT EXPANSION STRATEGY:
   - Do NOT arbitrarily increase existing sentence length
   - Only extend sentences if adding new sources, examples, evidence, or support
   - Create new sentences/paragraphs to support and strengthen existing points
   - Add supporting details, examples, and evidence between existing content
   - Use natural spacing to integrate new material seamlessly

4. RESEARCH & DATA INTEGRATION (MANDATORY):
   - Conduct research on the topic to find supporting evidence
   - Incorporate at least 2-3 new sources or cite data points
   - If insufficient valid sources exist, explicitly note: "No additional valid sources found for [specific claim]"
   - Ensure all sources are credible, relevant, and properly contextualized
   - Prioritize quantitative data, case studies, and industry benchmarks
   - Include real-world examples that illustrate author's existing arguments

5. SUPPORTING EVIDENCE STRATEGY:
   - Add data points that validate and strengthen existing claims
   - Include real-world examples that demonstrate author's perspectives
   - Provide statistical support or case study evidence where applicable
   - Use quotes from authoritative sources sparingly and strategically
   - Ensure evidence directly supports the paragraph's main point

6. CONTENT SECTION RECOMMENDATIONS:
   - Analyze if new arguments or content sections would strengthen author's original intent
   - Suggest (in a separate "Recommendations" section) any missing content areas
   - Include suggestions for new arguments that naturally extend the author's thesis
   - Note where additional depth or coverage would benefit the original intent
   - Only recommend additions that align with author's established perspective
   - Do NOT recommend contradictory viewpoints or alternative frameworks

7. TONE & STYLE CONSISTENCY:
   - Match sentence structure patterns from the original text
   - Use similar vocabulary and terminology as the author
   - Maintain formality level and professional standard throughout
   - Keep paragraph length and density consistent with original

OUTPUT FORMAT EXPECTATIONS:
- Expanded content maintaining ALL original structure
- New data points, sources, and examples naturally embedded
- Author's original arguments strengthened with supporting evidence
- (Optional) "Expansion Recommendations" section if new sections would strengthen original intent
"""
    
    def _build_validation_checklist(self, services: dict[str, Any], active_count: int) -> str:
        """Build validation checklist based on active services"""
        items = []
        if services['compress']:
            items.append(f"✓ Word count = EXACTLY {services['compress']} words (verify by counting)")
        if services['expand']:
            items.append(f"✓ Word count = EXACTLY {services['expand']} words (verify by counting)")
        if services['tone']:
            items.append(f"✓ Every sentence uses '{services['tone']}' tone consistently")
        if active_count > 1:
            items.append(f"✓ All {active_count} services applied simultaneously")
        return "\n".join(items)
    
    def _build_tone_instructions(self, tone: str) -> str:
        """Build detailed tone adjustment instructions"""
        tone_instruction = self._build_tone_critical_points(tone)
        return f"""2. TONE (SECOND PRIORITY):
   - Style: '{tone}' tone throughout entire content
   - Requirements:
{tone_instruction}
   - Apply: Every sentence must reflect '{tone}' tone
   - Maintain: Original meaning and key points while changing expression"""
    
    def _build_multi_service_prompt(self, title: str, services: dict[str, Any], active_count: int, has_supporting: bool, current_word_count: int = 0) -> tuple[str, str]:
        """Build system and user prompts for multiple services"""
        detailed_instructions = []
        task_list = []
        
        if services['compress']:
            task_list.append(f"compress to exactly {services['compress']} words")
            detailed_instructions.append(self._build_compression_instructions(services['compress'], current_word_count))
        
        if services['expand']:
            task_list.append(f"expand to exactly {services['expand']} words")
            detailed_instructions.append(self._build_expansion_instructions(services['expand'], current_word_count))
        
        if services['tone']:
            task_list.append(f"adjust tone to: {services['tone']}")
            detailed_instructions.append(self._build_tone_instructions(services['tone']))
        
        if services['research']:
            task_list.append("add research insights and data")
            detailed_instructions.append("3. RESEARCH: Add relevant research insights, data points, and evidence-based information")
        
        if services['edit']:
            task_list.append("apply professional editing")
            detailed_instructions.append("4. EDIT: Apply professional editing for grammar, clarity, and flow")
        
        if services['suggestions']:
            task_list.append("include improvement suggestions")
            detailed_instructions.append("5. SUGGESTIONS: Provide strategic feedback using PwC Brand & Content framework in a separate section")
        
        tasks_description = " AND ".join(task_list)
        detailed_text = "\n\n".join(detailed_instructions)
        
        # Build validation checklist
        validation_checklist = self._build_validation_checklist(services, active_count)
        
        suggestions_format = ""
        suggestions_framework = ""
        if services['suggestions']:
            suggestions_format = "\n\n## Suggestions for Improvement\n\n[Strategic feedback using PwC framework]"
            suggestions_framework = f"\n\nSUGGESTIONS FRAMEWORK:\n{self._get_suggestions_prompt_template()}"
        
        system_prompt = f"""You are a PwC content refinement expert.
{'MANDATORY: A supporting document is provided. You MUST explicitly incorporate concepts, terminology, or insights from the SUPPORTING DOCUMENT into the final content.' if has_supporting else ''}

TASK: Apply {active_count} services SIMULTANEOUSLY: {tasks_description}

SERVICE PRIORITY ORDER:
1. Word Count (if requested) - STRICTEST requirement
2. Tone (if requested) - Must be consistent throughout
3. Other services (research, edit, suggestions)

WHAT TO PRESERVE (CRITICAL):
- Original document structure and section order
- Author's original tone, objectives, and primary arguments
- ALL citations, references, and case studies that support arguments
- Section headings and overall organization

DETAILED INSTRUCTIONS:
{detailed_text}

STRUCTURE PRESERVATION (NON-NEGOTIABLE):
- Keep ALL original paragraphs in their exact order
- The number of paragraphs in output MUST match input
- No paragraph may be removed, merged, or skipped
- Conclusions and final sections MUST be retained
- Compress/Expand by improving efficiency WITHIN paragraphs

OUTPUT FORMAT:
**{title}**

[Refined content - all services applied together]{suggestions_format}
{suggestions_framework}

VALIDATION CHECKLIST (Verify before submitting):
{validation_checklist}

CRITICAL REMINDERS:
- Apply ALL {active_count} services in ONE unified output
- Do NOT create separate sections for each service (except suggestions)
- Every sentence must satisfy ALL requirements simultaneously
- Word count is the PRIMARY constraint - tone and other services must work within this limit"""
        
        return system_prompt, detailed_text
    
    def _build_compression_prompt(self, word_limit: str, title: str, current_count: int = 0) -> str:
        """Build system prompt for compression using MASTER PROMPT 5-STEP WORKFLOW"""
        
        compression_ratio = ((int(word_limit) / current_count) * 100) if current_count > 0 else 100
        words_to_remove = current_count - int(word_limit) if current_count > 0 else 0
        
        return f"""You are a senior editorial consultant working on long-form, high-stakes content such as white papers, analyst POVs, and CXO thought leadership.

YOUR PRIMARY OBJECTIVES (in priority order):
1. Preserve original intent, meaning, and factual accuracy
2. Maintain structure, tone, and narrative coherence
3. Achieve an EXACT final word count of {word_limit} words

DOCUMENT CONTEXT:
- Current Word Count: {current_count} words
- Target Word Count: {word_limit} words
- Compression Needed: {words_to_remove} words ({compression_ratio:.1f}% of original)

This is a large document. You MUST follow the workflow below strictly and sequentially.
⸻ DO NOT SKIP STEPS. DO NOT MERGE STEPS. DO NOT REWRITE THE ENTIRE DOCUMENT IN ONE PASS. ⸻

⸻
STEP 1 — STRUCTURAL ANALYSIS (Planning Only)
⸻
• Identify all sections and subsections
• Estimate current word count per section
• Identify the role of each section (context, argument, evidence, synthesis, conclusion)
• Do not rewrite any content

OUTPUT: A table only with columns:
| Section | Current Words | Role |

⸻
STEP 2 — TARGET WORD ALLOCATION
⸻
• Allocate target word counts per section so the total equals exactly {word_limit} words
• Preserve the relative importance of sections
• Avoid over-expanding introductions or conclusions

OUTPUT: A table with:
| Section | Current Words | Target Words | Adjustment (+/-) |

⸻
STEP 3 — SECTION-BY-SECTION REWRITE
⸻
For each section (in order):
• Rewrite ONLY that section to its allocated word count
• Preserve meaning, tone, and audience
• Do not introduce new ideas, facts, or examples
• Do not reference other sections
• Count words before finalizing each section

COMPRESSION TACTICS FOR EACH SECTION:
• Remove redundancy and repetition within sections
• Eliminate filler words: "very," "quite," "somewhat," "arguably," "perhaps"
• Replace wordy phrases:
  - "in order to" → "to"
  - "at the end of the day" → "ultimately"
  - "take into consideration" → "consider"
  - "it is important to note that" → [integrate directly]
• Tighten sentences (combine related thoughts)
• Use active voice over passive
• Remove excessive qualifiers and hedging language
• Trim secondary examples (keep strongest only)

OUTPUT: Each rewritten section clearly labeled with:
[SECTION NAME - X words]
[Rewritten content]

⸻
STEP 4 — ASSEMBLY & COHERENCE PASS
⸻
• Assemble all rewritten sections in order
• Improve transitions and terminology consistency
• Remove repetition across sections
• Do not change any section word counts

OUTPUT: Full assembled document

⸻
STEP 5 — FINAL VALIDATION (Hard Gate)
⸻
Report ONLY:
• Final total word count
• Confirmation that it equals exactly {word_limit} words
• Any risks or assumptions (if applicable)

⸻
NON-NEGOTIABLE RULES
⸻
• No single-pass rewriting
• No content invention
• No structural deletion without redistribution
• Exact word count enforced at document level
• Section-level tolerance ±2–3% only during drafting

⸻
FINAL OUTPUT FORMAT
⸻
Show ONLY the compressed content in this format:

**{title}**

[Compressed content - exactly {word_limit} words]

NOTHING ELSE - no steps shown, no analysis visible, ONLY the final compressed content."""
    
    def _build_expansion_prompt(self, word_limit: str, title: str, current_count: int, has_supporting: bool = False) -> str:
        """Build system prompt for expansion only"""
        supporting_instruction = ""
        if has_supporting:
            supporting_instruction = """
SUPPORTING DOCUMENTS AVAILABLE:
- You have access to supporting materials (marked as SUPPORTING DOCUMENT)
- Use supporting documents to add relevant information and context
- Extract insights, examples, and data that strengthen the main content
- Seamlessly integrate supporting content without contradicting the primary document"""
        
        return f"""You are a PwC content expansion expert specializing in author-centric material enhancement.

TASK: Expand content to EXACTLY {word_limit} words while strengthening author's arguments with research-backed evidence.

CURRENT STATUS:
- Current Word Count: {current_count} words
- Target Word Count: {word_limit} words
- Expansion Needed: {int(word_limit) - current_count} words
{supporting_instruction}

{self._build_expansion_guidelines()}

DETAILED EXPANSION STRATEGY:

1. ANALYZE EXISTING CONTENT:
   - Identify author's main arguments and perspectives
   - Map existing claims that need quantitative/qualitative support
   - Note areas where additional evidence would strengthen arguments
   - Understand author's tone, style, and structural approach

2. RESEARCH & EVIDENCE GATHERING:
   - Conduct research to find supporting data, case studies, examples
   - Target: Find and incorporate at least 2-3 new sources/data points
   - Prioritize recent, credible, industry-relevant evidence
   - If sources are limited, explicitly note any gaps with: "No additional valid sources found for [claim]"

3. STRATEGIC EXPANSION:
   - Add quantitative data (statistics, benchmarks, metrics) supporting existing arguments
   - Include qualitative support (expert perspectives, case studies, real-world examples)
   - Insert supporting evidence between relevant paragraphs or within them
   - Create new paragraphs for substantial supporting evidence/examples
   - Maintain natural flow and logical progression

4. CONTENT RECOMMENDATIONS:
   - At the end (marked as "EXPANSION RECOMMENDATIONS:"), suggest:
     • New arguments that would strengthen author's original intent
     • Additional content sections that naturally fit the author's thesis
     • Missing perspectives or coverage areas aligned with author's viewpoint
   - Format: Bulleted list with brief explanations
   - Do NOT recommend contradictory frameworks or alternative viewpoints

VALIDATION CHECKLIST:
✓ Word count = EXACTLY {word_limit} words (verify by counting)
✓ Author's original tone and voice maintained throughout
✓ ALL original paragraphs preserved in original order
✓ No fundamental restructuring of original content
✓ At least 2-3 new sources or data points incorporated
✓ New evidence directly supports existing arguments
✓ Sentences expanded only when adding substance/evidence
✓ Real-world examples included where applicable
✓ Expansion Recommendations section included (if applicable)

OUTPUT FORMAT:
**{title}**

[Expanded content - exactly {word_limit} words, maintaining author's structure and voice]

---

EXPANSION RECOMMENDATIONS:
[List of suggested new arguments/sections that would strengthen original intent (if any)]"""
    
    def _build_tone_prompt(self, tone: str, title: str,current_word_count:int, target_word_count: int | None = None) -> str:
        """Build system prompt for tone adjustment only"""
        tone_instruction = self._get_tone_instruction(tone)
        length_constraint = f"\n- Target length: {target_word_count} words (±10% acceptable)" if target_word_count else ""
        
        return f"""You are a PwC tone adjustment expert.

TASK: Rewrite content in '{tone}' tone.

TONE REQUIREMENTS:
{tone_instruction}

CONSTRAINTS:
- Preserve original structure and paragraph count
- Keep ALL paragraphs in their original order
- Keep original meaning and key points{length_constraint}
- Only change HOW things are said, not WHAT is said

WHAT TO PRESERVE (CRITICAL):
- Original document structure and section order
- Author's original tone, objectives, and primary arguments
- ALL citations, references, and case studies that support arguments
- Section headings and overall organization

WORD COUNT CONSTRAINT (CRITICAL):
- Original content: {current_word_count} words
- You MUST maintain approximately the same length
- Do NOT expand or compress significantly
- Only change HOW things are said, not add/remove content

METHOD:
- Adjust vocabulary to match tone
- Modify sentence structure for tone
- Change formality level as needed
- Maintain consistent tone from first word to last

OUTPUT FORMAT:
**{title}**

[Content in {tone} tone - preserve structure and meaning]"""
    
    def _build_suggestions_prompt(self, content: str) -> str:
        """Build system prompt for suggestions only"""
        return f"""ROLE: Senior PwC Brand & Content Strategist and Executive Editor

TASK: Analyze content and provide strategic feedback (NOT rewrite)

{self._get_suggestions_prompt_template().format(content=content)}"""
    
    def _build_generic_prompt(self, title: str) -> str:
        """Build system prompt for generic refinement"""
        return f"""You are a PwC content optimization expert.

TASK: Refine the content according to the provided instructions.
WHAT TO PRESERVE (CRITICAL):
- Original document structure and section order
- Author's original tone, objectives, and primary arguments
- ALL citations, references, and case studies that support arguments
- Section headings and overall organization

GUIDELINES:
- Preserve original structure and paragraph order
- Maintain key points and meaning
- Apply professional editing standards
- Ensure clarity and readability

OUTPUT FORMAT:
**{title}**

[Refined content]"""
    
    async def refine_content(self, request_data: dict[str, Any]):
        """Refine content based on JSON request with structured service configuration
        
        Args:
            request_data: JSON request containing original_content and services array
        """
        # Extract original content and services from JSON request
        original_content = request_data.get('original_content', '').strip()
        services_list = request_data.get('services', [])
        
        if not original_content:
            logger.error("[Refine Content] No original content provided in request")
            error_message = f"data: {json.dumps({'type': 'error', 'error': 'Original content is required'})}\n\n"
            yield error_message
            return
        
        logger.info(f"[Refine Content] Processing JSON request with {len(services_list)} services")
        
        # Parse services from JSON structure
        services = self._parse_services_from_json(services_list, original_content)
        
        title = self._generate_title(services)
        
        logger.info(f"[Refine Content] Generated title: {title}")
        logger.info(f"[Refine Content] Services configuration: {services}")
        logger.info(f"[Refine Content] Total Word Count: {services['current_word_count']}")
        
        # Prepare content for LLM with supporting documents
        llm_input_content = original_content
        has_supporting = False
        
        # For EXPANSION: Include all available research documents
        if services.get('is_expand'):
            # Collect all available supporting documents for expansion
            supporting_docs = []
            
            # 1. User-uploaded expand supporting document (HIGHEST PRIORITY)
            if services.get('expand_supporting_doc'):
                supporting_docs.append(("EXPANSION SUPPORTING DOCUMENT", services['expand_supporting_doc']))
                has_supporting = True
                logger.info(f"[Refine Content] Expansion supporting document found")
                
                # Include instructions if available
                if services.get('expand_supporting_doc_instructions'):
                    supporting_docs.append(("EXPANSION SUPPORTING DOCUMENT INSTRUCTIONS", services['expand_supporting_doc_instructions']))
                    logger.info(f"[Refine Content] Expansion supporting document instructions found")
            
            # 2. PWC content from research section
            if services['research_supporting_docs'].get('pwc_content'):
                supporting_docs.append(("PWC RESEARCH CONTENT", services['research_supporting_docs']['pwc_content']))
                has_supporting = True
                logger.info(f"[Refine Content] PWC research content found for expansion")
            
            # 3. Proprietary research content
            if services['research_supporting_docs'].get('proprietary_results'):
                supporting_docs.append(("PROPRIETARY RESEARCH CONTENT", services['research_supporting_docs']['proprietary_results']))
                has_supporting = True
                logger.info(f"[Refine Content] Proprietary research content found for expansion")
            
            # 4. Third-party research content
            if services['research_supporting_docs'].get('third_party_results'):
                supporting_docs.append(("THIRD-PARTY RESEARCH CONTENT", services['research_supporting_docs']['third_party_results']))
                has_supporting = True
                logger.info(f"[Refine Content] Third-party research content found for expansion")
            
            # 5. External research content
            if services['research_supporting_docs'].get('external_results'):
                supporting_docs.append(("EXTERNAL RESEARCH CONTENT", services['research_supporting_docs']['external_results']))
                has_supporting = True
                logger.info(f"[Refine Content] External research content found for expansion")
            
            # Build formatted input with all supporting documents if available
            if supporting_docs:
                llm_input_content = f"""PRIMARY DOCUMENT (BASE CONTENT):
{original_content}"""
                
                for doc_title, doc_content in supporting_docs:
                    llm_input_content += f"""

{doc_title}:
{doc_content}"""
                
                llm_input_content += """

GUIDELINE:
Use ALL provided supporting documents to strengthen and expand the primary content.
Prioritize content from uploaded documents first, then external research.
Do NOT invent facts.
Do NOT contradict the primary document.
Integrate insights seamlessly into existing paragraphs."""
                
                logger.info(f"[Refine Content] Expansion with {len(supporting_docs)} supporting document(s)")
        
        # If research service enabled (non-expansion), prepare for research
        elif services.get('research'):
            logger.info(f"[Refine Content] Research service enabled (non-expansion)")
            # External research would be integrated via data_source_agent during prompt building
        
        # Count active services
        active_services_count = self._get_active_service_count(services)
        
        # Build prompts based on service combination
        if active_services_count > 1:
            system_prompt, _ = self._build_multi_service_prompt(
                title, services, active_services_count, has_supporting, services['current_word_count']
            )
            
            # Build user prompt for multiple services
            task_list = []
            if services['compress']:
                task_list.append(f"✓ compress to exactly {services['compress']} words")
            if services['expand']:
                task_list.append(f"✓ expand to exactly {services['expand']} words")
            if services['tone']:
                task_list.append(f"✓ adjust tone to: {services['tone']}")
            if services['research']:
                task_list.append("✓ add research insights and data")
            if services['edit']:
                task_list.append("✓ apply professional editing")
            if services['suggestions']:
                task_list.append("✓ include improvement suggestions")
            
            tasks_list_text = "\n".join(task_list)
            
            reminders = []
            if services['compress']:
                reminders.append(f"- WORD COUNT: Final content MUST be EXACTLY {services['compress']} words")
            if services['expand']:
                reminders.append(f"- WORD COUNT: Final content MUST be EXACTLY {services['expand']} words")
            if services['tone']:
                reminders.append(f"- TONE: Every sentence MUST use '{services['tone']}' tone consistently")
            if active_services_count > 1:
                reminders.append(f"- COMBINATION: All {active_services_count} services must be applied simultaneously")
            
            reminders_text = "\n".join(reminders)
            
            user_prompt = f"""Apply these {active_services_count} services TOGETHER in ONE output:

{tasks_list_text}

PRIORITY REQUIREMENTS:
{reminders_text}

Content to refine:
{llm_input_content}

REMEMBER:
- Combine ALL services together in a single unified output
- Do NOT apply them separately or in sequence
- Every sentence must satisfy ALL requirements
- Word count takes priority, then tone, then other services"""
        
        elif services['suggestions']:
            system_prompt = self._build_suggestions_prompt(original_content)
            user_prompt = f"Please analyze this content and provide strategic feedback using the PwC framework:\n\n{original_content}"
        
        elif services['expand']:
            system_prompt = self._build_expansion_prompt(services['expand'], title, services['current_word_count'], has_supporting)
            user_prompt = llm_input_content
        
        elif services['compress']:
            system_prompt = self._build_compression_prompt(
                services['compress'], 
                title,
                services['current_word_count']
            )
            user_prompt = llm_input_content
        
        elif services['tone']:
            system_prompt = self._build_tone_prompt(services['tone'], title, services['current_word_count'], services['requested_word_limit'])
            user_prompt = llm_input_content
        
        else:
            system_prompt = self._build_generic_prompt(title)
            user_prompt = llm_input_content
        
        # Build messages for LLM
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            logger.info(f"[Refine Content] Active services: {active_services_count}")
            logger.info(f"[Refine Content] Title: {title}")
            
            if active_services_count > 1:
                task_descriptions = []
                if services['compress']:
                    task_descriptions.append(f"compress to {services['compress']} words")
                if services['expand']:
                    task_descriptions.append(f"expand to {services['expand']} words")
                if services['tone']:
                    task_descriptions.append(f"adjust tone to {services['tone']}")
                if services['research']:
                    task_descriptions.append("add research (PWC-first strategy)")
                if services['edit']:
                    task_descriptions.append("edit")
                if services['suggestions']:
                    task_descriptions.append("suggest improvements")
                logger.info(f"[Refine Content] MULTIPLE SERVICES - Combining: {', '.join(task_descriptions)}")
            
            logger.info('[Refine Content] Sending prompt to LLM', extra={'request_id': id(request_data)})

            logger.info('[Refine Content] Sending prompt to LLM', messages)
            async for chunk in self.stream_response(messages):
                yield chunk
                
        except Exception as e:
            logger.error(f"[Refine Content] Error: {e}", exc_info=True)
            error_message = f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
            yield error_message
    
    async def execute(self, *args, **kwargs):
        """Execute the refine content workflow"""
        return await self.refine_content(*args, **kwargs)

