from typing import Dict, List
import json

from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.messages import HumanMessage
from app.core.deps import get_llm_client_agent

from .schema import (
    DocumentStructure,
    DocumentBlock,
    FeedbackItem,
    EditorResult,
    BlockEditResult,
    EditorName,
    ListedBlockEditResult,
    SingleEditorFeedback
)

from .prompt import (
    BRAND_EDITOR_PROMPT,
    COPY_EDITOR_PROMPT,
    LINE_EDITOR_PROMPT,
    CONTENT_EDITOR_PROMPT,
    DEVELOPMENT_EDITOR_PROMPT
)
import logging
import os

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# GLOBAL LLM INSTANCE
# ----------------------------------------------------------------------
llm = get_llm_client_agent()


# ----------------------------------------------------------------------
# EDITOR PROMPT MAP
# ----------------------------------------------------------------------
PROMPTS_BY_EDITOR: Dict[str, str] = {
    "development": DEVELOPMENT_EDITOR_PROMPT,
    "content": CONTENT_EDITOR_PROMPT,
    "copy": COPY_EDITOR_PROMPT,
    "line": LINE_EDITOR_PROMPT,
    "brand": BRAND_EDITOR_PROMPT,
    "brand-alignment": BRAND_EDITOR_PROMPT,
}


# ----------------------------------------------------------------------
# Extract usable string content from LangChain/OpenAI response
# ----------------------------------------------------------------------
def _extract_raw_content(response) -> str:
    """
    Unified extractor for various LLM response shapes.
    """
    if response is None:
        return ""

    if isinstance(response, str):
        return response

    if hasattr(response, "content"):
        return response.content or ""

    if isinstance(response, dict):
        if isinstance(response.get("content"), str):
            return response["content"]
        if isinstance(response.get("text"), str):
            return response["text"]
        if "choices" in response and isinstance(response["choices"], list):
            choice = response["choices"][0]
            if isinstance(choice, dict):
                msg = choice.get("message", {})
                if isinstance(msg, dict):
                    return msg.get("content", "")
                return choice.get("text", "")
    if isinstance(response, (list, tuple)) and response:
        return _extract_raw_content(response[0])

    return str(response)


# ----------------------------------------------------------------------
# EDITOR ENGINE — runs the correct prompt, parses JSON, normalizes schema
# ----------------------------------------------------------------------
def run_editor_engine(editor_type: EditorName, blocks: list[DocumentBlock]) -> EditorResult:
    logger.info(f"AM IN EDITOR ENGINE: {editor_type}_editor_tool")
    warnings: List[str] = []
    prompt = PROMPTS_BY_EDITOR[editor_type]
    doc = DocumentStructure(blocks=blocks)

    document_json = doc.model_dump_json(indent=2)
    messages = [HumanMessage(content=prompt.replace("{document_json}", document_json))]

    response = llm.with_structured_output(ListedBlockEditResult).invoke(messages)
    llm_output = response
    llm_blocks = json.loads(llm_output.model_dump_json())["blocks"]

    def get_block_by_id(block_id: str):
        """
        Returns the block object matching the given block_id from LLM output.
        """
        for block in llm_blocks:
            if isinstance(block, dict) and block.get("id") == block_id:
                return block
        return None
    
    def extract_id(blk):
        return blk.get("id") or blk.get("block_id")

    suggestion_map = {
        extract_id(blk): blk
        for blk in llm_blocks
        if isinstance(blk, dict) and isinstance(extract_id(blk), str)
    }
    
    merged_blocks: List[BlockEditResult] = []

    for block in doc.blocks:
        suggestion = get_block_by_id(block.id)

        if suggestion is None:
            merged_blocks.append(
                BlockEditResult(
                    id=block.id,
                    type=block.type,
                    level=block.level,
                    original_text=block.text,
                    suggested_text=block.text,
                    has_changes=False,
                    feedback_edit=[],
                )
            )
            continue

        suggested = suggestion.get("suggested_text", block.text)
        has_changes = suggested != block.text

        raw_feedback = suggestion.get("feedback_edit", [])
        normalized_feedback: List[SingleEditorFeedback] = []

        # Handle feedback_edit - can be list of SingleEditorFeedback or dict
        if isinstance(raw_feedback, list):
            # Already a list, validate and convert
            for fb_item in raw_feedback:
                if isinstance(fb_item, dict):
                    # Try to create SingleEditorFeedback
                    try:
                        normalized_feedback.append(SingleEditorFeedback(**fb_item))
                    except Exception:
                        # If it fails, skip this feedback item
                        pass
        elif isinstance(raw_feedback, dict):
            # Convert dict format to SingleEditorFeedback list
            for editor_name, items in raw_feedback.items():
                if isinstance(items, list):
                    feedback_items = [
                        FeedbackItem(**fb) for fb in items if isinstance(fb, dict)
                    ]
                    if feedback_items:
                        normalized_feedback.append(
                            SingleEditorFeedback(editor=editor_name, items=feedback_items)
                        )

        merged_blocks.append(
            BlockEditResult(
                id=block.id,
                type=block.type,
                level=block.level,
                original_text=block.text,
                suggested_text=suggested,
                has_changes=has_changes,
                feedback_edit=normalized_feedback,
            )
        )
    

    return EditorResult(
        editor_type=editor_type,
        blocks=merged_blocks,  # FIXED: Return merged_blocks instead of llm_blocks
        warnings=warnings,
    )


# ----------------------------------------------------------------------
# FALLBACK RESULT WHEN LLM FAILS
# ----------------------------------------------------------------------
def _fallback_editor_result(editor_type: EditorName,
                            doc: DocumentStructure,
                            warnings: List[str]) -> EditorResult:

    return EditorResult(
        editor_type=editor_type,
        warnings=warnings,
        blocks=[
            BlockEditResult(
                id=b.id,
                type=b.type,
                level=b.level,
                original_text=b.text,
                suggested_text=b.text,
                has_changes=False,
                feedback_edit=[],
            )
            for b in doc.blocks
        ],
    )


# ----------------------------------------------------------------------
# TOOL WRAPPERS FOR SUPERVISOR AGENT
# ----------------------------------------------------------------------
@tool(
        "development_editor_tool", 
        args_schema=DocumentStructure,
        description="Applies Development Editor to the document structure."
)
def development_editor_tool(blocks: list[DocumentBlock]) -> dict:
    result = run_editor_engine("development", blocks)
    return result.model_dump()

@tool(
        "content_editor_tool", 
        args_schema=DocumentStructure,
        description="Applies Content Editor to the document structure."
)
def content_editor_tool(blocks: list[DocumentBlock]) -> dict:
    result = run_editor_engine("content", blocks)
    return result.model_dump()


@tool(
        "line_editor_tool", 
        args_schema=DocumentStructure,
        description="Applies Line Editor to the document structure."
)
def line_editor_tool(blocks: list[DocumentBlock]) -> dict:
    result = run_editor_engine("line", blocks)
    return result.model_dump()


@tool(
        "copy_editor_tool", 
        args_schema=DocumentStructure,
        description="Applies Copy Editor to the document structure."
)
def copy_editor_tool(blocks: list[DocumentBlock]) -> dict:
    result = run_editor_engine("copy", blocks)
    return result.model_dump()


@tool(
        "brand_editor_tool", 
        args_schema=DocumentStructure,
        description="Applies Brand Editor to the document structure."
)
def brand_editor_tool(blocks: list[DocumentBlock]) -> dict:
    result = run_editor_engine("brand-alignment", blocks)
    return result.model_dump()
