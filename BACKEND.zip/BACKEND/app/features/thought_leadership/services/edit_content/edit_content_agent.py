from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
from langchain_core.messages import HumanMessage

# Reuse existing components
from app.features.thought_leadership.services.edit_content.graph import build_sequential_graph
from app.features.thought_leadership.services.edit_content.utils import (
    segment_document_with_llm,
    apply_decisions_to_document
)
from app.features.thought_leadership.services.edit_content.schema import (
    ConsolidateResult,
    EditorResult
)
from app.core.deps import get_llm_client_agent

import json
import logging
import asyncio
import uuid
from dotenv import load_dotenv

load_dotenv(".env", override=True)

# ---------------------------------------------------------------------
# GLOBAL SETUP
# ---------------------------------------------------------------------
llm = get_llm_client_agent()
logger = logging.getLogger(__name__)
router = APIRouter()

# ---------------------------------------------------------------------
# REQUEST MODELS
# ---------------------------------------------------------------------
class EditContentRequest(BaseModel):
    """Initial request to start sequential editing workflow"""
    messages: List[dict]
    editor_types: Optional[List[str]] = None


class NextEditorRequest(BaseModel):
    """Request to continue to next editor after user approval"""
    thread_id: str
    paragraph_edits: List[dict]
    decisions: List[dict]
    accept_all: bool = False
    reject_all: bool = False


class FinalArticleRequest(BaseModel):
    """Request to generate final article from all decisions"""
    original_content: str
    paragraph_edits: List[dict]
    decisions: List[dict]
    accept_all: bool = False
    reject_all: bool = False


# ---------------------------------------------------------------------
# FRONTEND CONVERSION HELPER
# ---------------------------------------------------------------------
def convert_into_frontend(
    result: ConsolidateResult,
    original: str,
    current_editor: str = None
) -> dict:
    """
    Convert ConsolidateResult to frontend format.
    
    If current_editor is provided, show ONLY that editor's feedback.
    Otherwise, show all feedback (for final view).
    
    Args:
        result: ConsolidateResult from graph
        original: Original content text
        current_editor: Name of current editor to filter feedback (optional)
    
    Returns:
        Formatted dict for frontend consumption
    """
    paragraphs = []
    final_text = []
    
    # helper to normalize editor names used in models vs UI
    def _normalize_editor_name(e: str) -> str:
        if not e:
            return e
        # The pydantic schema uses 'brand' as the attribute but elsewhere we
        # use 'brand-alignment' as the editor id. Normalize to attribute name.
        mapping = {
            "brand-alignment": "brand"
        }
        return mapping.get(e, e)

    for i, block in enumerate(result.blocks):
        # Collect feedback - ONLY from current editor if specified
        all_feedback = []
        
        if current_editor:
            # Show ONLY current editor's feedback
            normalized = _normalize_editor_name(current_editor)
            editor_feedback_list = getattr(block.editorial_feedback, normalized, [])
            for feedback_item in editor_feedback_list:
                all_feedback.append({
                    "editor": normalized,
                    "issue": feedback_item.issue,
                    "fix": feedback_item.fix,
                    "impact": feedback_item.impact,
                    "rule_used": feedback_item.rule_used,
                    "priority": feedback_item.priority
                })
        else:
            # Show all feedback (for final view)
            for editor_name in ["development", "content", "copy", "line", "brand"]:
                editor_feedback_list = getattr(block.editorial_feedback, editor_name, [])
                for feedback_item in editor_feedback_list:
                    all_feedback.append({
                        "editor": editor_name,
                        "issue": feedback_item.issue,
                        "fix": feedback_item.fix,
                        "impact": feedback_item.impact,
                        "rule_used": feedback_item.rule_used,
                        "priority": feedback_item.priority
                    })
        
        # Check if paragraph is unchanged for auto-approval
        is_unchanged = block.original_text.strip() == block.final_text.strip()
        
        # Filter editorial_feedback to only include current editor if specified
        if current_editor:
            # Only include current editor's feedback in editorial_feedback structure
            filtered_editorial_feedback = {
                "development": [],
                "content": [],
                "copy": [],
                "line": [],
                "brand": []
            }
            # Populate only the current editor's feedback (use normalized key)
            normalized = _normalize_editor_name(current_editor)
            editor_feedback_list = getattr(block.editorial_feedback, normalized, [])
            filtered_editorial_feedback[normalized] = [
                {
                    "issue": fb.issue,
                    "fix": fb.fix,
                    "impact": fb.impact,
                    "rule_used": fb.rule_used,
                    "priority": fb.priority
                }
                for fb in editor_feedback_list
            ]
            editorial_feedback_to_send = filtered_editorial_feedback
        else:
            # Show all feedback (for final view)
            editorial_feedback_to_send = block.editorial_feedback.model_dump()
        
        paragraphs.append({
            "index": i,
            "block_id": block.id,
            "block_type": block.type,
            "level": block.level,
            "original": block.original_text,  # This will be updated doc for next editor
            "edited": block.final_text,
            "has_changes": block.original_text != block.final_text,
            "tags": [],
            "feedback": all_feedback,  # ONLY current editor's feedback (if specified)
            "editorial_feedback": editorial_feedback_to_send,  # Filtered to current editor only
            "approved": True if is_unchanged else None,  # Auto-approve unchanged paragraphs
            "autoApproved": is_unchanged  # Mark unchanged paragraphs as auto-approved
        })
        final_text.append(block.final_text)
    
    return {
        "type": "editor_complete" if current_editor else "final_complete",
        "original_content": original,
        "final_revised": "\n\n".join(final_text),
        "paragraph_edits": paragraphs,
        "total_blocks": len(paragraphs),
        "total_feedback_items": sum(len(p["feedback"]) for p in paragraphs)
    }


# ---------------------------------------------------------------------
# INITIAL WORKFLOW ENDPOINT
# ---------------------------------------------------------------------
@router.post("")
async def edit_content_workflow(request: EditContentRequest):
    """
    Start sequential editing workflow - runs first editor.
    
    Flow:
    1. Validate input
    2. Segment document
    3. Select and order editors
    4. Generate thread_id for checkpointing
    5. Build graph input state
    6. Invoke graph (stops at interrupt after first editor)
    7. Extract and format result
    8. Stream response to frontend
    """
    # Step 1: Validation
    if not request.messages:
        raise HTTPException(400, "Messages cannot be empty")
    
    content = request.messages[-1].get("content", "").strip()
    if not content:
        raise HTTPException(400, "Content cannot be empty")
    
    async def stream():
        try:
            loop = asyncio.get_event_loop()
            
            # Step 2: Segment document
            logger.info("Segmenting document")
            doc = await loop.run_in_executor(
                None,
                segment_document_with_llm,
                content
            )
            
            # Step 3: Filter and order editors by sequence
            editor_sequence = ["development", "content", "line", "copy", "brand-alignment"]
            requested_editors = request.editor_types or editor_sequence
            logger.info("Editor_types",requested_editors)
            selected_editors = [e for e in editor_sequence if e in requested_editors]
            
            if not selected_editors:
                raise ValueError("No valid editors selected")
            
            # Step 4: Generate thread_id for checkpointing
            thread_id = str(uuid.uuid4())
            
            # Step 5: Build graph input state
            graph_input = {
                "messages": [
                    HumanMessage(content=doc.model_dump_json(indent=2)),
                ],
                "document": doc,
                "selected_editors": selected_editors,  # List of editor names
                "current_editor_index": 0,
                "editor_results": [],
                "final_result": None,
                "thread_id": thread_id,
            }
            
            # Step 6: Invoke sequential graph with interrupt
            logger.info(f"Running first editor: {selected_editors[0]}")
            graph = build_sequential_graph()
            config = {"configurable": {"thread_id": thread_id}}
            
            # Invoke will stop at interrupt
            result_state = await loop.run_in_executor(
                None,
                lambda: graph.invoke(graph_input, config=config)
            )
            
            # Step 7: Get current editor result
            current_state = graph.get_state(config)
            editor_results = current_state.values.get("editor_results", [])
            
            if not editor_results:
                raise ValueError("No editor result found")
            
            current_result = editor_results[-1]
            current_editor = selected_editors[0]
            
            # Step 8: Extract ConsolidateResult
            result = result_state.get("final_result")
            logger.info("result", result)
            if result is None:
                raise ValueError("Graph completed without final_result")
            
            if isinstance(result, dict):
                result = ConsolidateResult.model_validate(result)
            
            # Step 9: Convert for frontend (ONLY current editor feedback)
            payload = convert_into_frontend(result, content, current_editor=current_editor)
            payload["thread_id"] = thread_id
            payload["current_editor"] = current_editor
            payload["editor_index"] = 0
            payload["total_editors"] = len(selected_editors)
            
            yield f"data: {json.dumps(payload)}\n\n"
            yield "data: [DONE]\n\n"
            
        except Exception as e:
            logger.exception("Edit content workflow failed")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
    
    return StreamingResponse(stream(), media_type="text/event-stream")


# ---------------------------------------------------------------------
# NEXT EDITOR ENDPOINT
# ---------------------------------------------------------------------
@router.post("/next")
async def next_editor_workflow(request: NextEditorRequest):
    """
    Continue to next editor after user approval.
    
    Flow:
    1. Load checkpointed state
    2. Get current editor result
    3. Apply user decisions to update document
    4. Check if all editors complete
    5. Update state with approved document
    6. Resume graph execution (runs next editor)
    7. Extract and format next editor result
    8. Stream response to frontend
    """
    async def stream():
        try:
            loop = asyncio.get_event_loop()
            
            # Step 1: Load graph state from checkpoint
            graph = build_sequential_graph()
            config = {"configurable": {"thread_id": request.thread_id}}
            
            current_state = await loop.run_in_executor(
                None,
                lambda: graph.get_state(config)
            )
            
            if not current_state or not current_state.values:
                raise ValueError(f"Session not found: {request.thread_id}")
            
            state = current_state.values
            
            # Step 2: Get current editor result
            editor_results = state.get("editor_results", [])
            if not editor_results:
                raise ValueError("No editor results found")
            
            current_editor_result = editor_results[-1]
            original_doc = state["document"]
            selected_editors = state["selected_editors"]
            current_idx = state.get("current_editor_index", 0)
            
            # Step 3: Apply decisions to update document (THIS BECOMES ORIGINAL FOR NEXT EDITOR)
            updated_doc = await loop.run_in_executor(
                None,
                apply_decisions_to_document,
                original_doc,
                current_editor_result,
                request.paragraph_edits,
                request.decisions,
                request.accept_all,
                request.reject_all
            )
            
            # Step 4: Move to next editor
            next_idx = current_idx + 1
            
            if next_idx >= len(selected_editors):
                # All editors complete
                yield f"data: {json.dumps({'type': 'all_complete', 'message': 'All editors completed'})}\n\n"
                yield "data: [DONE]\n\n"
                return
            
            # Step 5: Update state with approved document
            updated_state = {
                **state,
                "document": updated_doc,  # Updated doc becomes "original" for next editor
                "current_editor_index": next_idx,
                "messages": [
                    HumanMessage(content=updated_doc.model_dump_json(indent=2)),
                ],
            }
            
            # Update state in checkpoint
            graph.update_state(config, updated_state)
            
            # Step 6: Resume graph from interrupt
            def resume_graph():
                # Stream from interrupt point - LangGraph will continue from where it left off
                final_state = None
                for chunk in graph.stream(updated_state, config=config):
                    # Each chunk is a dict with node name as key and state as value
                    current_state = graph.get_state(config)
                    final_state = current_state.values
                    
                    # Check if we've hit the next interrupt (expected behavior)
                    if current_state.next and len(current_state.next) > 0:
                        # If next contains __interrupt__, we've reached the next pause point
                        if "__interrupt" in current_state.next:
                            break
                
                # Return the final state (should have final_result from prepare_result node)
                if final_state is None:
                    final_state = graph.get_state(config).values
                
                return final_state
            
            result_state = await loop.run_in_executor(None, resume_graph)
            
            # Step 7: Get new editor result
            new_state = graph.get_state(config)
            new_editor_results = new_state.values.get("editor_results", [])
            
            if not new_editor_results or len(new_editor_results) <= len(editor_results):
                raise ValueError("Next editor did not produce result")
            
            new_editor_result = new_editor_results[-1]
            next_editor = selected_editors[next_idx]
            
            # Step 8: Extract ConsolidateResult
            result = result_state.get("final_result")
            if result is None:
                raise ValueError("Graph completed without result")
            
            if isinstance(result, dict):
                result = ConsolidateResult.model_validate(result)
            
            # Step 9: Get original content for frontend (updated doc)
            original_content = "\n\n".join([b.text for b in updated_doc.blocks])
            
            # Step 10: Convert for frontend (ONLY next editor feedback)
            payload = convert_into_frontend(result, original_content, current_editor=next_editor)
            payload["thread_id"] = request.thread_id
            payload["current_editor"] = next_editor
            payload["editor_index"] = next_idx
            payload["total_editors"] = len(selected_editors)
            
            yield f"data: {json.dumps(payload)}\n\n"
            yield "data: [DONE]\n\n"
            
        except Exception as e:
            logger.exception("Next editor workflow failed")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
    
    return StreamingResponse(stream(), media_type="text/event-stream")


# ---------------------------------------------------------------------
# FINAL ARTICLE GENERATION ENDPOINT
# ---------------------------------------------------------------------
@router.post("/final")
async def generate_final_article(request: FinalArticleRequest):
    """
    Generate final article from all user decisions.
    
    Decision priority:
    1. Global flags (reject_all > accept_all)
    2. Explicit paragraph decisions (approved=True/False)
    3. Auto-approval (for unchanged paragraphs)
    4. Default to original
    
    Args:
        request: FinalArticleRequest with all paragraph edits and decisions
    
    Returns:
        JSONResponse with final_article text
    """
    try:
        # Validation
        if not request.original_content:
            raise HTTPException(400, "Original content cannot be empty")
        
        if not request.paragraph_edits:
            raise HTTPException(400, "Paragraph edits cannot be empty")
        
        if request.accept_all and request.reject_all:
            raise HTTPException(400, "Cannot accept all and reject all at the same time")
        
        # Build decision map
        decision_map = {
            d["index"]: d.get("approved")
            for d in request.decisions
        }
        
        # Sort paragraphs
        sorted_edits = sorted(
            request.paragraph_edits,
            key=lambda x: x["index"]
        )
        
        # Validate indices
        indices = [p["index"] for p in sorted_edits]
        if len(indices) != len(set(indices)):
            raise HTTPException(400, "Duplicate paragraph indices detected")
        
        final_paragraphs = []
        block_types = []
        
        for edit in sorted_edits:
            index = edit["index"]
            approved = decision_map.get(index)
            auto_approved = edit.get("autoApproved", False)
            # Use a separate variable for the block type to avoid overwriting the
            # `block_types` list variable defined above.
            block_type = edit.get("block_type", "paragraph")
            level = edit.get("level", 0)

            block_types.append({
                "index": len(final_paragraphs),
                "type": block_type,
                "level": level
            })
            
            # Global overrides
            if request.reject_all:
                final_paragraphs.append(edit["original"])
                continue
            
            if request.accept_all:
                final_paragraphs.append(edit["edited"])
                continue
            
            # Paragraph decisions
            # Priority: explicit decision > auto-approval > default to original
            if approved is True:
                final_paragraphs.append(edit["edited"])
            elif approved is False:
                final_paragraphs.append(edit["original"])
            elif approved is None and auto_approved:
                # Only use auto-approval if no explicit decision was made
                final_paragraphs.append(edit["edited"])
            else:
                final_paragraphs.append(edit["original"])
        
        final_article = "\n\n".join(final_paragraphs)
        
        logger.info(
            "[Final Article] Generated final article with %d paragraphs",
            len(final_paragraphs)
        )
        
        return JSONResponse(
            content={"final_article": final_article,
            "block_types":block_types}
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("[Final Article] Error")
        raise HTTPException(500, "An error occurred while generating final article")
