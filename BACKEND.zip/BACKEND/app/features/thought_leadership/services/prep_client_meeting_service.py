from app.infrastructure.llm.base_services import BaseTLStreamingService
from app.features.thought_leadership.services.web_search_service import WebSearchService
from app.common.factiva_client import FactivaClient
from typing import AsyncGenerator, List, Optional, Dict, Any
import logging
import re
import json

logger = logging.getLogger(__name__)

# ============================================================================
# SHARED PROMPT COMPONENTS - Extracted to eliminate duplication
# ============================================================================

ANTI_FABRICATION_RULES = """### **ANTI-FABRICATION RULES** (MANDATORY):
- Do NOT invent statistics, percentages, dates, case studies, company claims, research findings, or expert quotes.
- Do NOT mention any report, survey, whitepaper, or study unless it exists.
- If no real data is available, speak generically (e.g., "many companies," "some industries," "a growing trend").
- Do NOT attribute ideas to specific companies unless they are well-known, verifiable examples. When unsure, write more generally.
- **COMPETITOR PROHIBITION (CRITICAL):** Do NOT use, cite, reference, or mention ANY content, methodologies, frameworks, case studies, research, insights, tools, or examples from Deloitte, McKinsey, EY, KPMG, or BCG — under ANY circumstances. Use ONLY PwC sources, methodologies, and case studies."""

PARAGRAPH_CITATIONS = """### **PARAGRAPH-LEVEL REFERENCES (CRITICAL)**
- **Citations must be placed INLINE at the end of the last sentence of each paragraph, NOT on a separate line.**
- **ONLY use citation numbers that match the sources provided below. Do NOT invent or add citation numbers beyond what is provided.**
- Use the format: **(Ref. 1)**, **(Ref. 2)**, etc.
- Each citation must correspond to a real source in the "Citations & References" section below.
- If multiple references inform a paragraph, list them as: **(Ref. 1; Ref. 3)**."""

CLIENT_MEETING_TEMPLATE_PROMPT = """## CLIENT MEETING PREPARATION TEMPLATE (MANDATORY STRUCTURE)

Follow this structure EXACTLY. Do not rename sections. Do not reorder sections.
Use concise, executive-ready language suitable for a client meeting pre-read.

### 1.Client Snapshot
- Total Revenue 
- Primary Business Lines
- Key Competitors

### 2. Financial Overview (Powered by CapIQ)
- YoY revenue growth
- Gross profit margin
- YoY stock performance
- Efficiency ratio
- 3-year total shareholder returns

### 3. Leadership & Governance (From BoardEx)
- Names
- Roles

### 4. Industry & Market Context
- Value chain overview
- Key considerations (including topic-specific considerations)
- Recent trends
- Common issues
- Potential opportunities

### 5. Competitive Insights
- Major news and announcements from the last 3–6 months
- Any competitor + topic developments from the last 12 months

### 6. Recent Developments & News (Factiva / WSJ)
- Key client developments from the last 3–6 months
- Client + topic news (last 12 months)
- Client + audience news (last 12 months

### 7. Strategic Objectives
- Earnings call and investor presentation priorities (last 6 months)
- Leadership public statements (last 6 months)
- Client + audience priorities (last 12 months)
- Key objectives from latest 10-K

### 8. What Others Are Saying
- Industry analyst perspectives (last 6 months)

### 9. Relevant Thought Leadership
- Internal sources first (topic + industry)
- Cross-industry topic insights second

### 10. Opportunity Assessment
- Test hypothesis that the topic is relevant and meaningful for the client
"""


BRAND_ALIGNMENT_EDITOR = """### **BRAND ALIGNMENT EDITOR Instructions**

    ### ROLE
    You ensure content strictly follows PwC brand: voice, terminology, territory references, visual identity, and messaging framework.

    ---

    ### VOICE AND TONE

    **Collaborative:**
    - Use "we/our/us" not "PwC" for the firm.
    - Use "you/your organization" not "clients".
    - Use conversational tone with contractions.

    **Bold:**
    - Use assertive, decisive language.
    - Remove unnecessary qualifiers.
    - Use short, direct sentences.

    **Optimistic:**
    - Prefer active voice.
    - Future-forward, outcome-focused.
    - Use action verbs: transform, unlock, accelerate, adapt, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transition, etc.

    ---

    ### PROHIBITED TERMS / STYLE

    - Do **not** use:
      - "catalyst" or "catalyst for momentum" → use "driver", "enabler", "accelerator".
      - "PwC Network" → "PwC network" (lowercase n).
      - "clients" when "you/your organization" works.
      - Emojis in professional content.
      - ALL CAPS for emphasis (only for acronyms).
      - Exclamation marks in headlines, subheads, or body copy.

    ---

    ### CHINA & TERRITORIES (LEGAL – STRICT)

    **Correct usage:**
    - "PwC China" (not "PwC China/Hong Kong").
    - "Hong Kong SAR", "Macau SAR".
    - "Chinese Mainland" (not "Mainland China").
    - Office references: "PwC China, Beijing Office", "PwC China, Hong Kong Office", etc.
    - Use "PwC China", "PwC Hong Kong", "PwC Macau" when referring to a single territory.
    - Use "Countries/Regions" or "Countries and Regions" where appropriate.
    - Use "Territory" in the context of PwC network/member firms.

    **Prohibited usage:**
    - "PwC China/Hong Kong" or variants.
    - "Mainland China" → use "Chinese Mainland".
    - "Greater China" (external use).
    - "PRC" (external use).
    - "CaTSH" (internal only).

    **Geographic references:**
    - You may reference "Chinese Mainland" and "Hong Kong" together, but never imply the same status.
    - Reflect that Hong Kong is a Special Administrative Region within China.

    ---

    ### BRAND POSITIONING & MESSAGING

    **Catalyst for Momentum (brand idea):**
    - Embody it through tone and vocabulary.
    - Do **not** use the word "catalyst" or phrase "catalyst for momentum".

    **Messaging framework:**
    - Use network-wide key messages (explicitly or implicitly).
    - Support with proof points (data, examples, case studies) where appropriate.
    - Ensure local legal/risk approval before using proof points.

    **"So you can":**
    - Reserved mainly for primary surfaces (e.g. paid ads, key headlines, key sign-offs).
    - Structure: "We [capabilities] so you can [outcomes]."
    - Use sparingly to protect impact (don't overuse).

    ---

    ### BRAND VOCABULARY (INFUSE, DON'T FORCE)

    **Movement words (examples):**
    adapt, break through, disrupt, evolve, modernize, reconfigure, redefine, reimagine, reinvent, reshape, rethink, revolutionize, shift, spark, transform, transition, unlock.

    **Energy words (examples):**
    act decisively, agile, anticipate, build, create, deliver, fast-track, forward-thinking, lay foundations, lead, move forward, navigate, propel, spot, surge.

    **Pace / outcome words (examples):**
    achieve, act, capitalize, drive, embrace resilience, further/faster, seize, accelerate progress, breakthrough results, build trust, gain competitive advantage, unlock value.

    Use combinations that feel natural and on-brand.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply **every** brand rule systematically.
    2. Enforce voice, terminology, geography, and positioning.
    3. Ensure strict legal compliance for China references.
    4. Preserve meaning while fixing brand violations.
    5. Flag all prohibited terms and replace with allowed alternatives."""

COPY_EDITOR_RULES = """## COPY EDITOR (IMPORTANT)

    ### ROLE
    You enforce PwC copy standards: punctuation, capitalization, spelling, abbreviations, numbers, dates, formats, and style consistency.

    Apply rules systematically to the full text while preserving meaning.

    ---

    ### KEY RULES (GROUPED)

    #### Abbreviations, Acronyms, All Caps
    - Use Oxford/Oxford Learner's Dictionary for standard abbreviations.
    - Acronyms: all caps (CEO, ESG, AI, B2B); exceptions: PwC, xLOS.
    - First use: spell out then acronym in brackets unless in OED (e.g. artificial intelligence (AI)).
    - Don't create new acronyms.
    - All caps only for acronyms or trademarked names (IDEO); never for emphasis.

    #### Spelling – American English
    - Use US English: -ize/-yze; -ization; -or (color), -er (center), -se nouns (license, defense).

    #### Contractions
    - Use contractions in most marketing, digital, internal, thought leadership, and speeches.
    - Avoid in formal/legal/sensitive documents.

    #### Numbers / Percentages
    - Percentages: always numerals + "%", no space ("5%", not "five percent").
    - Use commas in numbers 1,000+.
    - Large numbers: numerals + "million"/"bn" or "m"/"bn" (lowercase), consistent.

    #### PwC References
    - Write "PwC network" (lowercase n).
    - Don't capitalize generic descriptions ("network").

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Apply all relevant rules systematically.
    2. Check punctuation, capitalization, formatting, and style.
    3. Ensure consistency in numbers, dates, abbreviations, and terminology.
    4. Preserve meaning while correcting style and format."""

LINE_EDITOR_RULES = """## LINE EDITOR (IMPORTANT)

    ### ROLE
    You improve sentence-level clarity, correctness, consistency, and tone.

    **Boundaries (do NOT do):**
    - No restructuring sections or reordering major ideas.
    - No evaluating insight strength or evidence.
    - No detailed punctuation/formatting fixes.
    - No brand voice policing.

    You work **only** at sentence and wording level.

    ---

    ### OBJECTIVES

    1. Strengthen clarity and readability.
    2. Ensure correct grammar, usage, and voice.
    3. Align with PwC tone: clear, active, human, direct.
    4. Use inclusive, gender-neutral language.
    5. Enforce consistent terminology and style.
    6. Preserve intent while tightening execution.

    ---

    ### KEY RULES

    #### Active vs passive
    - Prefer active voice.
    - Convert passive where possible without changing meaning.

    #### Fewer vs less
    - Fewer = countable (fewer meetings, errors, people).
    - Less = uncountable (less time, noise, complexity).

    #### Point of view
    - Use "we/our/us" for the firm when appropriate.
    - Use "you/your" to address the reader directly.

    #### Gender neutrality
    - Use "they" for unspecified individuals.
    - Avoid gendered nouns (chairman → chairperson).

    #### Sentence length
    - One clear idea per sentence.
    - Break long, multi-clause sentences into shorter ones.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Output **only revised text**, no commentary.
    2. Preserve meaning while improving expression.
    3. Apply these rules consistently.
    4. Do not invent content—only refine what exists."""

CONTENT_EDITOR_RULES = """## CONTENT EDITOR (CRITICAL)

    ### ROLE
    You evaluate and strengthen the **insights, logic, and objective fit** of the content while preserving the author's core intent and voice.

    You focus on: insight strength, alignment with objectives, language that supports those objectives, evidence quality, structure, and MECE logic.

    ---

    ### OBJECTIVES

    1. **Evaluate insight strength and clarity**
      - Are insights specific, actionable, and clearly stated?
      - Are key insights prominent and easy to find?

    2. **Assess against content objectives**
      - Identify stated or implied objectives.
      - Check whether structure and content actually deliver on them.
      - Flag gaps between promise and delivery.

    3. **Refine language for objective alignment**
      - Preserve voice.
      - Strengthen language that supports objectives.
      - Remove or revise language that dilutes or contradicts objectives.

    4. **Ensure logical rigor and evidence quality**
      - Support significant claims with data, examples, or reasoning.
      - Remove or tighten weak or vague claims.
      - Maintain MECE structure where applicable.

    ---

    ### KEY RULES

    #### Insight evaluation
    - Strong insights are: Clear, specific, actionable, supported by evidence or solid reasoning, positioned where they have maximum impact.
    - Weak insights: Vague, generic or unsupported, hidden in dense text.

    #### Evidence and support
    - Every meaningful claim needs appropriate support: Data, stats, surveys, reputable sources or expert opinions, case examples, clear logic.

    #### Logical structure and flow
    - Ensure: Clear intro, logical progression of ideas, smooth transitions between sections, strong conclusion.
    - Remove: Logical fallacies, redundant or conflicting points.

    #### MECE organization
    - Sections and categories should be: Mutually exclusive (no overlap in content scope), collectively exhaustive (cover all relevant aspects).

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Evaluate insight strength and clarity across the whole piece.
    2. Assess and note alignment with content objectives.
    3. Refine language to better serve those objectives while preserving voice.
    4. Check evidence sufficiency and logical structure.
    5. Preserve intent while increasing clarity and impact.
    6. Flag issues with specific examples, rule references, and clear fixes where needed."""

DEVELOPMENT_EDITOR_RULES = """## DEVELOPMENT EDITOR (CRITICAL)

    ### ROLE
    You transform content at the **structure and narrative** level while enforcing PwC's tone: **Bold, Collaborative, Optimistic**.

    You diagnose and fix clarity, structure, logic, and flow problems. You do not hedge, praise, or apologize.

    ---

    ### TONE OF VOICE (ALWAYS USE ALL THREE)

    #### Bold
    - Use decisive, assertive language; remove soft qualifiers.
    - Cut jargon and filler; keep sentences tight.
    - Use rhythm and emphasis through structure, not exclamation marks.

    #### Collaborative
    - Write conversationally.
    - Use "we" and "you" to emphasize partnership: "We help you…" not "PwC helps organizations…".
    - Ask sharp, relevant questions that invite reflection.

    #### Optimistic
    - Use active voice and clear calls to action.
    - Show opportunity beyond challenge.
    - Use positive but realistic language supported by data.

    ---

    ### WHAT YOU CHANGE

    #### A. Structure
    - Reorder or regroup content for stronger logic.
    - Break long paragraphs.
    - Strengthen openings and conclusions.
    - Ensure each section supports one clear idea.

    #### B. Clarity
    - Replace vague claims with precise statements.
    - Remove ambiguity and contradictions.
    - Cut unnecessary detail that doesn't advance the message.

    #### C. Purpose alignment
    - Identify: Core message, priority takeaways, desired actions or mindset shift.
    - Rewrite so structure and emphasis serve that purpose.

    #### D. Language discipline
    - Short, direct sentences.
    - Simple transitions.
    - No clichés, filler, or unnecessary corporate jargon.
    - No poetic or ornamental phrasing.

    #### E. Brutal accuracy
    - Call out weak reasoning and unrealistic claims.
    - Tighten or remove hype.
    - Strengthen arguments with clearer logic and framing.

    ---

    ### CONSTRAINTS

    - No praise of the original text.
    - No process explanations or apologies.
    - No exclamation marks.
    - No generic motivational language.
    - Don't write "PwC helps organizations…": always "we".
    - Avoid filler (e.g. "in order to", "at the end of the day", "moving forward", "leverage" used as a buzzword).
    - Avoid lofty promises ("guaranteed", "transformational", "revolutionary") unless explicitly backed by evidence.
    - Tone must always remain **Bold + Collaborative + Optimistic** at the same time.

    ---

    ### OUTPUT REQUIREMENTS

    When editing, you must:
    1. Diagnose structural and narrative issues.
    2. Provide specific, actionable feedback.
    3. Rewrite for maximum clarity and impact.
    4. Enforce Bold + Collaborative + Optimistic tone throughout.
    5. Do not praise or apologize."""

# class Source:
#     """
#     Represents a research source (Factiva article, URL, etc.) for citation tracking.
#     """
#     def __init__(self, id: int, url: str, title: str = "", content: str = "", byline: str = "", publication_date: str = "", source_name: str = ""):
#         self.id = id
#         self.url = url
#         self.title = title
#         self.content = content
#         self.byline = byline
#         self.publication_date = publication_date
#         self.source_name = source_name


class PrepClientMeetingService(BaseTLStreamingService):
    """Service for prep client meeting generation workflow with Factiva research integration"""
    
    def __init__(self, llm_service, factiva_client: Optional[FactivaClient] = None):
        """
        Initialize prep client meeting Service
        
        Args:
            llm_service: LLM service
            factiva_client: Optional Factiva client for research sources
        """
        super().__init__(llm_service)
        self.web_search_service = WebSearchService()
        self.factiva_client = factiva_client
    
    def _build_prompt(
        self,
        clientname: str,
        topic: str,
        audience: str,
        word_limit: int,
        outline_doc: str = "",
    supporting_doc: str = ""
    ) -> str:
        """
        Build complete system prompt by combining shared components with format-specific config.
        
        Args:
            clientname, topic, audience, word_limit: Content parameters        
        Returns:
            Complete formatted system prompt string
        """
       
        # Build format-specific opening based on content type
        context_sections = ""
        if outline_doc:
            context_sections += f"\n\n### OUTLINE\n{outline_doc}"
        if supporting_doc:
            context_sections += f"\n\n### SUPPORTING CONTEXT\n{supporting_doc}"

        task_desc = f"""**Task:** Prepare a professional client meeting pre-read for **{clientname}** on the topic **"{topic}"**.
        The document is intended for **{audience}** and should help stakeholders quickly understand the client context, strategic considerations, and discussion angles **before the meeting**.
        Target length: approximately **{word_limit} words** (±2%).
        """
        # Build prompt template
        prompt = f"""
        {task_desc}
        {context_sections}
        ---
        {ANTI_FABRICATION_RULES}

        {PARAGRAPH_CITATIONS}

        {CLIENT_MEETING_TEMPLATE_PROMPT}

        ## Writing Style & Quality Standards 
        - **Active voice preferred**
        - **Clear, direct language**
        - **Minimal jargon** (define when used)
        - **Maintain focus** on topic and audience
        ---

        ## Word-Count Guidance
        - Target total ≈ {word_limit} words.  
        - Trim redundant sentences if too long; don't remove key data or insight.
        - Use shorter paragraphs and section-based structure.
        - Dont mention word count explicitly in the output.

        ---

        {BRAND_ALIGNMENT_EDITOR}

        {COPY_EDITOR_RULES}

        {LINE_EDITOR_RULES}

        {CONTENT_EDITOR_RULES}

        {DEVELOPMENT_EDITOR_RULES}

            """
        return prompt

    async def draft_client_meeting_prompt(self, user_prompt: str, clientname: str, topic: str, audience: str, word_limit: int, outline_doc: str = "",
    supporting_doc: str = "") -> AsyncGenerator[str, None]:

        system_prompt = self._build_prompt(
            clientname=clientname,
            topic=topic,
            audience=audience,
            word_limit=word_limit,outline_doc=outline_doc,
    supporting_doc=supporting_doc
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        # Step 1: Generate initial content and collect it
        logger.info(f" [meeting] Starting meeting content generation - target: {word_limit} words (±10%)")
        generated_content = await self.get_content(messages, max_tokens=30000)
        
        # Step 2: Validate word count
        logger.info(f"[meeting] Validating word count...")
        validation_result = await self.validate_word_count(
            content=generated_content,
            word_limit=word_limit,
            tolerance_percent=10
        )
        
        # Step 3: If content doesn't meet word count requirements, recreate it
        if not validation_result['is_valid']:
            logger.info(f"[meeting] Word count adjustment needed - {validation_result['status']}")
            
            # Recreate content with adjusted length and yield only the adjusted content
            async for chunk in self.recreate_content_with_adjusted_length(
                original_content=generated_content,
                validation_result=validation_result,
                topic=topic,
                audience=audience,
                outline_doc=outline_doc,
                supporting_doc=supporting_doc
            ):
                yield chunk
            
            logger.info(f"[meeting] Content adjustment completed")
        else:
            logger.info(f"[meeting] Content meets word count requirements - no adjustment needed")
            # Yield only the valid content
            # yield generated_content
            yield f"data: {json.dumps({'type': 'content', 'content': generated_content})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'done': True})}\n\n"


#     async def draft_client_meeting_prompt(
#         self, 
#         user_prompt: str
#     ) -> AsyncGenerator[str, None]:        
#         system_prompt = """You are an expert content writer for PwC thought leadership.
# Create comprehensive, high-quality professional content that demonstrates deep expertise and provides substantial value to readers.

# Writing Principles:
# - Professional tone with authoritative insights backed by evidence
# - Clear structure with compelling narrative flow
# - Include relevant PwC frameworks and methodologies with detailed explanations
# - Provide actionable recommendations with implementation guidance
# - Develop each key point thoroughly with context, analysis, and implications

# Remember: Thought leadership requires depth. Provide comprehensive coverage with rich insights, multiple perspectives, and thorough analysis."""
        
#         messages = [
#             {"role": "system", "content": system_prompt},
#             {"role": "user", "content": user_prompt}
#         ]
        
#         async for chunk in self.stream_response(messages):
#             yield chunk

    async def draft_content(
        self, 
        topic: str, 
        audience: str, 
        context: str
    ) -> AsyncGenerator[str, None]:
        
        user_prompt = f"Generate the client meeting pre-read using the above structure about {topic} for {audience}."
        if context:
            user_prompt += f"\n\nAdditional context: {context}"
        
        # async for chunk in self.draft_content_from_prompt(user_prompt):
        #     yield chunk
    
    async def execute(self, *args, **kwargs):
        """Execute draft content generation"""
        return await self.draft_content(*args, **kwargs)
    
    async def validate_word_count(self, content: str, word_limit: int, tolerance_percent: int = 10) -> dict:
        """
        Validate if the generated content word count is within acceptable limits using LLM.
        
        Args:
            content: Generated content to validate
            word_limit: Target word limit
            tolerance_percent: Acceptable deviation percentage (default: 10%)
        
        Returns:
            dict with keys:
                - word_count: Actual word count of the content
                - word_limit: Target word limit
                - tolerance_percent: Tolerance percentage
                - is_valid: Boolean indicating if content meets word count requirement
                - min_words: Minimum acceptable words (word_limit - tolerance)
                - max_words: Maximum acceptable words (word_limit + tolerance)
                - deviation: Actual deviation from target (positive = over, negative = under)
                - status: Status message ('VALID', 'TOO_SHORT', 'TOO_LONG')
        """
        logger.info(f"[WORD_COUNT_VALIDATION] Starting word count validation using regex")
        logger.info(f"[WORD_COUNT_VALIDATION] Content length: {len(content)} characters")
        logger.info(f"[WORD_COUNT_VALIDATION] Target word limit: {word_limit} (±{tolerance_percent}%)")
        
        # Regex-based word counting - use word boundaries to count actual words
        # Remove markdown formatting symbols first, then count words using regex
        normalized_content = content
        
        # Normalize newlines and whitespace
        normalized_content = re.sub(r'[\n\r\t]+', ' ', normalized_content)  # Replace newlines/tabs with spaces
        
        # Remove markdown formatting symbols (**, ##, ---, etc.) but keep content
        normalized_content = re.sub(r'\*\*', '', normalized_content)  # Remove **bold**
        normalized_content = re.sub(r'#+\s+', '', normalized_content)  # Remove ### headers
        normalized_content = re.sub(r'---+', '', normalized_content)  # Remove --- dividers
        normalized_content = re.sub(r'`+', '', normalized_content)  # Remove backticks
        normalized_content = re.sub(r'_{2,}', '', normalized_content)  # Remove underscores
        
        # Use regex word boundary to count words - includes contractions and hyphenated words
        # This pattern matches sequences of letters, digits, apostrophes, and hyphens
        word_pattern = r'\b[\w\'-]+\b'
        words = re.findall(word_pattern, normalized_content, re.UNICODE)
        
        # Filter out metadata keywords (case-insensitive)
        metadata_keywords = {'data', 'type', 'content'}
        filtered_words = [word for word in words if word.lower() not in metadata_keywords]
        
        word_count = len(filtered_words)
        logger.info(f"[WORD_COUNT_VALIDATION] Regex-based word count: {word_count} words (after removing metadata)")
        
        # Calculate tolerance range
        tolerance_words = int((word_limit * tolerance_percent) / 100)
        min_words = word_limit - tolerance_words
        max_words = word_limit + tolerance_words
        
        # Determine if content is valid
        is_valid = min_words <= word_count <= max_words
        
        # Calculate deviation
        deviation = word_count - word_limit
        
        # Determine status
        if is_valid:
            status = 'VALID'
        elif word_count < min_words:
            status = 'TOO_SHORT'
        else:
            status = 'TOO_LONG'
        
        logger.info(f"[WORD_COUNT_VALIDATION] Final validation result: {status} - {word_count} words (target: {word_limit})")
        
        return {
            'word_count': word_count,
            'word_limit': word_limit,
            'tolerance_percent': tolerance_percent,
            'is_valid': is_valid,
            'min_words': min_words,
            'max_words': max_words,
            'deviation': deviation,
            'status': status
        }
    
    async def recreate_content_with_adjusted_length(
        self,
        original_content: str,
        validation_result: dict,
        topic: str,
        audience: str,
        outline_doc: str = "",
        supporting_doc: str = ""
    ) -> AsyncGenerator[str, None]:
        """
        Recreate and adjust content to meet word count requirements.
        
        If content is too long, compress it while maintaining key insights.
        If content is too short, expand it with more details and examples.
        
        Args:
            original_content: The original generated content
            validation_result: Result from validate_word_count()
            topic: Topic of the content
            audience: Target audience
            outline_doc: Optional outline document for reference
            supporting_doc: Optional supporting document for reference
        
        Yields:
            Adjusted content chunks
        """
        word_count = validation_result['word_count']
        word_limit = validation_result['word_limit']
        status = validation_result['status']
        
        logger.info(f"[CONTENT_RECREATION] Starting content adjustment: status={status}, current_words={word_count}, target_words={word_limit}")
        
        if status == 'TOO_LONG':
            action_prompt = f"""The generated content has {word_count} words, but the target is {word_limit} words.
Please COMPRESS and condense the content to approximately {word_limit} words while:
1. Preserving all key insights and main arguments
2. Removing redundant examples or explanations
3. Tightening paragraph structures
4. Keeping important data points and evidence

Ensure all section headers remain in bold (**Header**) format.

Original content to compress:

{original_content}"""
        
        else:  # TOO_SHORT
            action_prompt = f"""The generated content has only {word_count} words, but the target is {word_limit} words.

Please EXPAND and enrich the content to approximately {word_limit} words by:
1. Adding more detailed analysis and context to existing sections
2. Expanding key insights with deeper explanations

Ensure all section headers remain in bold (**Header**) format.
Do NOT add fabricated data or unverifiable claims.

Original content to expand:

{original_content}"""
        if outline_doc:
            action_prompt += f"\n\nReference outline:\n{outline_doc}"

        if supporting_doc:
            action_prompt += f"\n\nUse supporting material as factual grounding:\n{supporting_doc}"

        logger.debug(f"[CONTENT_RECREATION] Prompting LLM for {status.lower()} adjustment")
        
        system_prompt = """You are an expert content editor specializing in PwC thought leadership. 
Your task is to adjust content length while maintaining quality, clarity, and impact.

When compressing:
- Keep all critical insights and evidence
- Tighten language and eliminate filler words
- Maintain structure and flow

When expanding:
- Add meaningful details and depth to existing arguments
- Use authoritative language and maintain professional tone

Always maintain PwC brand voice: collaborative, bold, and optimistic."""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": action_prompt}
        ]
        
        logger.info(f"[CONTENT_RECREATION] Calling LLM to adjust content length")
        async for chunk in self.stream_response(messages, temperature=0.7, max_tokens=30000):
            yield chunk
        
        logger.info(f"[CONTENT_RECREATION] Content adjustment completed")
