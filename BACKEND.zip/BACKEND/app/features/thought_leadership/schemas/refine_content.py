"""Pydantic schemas for Refine Content workflow with JSON-based service configuration"""

from pydantic import BaseModel, Field
from typing import Optional, List, Any


class ExpandServiceConfig(BaseModel):
    """Configuration for expand content service"""
    isSelected: bool
    type: str = "expand"
    original_word_count: int
    expected_word_count: int
    supportingDoc: Optional[str] = None


class CompressServiceConfig(BaseModel):
    """Configuration for compress content service"""
    isSelected: bool
    type: str = "compress"
    original_word_count: int
    expected_word_count: int


class ToneServiceConfig(BaseModel):
    """Configuration for tone adjustment service"""
    isSelected: bool
    type: str = "adjust_audience_tone"
    audience_tone: str


class PWCContentConfig(BaseModel):
    """PWC content source configuration - HIGHEST PRIORITY"""
    isSelected: bool
    supportingDoc: Optional[str] = None
    supportingDoc_instructions: Optional[str] = None


class ProprietarySourceConfig(BaseModel):
    """Proprietary source configuration"""
    isSelected: bool
    sources: List[str] = Field(default_factory=list)


class ThirdPartySourceConfig(BaseModel):
    """Third-party source configuration"""
    isSelected: bool
    sources: List[str] = Field(default_factory=list)


class ExternalResearchConfig(BaseModel):
    """External research configuration"""
    isSelected: bool


class ResearchServiceConfig(BaseModel):
    """Configuration for enhanced research service - uses data_source_agent for external sources"""
    isSelected: bool
    type: str = "enhanced_with_research"
    research_topics: Optional[str] = None
    research_guidelines: Optional[str] = None
    pwc_content: PWCContentConfig = Field(default_factory=lambda: PWCContentConfig(isSelected=False))
    proprietary: ProprietarySourceConfig = Field(default_factory=lambda: ProprietarySourceConfig(isSelected=False))
    thirdParty: ThirdPartySourceConfig = Field(default_factory=lambda: ThirdPartySourceConfig(isSelected=False))
    externalResearch: ExternalResearchConfig = Field(default_factory=lambda: ExternalResearchConfig(isSelected=False))


class SuggestionsServiceConfig(BaseModel):
    """Configuration for improvement suggestions service"""
    isSelected: bool
    type: str = "improvement_suggestions"
    suggestion_type: Optional[str] = "general"


class EditServiceConfig(BaseModel):
    """Configuration for content editing service"""
    isSelected: bool
    type: str = "edit_content"
    editors: List[str] = Field(default_factory=list)


class RefineContentRequest(BaseModel):
    """Complete request schema for refine content workflow"""
    messages: List[dict[str, Any]] = Field(default_factory=list)
    original_content: str
    services: List[dict[str, Any]]
    stream: bool = True
