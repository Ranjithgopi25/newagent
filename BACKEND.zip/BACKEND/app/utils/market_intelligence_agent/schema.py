from typing import Dict, List, Callable, Annotated
from pydantic import BaseModel, Field

class ResearchSignals(BaseModel):
    facts: List[str] = Field(default_factory=list)
    statistics: List[str] = Field(default_factory=list)
    trends: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    opportunities: List[str] = Field(default_factory=list)
    citations: List[str] = Field(default_factory=list)

def merge_tool_results(
    left: Dict[str, Dict[str, ResearchSignals]],
    right: Dict[str, Dict[str, ResearchSignals]],
) -> Dict[str, Dict[str, ResearchSignals]]:
    merged = dict(left)
    for area, tools in right.items():
        merged.setdefault(area, {})
        merged[area].update(tools)
    return merged


class GraphState(BaseModel):
    input: dict

    tool_results: Annotated[
        Dict[str, Dict[str, ResearchSignals]],
        merge_tool_results
    ] = Field(default_factory=dict)
